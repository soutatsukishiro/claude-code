# v5: sun, sky glow, clouds, horizon and fog rebuild (2026-10-04)

Scope: the sun and moon glow and rays, cloud lighting, the horizon blend and the fog
gradient. The following were not modified:
- the shadow system;
- water shading;
- caustics;
- plastic gloss;
- materials;
- vegetation;
- bloom code;
- color grading;
- particles;
- entities.

The exceptions are listed under "Changes outside the scope".

Backup of everything before this round: `backup/2026-10-04_before_sun_rebuild/` (the whole
`shaders` folder and the README).

Status:
- **Measured:** WebGL2 compile and link of every program in 62 option sets (496 programs, 0
  failures), and a WebGL2 render of the new sky/sun/cloud/fog math compared against your
  screenshots.
- **Not tested:** nothing has run inside Minecraft yet.
- **Estimates:** all performance numbers below are estimates.

---

## 1. Capability check

- I have **no screen capture of the Minecraft window** in this session.
  - The browser pane I have was used only to compile the shaders and render the sky math in
    WebGL2.
  - I captured nothing from the game and kept nothing else.
- Your three images were sampled pixel by pixel (exact values, from the copies the app saved).
  The numbers below are real samples, not estimates by eye.
- Iris 1.11.7 / Minecraft 26.3 facts used below were read from the jars in your profile:
  - `sun=false` exists (PackDirectives.shouldRenderSun);
  - the sky render stages exist (MixinSkyRenderer: SKY, SUNSET, STARS, VOID, SUN, MOON);
  - the explicit colortex clear colour exists;
  - the vanilla sun quad is 30/100;
  - sun.png is 32 x 32 with the bright 8 x 8 square in the middle;
  - the vanilla ring colours are #FFD54A / #FFFFAA / #FFFFD9.

## 2. The references and your current state (measured)

**CURRENT (image 1)**
| Element | Measured | Comment |
|---|---|---|
| Sky top | #5D78A3 | grey-blue, ~25 % darker than the palette (#7F9FDC): the old "palette minus approximated vanilla dome" left the approximation error in the sky |
| Sky just above the horizon | #677992 … #7F8FA6 | |
| Band below the horizon | #9D9696 … #ACA2A3, beige-pink | hard one-row step #7B8EA5 → #ABA5A2 at the horizon |
| Sun | flat #BFBFBF (SD 0 over 40 x 40 px) | no glow: 2 px outside it is already sky (#8AA0B4) |
| Cloud body | #8E95A7 / #878E9E | grey, opaque look |
| Ray blotches | #909FB9 / #959DB1, luma SD 5.0–6.4 | flat sky has SD 0.8–2.1: this is the grain |
| Blotch below the horizon | #AFA6A5, SD 4.6 | the fog brightened by the noisy ray mask |

Your analysis is correct. What else I see:
- The blotches continue onto the band below the horizon (the old fog was brightened inside the
  ray mask).
- The band is far water/terrain fogged with the old warm "near fog" colour, not the sky
  colour.
- The clouds have no face structure (top, side and underside look the same).

**TARGET 1 (clouds, sky, haze)**: corrections to your estimates.
| Element | Your estimate | Measured | Note |
|---|---|---|---|
| Sky top | #6593EE | **#6596EE** (#6594EF…#6292ED, slightly darker at mid height) | |
| Horizon | #A5B8EE | **#A3B8EC** | |
| Cloud upper body | #A9B3EE | **#A1B0ED** | darkens toward the base: #8DA1E6 |
| Cloud light edge | #C8D0F8 | **#AAB4F2 / #ABB5F4** | thin side faces seen edge-on |
| Cloud underside | #98A4E6 | **#829BE5** | |
| Distant terrain | – | #889BCB | |

All cloud values are cloud plus sky behind it. I reproduce them as composites at opacity 0.65
(side faces 0.75).

Other observations:
- The far clouds are almost only their light outlines, because their bodies fade into the sky.
- Flat-sky grain is luma SD 0.56–0.85 (image compression).

**TARGET 2 (sun)**
| Element | Measured |
|---|---|
| Sun centre | **#FFFFFE**: overexposed white, not #FFFBE6. The square is rotated a few degrees on screen (its edges follow the sun path, like the vanilla quad). Half size about 44 px. |
| Glow profile above the top edge (R channel over the sky) | +60 at 8 px, +38 at 16, +27 at 24, +21 at 32, +16 at 40, +12 at 48, +8 at 64, +2 at 104, +1 at 150. Monotonic, so no 8-bit rings in my samples. |
| Glow colour | a mix toward a warm white of about #FFF7F0. Blue does not rise, so it is a mix, not an addition. |
| Sky around | #6998F3 … #6A9BF3 |
| Block in front of the sun | Hides it, but its face inside the sun disc area is strongly lifted (#E8E2DB → #D0C7AA → #A39681 fading down over about 50 px). The rim along the edge nearest the sun is warm beige to yellow (#E8E4D1 → #D9D0A8 → #D1C391), less saturated than #E8C060. |

## 3. Gap table

| Element | Current | Target | Responsible (old → new) |
|---|---|---|---|
| Ray appearance | grainy blue blotches | no rays, only a gentle uniform radiance | composite ATMOSPHERIC_RAYS → removed; analytic ray lobes in the glow (ambience.glsl `ambCelestialGlow`) |
| Grain | SD 5–6.4 | about 0.4 (invisible dither) | per-pixel random jitter → none; static IGN dither in final |
| Edge quality / upsampling | quarter-res, unfiltered pattern, 4x upscale | full-res analytic | colortex5 rays → none |
| Sun disc | flat #BFBFBF, hole/second disc in some presets | one bright square, #FFFBE6, vanilla size | SUN_STYLE/GOLDEN_SUN_GLOW/ORB → `ambSunDisc` + `sun=false` |
| Sun bloom | none | thin bloom hugging the square | → core term (square distance) |
| Wide halo | screen-space, FOV dependent | very faint, circular | CELESTIAL_GLOW → `ambHaze` halo (angle based) |
| Occlusion | rays leak, blotches around edges | block hides sun, glow only on sky | → glow only on sky pixels; veil × visibility V |
| Warm edge rim | none | thin warm rim on the edge nearest the sun | → final `SUN_EDGE_RIM` (2 depth taps toward the sun) |
| Cloud colour / translucency | grey #8E95A7, over the vanilla sky | lavender, translucent over the palette sky | gbuffers_clouds rewrite + gbuffers_skybasic |
| Cloud outline | none | light side faces | → lighter, denser side faces |
| Cloud underside | same as body | #829BE5 | → derived underside colour |
| Sky gradient | #5D78A3 grey | #6596EE → #A3B8EC | palette rows + `ambSkyGradient` (fitted curve) |
| Horizon match | hard step, beige band | no line | fog colour = `ambienceSky(view dir)` |
| Fog colour | warm near colour ≠ sky | = sky behind | `ambienceFog` |
| Fog gradient | closed form (kept), blocky banks | smooth banks | `ambFogBank` smooth value noise |

## 4. Code review of the old ray, glow, sky, cloud and fog code

| # | File / function | Problem | Severity | Fix |
|---|---|---|---|---|
| 1 | composite.fsh, ATMOSPHERIC_RAYS | Random per-pixel jitter `cheapHash(gl_FragCoord + floor(frameTimeCounter*6))`, re-rolled 6 times a second, 8–12 samples, no accumulation: **grain and 6 Hz crawl** | critical | removed |
| 2 | same | Hard `step(0.99995, depth)` on every tap, then `4·o·(1−o)`, which peaks at partial openings: **bright bands exactly around cloud and leaf edges (the blotches)**. Clouds counted as occluders. | high | removed |
| 3 | same + final | Quarter-res colortex5 enlarged 4x with plain bilinear, no depth awareness: **blocky grain and light bleeding over silhouettes** | high | removed (no ray data in colortex5) |
| 4 | composite `shadowVisibility` | **The rays read the shadow map** (shadowtex0, hard step) per pixel | rule | removed; the shadow system itself is untouched |
| 5 | final, fog | `nearColor *= 1 + rayMask·0.35`: the noisy ray mask brightened the fog (the blotch below the horizon) | high | removed |
| 6 | PIXEL_SNAPPED_RAYS (on in HIGH/CINEMATIC and in your saved options) | 4 levels on an 8-px grid: stepped blocks | high | removed |
| 7 | final, sky | Palette sky = vanilla + (palette − approximated vanilla dome); every approximation error, the sunrise fan and tone-map differences stayed in the sky (the darker grey sky, the wrong colour below the horizon) | high | sky rebuilt analytically; only moon and stars come from vanilla |
| 8 | ambience.glsl `ambienceFog` | Fog colour = palette near colour + glow, mixed toward the sky only from 0.2 to 0.9 × render distance: **the beige band and its hard edge** | critical | fog colour = `ambienceSky(view direction)`, the same function as the sky |
| 9 | `ambienceSky` | Below the horizon `horizon × 0.82`: a darker band | medium | horizon colour below the horizon |
| 10 | final, GOLDEN_TARGET_HAZE | Amber haze added on top of the Ambience fog but not to the sky: a band at golden hour | medium | now only on the legacy path (Ambience fog off) |
| 11 | final, SUN_STYLE 1 (default in every preset) | Covered the vanilla square's centre with the sky colour using a screen-space size (FOV and aspect dependent): **a hole plus a round disc** | high | `sun=false` + one analytic sun |
| 12 | final, GOLDEN_SUN_GLOW | A second screen-space square core at golden hour (**double sun**), glow quantized to 8 levels on a 12-px grid (**stepped rings**) | high | removed |
| 13 | final, SECONDARY_GOLDEN_ORB | A second disc near the sun | medium | removed |
| 14 | final, CELESTIAL_GLOW | Halo in screen UV (distorts with FOV and aspect), **pops** when the sun crosses the camera plane (`vSunUV = −2`) | medium | removed; the glow is angle-based in world space |
| 15 | Glow stacking | Rays + CELESTIAL_GLOW + GOLDEN_SUN_GLOW + fog phase + golden haze phase + bloom of the sun: 4–6 stacked glows | medium | one glow model |
| 16 | `ambFogBank` quality 1 | One hash per 48-block cell, no interpolation: **hard density steps** in the haze | medium | smooth value noise (quality 1 = 1 sample, 2 = 2 octaves) |
| 17 | `ambFogBank` drift | Linear in frameTimeCounter: jumps when it wraps (every hour) | low | circular drift that closes exactly at the wrap |
| 18 | gbuffers_clouds | Opacity 0.8 over the **vanilla** sky (not the palette): grey and opaque, wrong colour through the clouds | medium | sky-derived colours, 0.65 opacity, blended over the palette sky written by gbuffers_skybasic |
| 19 | final dither | Bayer 4x4, only with the Ambience colours | low | static triangular IGN dither (SKY_DITHER) |
| 20 | Math | `atan(0,0)` and normalizing zero vectors: guarded. Sun behind the camera: everything is angle-based now. Off-screen sun: the glow comes from the angle, and the veil fades with a smoothstep. | – | done |
| 21 | Buffers | colortex0 RGBA16F (no 8-bit banding before final), colortex5 RGBA16F, colortex1 RGBA8 (markers only) | ok | unchanged |
| 22 | Settings | ATMOS_RAY_*, PIXEL_RAY_GRID, PIXEL_SNAPPED_RAYS, GOLDEN_RAY_BOOST, GOLDEN_GLOW_* lived in every preset; `program.composite.enabled` depended on ATMOSPHERIC_RAYS | – | removed; composite condition updated |

**What made the grain and the blotches:** items 1 to 3, made worse by 5 and 6. Random
per-pixel jitter re-rolled 6 times a second, sampled with hard depth steps whose response
peaks at partial occlusion (the cloud edges). It was computed at quarter resolution and
enlarged 4x with no filtering or depth awareness. The noisy result then brightened the fog
below the horizon.

## 5. Design note: why the new system cannot produce those artifacts

### One sky colour function
`ambienceSky(dir)` combines four smooth terms:
- a vertical gradient fitted to target 1;
- the golden-hour tint;
- the wide halo;
- the haze sun scattering.

These parts all call it with the real view direction:
- the sky pixels;
- the fog at every distance;
- the clouds' distance haze;
- the sky behind translucent clouds;
- the water's Tier-1 reflection.

Terrain at the fog end is therefore exactly the colour of the sky behind it, and there is no
line by construction. The synthetic render shows no step at the ground/sky boundary: the
colour holds at #AFC2F6/#AFC2F7 from 4 px above to 10 px below the horizon, then ramps
smoothly into the ground.

### Sun and glow (zero texture fetches)
- **Sun disc.** The vanilla quad is disabled (`sun=false`). The analytic square is drawn with
  exactly the vanilla size and orientation:
  - the gnomonic projection on the quad plane;
  - half size 0.075 from the 26.3 SkyRenderer and sun.png;
  - the vanilla pixel rings, lifted: #FFF2C2 / #FFFADB / #FFFBE6;
  - one-pixel anti-aliased edges.

  There is one sun only. SUN_STYLE 1 is a soft round disc of the same area.
- **Glow.** It is fitted to target 2:
  - a thin bloom 0.47·exp(−d/0.125h) that hugs the square;
  - a round mid glow 0.37·exp(−d/0.65h);
  - a very faint wide halo (SUN_HALO_STRENGTH 0.10, falloff SUN_HALO_SIZE).

  These are smooth exponentials of the angle: never stepped, never quantized, with no
  screen-space or FOV dependence. They stay correct off-screen and behind the camera.
- **Rays.** The mid glow is multiplied by `1 + RAY_VARIATION × lobes`:
  - 7 + 11 smooth cosine lobes;
  - integer counts, so there is no seam;
  - rotation rates that repeat exactly when frameTimeCounter wraps;
  - faded out near the disc, where the lobes would get thin.

  No noise, no hash.
- **Occlusion of the glow.** It is drawn only on sky pixels. Translucent clouds show it by
  their transparency, so a cloud crossing the sun dims it smoothly.

### Veil and rim (the only sampling)
- **Sun visibility V.** It averages 9/13/21/29 fixed taps in rings inside the sun square. It
  runs in final.vsh, once per vertex, so a few dozen fetches per frame in total. Open sky
  counts 1 and a cloud counts its transparency. There are no random offsets.
- **Veil.** `VEIL_STRENGTH × V × screen fade × falloff(angle) × (1 − exp(−distance/6))`, mixed
  toward the warm glow colour. It is analytic per pixel: no blur, no buffer.
- **Rim.** Two depth taps 1.5 and 3.5 px toward the sun's screen position. Only the edge
  nearest the sun gets a thin warm line, and only right around the sun.

### Fog
- Closed-form height fog (kept): exactly the same density, clear zone and render-distance
  ramp as v4.
- The colour is the sky function.
- Banks are smooth value noise.
- Under cloud shadows the near haze is slightly darker. That effect is gone by the far end.

### Dither
Static triangular IGN at SKY_DITHER/255 before the 8-bit output. It has no frame input, so
there is no crawl. Measured flat-sky luma SD is 0.36–0.41, below the JPEG grain of your
references (0.42–0.85).

### What it cannot do
- True light shafts through leaves. They would need the shadow map or a radial blur.
- A cleaner future option, not implemented, as you asked: a quarter-resolution radial blur
  with a fixed 12-tap pattern on a smooth sky mask, a 4-tap bilateral upsample and a cone fade.
  I would only add that with your approval.
- Temporal smoothing of V: there is no history buffer that is safe to read and write. V
  changes by at most 1/N of the veil when an edge crosses a tap. That only happens while the
  camera or the sun moves, never as flicker, and the higher tap counts make the steps finer.

### Estimated cost (GTX 1050 Ti, 1080p, LOW)
| Part | Estimate |
|---|---|
| Removed ray pass | about −0.10 to −0.15 ms |
| gbuffers_skybasic | +0.03–0.05 ms |
| Sky in final | ≈ the old sky + glow code |
| Fog colour via the sky function | +0.03–0.04 ms |
| Smooth banks (MEDIUM+) | +0.01–0.02 ms |
| Veil | +0.02 ms |
| Rim | < 0.01 ms (only near the sun) |
| V taps | < 0.005 ms |
| Cloud shading | +0.01–0.02 ms |

- **Feature total:** about 0.20–0.30 ms on LOW and about 0.10–0.15 ms on an RTX 3050 (MEDIUM).
- **Net:** roughly neutral or slightly faster than before, because the ray pass is gone.
- **Status:** none of these numbers were measured.

## 6. Synthetic render vs your screenshots (WebGL2, the shader math only, not the game)

Rendered at target 2's scale: 784 x 566, FOV 51.5°, which gives the same 44 px sun half size.

| Quantity | Render | Target |
|---|---|---|
| Sun centre | #FFFBE6 | #FFFFFE (overexposed); spec #FFFBE6 |
| Glow profile ΔR at 8/16/24/32/40/48/64/104/150 px | 59/38/27/22/16/13/9/3/1 | 60/38/27/21/16/12/8/2/1 |
| Sky far from the sun | #6596EE | #6998F3 … #6A9BF3 |
| Flat-sky luma SD, with dither | 0.41 | 0.42–0.80 |
| Sky column top → horizon (FOV 70, horizon at the bottom) | #6596EE … #6593ED … #8AAAEF … #A5B9F0 | #6594EF … #6895EA … #8AA6EA … #A3B8EC |
| Cloud upper body / side face / side base / underside | #A0B1EE / #ACB6EE / #90A2E6 / #829BE4 | #A1B0ED / #AAB4F2 / #8DA1E6 / #829BE5 |
| Sunset sun / glow | #FFD490 / #FFC896 | (no reference) |

The game adds its own steps:
- the real cloud mesh;
- vignette and grading;
- Minecraft's actual FOV.

Expect small differences there.

## 7. Files

| File | Status |
|---|---|
| `shaders/lib/settings.glsl` | changed: options removed and added, forcing block for SUN_DEBUG, internal AMB_SUN_VISIBILITY |
| `shaders/lib/ambience.glsl` | changed: one sky function, analytic sun and glow, sky-derived cloud colours, fog colour, smooth banks, dither. Cloud-shadow code and terrain response byte-identical. |
| `shaders/gbuffers_skybasic.vsh/.fsh` | **new** (a sky program in the existing gbuffer stage, not a new pass) |
| `shaders/gbuffers_clouds.vsh/.fsh` | rewritten (lighting only; geometry and motion untouched) |
| `shaders/composite.fsh` | changed: rays removed (bloom, shallow-water shafts, pollen untouched) |
| `shaders/final.vsh` | changed: sun visibility taps |
| `shaders/final.fsh` | changed: sky rebuild, fog call, veil and rim, debug, dither. SSR water code unchanged. |
| `shaders/shaders.properties` | regenerated: `sun=false`, programs, cloud blend, screens, sliders, presets |
| `shaders/lang/en_us.lang` | labels |
| shadow.vsh, shadow.fsh, lib/shadow_distortion.glsl | **unchanged** (shadow system) |
| gbuffers_water.*, gbuffers_terrain.*, gbuffers_textured_lit.*, lib/gbuffers.vsh, lib/gbuffers_forward.fsh, lib/water_reflection.glsl, composite.vsh, block.properties, textures/clouds.png | **unchanged** |

### Changes outside the scope (unavoidable)
- **Bloom.** The code is unchanged, but its input changed:
  - the vanilla sun is no longer in colortex0, replaced by the analytic sun with its own thin
    bloom (the composite bloom still sees the analytic sun);
  - the sky behind is the palette sky instead of the vanilla sky.
- **Water.** No water code changed, but water picks up the new sky:
  - the Tier-1 reflection calls the same sky function, so it reflects the new cornflower sky
    and the new cloud colours;
  - the screen-space reflection sees the palette sky in colortex0;
  - far water gets the new fog colour (that is the fix for the band; FOG_ON_WATER still works
    as before).
- **Tone curve.** The existing shoulder is now skipped on sky and cloud pixels. They are
  composed directly in display colours, so the sky seen through a cloud matches the sky beside
  it.

## 8. Options

**Removed** (old rays and old sun glows):
- ATMOSPHERIC_RAYS
- GOLDEN_TARGET_RAYS
- PIXEL_SNAPPED_RAYS
- ATMOS_RAY_INTENSITY
- ATMOS_RAY_SOFTNESS
- ATMOS_RAY_LENGTH
- ATMOS_RAY_SAMPLES
- PIXEL_RAY_GRID
- GOLDEN_RAY_BOOST
- CELESTIAL_GLOW
- CELESTIAL_GLOW_STRENGTH
- CELESTIAL_GLOW_RADIUS
- GOLDEN_SUN_GLOW
- GOLDEN_GLOW_STRENGTH
- GOLDEN_GLOW_PIXEL_SIZE
- GOLDEN_GLOW_BLOCKINESS
- GOLDEN_GLOW_LEVELS
- GOLDEN_SUN_CORE_SIZE
- GOLDEN_BAND_STRENGTH
- GOLDEN_CROSS_STRENGTH
- SECONDARY_GOLDEN_ORB
- SECONDARY_ORB_STRENGTH
- SECONDARY_ORB_SIZE
- SUN_DISC_SIZE
- ENV_SKY_PALETTE: the sky is now always the one function, so a blend toward vanilla would break
  the cloud and fog match.

**Reused:**
- SUN_STYLE: 0 = vanilla square (new default), 1 = soft round.
- CLOUD_OPACITY: default 0.65.
- FOG_* (unchanged meaning; FOG_BANK_STRENGTH default 0.30).

**New:**
- SUN_GLOW
- SUN_RAYS
- SUN_VEIL
- SUN_EDGE_RIM
- SUN_DEBUG
- SUN_GLOW_STRENGTH
- SUN_HALO_SIZE
- SUN_HALO_STRENGTH
- RAY_VARIATION
- VEIL_STRENGTH
- EDGE_RIM_STRENGTH
- SUN_VISIBILITY_TAPS
- SKY_DITHER
- CLOUD_BRIGHTNESS
- CLOUD_EDGE_HIGHLIGHT
- CLOUD_UNDERSIDE_DARKNESS
- CLOUD_SUN_LIGHT
- SUN_DEBUG_MODE

**Menu:** Ambience → **Sun and Sky Glow** (new), plus the cloud and fog sliders in Clouds / Fog.
The old "Light Shafts" screen is now "Pollen and Birds".

**Presets** (all 194 options explicit in each preset):
| Preset | Glow + rays | Veil | Rim | V taps | Sun scatter | Banks | Cloud lighting |
|---|---|---|---|---|---|---|---|
| ULTRA LOW | on | off | off | (9) | off | off | vanilla colours over the palette sky |
| LOW | on | on | on | 9 | on | off | on |
| MEDIUM | on | on | on | 13 | on | 1 smooth | on |
| HIGH | on | on | on | 21 | on | 2 octaves | on |
| CINEMATIC | on | on | on | 29 | on | 2 octaves | on |

**Other leftovers I noticed** in shaders.properties (reported only; nothing rewritten):
- GOLDEN_BLOCKY_BLOOM pixelates the bloom source (blocky bloom around bright things).
- ATMOSPHERIC_PARTICLES and GOLDEN_FAKE_BIRDS are screen-space.
- RAY_INTENSITY/RAY_LENGTH are the shallow-water shafts, not sun rays (the names are confusing).
- SKY_GRADE, SKY_GRADIENT_STRENGTH, ATMOSPHERIC_HAZE, HAZE_*, HORIZON_BLEND and
  GOLDEN_TARGET_HAZE now only matter when the Ambience colours or fog are off, or in the Nether
  and the End.
- ATMOS_DEBUG mode 2, VV_DEBUG mode 2 and TARGET_DEBUG modes 2 and 6 (old ray/glow views) show
  black.

## 9. Pass order

1. **shadow** (unchanged)
2. **gbuffers**, in order:
   - **skybasic** (new): palette sky, glow and analytic sun into colortex0. Vanilla stars are
     kept at night; the sunrise fan and the void disc are dropped.
   - the vanilla moon (Iris default program).
   - terrain, entities and the hand (unchanged).
   - **clouds**: translucent over the palette sky, marker in colortex1.
   - **water** (unchanged).
3. **composite** (quarter resolution): bloom, shallow-water shafts and pollen into
   colortex5.rgb.
4. **final**, in order:
   - SSR (unchanged);
   - bloom added;
   - tone curve (skipped on sky and cloud pixels);
   - **sky rebuilt** on sky pixels (the same function, plus the moon and stars from vanilla);
   - **fog, once** (terrain and water; never sky or clouds);
   - **veil + rim**;
   - grading, vignette;
   - debug;
   - **dither**;
   - output.

No pass reads a buffer it writes.

## 10. Artifact test plan (please run in game)

| # | Test | How to check | Expected |
|---|---|---|---|
| 1 | Sun at midday | Look at the sun. Also check SUN_DEBUG 16 (banding test). | No grain, no blotches. In SUN_DEBUG 16 the sky turns into fine grain, not wide stripes. |
| 2 | Turn 360° with the sun entering and leaving the view | Watch the glow and veil. | No pops, no flicker. |
| 3 | Sun partly behind a block, a trunk, leaves, a cloud | Watch the glow edge. Check SUN_DEBUG 6, 7, 8. | No glow over the block. Thin warm rim on the edge nearest the sun. SUN_DEBUG 6 (V) changes smoothly; 7 (veil) is smooth; 8 shows the rim only. |
| 4 | Sun at and just past the screen edge | Watch the glow and veil. | Continuous. |
| 5 | Facing away from the sun | Look for a glow. | Nothing. |
| 6 | Cloud crossing the sun | Watch the sun and glow. | The sun and glow dim by the cloud's transparency. |
| 7 | 720p / 1080p / 1440p / 4K, GUI scales | Compare the sun. | Same sun size relative to the screen, crisp edges. |
| 8 | FOV 30–110 | Watch the sun shape. | The square stays a square (gnomonic, like vanilla). |
| 9 | Sunrise and sunset | Look at the horizon. Check SUN_DEBUG 10. | No band. SUN_DEBUG 10 is black at the horizon. |
| 10 | Rain, thunder, night, underwater, Nether, End | Check each. | Rain and thunder: glow and sun fade, grey fog. Night: a small cool moon glow. Underwater: disabled (vanilla underwater look). Nether and End: unchanged vanilla-like fog, no glow. |
| 11 | Speed | F3 FPS on LOW vs v4. | The same or better (estimate). |
| 12 | Far from spawn, cloud height and above | Check clouds, fog, sky. | Wrapped coordinates; clouds stay translucent over terrain when seen from above. |

**Screenshots I need** (F1, same world, coordinates, FOV, render distance and resolution, before
and after):
- noon, 45° up at the sun;
- the horizon with the sun in view;
- a cloud field;
- the sun behind a block;
- distant terrain at the horizon;
- sunrise and sunset;
- SUN_DEBUG 6, 10 and 16.

## 11. Things I could not verify in Iris

1. **Iris stage numbers in `gbuffers_skybasic`.** The code uses Iris's stage numbers
   (MC_RENDER_STAGE_*) to keep the stars and drop the sunrise fan.
   - If the vanilla stars disappear, those numbers did not arrive. The procedural stars still
     show.
   - If the whole sky looks vanilla, skybasic did not run. Send `latest.log`.
2. **Moon and stars near the horizon.** Below about 2° above the horizon, colortex0 holds the
   vanilla clear colour, so the moon and stars are not kept there. They fade into the haze
   instead.
3. **Cloud colours.** They were fitted against target 1 assuming the faces the cloud mesh
   produces. The real mesh may need small tuning (CLOUD_EDGE_HIGHLIGHT,
   CLOUD_UNDERSIDE_DARKNESS).
4. **Tall peaks above y=192.** A peak behind a cloud is seen through it normally. No issue
   expected.

## 12. Tuning tips

| Goal | Change |
|---|---|
| Softer rays | RAY_VARIATION 0.06 |
| No rays at all | RAY_VARIATION 0.00, or SUN_RAYS off |
| Bigger halo | SUN_HALO_SIZE 0.40–0.55, SUN_HALO_STRENGTH 0.20 |
| Less glow | SUN_GLOW_STRENGTH 0.50–0.75 |
| Stronger veil over blocks (like the face of the block in target 2) | VEIL_STRENGTH 0.45–0.60 |
| No veil or rim | turn SUN_VEIL or SUN_EDGE_RIM off |
| Less fog | FOG_DENSITY 0.006, or FOG_START 48 |
| Fog only far away | FOG_END stays 1.00, FOG_START 64 |
| More lavender clouds | CLOUD_BRIGHTNESS 1.10 + ENV_LAVENDER 1.50 |
| More translucent clouds | CLOUD_OPACITY 0.50 |
| Stronger outlines | CLOUD_EDGE_HIGHLIGHT 0.75–1.00 |
| Darker undersides | CLOUD_UNDERSIDE_DARKNESS 0.70 |
| Turn the dither off to test | SKY_DITHER 0.00 (then SUN_DEBUG 16 shows the raw 8-bit steps) |
| Round sun | SUN_STYLE 1 |

## 13. Questions for you

1. **How strong should the veil be?** Target 2 shows the face of the block inside the sun disc
   strongly lifted (#E8E2DB), while your text asks for no glow on the face. I chose a moderate
   veil (0.30). Should it be stronger?
2. **Pure white sun or #FFFBE6?** Target 2's sun is pure overexposed white; your spec says
   #FFFBE6 with the vanilla look. I kept #FFFBE6 with faint vanilla pixel rings. Do you want a
   flat white square instead?
