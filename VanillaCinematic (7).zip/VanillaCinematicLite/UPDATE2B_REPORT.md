# Update 2B: block lighting (report)

Two related changes to how blocks are lit, nothing else redesigned:

- **A. Directional face lighting** (`DIRECTIONAL_LIGHTING`): the face of a block turned to the sun (the
  moon at night) is brighter, faces turned away get only the sky ambient.
- **B. Micro-detail lighting** (`BLOCK_MICRO_DETAIL` and four group toggles): on selected blocks only
  small details catch the light (sand grains, obsidian speckles, lit leaf texels, farmland furrows,
  ice glints), derived from the vanilla texture. It replaces the plastic gloss on blocks.

Backup of everything before this update: `backup/2026-10-05_before_update2b/` (the whole `shaders/`
folder, README.md, UPDATE2A_REPORT.md).

"Measured" below means measured with the pack's real programs (terrain, water, entities, sky,
composite, final) in a WebGL test harness on the vanilla 26.3 textures, or measured in your three
screenshots. "Estimate" means not measured. Nothing was run in Minecraft.

## 1. Capability check

I have no screen capture or computer-use tool that can see the Minecraft window in this session, so
I captured nothing from the game. Instead I read the 26.3 client jar and the Iris 1.11.7 jar,
measured your three screenshots and 171 vanilla textures, and rendered test scenes with the pack's
own programs in a browser harness. The screenshot list I need from you is in section 11 (your rules:
ask first, Minecraft window only, keep nothing else).

## 2. Your three screenshots (measured)

All values are 8-bit sRGB averages; L = luminance (0-255).

| | Region | Measured | Your estimate |
|---|---|---|---|
| Image 1 (obsidian on snow) | sunlit face (the narrow left face) | #3C4258, L 66 (upper) / #3A3F52, L 63 (lower) | about #25253F base, speckles #4A4A86 |
| | face turned away (the wide front face) | #222943, L 41 / #24293F, L 42 | about #1E1E38 |
| | ratio lit / away | **1.58** | 1.3 to 1.5 |
| | speckle spread, p98 / median | lit 1.28, away 1.54 | "more speckle contrast on the lit face" |
| | snow lit / in the pillar's shadow | #A4B1E3 / #6C8EC6 (shadow at 0.78 of the lit snow) | |
| Image 2 (swamp tree) | canopy top / front side / left side / underside | #486371 L 94 / #466064 L 91 / #3C586B L 84 / #314A56 L 69 | |
| | lit leaf texels / shaded leaf texels | #537474 to #608783 / #21353C to #30464B | #4E8F88 / #2D4E52 |
| | bark, vines | #322E28 L 46, #4A6468 L 95 | |
| Image 3 (dark pillar) | face, top to bottom | mean L 104 at the top, smoothly down to L 55 at the bottom | upper speckles, darker lower part |
| | bright speckles | #A0B0E8 (sky coloured), 22 % of the pixels of the top block only, ending exactly at a block edge | about #8A8A98 |
| | lower blocks | #393B4D, L 60 | about #2E2E3C |

What this tells me:

- **Image 1:** the lit face is 1.58 x the face turned away. The lit face does not have more speckle
  contrast: relative to its own brightness it has less (it is seen at a grazing angle, so its texels
  are minified, and the light lifts the dark texels too). The away face is cool blue-grey, not black.
- **Image 2:** top 1.36 x the underside; the sides sit in between (the sun hits both visible sides
  partly). The light bits in the canopy (#94A3D9) are sky seen through leaf gaps.
- **Image 3:** the gradient is view-dependent, not sun angle or sky light. A flat face has one N.L
  for the sun, and sky light changes in steps per block, not smoothly along a face. The camera is
  low and looks up, so the upper part is seen at a more grazing angle, where a sky reflection gets
  stronger (Fresnel). The bright speckles have the sky's colour, so they are a sky reflection on the
  light texels. The hard cut at a block edge means those speckles belong to that block (a different
  block or texture variant, or a per-block value); they are not caused by the sun.
- **Does any of them look like your current result?** Not in block lighting. In my harness the
  current build gives the obsidian pillar a lit/away ratio of 1.06 at a 45-degree sun (section 9),
  and no texel highlights. The sky, the flat lavender-white clouds and the blue snow shadow look like
  the references the pack's sky and clouds were fitted to earlier. I cannot see your game, so this
  comes from the code and the harness.
- **One difference I did not change:** the reference renders dark blocks much brighter and bluer
  (obsidian L 41 to 66). In the harness the pack's obsidian is L 8 to 18, because the vanilla
  obsidian texture is very dark (mean luminance 0.049). That is the reference shader's ambient or
  exposure, not face lighting; matching it would change the whole scene's exposure.

## 3. How blocks were lit before

1. `texel = texture x vertex colour`. The vertex colour carries the biome tint and Sodium's ambient
   occlusion only (see 4.1).
2. `base = texel x vanilla lightmap` (sky light and block light, the same for every face).
3. Cast shadow: `base *= 1 - (1 - shadow) x skyLight x N.L x 0.34`.
4. `DIRECTIONAL_LIGHTING`: `base += base x 0.08 x N.L x shadow x (warm by day, cool by night)`.
5. Colour responses: warm/cool grade, ambience terrain response, shadow colours (all luminance
   preserving tints driven by N.L and the shadow).
6. Highlight: the plastic gloss (specular `x^28 x 0.25` plus Fresnel `0.07`) on everything, plus
   `MATERIAL_RESPONSE` gloss per block group; leaf, golden-hour and thin-block back-lights.
7. Wet ground, emissive, caustics, then fog in final.

So the only differences between faces were the 34 % cast shadow (only on faces turned to the light)
and an 8 % lift: a wall turned away from the sun was as bright as a lit one.

## 4. Code review and diagnosis

### 4.1 Why the faces looked alike

| # | Check | Finding | Severity | Fix |
|---|---|---|---|---|
| a | Vanilla face shading in the vertex colour | Iris 1.11.7 replaces vanilla's per-face shade (top 1.0, north/south 0.8, east/west 0.6, bottom 0.5, `CardinalLighting`) with the top value for every face, because the pack does not set `oldLighting` (Iris: `MixinClientLevel` on `CardinalLighting.byFace` returns UP when `shouldDisableDirectionalShading()`, which is `!oldLighting`, default false; checked in both jars). The vertex colour therefore holds tint and AO only: no shading at all, so nothing is applied twice. | High (root cause) | Face lighting done in the shader (change A), on the sky-lit part of the lightmap. |
| b | Is N.L used? | Only to scale the cast shadow and the 8 % lift. A face turned away (N.L = 0) gets neither, so it is as bright as a lit face. | High | Direct term with wrap; faces turned away get only the ambient. |
| c | Wrap or minimum light | Effectively a 100 % floor: shaded faces keep the full vanilla light. | High | `SHADE_FLOOR` 0.45 as the real minimum. |
| d | Lightmap or sky light dominating | Yes: the vanilla lightmap lights every face the same. | High | The face factor multiplies its sky-lit share. |
| e | `DIRECTIONAL_LIGHTING`, `DIRECTIONAL_LIGHT_STRENGTH` | They work but give at most +8 %; off in ULTRA LOW; they also lifted water, the player, mobs and particles. | Medium | `DIRECTIONAL_LIGHTING` is now the face lighting. The old lift moved to `PREVIOUS_SUN_LIFT` (set as before per preset) so water and entities are unchanged. |
| f | Normals | Correct: `vNormalView = normalize(gl_NormalMatrix x gl_Normal)`, `vWorldNormal = mat3(gbufferModelViewInverse) x vNormalView` (world space), normalized again per pixel, constant per face. Leaves are cubes with real normals. Cross-shaped plants have sideways diagonal normals on both sides, so N.L lighting would give them dark backs. | Info | Plants use an up-blended normal (`PLANT_NORMAL_UP_BLEND`). |
| g | Shadow on faces turned away | Not darkened twice, because they were never darkened. But a cast shadow made a sun-facing face darker than a face turned away (measured 0.76 in a full shadow), which is inconsistent. | Medium | The shadow now only scales the direct term: in a full shadow both faces are equal (measured 1.00). |

### 4.2 Plastic and material leftovers

| File / place | Finding | Severity | Action |
|---|---|---|---|
| `lib/gbuffers_forward.fsh`, `shadeFragment` highlight | Plastic gloss (`GLOSS_STRENGTH` 0.25, `HIGHLIGHT_SIZE` 28, `GLOSS_FRESNEL` 0.07) on every surface, blocks included, in every preset. | High (requested) | Removed on blocks (terrain program and the non-water part of the translucent program). The player, mobs, items and particles keep it; so does the water's low-preset gloss. |
| same, `#ifdef MATERIAL_RESPONSE` | Group gloss on blocks: earth 0.10, stone 0.30, masonry 0.48, metal 0.76 + 0.30, glass/ice 0.58, plus Fresnel up to 0.32. Contributed exactly 0 to entities and water (their class is 0 or 1). | High (requested) | Code and the options `MATERIAL_RESPONSE`, `MATERIAL_RESPONSE_STRENGTH` removed. |
| `WET_GROUND` | Uses the plastic specular curve for its rain highlight. | Info | Unchanged (you asked not to change the wet ground). |

### 4.3 Block ID plumbing

- **How IDs arrive:** `block.properties` -> `mc_Entity.x`. On Sodium terrain Iris decodes it as
  `int(mc_Entity >> 1) - 1`, so unmapped blocks read -1 (checked in Iris's `SodiumTransformer`).
- **What reads them:** water detection (1), leaf back-light (2), thin-block back-light (3, 8), shadow
  colour surface response (4 earth, 5 and 6 stone), emissive blocks (9), the VV material debug view.
- **New encoding:** micro-detail blocks get `1000 + 10 x material + class`, where class is the ID the
  block had before (0 = unlisted). The vertex shader splits it again, so every system above sees
  exactly the class it saw before. Proven: the terrain with both 2B features off is bit-identical to
  the old build with its block gloss off (section 9).
- **Unmapped and modded blocks:** keep their old value, material 0, so they get the face lighting
  only.
- **Block entities** (chests, signs, beds, banners, skulls): Iris draws them with `gbuffers_terrain`
  (fallback Block -> Terrain, checked in Iris's `ProgramId`). They get the face lighting with their
  real normals. Their `mc_Entity` value comes from Iris's entity vertex format, which I could not
  verify; unless it happens to be a 1000+ ID they get no micro-detail.

### 4.4 Generic checks

| Check | Result |
|---|---|
| Compile and link | Every preset and 169 option/debug variants, 10 programs each: 1,690 compiled and linked with 0 failures (WebGL2 through ANGLE/Direct3D 11; not a real GL driver). |
| Buffer formats | colortex0 stays RGBA16F. Glints and reflections are limited so no channel passes 1.15 before the tone shoulder (about 1.0 after it): no HDR sparkles for the 8-bit output or the bloom. |
| Pass order | Everything runs in the gbuffers, before fog and rays (final) and before bloom (composite). |
| NaN / Inf / division by zero | Every normalize goes through `inversesqrt(max(dot, eps))`; divisions have floors; smoothstep edges are always increasing (texture spread floor 0.02, lobe at least 0.01 rad). |
| Precision far from the origin | Texel IDs are `cameraPositionInt x 16 + floor(camera-relative position x 16)`: exact integers anywhere; the hash wraps in uint arithmetic. |
| Nether and End | Face lighting and sun/moon glints are multiplied by the existing overworld factor; torch glints stay (lava light is block light). |
| Rain and thunder | Direct light amount `k x (1 - 0.75 rain)(1 - 0.4 thunder)`, the weights the shadow colours already use. The moon uses the Update 2A moon light. |
| Iris option detection | Every new boolean has an `#ifdef` reference. |
| Interpolators | Terrain program: 42 -> 60 components; translucent program: 62 -> 63. GL 3.3 guarantees 64; desktop GPUs give 128. |
| Unused sliders, presets that do nothing | No new unused option. Every preset defines all 279 options. The `program.*.enabled` conditions are unaffected (no new passes). |

### 4.5 Existing issues I noticed (not changed)

1. **Sun/moon switch:** at the horizon Iris switches `shadowLightPosition` and the shadow map from
   the sun to the moon. The previous terms that use N.L x shadow (warm/cool grade, shadow colours, the
   old lift on water and entities) can step on east and west walls at that moment. The new face
   light is 0 on both sides of the switch, so it cannot step. Low.
2. **Warm day tint at night:** `ATMOSPHERIC_GRADE`'s warm "day" tint has no day factor, so at night
   it tints faces turned to the moon (up to +4.5 % red at `WARM_COOL_STRENGTH` 0.10). Fix: multiply
   `directSunMask` by `day`. Low.
3. **Cast shadows at full strength in rain, thunder and at night:** the old darkening had no
   weather or night factor. On blocks the new face light fixes this (the shadow scales the direct
   light). Water and entities keep the old behaviour. Medium.
4. **Stairs, slabs and walls:** they were never listed in `block.properties`, so the shadow colours
   do not give them the stone/earth surface response their full blocks get. I kept that (frozen
   shadow colours). Fix: give the variants their base block's class. Low.
5. **Screen-anchored shadow kernel:** the 4- and 8-tap shadow filter (`SHADOW_QUALITY` 2 and 3)
   shifts its taps by a screen-anchored pattern, so soft shadow edges can crawl slightly in motion.
   Low.
6. **Still open from the Update 2A report:** the warm-biome golden tint at night, and the stale
   debug modes ATMOS 2, VV 2 and TARGET 2/6.

## 5. Design notes

### 5.1 Change A: directional face lighting

```
F = shadeLevel x hemi(N) + kD x visibility x wrap(N.L)        (never below SHADE_FLOOR)
hemi(N)    = mix(0.70, 1.0, N.y x 0.5 + 0.5)                 (sky dome: up 1.0, sides 0.85, down 0.70)
wrap(x)    = max(x, 0) x (1 - WRAP) + WRAP x smoothstep(0, 0.1, x)
k          = direct light amount: sun 1 in clear daylight (fading over its last 4 degrees),
             moon = MOON_FACE_CONTRAST x the Update 2A moon light; x rain and thunder weights
kD         = k x (DIRECTIONAL_LIGHT_STRENGTH + 0.34 x FACE_CONTRAST)
shadeLevel = 1 + k x (0.08 x sunHeight - kD/k x wrap(sunHeight))   (+ AMBIENT_AMOUNT_BIAS x k)
base      *= mix(1, F, skyLight x skyShare x overworld)            (block light and light sources untouched)
```

- **Exposure:** the shade level is chosen so that an unshadowed upward face is exactly as bright as
  before (flat light plus the previous 8 % lift x sun height) at every sun height, so the landscape
  keeps its approved exposure. Measured: sunlit snow L 227.3 vs 226.8 before; snow in a full cast
  shadow L 172.9 vs 175.3. The contrast goes to the walls.
- **Shadows:** in clear daylight a face turned away keeps 0.66 of the flat light, exactly as deep as
  the previous cast shadow on a sun-facing face. The shadow factor only scales the direct term,
  through the same N.L, so nothing is darkened twice. Faces the shadow map never reads (edge-on to
  the light) get no direct light at all, so they cannot glow inside cast shadows.
- **One light at a time:** Iris's `shadowLightPosition` is the sun while it is up and the moon after,
  and k is 0 on both sides of the switch.
- **Colour:** the factor only sets brightness. The existing warm/cool grade, ambience response and
  shadow colours keep tinting the lit and shaded sides as before, so nothing is tinted twice.
- **Torchlight and light sources:** the factor applies only to the share of the lightmap that comes
  from the sky. Quality 2 reads it exactly with one extra lightmap read; quality 1 estimates it.
  Class 9 blocks (torches, lava, glowstone and the like) are never shaded by the sun.
- **Plants:** cross-shaped plants use an up-blended normal, and their shadow is looked up on both
  sides, like the leaves already were.
- **Why artifact-free:** analytic, per face, no textures, no noise, smooth weights only.
- **Cost (estimate):** about 25 ALU per pixel plus one 16 x 16 lightmap read (none at quality 1),
  and about 40 ALU per vertex (light amount, moon light).
- **Cannot do:** real per-texel normals (no normal maps), bounce light from the ground colour, or AO
  beyond what Sodium bakes. Cast shadows still come only from the existing shadow map.

### 5.2 Change B: micro-detail

- **Detail mask D:** the texel's own luminance against the measured mean and standard deviation of
  that block's texture (per material, side and top separately, measured on all 171 textures):
  `D = smoothstep(mean + zlo x std, mean + zhi x std, L)`. Only grains, speckles, lit leaf texels and
  ridges qualify. Far away the mipmaps average them away, so D fades by itself. I chose constants
  over a low-mip read: a low mip of the atlas depends on your mipmap setting and on the sprite size,
  and costs a fetch.
- **Texel ID:** the 16-per-block world grid of the face (top/bottom: x,z; X faces: z,y; Z faces:
  x,y), half a texel inside the block along the normal, with a different seed per face orientation.
  On full blocks, slabs, stairs and snow layers this is exactly the texture's texel grid; the debug
  view shows clean squares. Cross-shaped models (amethyst buds) use the atlas texel plus the block
  position instead, because a world grid cannot line up with a diagonal quad.
- **Glints** (glitter, gloss, leaf wax):
  - one static micro-normal per texel from an integer hash (tilt up to about 60 degrees);
  - the texel glints when its micro-normal points along the half vector of the sun (moon) and the
    view from the texel's centre, so the whole texel square has one state;
  - the half vector is quantized to `GLINT_ANGLE_STEPS`, so glints switch in discrete steps;
  - three levels (off, soft, bright);
  - at most `MAX_GLINT_COVERAGE` of the texels can ever glint.
- **Fades:** footprint (gone once a texel is smaller than about a pixel: no moire or shimmer at
  distance or grazing angles), distance (`GLINT_FADE_START`-`END`), the shadow map and cloud shadow,
  the face facing the light (the same N.L as change A), rain and thunder (through k), indoors (sky
  light), and 0.3 underwater.
- **Sheen** (sheen kinds, foliage, metals): the lighter texels of the lit side get a little more
  light. Half follows the face light, half grows toward the sun's reflection (a soft Blinn-Phong
  lobe). Farmland ridges get a furrow tilt per texel column: the furrow profile measured from the
  texture, run along world x as the vanilla UV mapping puts it.
- **Sky reflection** (gloss kinds): a Fresnel-weighted mix of the palette sky light and the fog
  colour along the reflected view. On ice and glass it covers the face; on obsidian, blackstone,
  basalt, quartz and prismarine it covers only the detail texels (image 3's sky-coloured speckles).
- **Night:** moon light only, cool, scaled by the moon's light (phase, weather, `MOON_LIGHT_INTENSITY`)
  and `MOON_FACE_CONTRAST`.
- **Torches:** tiny warm glints where block light dominates. Block light has no direction, so the
  light is taken from the viewer.
- **Why artifact-free:**
  - the hash is static, so nothing changes over time;
  - glint state depends only on the camera position, quantized;
  - the footprint fade removes everything sub-pixel;
  - no blur, so each highlight is a hard texel square;
  - the limits keep it below the bloom's runaway range.
- **Cost (estimate):** 2 derivatives and about 35 ALU for D and the texel frame; about 40 ALU more on
  the few texels that can glint (a branch); sheen about 15 ALU; reflection about 20 ALU (gloss
  only). No texture reads.
- **Cannot do:** authored PBR (roughness, metalness, per-texel normals or height), anisotropic wood
  highlights, real subsurface scattering, or wetness per block state (only farmland moisture 7 has
  its own ID). Torch glints have no real direction. Stained glass has a uniform texture, so it gets
  no glints.

### 5.3 Performance (estimates; nothing was measured on a GPU)

The browser could not time GPU work here: timer queries never resolved while the pane was hidden,
and synchronous timing only returned the 5-microsecond timer floor.

- **ULTRA LOW (face lighting, quality 1):** about 0.03-0.05 ms on a GTX 1050 Ti at 1080p.
- **LOW (+ exact sky share, leaf sheen, sand glitter):** about 0.10-0.15 ms on the 1050 Ti (budget
  0.25 ms).
- **MEDIUM (all groups):** about 0.06-0.10 ms on an RTX 3050 at 1080p (budget 0.2 ms).
- **Vertex cost:** about 60 ALU per terrain vertex (light amount, moon light, material tables) is
  part of these numbers.
- No new passes, no new buffers, at most one extra texture read (the lightmap).

## 6. Material groups

- **Encoding:** 126 materials in 40 kinds; 375 block names, all checked against the 26.3 and 1.21.1
  block lists.
- **Only in 1.21.4+:** the pale oak log, wood, stripped, planks, stairs, slab, fence, fence gate,
  pressure plate, button and leaves. On 1.21.1 Iris logs "Failed to get entry" and skips them; that
  string is in the Iris jar, the skip itself I inferred.
- **Variants:** stairs, slabs, walls, fences, fence gates, pressure plates and buttons share their
  base block's material where they use its texture. Doors and trapdoors are not included: they have
  their own textures.
- **Texture means:** measured on the 26.3 textures; their pixels are identical in 1.21.1 for every
  block I compared (only the PNG encoding differs).
- **Where the values live:** `block.properties` and `lib/block_tables.glsl` are generated together
  from one definition, so they cannot drift apart.

Kind parameters (D thresholds in standard deviations of the block's own texture; density relative,
x `MAX_GLINT_COVERAGE` x `GLINT_DENSITY_SCALE`; tilt in tangent units; lobe in degrees x
`BLOCK_GLINT_SIZE`; strengths x the group sliders). Fade distances are global
(`GLINT_FADE_START` 16, `GLINT_FADE_END` 48); the leaf back-light is the existing `LEAF_TRANSMISSION`
and the vine/carpet back-light the existing `THIN_TRANSMISSION_STRENGTH`.

| Kind | Type | D thresholds (std) | Density | Tilt | Lobe | Glint colour | Albedo mix | Glint | Sheen | Sheen lobe | Sky refl. | Flags |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| sand | glitter | 0.6 .. 1.4 | 1 | 1.4 | 14 deg | #FFF2D0 | 0 | 0.55 | 0 | 0 | 0 | 8 |
| red_sand | glitter | 0.6 .. 1.4 | 1 | 1.4 | 14 deg | #FFD8B8 | 0 | 0.55 | 0 | 0 | 0 | 8 |
| snow | glitter | -9 .. -8 | 0.8 | 1.4 | 11 deg | #EAF2FF | 0 | 0.4 | 0 | 0 | 0 | 0 |
| powder_snow | glitter | -9 .. -8 | 0.4 | 1.4 | 12 deg | #EAF2FF | 0 | 0.25 | 0 | 0 | 0 | 0 |
| gravel | glitter | 1 .. 1.8 | 0.35 | 1.2 | 9 deg | #E4E6EE | 0 | 0.3 | 0 | 0 | 0 | 0 |
| calcite | glitter | 0.8 .. 1.6 | 0.35 | 1.2 | 9 deg | #F4F6FF | 0 | 0.3 | 0 | 0 | 0 | 0 |
| deepslate | glitter | 0.9 .. 1.8 | 0.3 | 1.2 | 9 deg | #C8CCDA | 0 | 0.3 | 0 | 0 | 0 | 0 |
| soul | glitter | 0.9 .. 1.8 | 0.2 | 1.2 | 9 deg | #E8DCCB | 0 | 0.15 | 0 | 0 | 0 | 0 |
| farmland | sheen | 0 .. 0.9 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.22 | 0.55 | 0 | 1 |
| farmland_wet | sheen | 0 .. 0.9 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.3 | 0.7 | 0 | 1 |
| clay_mud | sheen | 0.6 .. 1.4 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.1 | 0.7 | 0 | 0 |
| grass | sheen | 0.5 .. 1.3 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.08 | 0.5 | 0 | 0 |
| moss | sheen | 0.5 .. 1.3 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.1 | 0.5 | 0 | 0 |
| dirt | sheen | 0.7 .. 1.5 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.05 | 0.5 | 0 | 0 |
| stone | sheen | 0.9 .. 1.7 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.06 | 0.55 | 0 | 0 |
| log | sheen | 0.5 .. 1.3 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.12 | 0.5 | 0 | 0 |
| stripped_log | sheen | 0.5 .. 1.3 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.16 | 0.5 | 0 | 0 |
| planks | sheen | 0.6 .. 1.4 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.05 | 0.5 | 0 | 0 |
| mushroom | sheen | 0.5 .. 1.3 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.1 | 0.5 | 0 | 0 |
| ice | gloss | -9 .. -8 | 0.6 | 1 | 8 deg | #D8EAFF | 0 | 0.6 | 0 | 0 | 0.25 | 0 |
| packed_ice | gloss | -9 .. -8 | 0.6 | 1 | 8 deg | #D8EAFF | 0 | 0.55 | 0 | 0 | 0.18 | 0 |
| blue_ice | gloss | -9 .. -8 | 0.7 | 1 | 11 deg | #D0E4FF | 0 | 0.6 | 0 | 0 | 0.22 | 0 |
| obsidian | gloss | 0.6 .. 1.4 | 1 | 1.2 | 13 deg | #8A7CFF | 0.3 | 0.8 | 0 | 0 | 0.2 | 4 |
| amethyst | gloss | 0.5 .. 1.3 | 1 | 1.4 | 13 deg | #F0D8FF | 0.4 | 0.9 | 0 | 0 | 0.1 | 4 |
| blackstone | gloss | 1 .. 1.8 | 0.5 | 1.2 | 9 deg | #C8C4D8 | 0 | 0.4 | 0 | 0 | 0.08 | 4 |
| basalt | gloss | 0.9 .. 1.7 | 0.3 | 1 | 9 deg | #D0D0D8 | 0 | 0.3 | 0 | 0 | 0.06 | 4 |
| quartz | gloss | 0.5 .. 1.3 | 0.3 | 0.8 | 12 deg | #FFFFFF | 0 | 0.25 | 0.06 | 0.6 | 0.08 | 4 |
| prismarine | gloss | 0.7 .. 1.5 | 0.6 | 1.2 | 9 deg | #B8FFF0 | 0.4 | 0.5 | 0 | 0 | 0.1 | 4 |
| glass | gloss | 0.4 .. 1 | 0.5 | 0.6 | 8 deg | #F0FAFF | 0 | 0.4 | 0 | 0 | 0.15 | 4 |
| copper | gloss | 0.4 .. 1.2 | 0.8 | 0.9 | 10 deg | #FFC8A8 | 1 | 0.6 | 0.1 | 0.6 | 0 | 0 |
| gold | gloss | 0.4 .. 1.2 | 0.8 | 0.9 | 10 deg | #FFF0A0 | 1 | 0.7 | 0.1 | 0.6 | 0 | 0 |
| iron | gloss | 0.4 .. 1.2 | 0.8 | 0.9 | 10 deg | #FFFFFF | 1 | 0.6 | 0.1 | 0.6 | 0 | 0 |
| gem | gloss | 0.4 .. 1.2 | 0.8 | 1 | 10 deg | #E0FFFF | 1 | 0.7 | 0 | 0 | 0.05 | 4 |
| netherite | gloss | 0.6 .. 1.4 | 0.6 | 0.9 | 10 deg | #D8D0E0 | 0.6 | 0.4 | 0.06 | 0.6 | 0 | 0 |
| ore | gloss | 1 .. 1.8 | 1 | 1.2 | 13 deg | #FFFFFF | 1 | 0.8 | 0 | 0 | 0 | 0 |
| leaves | foliage | 0.3 .. 1.1 | 0.1 | 1 | 12 deg | #F0FFD0 | 1 | 0.2 | 0.22 | 0.45 | 0 | 0 |
| vines | foliage | 0.4 .. 1.2 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.16 | 0.45 | 0 | 0 |
| carpet | foliage | 0.4 .. 1.2 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.12 | 0.45 | 0 | 16 |
| plants | foliage | 0.4 .. 1.2 | 0 | 0 | 0 deg | #000000 | 0 | 0 | 0.06 | 0.45 | 0 | 2 |

Materials (IDs, measured texture statistics, blocks):

| # | Material | Kind | IDs | Side texture (mean / std) | Top texture (mean / std) | Blocks |
|---|---|---|---|---|---|---|
| 1 | sand | sand | 1010 1014 | sand (0.810 / 0.038) | sand (0.810 / 0.038) | sand suspicious_sand |
| 2 | red_sand | red_sand | 1024 | red_sand (0.457 / 0.029) | red_sand (0.457 / 0.029) | red_sand |
| 3 | snow | snow | 1030 | snow (0.993 / 0.020) | snow (0.993 / 0.020) | snow snow_block |
| 4 | powder_snow | powder_snow | 1040 | powder_snow (0.989 / 0.020) | powder_snow (0.989 / 0.020) | powder_snow |
| 5 | gravel | gravel | 1050 | gravel (0.503 / 0.067) | gravel (0.503 / 0.067) | gravel suspicious_gravel |
| 6 | calcite | calcite | 1065 | calcite (0.878 / 0.075) | calcite (0.878 / 0.075) | calcite |
| 7 | diorite | calcite | 1070 1075 | diorite (0.739 / 0.136) | diorite (0.739 / 0.136) | diorite diorite_stairs diorite_slab diorite_wall |
| 8 | deepslate | deepslate | 1085 | deepslate (0.315 / 0.083) | deepslate_top (0.343 / 0.069) | deepslate |
| 9 | cobbled_deepslate | deepslate | 1090 1095 | cobbled_deepslate (0.304 / 0.082) | cobbled_deepslate (0.304 / 0.082) | cobbled_deepslate cobbled_deepslate_stairs cobbled_deepslate_slab cobbled_deepslate_wall |
| 10 | soul_sand | soul | 1100 | soul_sand (0.257 / 0.064) | soul_sand (0.257 / 0.064) | soul_sand |
| 11 | soul_soil | soul | 1110 | soul_soil (0.238 / 0.051) | soul_soil (0.238 / 0.051) | soul_soil |
| 12 | farmland | farmland | 1120 | dirt (0.401 / 0.090) | farmland (0.427 / 0.095) | farmland:moisture=0 farmland:moisture=1 farmland:moisture=2 farmland:moisture=3 farmland:moisture=4 farmland:moisture=5 farmland:moisture=6 |
| 13 | farmland_wet | farmland_wet | 1130 | dirt (0.401 / 0.090) | farmland_moist (0.197 / 0.055) | farmland:moisture=7 |
| 14 | clay | clay_mud | 1144 | clay (0.652 / 0.026) | clay (0.652 / 0.026) | clay |
| 15 | mud | clay_mud | 1154 | mud (0.229 / 0.027) | mud (0.229 / 0.027) | mud |
| 16 | packed_mud | clay_mud | 1160 | packed_mud (0.441 / 0.041) | packed_mud (0.441 / 0.041) | packed_mud |
| 17 | grass_block | grass | 1170 | grass_block_side (0.425 / 0.119) | grass_block_top (0.578 / 0.069) | grass_block |
| 18 | moss_block | moss | 1180 | moss_block (0.395 / 0.060) | moss_block (0.395 / 0.060) | moss_block |
| 19 | dirt | dirt | 1194 | dirt (0.401 / 0.090) | dirt (0.401 / 0.090) | dirt |
| 20 | coarse_dirt | dirt | 1204 | coarse_dirt (0.356 / 0.100) | coarse_dirt (0.356 / 0.100) | coarse_dirt |
| 21 | rooted_dirt | dirt | 1214 | rooted_dirt (0.432 / 0.102) | rooted_dirt (0.432 / 0.102) | rooted_dirt |
| 22 | podzol | dirt | 1224 | podzol_side (0.364 / 0.101) | podzol_top (0.261 / 0.050) | podzol |
| 23 | mycelium | dirt | 1234 | mycelium_side (0.361 / 0.103) | mycelium_top (0.398 / 0.028) | mycelium |
| 24 | dirt_path | dirt | 1240 | dirt_path_side (0.416 / 0.090) | dirt_path_top (0.483 / 0.036) | dirt_path |
| 25 | stone | stone | 1250 1255 | stone (0.492 / 0.042) | stone (0.492 / 0.042) | stone stone_stairs stone_slab stone_pressure_plate stone_button |
| 26 | cobblestone | stone | 1260 1265 | cobblestone (0.500 / 0.115) | cobblestone (0.500 / 0.115) | cobblestone cobblestone_stairs cobblestone_slab cobblestone_wall |
| 27 | mossy_cobblestone | stone | 1270 1275 | mossy_cobblestone (0.451 / 0.090) | mossy_cobblestone (0.451 / 0.090) | mossy_cobblestone mossy_cobblestone_stairs mossy_cobblestone_slab mossy_cobblestone_wall |
| 28 | andesite | stone | 1280 1285 | andesite (0.534 / 0.063) | andesite (0.534 / 0.063) | andesite andesite_stairs andesite_slab andesite_wall |
| 29 | oak_log | log | 1294 | oak_log (0.344 / 0.084) | oak_log_top (0.488 / 0.121) | oak_log oak_wood |
| 30 | spruce_log | log | 1304 | spruce_log (0.159 / 0.038) | spruce_log_top (0.329 / 0.062) | spruce_log spruce_wood |
| 31 | birch_log | log | 1314 | birch_log (0.843 / 0.210) | birch_log_top (0.703 / 0.137) | birch_log birch_wood |
| 32 | jungle_log | log | 1324 | jungle_log (0.269 / 0.051) | jungle_log_top (0.451 / 0.110) | jungle_log jungle_wood |
| 33 | acacia_log | log | 1334 | acacia_log (0.382 / 0.056) | acacia_log_top (0.391 / 0.053) | acacia_log acacia_wood |
| 34 | dark_oak_log | log | 1344 | dark_oak_log (0.188 / 0.036) | dark_oak_log_top (0.189 / 0.027) | dark_oak_log dark_oak_wood |
| 35 | mangrove_log | log | 1354 | mangrove_log (0.269 / 0.040) | mangrove_log_top (0.234 / 0.047) | mangrove_log mangrove_wood |
| 36 | cherry_log | log | 1364 | cherry_log (0.151 / 0.036) | cherry_log_top (0.589 / 0.255) | cherry_log cherry_wood |
| 37 | pale_oak_log | log | 1370 | pale_oak_log (0.312 / 0.065) | pale_oak_log_top (0.750 / 0.237) | pale_oak_log pale_oak_wood |
| 38 | stripped_oak_log | stripped_log | 1384 | stripped_oak_log (0.576 / 0.048) | stripped_oak_log (0.576 / 0.048) | stripped_oak_log stripped_oak_wood |
| 39 | stripped_spruce_log | stripped_log | 1394 | stripped_spruce_log (0.364 / 0.024) | stripped_spruce_log (0.364 / 0.024) | stripped_spruce_log stripped_spruce_wood |
| 40 | stripped_birch_log | stripped_log | 1404 | stripped_birch_log (0.691 / 0.043) | stripped_birch_log (0.691 / 0.043) | stripped_birch_log stripped_birch_wood |
| 41 | stripped_jungle_log | stripped_log | 1414 | stripped_jungle_log (0.539 / 0.031) | stripped_jungle_log (0.539 / 0.031) | stripped_jungle_log stripped_jungle_wood |
| 42 | stripped_acacia_log | stripped_log | 1424 | stripped_acacia_log (0.423 / 0.020) | stripped_acacia_log (0.423 / 0.020) | stripped_acacia_log stripped_acacia_wood |
| 43 | stripped_dark_oak_log | stripped_log | 1434 | stripped_dark_oak_log (0.230 / 0.020) | stripped_dark_oak_log (0.230 / 0.020) | stripped_dark_oak_log stripped_dark_oak_wood |
| 44 | stripped_mangrove_log | stripped_log | 1444 | stripped_mangrove_log (0.266 / 0.020) | stripped_mangrove_log (0.266 / 0.020) | stripped_mangrove_log stripped_mangrove_wood |
| 45 | stripped_cherry_log | stripped_log | 1454 | stripped_cherry_log (0.629 / 0.027) | stripped_cherry_log (0.629 / 0.027) | stripped_cherry_log stripped_cherry_wood |
| 46 | stripped_pale_oak_log | stripped_log | 1460 | stripped_pale_oak_log (0.940 / 0.035) | stripped_pale_oak_log (0.940 / 0.035) | stripped_pale_oak_log stripped_pale_oak_wood |
| 47 | oak_planks | planks | 1470 1474 | oak_planks (0.524 / 0.097) | oak_planks (0.524 / 0.097) | oak_planks oak_stairs oak_slab oak_fence oak_fence_gate oak_pressure_plate oak_button |
| 48 | spruce_planks | planks | 1480 1484 | spruce_planks (0.348 / 0.056) | spruce_planks (0.348 / 0.056) | spruce_planks spruce_stairs spruce_slab spruce_fence spruce_fence_gate spruce_pressure_plate spruce_button |
| 49 | birch_planks | planks | 1490 1494 | birch_planks (0.686 / 0.080) | birch_planks (0.686 / 0.080) | birch_planks birch_stairs birch_slab birch_fence birch_fence_gate birch_pressure_plate birch_button |
| 50 | jungle_planks | planks | 1500 1504 | jungle_planks (0.480 / 0.093) | jungle_planks (0.480 / 0.093) | jungle_planks jungle_stairs jungle_slab jungle_fence jungle_fence_gate jungle_pressure_plate jungle_button |
| 51 | acacia_planks | planks | 1510 1514 | acacia_planks (0.408 / 0.051) | acacia_planks (0.408 / 0.051) | acacia_planks acacia_stairs acacia_slab acacia_fence acacia_fence_gate acacia_pressure_plate acacia_button |
| 52 | dark_oak_planks | planks | 1520 1524 | dark_oak_planks (0.182 / 0.040) | dark_oak_planks (0.182 / 0.040) | dark_oak_planks dark_oak_stairs dark_oak_slab dark_oak_fence dark_oak_fence_gate dark_oak_pressure_plate dark_oak_button |
| 53 | mangrove_planks | planks | 1530 1534 | mangrove_planks (0.264 / 0.056) | mangrove_planks (0.264 / 0.056) | mangrove_planks mangrove_stairs mangrove_slab mangrove_fence mangrove_fence_gate mangrove_pressure_plate mangrove_button |
| 54 | cherry_planks | planks | 1540 1544 | cherry_planks (0.739 / 0.070) | cherry_planks (0.739 / 0.070) | cherry_planks cherry_stairs cherry_slab cherry_fence cherry_fence_gate cherry_pressure_plate cherry_button |
| 55 | pale_oak_planks | planks | 1550 | pale_oak_planks (0.861 / 0.094) | pale_oak_planks (0.861 / 0.094) | pale_oak_planks pale_oak_stairs pale_oak_slab pale_oak_fence pale_oak_fence_gate pale_oak_pressure_plate pale_oak_button |
| 56 | bamboo_planks | planks | 1560 1564 | bamboo_planks (0.670 / 0.098) | bamboo_planks (0.670 / 0.098) | bamboo_planks bamboo_stairs bamboo_slab bamboo_fence bamboo_fence_gate bamboo_pressure_plate bamboo_button |
| 57 | brown_mushroom_block | mushroom | 1570 | brown_mushroom_block (0.461 / 0.020) | brown_mushroom_block (0.461 / 0.020) | brown_mushroom_block |
| 58 | red_mushroom_block | mushroom | 1580 | red_mushroom_block (0.311 / 0.097) | red_mushroom_block (0.311 / 0.097) | red_mushroom_block |
| 59 | mushroom_stem | mushroom | 1590 | mushroom_stem (0.773 / 0.024) | mushroom_stem (0.773 / 0.024) | mushroom_stem |
| 60 | brown_mushroom | mushroom | 1600 | brown_mushroom (0.482 / 0.130) | brown_mushroom (0.482 / 0.130) | brown_mushroom |
| 61 | red_mushroom | mushroom | 1610 | red_mushroom (0.412 / 0.228) | red_mushroom (0.412 / 0.228) | red_mushroom |
| 62 | ice | ice | 1628 | ice (0.709 / 0.033) | ice (0.709 / 0.033) | ice frosted_ice |
| 63 | packed_ice | packed_ice | 1638 | packed_ice (0.694 / 0.046) | packed_ice (0.694 / 0.046) | packed_ice |
| 64 | blue_ice | blue_ice | 1648 | blue_ice (0.639 / 0.039) | blue_ice (0.639 / 0.039) | blue_ice |
| 65 | obsidian | obsidian | 1655 | obsidian (0.049 / 0.056) | obsidian (0.049 / 0.056) | obsidian |
| 66 | crying_obsidian | obsidian | 1660 | crying_obsidian (0.073 / 0.063) | crying_obsidian (0.073 / 0.063) | crying_obsidian |
| 67 | amethyst_block | amethyst | 1670 | amethyst_block (0.441 / 0.122) | amethyst_block (0.441 / 0.122) | amethyst_block budding_amethyst |
| 68 | amethyst_buds | amethyst | 1680 | amethyst_cluster (0.551 / 0.177) | amethyst_cluster (0.551 / 0.177) | amethyst_cluster large_amethyst_bud medium_amethyst_bud small_amethyst_bud |
| 69 | blackstone | blackstone | 1690 1695 | blackstone (0.146 / 0.062) | blackstone_top (0.150 / 0.058) | blackstone gilded_blackstone blackstone_stairs blackstone_slab blackstone_wall |
| 70 | polished_blackstone | blackstone | 1700 1706 | polished_blackstone (0.197 / 0.058) | polished_blackstone (0.197 / 0.058) | polished_blackstone_stairs polished_blackstone_slab polished_blackstone_wall polished_blackstone_pressure_plate polished_blackstone_button polished_blackstone |
| 71 | polished_blackstone_bricks | blackstone | 1710 1716 | polished_blackstone_bricks (0.174 / 0.066) | polished_blackstone_bricks (0.174 / 0.066) | cracked_polished_blackstone_bricks chiseled_polished_blackstone polished_blackstone_brick_stairs polished_blackstone_brick_slab polished_blackstone_brick_wall polished_blackstone_bricks |
| 72 | basalt | basalt | 1725 | basalt_side (0.287 / 0.063) | basalt_top (0.320 / 0.103) | basalt |
| 73 | polished_basalt | basalt | 1730 | polished_basalt_side (0.347 / 0.093) | polished_basalt_top (0.388 / 0.095) | polished_basalt |
| 74 | smooth_basalt | basalt | 1745 | smooth_basalt (0.285 / 0.066) | smooth_basalt (0.285 / 0.066) | smooth_basalt |
| 75 | quartz | quartz | 1750 1756 | quartz_block_side (0.905 / 0.022) | quartz_block_top (0.905 / 0.022) | quartz_pillar quartz_stairs quartz_slab smooth_quartz_stairs smooth_quartz_slab quartz_block quartz_bricks chiseled_quartz_block smooth_quartz |
| 76 | polished_granite | quartz | 1760 1766 | polished_granite (0.453 / 0.084) | polished_granite (0.453 / 0.084) | polished_granite_stairs polished_granite_slab polished_granite |
| 77 | polished_diorite | quartz | 1770 1776 | polished_diorite (0.758 / 0.132) | polished_diorite (0.758 / 0.132) | polished_diorite_stairs polished_diorite_slab polished_diorite |
| 78 | polished_andesite | quartz | 1780 1786 | polished_andesite (0.526 / 0.082) | polished_andesite (0.526 / 0.082) | polished_andesite_stairs polished_andesite_slab polished_andesite |
| 79 | polished_deepslate | quartz | 1790 1796 | polished_deepslate (0.285 / 0.079) | polished_deepslate (0.285 / 0.079) | polished_deepslate_stairs polished_deepslate_slab polished_deepslate_wall polished_deepslate |
| 80 | polished_tuff | quartz | 1800 1806 | polished_tuff (0.402 / 0.049) | polished_tuff (0.402 / 0.049) | polished_tuff_stairs polished_tuff_slab polished_tuff_wall polished_tuff |
| 81 | prismarine | prismarine | 1810 1815 | prismarine (0.578 / 0.104) | prismarine (0.578 / 0.104) | prismarine prismarine_stairs prismarine_slab prismarine_wall |
| 82 | prismarine_bricks | prismarine | 1820 | prismarine_bricks (0.609 / 0.086) | prismarine_bricks (0.609 / 0.086) | prismarine_bricks prismarine_brick_stairs prismarine_brick_slab |
| 83 | dark_prismarine | prismarine | 1830 1835 | dark_prismarine (0.322 / 0.076) | dark_prismarine (0.322 / 0.076) | dark_prismarine dark_prismarine_stairs dark_prismarine_slab |
| 84 | glass | glass | 1848 | glass (0.809 / 0.089) | glass (0.809 / 0.089) | glass glass_pane |
| 85 | tinted_glass | glass | 1858 | tinted_glass (0.150 / 0.022) | tinted_glass (0.150 / 0.022) | tinted_glass |
| 86 | stained_glass | glass | 1860 1868 | white_stained_glass (1.000 / 0.020) | white_stained_glass (1.000 / 0.020) | black_stained_glass blue_stained_glass brown_stained_glass cyan_stained_glass gray_stained_glass green_stained_glass light_blue_stained_glass light_gray_stained_glass lime_stained_glass magenta_stained_glass orange_stained_glass pink_stained_glass purple_stained_glass red_stained_glass white_stained_glass yellow_stained_glass black_stained_glass_pane blue_stained_glass_pane brown_stained_glass_pane cyan_stained_glass_pane gray_stained_glass_pane green_stained_glass_pane light_blue_stained_glass_pane light_gray_stained_glass_pane lime_stained_glass_pane magenta_stained_glass_pane orange_stained_glass_pane pink_stained_glass_pane purple_stained_glass_pane red_stained_glass_pane white_stained_glass_pane yellow_stained_glass_pane |
| 87 | copper | copper | 1870 1875 1877 | copper_block (0.485 / 0.071) | copper_block (0.485 / 0.071) | copper_block waxed_copper_block cut_copper waxed_cut_copper raw_copper_block copper_ore deepslate_copper_ore chiseled_copper waxed_chiseled_copper copper_grate waxed_copper_grate cut_copper_stairs cut_copper_slab waxed_cut_copper_stairs waxed_cut_copper_slab |
| 88 | exposed_copper | copper | 1880 1887 | exposed_copper (0.516 / 0.052) | exposed_copper (0.516 / 0.052) | exposed_copper exposed_cut_copper waxed_exposed_copper waxed_exposed_cut_copper exposed_chiseled_copper exposed_copper_grate exposed_cut_copper_stairs exposed_cut_copper_slab waxed_exposed_chiseled_copper waxed_exposed_copper_grate waxed_exposed_cut_copper_stairs waxed_exposed_cut_copper_slab |
| 89 | weathered_copper | copper | 1890 1897 | weathered_copper (0.551 / 0.065) | weathered_copper (0.551 / 0.065) | weathered_copper weathered_cut_copper waxed_weathered_copper waxed_weathered_cut_copper weathered_chiseled_copper weathered_copper_grate weathered_cut_copper_stairs weathered_cut_copper_slab waxed_weathered_chiseled_copper waxed_weathered_copper_grate waxed_weathered_cut_copper_stairs waxed_weathered_cut_copper_slab |
| 90 | oxidized_copper | copper | 1900 1907 | oxidized_copper (0.563 / 0.085) | oxidized_copper (0.563 / 0.085) | oxidized_copper oxidized_cut_copper waxed_oxidized_copper waxed_oxidized_cut_copper oxidized_chiseled_copper oxidized_copper_grate oxidized_cut_copper_stairs oxidized_cut_copper_slab waxed_oxidized_chiseled_copper waxed_oxidized_copper_grate waxed_oxidized_cut_copper_stairs waxed_oxidized_cut_copper_slab |
| 91 | gold_block | gold | 1917 | gold_block (0.807 / 0.096) | gold_block (0.807 / 0.096) | gold_block |
| 92 | raw_gold_block | gold | 1927 | raw_gold_block (0.673 / 0.154) | raw_gold_block (0.673 / 0.154) | raw_gold_block |
| 93 | iron_block | iron | 1937 | iron_block (0.863 / 0.070) | iron_block (0.863 / 0.070) | iron_block |
| 94 | raw_iron_block | iron | 1947 | raw_iron_block (0.550 / 0.147) | raw_iron_block (0.550 / 0.147) | raw_iron_block |
| 95 | diamond_block | gem | 1950 | diamond_block (0.812 / 0.097) | diamond_block (0.812 / 0.097) | diamond_block |
| 96 | emerald_block | gem | 1960 | emerald_block (0.631 / 0.119) | emerald_block (0.631 / 0.119) | emerald_block |
| 97 | netherite_block | netherite | 1977 | netherite_block (0.246 / 0.060) | netherite_block (0.246 / 0.060) | netherite_block |
| 98 | ancient_debris | netherite | 1980 | ancient_debris_side (0.274 / 0.107) | ancient_debris_top (0.282 / 0.156) | ancient_debris |
| 99 | iron_ore | ore | 1995 | iron_ore (0.511 / 0.076) | iron_ore (0.511 / 0.076) | iron_ore |
| 100 | gold_ore | ore | 2005 | gold_ore (0.527 / 0.122) | gold_ore (0.527 / 0.122) | gold_ore |
| 101 | diamond_ore | ore | 2015 | diamond_ore (0.537 / 0.113) | diamond_ore (0.537 / 0.113) | diamond_ore |
| 102 | emerald_ore | ore | 2025 | emerald_ore (0.505 / 0.116) | emerald_ore (0.505 / 0.116) | emerald_ore |
| 103 | deepslate_iron_ore | ore | 2035 | deepslate_iron_ore (0.395 / 0.137) | deepslate_iron_ore (0.395 / 0.137) | deepslate_iron_ore |
| 104 | deepslate_gold_ore | ore | 2045 | deepslate_gold_ore (0.407 / 0.171) | deepslate_gold_ore (0.407 / 0.171) | deepslate_gold_ore |
| 105 | deepslate_diamond_ore | ore | 2055 | deepslate_diamond_ore (0.398 / 0.166) | deepslate_diamond_ore (0.398 / 0.166) | deepslate_diamond_ore |
| 106 | deepslate_emerald_ore | ore | 2065 | deepslate_emerald_ore (0.383 / 0.164) | deepslate_emerald_ore (0.383 / 0.164) | deepslate_emerald_ore |
| 107 | nether_gold_ore | ore | 2075 | nether_gold_ore (0.262 / 0.178) | nether_gold_ore (0.262 / 0.178) | nether_gold_ore |
| 108 | oak_leaves | leaves | 2082 | oak_leaves (0.565 / 0.125) | oak_leaves (0.565 / 0.125) | oak_leaves |
| 109 | spruce_leaves | leaves | 2092 | spruce_leaves (0.495 / 0.131) | spruce_leaves (0.495 / 0.131) | spruce_leaves |
| 110 | birch_leaves | leaves | 2102 | birch_leaves (0.508 / 0.084) | birch_leaves (0.508 / 0.084) | birch_leaves |
| 111 | jungle_leaves | leaves | 2112 | jungle_leaves (0.604 / 0.098) | jungle_leaves (0.604 / 0.098) | jungle_leaves |
| 112 | acacia_leaves | leaves | 2122 | acacia_leaves (0.584 / 0.102) | acacia_leaves (0.584 / 0.102) | acacia_leaves |
| 113 | dark_oak_leaves | leaves | 2132 | dark_oak_leaves (0.592 / 0.113) | dark_oak_leaves (0.592 / 0.113) | dark_oak_leaves |
| 114 | mangrove_leaves | leaves | 2142 | mangrove_leaves (0.505 / 0.140) | mangrove_leaves (0.505 / 0.140) | mangrove_leaves |
| 115 | cherry_leaves | leaves | 2152 | cherry_leaves (0.731 / 0.123) | cherry_leaves (0.731 / 0.123) | cherry_leaves |
| 116 | azalea_leaves | leaves | 2162 | azalea_leaves (0.410 / 0.088) | azalea_leaves (0.410 / 0.088) | azalea_leaves |
| 117 | flowering_azalea_leaves | leaves | 2172 | flowering_azalea_leaves (0.412 / 0.090) | flowering_azalea_leaves (0.412 / 0.090) | flowering_azalea_leaves |
| 118 | pale_oak_leaves | leaves | 2180 | pale_oak_leaves (0.472 / 0.122) | pale_oak_leaves (0.472 / 0.122) | pale_oak_leaves |
| 119 | vine | vines | 2193 | vine (0.455 / 0.110) | vine (0.455 / 0.110) | vine |
| 120 | glow_lichen | vines | 2209 | glow_lichen (0.494 / 0.053) | glow_lichen (0.494 / 0.053) | glow_lichen |
| 121 | moss_carpet | carpet | 2210 | moss_block (0.395 / 0.060) | moss_block (0.395 / 0.060) | moss_carpet |
| 122 | lily_pad | carpet | 2220 | lily_pad (0.524 / 0.110) | lily_pad (0.524 / 0.110) | lily_pad |
| 123 | mangrove_roots | carpet | 2230 | mangrove_roots_side (0.242 / 0.037) | mangrove_roots_top (0.240 / 0.039) | mangrove_roots |
| 124 | grass_plants | plants | 2243 | short_grass (0.571 / 0.087) | short_grass (0.571 / 0.087) | short_grass tall_grass |
| 125 | fern_plants | plants | 2253 | fern (0.488 / 0.099) | fern (0.488 / 0.099) | fern large_fern |
| 126 | flowers | plants | 2263 | poppy (0.300 / 0.071) | poppy (0.300 / 0.071) | dandelion poppy blue_orchid allium azure_bluet red_tulip orange_tulip white_tulip pink_tulip oxeye_daisy cornflower lily_of_the_valley wither_rose sunflower lilac rose_bush peony |

## 7. Files

| File | Status |
|---|---|
| `lib/block_lighting.glsl` | **New**: the face light and micro-detail functions. |
| `lib/block_tables.glsl` | **New, generated**: kind and material tables. |
| `lib/gbuffers.vsh` | Changed: ID split, per-frame light amount, per-block material values (terrain), material index (translucent). |
| `lib/gbuffers_forward.fsh` | Changed (details below). |
| `lib/settings.glsl` | Changed: new options, removed `MATERIAL_RESPONSE*`, new derived switch. |
| `block.properties` | Regenerated. |
| `shaders.properties` | Regenerated: screens, sliders, presets. |
| `lang/en_us.lang` | Changed: labels. |
| Everything else | Unchanged (checked by file hash): all program files (`gbuffers_*.vsh/.fsh`, `composite*`, `final*`, `shadow*`), `lib/ambience.glsl`, `lib/sun_rays.glsl`, `lib/water_reflection.glsl`, `lib/shadow_distortion.glsl`, `textures/clouds.png`. |

Changes in `lib/gbuffers_forward.fsh`:
- include and inputs;
- derivatives taken before the discard;
- the face model on blocks, in place of the old shadow line and lift (both kept unchanged for water
  and entities);
- gloss removal on blocks;
- `MATERIAL_RESPONSE` removed;
- glints added to the highlight;
- debug views.

Frozen-system lines touched (all in `lib/gbuffers_forward.fsh`):

1. **The shadow lookup gate**, one added line: cross-shaped plants also look the shadow up from
   their back side, as the leaves already did. `getShadow` itself (bias, filtering, grid snapping) is
   untouched. Without it, half of the grass quads under a tree would be lit as if in the sun.
2. **The previous cast-shadow line and directional lift:** unchanged code. Blocks now take them only
   when the face lighting is off. The lift's switch is `PREVIOUS_SUN_LIFT` instead of
   `DIRECTIONAL_LIGHTING`.
3. **Water and entities:** not touched. Their output is proven bit-identical in every preset
   (section 9).

## 8. Options

**New, Block Lighting screen (change A):**
- `DIRECTIONAL_LIGHTING` (existing name, new meaning);
- `FACE_LIGHTING_QUALITY` 2 [1 2];
- `FACE_CONTRAST` 1.00;
- `DIRECTIONAL_LIGHT_STRENGTH` 0.08 (existing; now the brightest face's lift);
- `SHADE_FLOOR` 0.45, `DIRECTIONAL_WRAP` 0.08, `MOON_FACE_CONTRAST` 0.30;
- `PLANT_NORMAL_UP_BLEND` 0.70, `AMBIENT_AMOUNT_BIAS` 0.00;
- `PREVIOUS_SUN_LIFT` (new, see below).

**New, Block Micro-Detail screen (change B):**
- toggles `BLOCK_MICRO_DETAIL`, `GLITTER_BLOCKS`, `SHEEN_BLOCKS`, `GLOSS_BLOCKS`, `FOLIAGE_SPARKLE`;
- `MICRO_DETAIL_QUALITY` 2 [1 2];
- strengths `GLITTER_STRENGTH`, `SHEEN_STRENGTH`, `GLOSS_BLOCK_STRENGTH`, `FOLIAGE_STRENGTH` (all 1.00);
- `GLINT_DENSITY_SCALE` 1.00, `BLOCK_GLINT_SIZE` 1.00, `GLINT_ANGLE_STEPS` 12, `DETAIL_THRESHOLD` 1.00;
- `MAX_GLINT_COVERAGE` 0.12, `GLINT_FADE_START` 16, `GLINT_FADE_END` 48, `TORCH_GLINT` 0.05.

**Debug:** `BLOCK_DEBUG`, `BLOCK_DEBUG_MODE` [1-17].

**Removed:** `MATERIAL_RESPONSE`, `MATERIAL_RESPONSE_STRENGTH`.

**Renamed from your spec** (the names already existed):
- the gloss group's strength is `GLOSS_BLOCK_STRENGTH`, because `GLOSS_STRENGTH` is the entity
  plastic;
- the glint size is `BLOCK_GLINT_SIZE`, because `GLINT_SIZE` is the water's wave glint.

**The one setting split, and why it was unavoidable:** `DIRECTIONAL_LIGHTING` also switched an 8 %
lift on water, the player, mobs and particles. ULTRA LOW now needs `DIRECTIONAL_LIGHTING` on for the
face lighting, which would have changed water and entities there. The old lift therefore got its own
switch, `PREVIOUS_SUN_LIFT`, set as `DIRECTIONAL_LIGHTING` was before: off in ULTRA LOW, on
elsewhere.

**Screens:**
- "Block Lighting" and "Block Micro-Detail" on the main screen after "Lighting and Shadows";
- `DIRECTIONAL_LIGHTING` and `DIRECTIONAL_LIGHT_STRENGTH` moved there;
- "Materials" is now "Entity Plastic" (the four plastic sliders).

**Presets** (every preset defines all 279 options):

| Preset | Face lighting | Micro-detail |
|---|---|---|
| ULTRA LOW | on, quality 1 | none (all toggles "!") |
| LOW | on, quality 2 | leaf sheen + sand glitter at 0.6 density, quality 1 (no hash elsewhere); sheen and gloss groups "!" |
| MEDIUM (default) | on, quality 2 | all groups, 12 angle steps |
| HIGH | on, quality 2 | all groups, 16 angle steps |
| CINEMATIC | on, quality 2 | all groups, 24 angle steps |

## 9. Test results (measured in the harness)

**Identity (float outputs bit for bit, 3 repeated frames per build, a match counts):**

| Test | Variants | Result |
|---|---|---|
| Water (fluid quads, both outputs) | defaults, ULTRA LOW, LOW, MEDIUM, HIGH, CINEMATIC x day 45, low sun, night, rain | 24 / 24 identical |
| Entities and particles (`gbuffers_textured_lit`) | same | 24 / 24 identical |
| Terrain with both 2B features off vs the old build with its block gloss off | 4 option sets x 4 scenes | 16 / 16 identical |
| Sky, composite and final (no terrain) | defaults, LOW, CINEMATIC x day, night, dusk | 9 / 9 identical |

**Face lighting (pillar scene, final 8-bit image; lit face vs the other visible face):**

| Sun | Obsidian | Polished blackstone | Before |
|---|---|---|---|
| 45 degrees | 1.46 | 1.52 | 1.06 / 1.11 |
| 20 degrees (low) | 1.51 | 1.58 | 1.23 / 1.14 |
| 70 degrees | 1.29 | 1.33 | 1.03 / 1.08 |
| Noon (sun at the zenith: all sides equal, the top brightest) | 1.00 | 1.04 | 1.01 / 1.04 |
| Sun behind the face | 1.00 | 1.04 | |
| Full moon 40 degrees | 1.12 | 1.15 | 1.10 / 1.25 |
| Rain | 1.10 | 1.13 | 1.04 / 1.09 |
| Full cast shadow | 1.00 | 1.04 | 0.76 / 0.79 |

- **Face light factor at 45 degrees:** sunlit side 0.944, edge-on side 0.637, sunlit top 1.056. In a
  full shadow: 0.637 / 0.637 / 0.750. Noon: sides 0.561, top 1.079.
- **Your reference** measured 1.58.

**Micro-detail** (5 x 5 patch from 12 camera positions around it, sun 35 degrees):

| Material | Glinting texels per view (of 6,400) | Share of texels (mean / max) | Detail texels (D > 0) |
|---|---|---|---|
| sand | 14 (max 27) | 0.20 % / 0.39 % | 28 % |
| red sand | 14 (max 26) | 0.19 % / 0.38 % | 28 % |
| snow | 28 (max 45) | 0.39 % / 0.60 % | 100 % |
| blue ice / packed ice | 26 / 13 | 0.39 % / 0.18 % | 100 % |
| obsidian | 11 (max 18) | 0.17 % / 0.28 % | 20 % |
| amethyst | 9 | 0.13 % | 23 % |
| copper / gold / iron | 7 / 5 / 4 | 0.06-0.11 % | 35-55 % |
| gravel / deepslate / calcite (faint) | 1.3 / 0.8 / 0.5 | about 0.01 % | 14-20 % |
| oak leaves (waxy) | 0.8 | 0.01 % | 26 % |

- **Sunlit obsidian wall** (15 faces): 5.6 glinting texels per view (max 9).
- **Sheen on the detail texels:** leaves +10.6 % (max 13 %), farmland +5 % (max 18 % on furrows turned
  to the sun), stone +2.7 %, metals +1 to 2 %.
- **LOW preset:** sand 0.10 % of texels, every non-sand group 0 (no hash).
- **Coverage:** never above 0.7 % of texels in any view (the cap is 12 %).
- **Stability** (sand, camera moved sideways; glints depend on the camera position, not its direction):

| Camera step | Glint changes per step |
|---|---|
| 0.002 block | 0 |
| 0.01 block | 0.3 of about 14 glints (each lasts about half a block of movement) |
| 0.05 block | 1.0 |
| 0.1 block | 2.2 |

  Split squares (pixels of one texel at different levels): 0 to 0.2 per frame.
- **Distance** (sand strip seen along the ground): glints only in the nearest 8 blocks at that
  grazing view (the footprint fade); none at any distance where texels are smaller than a pixel.
- **Compile:** 1,690 / 1,690 programs, 0 failures (final code).

Images saved by the harness (not the game): `%TEMP%\vclpal\update2b\out\` (`cmp_*.png` old | new,
`debug_*.png`). They are working files on this machine, not part of the pack.

## 10. Changelog

- **Added:** directional face lighting on blocks:
  - sun-facing faces brighter, faces turned away get the sky ambient only;
  - hemispherical ambient (top, sides, bottom);
  - gentle cool moon contrast at night;
  - weather fades the contrast;
  - plants lit from above;
  - sunlit tops keep their previous brightness.
- **Added:** micro-detail lighting on 375 blocks in four groups (glitter, sheen, gloss, foliage):
  - texel-sized, view-dependent glints that switch in steps;
  - sheen on lighter texels;
  - sun-catching furrows on farmland;
  - faint sky reflection on ice, glass and the speckles of dark gloss blocks;
  - tiny torch glints;
  - fades by texel size and distance.
- **Added:** 17 debug views (`BLOCK_DEBUG`).
- **Added:** "Block Lighting" and "Block Micro-Detail" screens, 28 new options, all presets complete.
- **Removed:** the plastic gloss on blocks; the `MATERIAL_RESPONSE` gloss and its two options.
- **Fixed (on blocks):**
  - faces turned away from the sun were as bright as lit ones;
  - a cast shadow made a sun-facing face darker than a face turned away;
  - cast shadows stayed at full strength in rain and at night.
- **Visible differences:**
  - walls and undersides are darker: turned away about 0.64 x at a 45-degree sun, 0.56 x at noon,
    0.85 x in overcast; bottoms 0.70 x;
  - sun-facing walls at low sun get brighter;
  - block entities (chests, signs) get the face lighting too;
  - cast shadows on blocks are lighter in rain and at night;
  - no plastic sheen on blocks.
- **Unchanged (proven):** water, the player, mobs and particles, sky, sun, moon, clouds, fog,
  composite and final. Shadow generation and shadow colours are untouched code.
- **Performance:** estimated +0.03 to 0.15 ms depending on the preset (section 5.3).

## 11. Test plan (in game) and screenshots I need

Test world: a flat area with an obsidian pillar and a crying obsidian block on snow, and a polished
blackstone pillar. Add patches of sand, red sand, gravel, snow, farmland (one patch dry, one next to
water so it turns wet), ice, packed ice, blue ice, deepslate, stone, andesite, cobblestone, copper,
gold and iron blocks, amethyst, prismarine, clay, mud, grass and podzol. Add logs and stripped logs,
leaves of every tree type, a tree with vines (swamp), mushrooms, and a torch-lit cave.

1. **Face contrast:**
   - `/time set 1000` (sunrise side), `6000` (noon), `11500` (sunset), `18000` (night);
   - look at each pillar from a corner;
   - expected: the sun-facing side clearly brighter (about 1.4-1.6 x at mid sun), never black; at noon
     all sides equal and the top brightest; at night a faint cool difference.
   - `BLOCK_DEBUG` view 17 shows the factor x 0.5: sunlit side about 0.47, side turned away about 0.32,
     sunlit top about 0.53.
2. **Micro-detail:**
   - walk and turn slowly next to each patch;
   - expected: sparse, square, texel-sized highlights; they stay put while you stand still; they
     change one by one as you move; no shimmer; nothing on faces turned away from the sun or in
     shadow.
3. **Distance:** walk away from sand and leaves. Glints fade out without shimmer; view 12 (footprint
   fade) goes black where texels get smaller than a pixel.
4. **Weather and places:**
   - `/weather rain`, then `/weather thunder`: contrast and glints weaker;
   - indoors, caves with torches: torch-lit faces as before, tiny warm glints only;
   - underwater: weak;
   - Nether and End: no face lighting, no sun glints;
   - far from spawn: teleport to 1,000,000 0 1,000,000 and check view 8 (the texel squares must stay
     clean);
   - 720p / 1080p / 1440p / 4K, GUI scales, FOV 30 to 110.
5. **Before / after:**
   - view 16 (left half without, right half with this update);
   - or `DIRECTIONAL_LIGHTING` off and `BLOCK_MICRO_DETAIL` off for "before";
   - water, the player, mobs, the sky and clouds must not change.
6. **Performance:** F3 frame time with `BLOCK_MICRO_DETAIL` and `DIRECTIONAL_LIGHTING` on and off,
   in a forest and on a beach.

Screenshots (F1, the same world, coordinates, camera, time, FOV, render distance, GUI scale and
resolution; one "before" with both features off and one "after"):

1. the obsidian pillar on snow, the dark pillar and the swamp tree (your three references);
2. sand and red sand under the sun;
3. farmland, dry and wet;
4. ice, packed ice and blue ice;
5. obsidian up close;
6. a forest canopy from below and from the side;
7. a close view of leaves;
8. the pillar scene at sunset and at night;
9. optional: debug views 3, 8, 9, 11 and 17 of the pillar scene.

With those I can measure the real face ratios, the glint share per group and, from two frames 0.1
block apart, the flicker, then iterate.

## 12. Not verified without the game

- **The in-game look and real performance.** The harness has no Sodium ambient occlusion, its
  lightmap only imitates vanilla's, and it has no real shadow map: shadows were tested as "none" and
  "full" only.
- **Driver behaviour:** bit-exactness and compilation on NVIDIA, AMD and Intel GL drivers (verified
  on ANGLE / Direct3D 11 only).
- **Block entities:** their `mc_Entity` value, so whether any of them could pick up a micro-detail
  material by accident.
- **The lightmap layout:** that the 26.3 lightmap still has block light on u and sky light on v (the
  pack already relies on it; the sky-share read uses u = 1/32).
- **Interpolators:** that Iris adds no extra ones on top of the 60 (terrain) and 63 (translucent)
  components.
- **Pale oak on 1.21.1:** the skip of its unknown names, inferred from the "Failed to get entry"
  string in the Iris jar.
- **Furrow direction:** derived from the vanilla UV rule for upward faces (checked in
  `FaceBakery.defaultFaceUV`). If the lit furrow sides look swapped in game, the table only needs its
  sign flipped.
- **Image 3's speckles:** whether they come from a different block there.

## 13. Debug views (`BLOCK_DEBUG_MODE`) and the expected correct look

They are written as the block colour, so final grades them like the scene (fog beyond 32 blocks,
tone shoulder). Raw colours would need one compile-time line in `final.fsh`, which is outside this
update's files, so I did not add it; tell me if you want it.

| View | Shows | Expected |
|---|---|---|
| 1 | Face normal | Flat colour per face (up = green-ish, east = pink); plants pale green (up-blended). |
| 2 | N.L | Bright on faces turned to the light, black on the others. |
| 3 | Sun-facing mask | Gold where the direct light reaches, dark elsewhere; shadows dark. |
| 4 | Direct term | Grey on lit faces only. |
| 5 | Ambient term (x 0.5) | Tops brightest, sides a little darker, bottoms darkest. |
| 6 | Vanilla vertex colour | Tint and AO only: every face of an untinted block equally bright, corners darker (this confirms there is no baked face shading). |
| 7 | Material group | Yellow glitter, green sheen, blue gloss, teal foliage, near-black for none. |
| 8 | Texel ID | Random colours in clean 16-per-block squares on every face. |
| 9 | Detail mask D | White grains and speckles; snow and ice white; dark elsewhere. |
| 10 | Glint before quantization | Sparse grey dots. |
| 11 | Glint levels | Sparse squares at two levels; stable while standing still. |
| 12 | Footprint fade | White near, black where texels get smaller than a pixel. |
| 13 | Distance fade | White to 16 blocks, black from 48. |
| 14 | Sheen (x 4) | Lighter texels on lit faces only. |
| 15 | Micro-detail contribution (x 2) | Dark everywhere except glints, sheen and the faint sky reflection. |
| 16 | Before / after split | Left half: the previous face lighting (flat, with the old lift), no micro-detail. Right half: this update. The plastic gloss is not brought back on the left. |
| 17 | Face light factor (x 0.5) | 0.5 = the previous flat light; sunlit tops about 0.53, faces turned away about 0.3. |
