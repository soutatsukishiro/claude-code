# Update 4.1 (End VV): névoa volumétrica do flash e grão do céu

## Como restaurar o estado anterior

Backup: `backup/2026-10-07_before_end_vv_4_1/`, com os arquivos da versão anterior completos. Para voltar,
copie-os por cima. Esta atualização não cria arquivos novos no `shaders/`.

## 1. O pedido

> O volumetric fog no flash do End não está agradável, veja como ele se comporta no Vibrant Visuals (imagem 2),
> diferente da 1. O skybox do End no Vibrant Visuals tem alguns granulados leves: leve esse efeito para o shader.

Este relatório chama as imagens assim:

- **Imagem 5:** o seu Java.
- **Imagem 6:** o Vibrant Visuals.
- **Imagens 2 e 4:** as referências VV anteriores.

## 2. O que as imagens mostram

### Névoa

Medido em luma (0–255):

| Ponto | Seu Java (imagem 5) | Vibrant Visuals (imagem 6) |
|---|---|---|
| Pilares na frente do brilho | 4–11, pretos e nítidos | 24–27 (esquerdo), 23–25 (direito), 40–45 perto do centro |
| Enderman a ~30 blocos | – | 38 |
| Chão de end stone sob o brilho | #625040 (83–85) | #534940 (~75) |
| Chão longe do brilho | – | #4A4A2F (~71) |

- No VV o brilho é luz *no ar, na frente da cena*. Os pilares e endermen a 25–35 blocos ficam com 60 a 80% do
  brilho do céu naquele ângulo.
- O end stone, que é claro, só fica levemente roxo.
- O ar entre uma superfície e o flash fica na sombra dela:
  - na imagem 4, o pilar bem na frente do flash continua escuro (11, contra 45–54 ao lado);
  - na imagem 2, o pilar ao lado do flash vai de 52 no lado do flash a 26 no lado oposto.
- A nossa névoa misturava o céu brilhante só na fração da névoa fina (10–20%). Por isso os pilares ficavam
  pretos e o brilho parecia um disco colado atrás deles.

### Grão do céu

- **No VV:** um grão fino. Desvio de luma (passa-alta) que cresce com a altura:

| Elevação | Desvio de luma |
|---|---|
| 10–20° | ~0,15 |
| 30–37° | 0,3–0,6 |
| 40–45° | 0,5–0,9 |

  - É um pouco mais forte no azul e correlacionado em 1–2 px.
  - É a textura vanilla do céu do End aparecendo por baixo das "atmosféricas" do VV.
- **No seu Java:** liso (0,04–0,2, só o dither).

## 3. Como foi feito

Tudo fora do jogo: medições, modelos numéricos e compilação. Não renderizei no Minecraft.

1. **Painel de design.** Três modelos independentes (físico, ajuste empírico, direção de arte) e um juiz que
   recalculou as previsões de cada um.
   - O vencedor combina:
     - a luz somada em "gama 2" de um modelo;
     - a sombra volumetric em espaço de tela de outro.
   - **Erro nos 16 pontos de controle:** 2,9 de luma, contra 12,6 da névoa antiga.
2. **Revisão adversarial.** Quatro revisores (correção, Vitrail, calibração, opções/docs), cada um com um
   cético tentando derrubar os achados.
   - 13 problemas confirmados, todos corrigidos. Os dois graves:
     - a borda de longe era misturada duas vezes durante o flash, e a borda da ilha "piscava" no início e no fim
       de cada flash;
     - a marcha com 12 amostras fixas pulava objetos finos e quebrava a sombra em faixas.
3. **Verificação das correções.** Três checadores. Acharam mais um problema grave (o pilar "acendia" quando o
   flash cruzava a borda da tela) e alguns menores. Todos corrigidos.
4. **Verificação final minha:** a borda da tela, a não-sombra falsa no chão e os pontos de controle.

## 4. O que mudou

### 4.1 A névoa do flash é volumétrica (`final.fsh`, `lib/dimension_ambience.glsl`)

- **Entre flashes nada muda.** A névoa fina e a borda de longe continuam iguais. Conferido no SPIR-V otimizado:
  mesmas instruções.
- **Durante o flash**, o próprio brilho do céu daquela direção é somado como luz espalhada no ar, em luz quase
  linear (gama 2,5):

  ```
  cor = (h^2,5 + fração * ((B + G)^2,5 − B^2,5))^(1/2,5)
  ```

  - `h` é a superfície, `B` o céu, `G` o brilho do céu.
  - A mesma luz levanta muito o preto e pouco o end stone.
  - Uma superfície escura nunca fica mais clara que o céu atrás dela.
  - Longe, o terreno chega exatamente ao céu brilhante.
- **A fração** é `L / (L + 48 / FLASH_FOG_BOOST)` sobre o trecho iluminado `L` do raio de visão:
  - ~56% a 30 blocos e ~71% a 60;
  - nada nos primeiros blocos, para não velar a mão nem o chão aos seus pés.
- **A borda de longe** entra na própria fração. Com brilho zero, a saída é exatamente a de antes, então nada
  "pisca" quando o flash começa ou termina.
- **A névoa fina** não engrossa mais durante o flash. O chão longe do flash mantém o valor, como no VV.
- **Exponente 2,5 e alcance 24**, depois da revisão, com o chão real do pack:

| Configuração | Pilares/mobs (RMS) | Chão (RMS) | Chão sob o brilho na imagem 6 |
|---|---|---|---|
| Gama 2, alcance 16 | 2,38 | 3,85 | +5,8 / +7,7 |
| Gama 2,5, alcance 24 | 2,74 | 2,89 | +2,9 / +4,1 |

### 4.2 A sombra volumétrica (`composite1`, opção `FLASH_FOG_SHADOWS`)

Sem shadow map: funciona do LOW para cima.

- **Princípio:** o flash é uma luz direcional, então o ponto dele na tela é o ponto de fuga dos raios. A
  marcha anda do pixel até esse ponto e vê o que bloqueia a luz de cada trecho do raio de visão.
- **Espessura dos objetos:** cada objeto tem espessura finita, `max(3, 0,2·distância)` blocos.
  - Um pilar escurece o ar na frente do lado dele oposto ao flash (imagens 2 e 4).
  - Pilares e mobs não projetam cunhas escuras infinitas atrás de si.
  - Superfícies contínuas são unidas entre as amostras e até o ponto do flash.
  - Se a marcha sai da tela sobre um objeto que bloqueia, ele é tomado como contínuo até o flash. Assim
    nada muda quando o flash cruza a borda da tela.
  - O chão nunca faz sombra falsa (testado com o flash em vários lados e alturas).
- **Amostras:** uma a cada 8 px em 1080p, de 8 até `FLASH_FOG_TAPS`. Depois disso o espaçamento cresce, mas
  a espessura finita mantém o erro de um objeto fino pulado abaixo de 1/255.
- **União:** guardada em 24 faixas ao longo do raio.
- **Bordas:** suavizadas a 1,2 alturas de tela do flash e quando o flash sai da janela −0,6…1,6.
- **Upsample:** sensível à profundidade. Numa silhueta em que nenhum dos 4 texels vizinhos está na
  profundidade do pixel, usa o texel mais próximo em profundidade numa vizinhança 3×3, sem borda escura.
- **Precisão contra um traçado de raios 3D:**

| Geometria | Erro de luma (rms) | Erro máximo |
|---|---|---|
| Imagem 6 | 0,03 | 0,4 |
| Imagem 2 | 0,12 | 1,1 |
| Imagem 4 | 0,07 | 2,1 |

  - Pilar na frente do flash: 0,00 (verdade 0,00).
  - Pilar ao lado do flash: 0,21 / 0,29 / 0,46 (verdade 0,16 / 0,24 / 0,44).
- **Substitui os raios do flash.** O VV não desenha raios; a sombra da névoa faz os próprios. Com ela ligada,
  `END_FLASH_SHAFTS` e `FLASH_SHAFT_STRENGTH` não fazem nada.

### 4.3 A luz do flash no chão (`lib/gbuffers_forward.fsh`)

- Faces viradas para cima ficam com um quarto da luz direta do flash.
- O chão sob o brilho estava 6–13 luma acima do VV.
- Erro nos pontos de chão iluminado: RMS 3,7, contra 8,7 antes. Na imagem 5, o ponto que estava em #634F42
  fica perto de #544B3A (VV: #534940).

### 4.4 O grão do céu (`END_SKY_GRAIN`, padrão 25)

- **O que é:** a textura vanilla do céu do End a 25% do contraste dela, com o mesmo mapeamento do jogo, então
  gira com o céu.
- **Média 2×2 texels:** sem cintilação de texels menores que um pixel, e com a correlação de 1–2 px do VV.
- **Fade:** entra de ~9° a ~44° de elevação.
- **Simulado depois da mesma compressão webp do print:**

| Faixa | 9–15° | 15–21° | 21–27° | 27–32° | 32–37° | 37–41° | 41–45° |
|---|---|---|---|---|---|---|---|
| Pack | 0,03 | 0,14 | 0,15 | 0,30 | 0,49 | 0,63 | 0,67 |
| VV | 0,13 | 0,16 | 0,25 | 0,38 | 0,52 | 0,58 | 0,70 |

- Para o céu liso de antes, use 0.

## 5. Opções e presets

| Opção | Antes | Agora |
|---|---|---|
| `FLASH_FOG_SHADOWS` | – | ligado do LOW ao CINEMATIC |
| `FLASH_FOG_TAPS` | – | 24 LOW, 32 MEDIUM, 48 HIGH, 64 CINEMATIC |
| `FLASH_FOG_BOOST` 2,0 | densidade da névoa no flash | velocidade com que o ar enche de brilho (metade do brilho a 24 blocos de ar iluminado) |
| `END_SKY_GRAIN` | 0 | 25 (lista 0, 10, 15, 20, 25, 35, 50, 100) |
| `END_DEBUG_MODE` 5 | névoa extra do flash | vermelho = fração do brilho no ar; verde = trecho iluminado |

- O ULTRA LOW não tem flashes, como antes.
- No LOW o `composite1` agora roda em toda dimensão. Fora do flash do End ele só copia o buffer: ~0,01 ms numa
  GPU dedicada, menos de 0,1 ms numa integrada.

## 6. Vitrail (Vulkan)

- **Compilação:** os programas mudados foram convertidos para GLSL 450 de Vulkan e compilados com
  `glslangValidator -V` mais `spirv-val` em todos os presets. Zero erros.
- **Interface:** as entradas e saídas do `composite1` batem entre os dois estágios.
- **Expressões `program.*.enabled`:** conferidas com a gramática do Vitrail (portada do código-fonte).
- **Regras seguidas:** loops com limite constante, operações `uint` dentro do intervalo, `smoothstep` em ordem,
  nada lido sem inicializar, `pow` só com base ≥ 0.
- **Não verificado:** a tradução real do Vitrail, porque precisa do jogo.

## 7. Custo

Estimativas, não medições.

| Item | Custo |
|---|---|
| Marcha durante um flash, 1080p, GTX 1060 | ~0,2 ms com 32 amostras; ~0,25 ms com 48 |
| Marcha em 4K | ~4× |
| Upsample no `final`, por pixel de terreno com brilho | 4 depths + 4 leituras; na silhueta mais 9 |
| Sem flash | nada |
| Grão do céu | 4 leituras de textura por pixel de céu acima de ~9° |
| No LOW | +1 passe de cópia em ¼ de resolução |

## 8. Teste no jogo

1. Preset MEDIUM, ilha do End, `/gamerule advance_time true`.
2. **Durante um flash, olhe para o brilho com pilares na frente.** Deve aparecer:
   - os pilares a 20–60 blocos enevoados de roxo, mais claros no lado do flash;
   - um pilar bem na frente do flash escuro;
   - o chão claro só levemente roxo;
   - nada de borda piscando no começo ou no fim do flash.
3. **Gire até o flash sair pela borda da tela:** o pilar que o esconde não pode acender.
4. **Céu acima de ~30°:** grão fino e leve, mais visível olhando para cima.
5. **Debug:** `END_DEBUG` modo 5 mostra a névoa (vermelho) e a sombra dela (verde).

## 9. Limites conhecidos

- **Dois pontos ~5,5 luma abaixo do VV:**
  - o lado do flash do pilar da imagem 2;
  - o lado oposto do pilar direito da imagem 6.
  - A marcha bate com a verdade 3D nesses pontos. A diferença vem da forma do brilho.
- **Objetos finos perto da câmera** (uma haste a 10 blocos) escurecem um pouco demais a névoa atrás deles:
  no máximo −2,3 de luma.
- **Um enderman cobrindo o flash** a ~30 blocos, de pé no chão: a sombra no ar junto aos pés dele pode
  passar ~6–19 de luma (tem a mesma profundidade do chão).
- **Distâncias e FOV das referências são estimados.** Se a névoa encher rápido ou devagar demais no seu jogo,
  ajuste `FLASH_FOG_BOOST`.
