# Update 1: soft sun rays, clouds that hide the sun, dynamic shadow colours, underwater caustics

Pack: Vanilla Cinematic Lite. Game actually running: Minecraft 26.3, Iris 1.11.7, Sodium 0.9.2,
Fabric (not 1.21.1). Backup of every file as it was before this update:
`backup/2026-10-04_before_update1/` (whole `shaders` folder and README, taken before any edit).

## 1. Capability check

- I have no screen-capture or desktop computer-use tool that can see the Minecraft window. The
  two browsers in this session only see web pages. I did not capture anything from the game.
- What I could do instead:
  - read your reference image's pixels (System.Drawing);
  - compile all programs for 103 option sets in a WebGL2 harness;
  - run render tests that execute the pack's own code. The harness extracts final.vsh's
    visibility taps and final.fsh's veil/rim/shaft block from the files, and uses
    `lib/sun_rays.glsl`, `lib/ambience.glsl` and `shadowColorResponse` as they are.
- These tests check colours, smoothness and absence of noise; they are not the game.

## 2. Your reference, measured (pixel sampling of the attached 770 x 735 image)

| Element | Your estimate | Measured | Notes |
|---|---|---|---|
| Sky far from the sun | #6E9AEA | #7098E8 (corner), #7B9CEA (above the sun), #84A1EA (180 px left) | cornflower, grain SD 0.31-0.48 |
| Sun interior | #FFF6D8 | #FFFBF1 to #FFFDF3, outer texel ring #FFF6E5 | whiter than the estimate; ~84 px square, half size ~42 px |
| Halo right above the sun | - | #B9BFED (15 px), #A5B2EB (55 px), #92A7EB (110 px) | smooth exponential falloff |
| "Concentric rings" | do not want | 8-bit plateaus: the luma drops by 1 every 8-16 px, no dither | plain banding, not a ring term |
| Stone (shaded faces) | #7C8CB0 | #4E5A7F to #555F83 | darker than the estimate |
| Rim on the edge under the sun | #E8D8A0 | #D3B689 / #D4B585 (as rendered) | golden: (1.00, 0.82, 0.50) mixed in at about 0.55 |
| Stone just below the sun | - | +3 px #C6A882, +12 #AD9A8E, +30 #8A8289, +54 #7B7687, base #5C6079 | a warm bleed over about 60-70 px |
| Stone in front of the disc | - | #D6C09E falling to #7E7A90 within ~65 px to the right | warm, strongest inside the disc area |
| Cloud body (seen from below) | #F2DDE8 | #DACEE0 (#D8CCDF..#DBCCDF); far, lower clouds #C1BDDD | opaque, pale lavender-pink |
| Cloud edges | lighter | 1 px #DCDCFF (bluish white), then a lighter band #E3D1DD..#E6D6E2 | the thin outline is the side face seen edge-on |
| Cloud gradient | - | #E1D1DD on the sun side to #CFC7DE on the far side | brighter toward the sun |
| Floating strip | - | #71748C | part of your world |

- **What I see besides your list.** The glow does spread onto the stone, but only right around the
  sun: the stone in front of the disc is strongly warmed, and that fades to the normal stone colour
  within about 1.5 sun sizes. The far halo stops at the silhouette. The rim is golden, not
  pale yellow.
- **How the previous pack compared.**
  - The sky glow was close: v5 was fitted to a very similar profile.
  - The rim was a 1.5/3.5-pixel line with a binary sky test, no facing term and no scaling with
    resolution.
  - The veil was there but weaker and less golden than the reference bleed.
  - Translucent clouds let the sun show through.
  - There were no shafts.

## 3. Code review (before this update)

| # | File / function | Finding | Severity | Fix in this update |
|---|---|---|---|---|
| A1 | final.fsh rim block | 2 depth taps at 1.5 and 3.5 px (not resolution-scaled), hard `depth > 0.99999` test, no facing term: a 1-px line that crawls with the geometry and is thinner at 4K | medium | 3/4/6 resolution-scaled taps with smooth weights, smooth sky mask, depth-derived normal weighting (`lib/sun_rays.glsl`) |
| A2 | final.vsh `sunTap` | Point taps (`textureLod` on the nearest depth texture). V jumped by 1/13 (7.7 %) each time an edge crossed a tap, so the veil and rim popped slightly | medium | Bilinear area taps (4 bilinear samples each); test: largest V change 3.5 % per 0.05 degree of sun motion |
| A3 | final.fsh rim | Faded with sqrt(V): vanished when a block hid the sun completely, and the moment the sun's centre sank below an edge while the disc still showed | low | 55 % "silver lining" when hidden by blocks (none behind clouds); taps away from the centre inside the disc area; test: rim continuous through every 0.05 degree step |
| A4 | final.vsh / final.fsh | Clouds counted as 35 % occluders (translucent), so the veil and rim stayed on behind clouds | medium | Opaque clouds plus a separate cloud-cover value |
| A5 | composite / final | No shafts at all since v5 removed the noisy ones | - | New deterministic shafts (composite mask + composite1 march + bilateral upsample) |
| A6 | colortex5 | Bloom, shallow-water shafts and pollen are summed in RGB and upsampled bilinearly (not depth-aware), so they can bleed about 4 px over silhouettes | info, out of scope | Not touched; the new shafts use alpha with their own depth-aware upsample |
| A7 | banding | colortex0 is RGBA16F and final already applies a static triangular dither (SKY_DITHER 0.75/255) | ok | Kept. Harness: flat-sky SD 0.53 with dither, 0.39 without (gradient only) |
| A8 | shadow map | The sun system reads no shadow map (composite reads `shadowtex1` only for the shallow-water shafts and two debug views) | ok | Still true; rim and shafts use only `depthtex0` and the cloud marker |
| A9 | composite.fsh shallow-water shafts | Built from `noisetex` (noise streaks), named RAY_INTENSITY / RAY_LENGTH | info, out of scope (water) | Reported only |
| B1 | gbuffers_clouds.fsh | alpha = min(0.65 x ..., 0.95): the analytic sun that gbuffers_skybasic draws behind the clouds showed through at 35 % | high (the reported bug) | CLOUDS_BLOCK_SUN: alpha = CLOUD_OPACITY (1.0) |
| B2 | gbuffers_clouds.fsh | Far edge faded by alpha, so the sun also showed through far clouds | medium | Colour fade: haze toward the same sky function; at the mesh edge the full sky with the disc, marker opacity fading with it |
| B3 | draw order / depth (verified in the 26.3 jar) | Sky pass (analytic sun, vanilla moon and stars) → solid → classic translucency → `CloudRenderer.render` → weather. The CLOUDS pipeline uses `DepthStencilState.DEFAULT` = (GREATER_THAN_OR_EQUAL, write = true): vanilla clouds write depth | ok | Opaque clouds therefore overwrite the sun, moon and stars completely. Under Iris the depth state follows the pipeline; not verifiable without the game, and the cloud marker makes it irrelevant for final |
| B4 | final.fsh sky | The sun disc is rebuilt on sky pixels only (`!cloudPixel`); the glow sits on sky pixels and in skybasic | ok | Unchanged; the cloud's own glow-through replaces the glow on clouds |
| C1 | gbuffers_forward `shadeFragment` | Shadow factor applied as `base *= 1 - (1 - shadow) * litBySky * nDotL * 0.34`: at most 34 % darker, never black | ok | Unchanged shape and strength for terrain casters |
| C2 | same, ATMOSPHERIC_GRADE | Constant cool shade tint (0.945, 0.98, 1.045) | low | Follows the ambient sky light when SHADOW_COLORS is on |
| C3 | ambience terrain response | Shade already gets the palette sky-light hue x ENV_SHADOW_COOLNESS (biome only 12 %) | ok | Kept; the new shadow colour comes on top |
| C4 | shadow.fsh | Writes black to shadowcolor0 ("deliberately ignored"); no entity distinction anywhere | - | New `shadow_entities` program writes an entity flag |
| C5 | cloud shadows | Exist (CLOUD_SHADOW_ENABLE): computed once per fragment, multiplied into the shadow factor, reused by caustics and wave light | ok | Reused for sunStrengthEff, with no new fetch |
| C6 | rain | Shadow-map shadows keep full darkness in rain | low | Player/mob shadows now weaken in rain; terrain unchanged (see notes) |
| C7 | Nether / End | `overworld` gate: no shadow-map darkening there at all | info | Nothing to tint there; unchanged |
| D1 | gbuffers_forward underwater route | Opt-in, off by default; used `eyeBrightnessSmooth` (lagging) only as a fade | - | Default ON; surface height estimated from the instant `eyeBrightness` |
| D2 | same | Exclusion was `vPlayerPosition.y < 2.0`: terrain up to 2 blocks above the eye (shore blocks above water seen from below) got caustics | high | Surfaces at or above the estimated surface get none; faces touching air under open sky (sky light 15) get none |
| D3 | same | No depth fade, no absorption, walls at full strength at any depth (column unknown = -1) | medium | The same CAUSTIC_FULL_DEPTH / CAUSTIC_FADE_DEPTH fades, absorption and wall depth fade as outside |
| D4 | same | Fixed 32-40 block distance, unrelated to the underwater fog | low | Tied to `fogEnd` (vanilla water fog) |
| D5 | pass order | Caustics before the liquid fog (end of shadeFragment); final skips its haze underwater | ok | Kept |
| G1 | shaders.properties | `program.composite.enabled` would not include the shaft mask | - | Adds SUN_SHAFTS and LIGHT_DEBUG; `program.composite1.enabled = SUN_SHAFTS \|\| LIGHT_DEBUG` |
| G2 | presets | All define all options | ok | Now 233 options (65 booleans, 168 values), all in every preset |

**Other stale or inherited settings (reported, not changed):**
- RAY_INTENSITY and RAY_LENGTH drive the shallow-water shafts, not sun rays.
- BIOME_TINT_STRENGTH, SKY_GRADE, ATMOSPHERIC_HAZE and the golden haze act only with the Ambience
  options off.
- The debug placeholders VV_DEBUG 2, ATMOS_DEBUG 2 and TARGET_DEBUG 2/6 show black.
- The `atmos*` category uniforms rely on Iris CAT_* values (CAT_SAVANNA is never assigned) and
  still feed the golden grade and pollen.
- ULTRA LOW and LOW keep ENTITY_SHADOWS off, so the player casts no shadow there.
- With both AMBIENCE_CLOUDS and AMBIENCE_COLORS off, Iris draws its own translucent clouds, and
  CLOUDS_BLOCK_SUN cannot act.

## 4. Verified in the jars (no invented names)

- **Iris ProgramId** includes `ShadowEntities` (falls back to `Shadow`). ShaderKey has
  `SHADOW_ENTITIES_CUTOUT` and `CLOUDS` / `CLOUDS_SODIUM`.
- **`eyeBrightness`:**
  - computed as (block x 16, sky x 16) at `BlockPos.containing(entity.position().x, getEyeY(), z)`,
    read every frame;
  - not smoothed, unlike `eyeBrightnessSmooth`;
  - uses the tick position, so it can lag the interpolated camera by one tick, which is why the
    estimate is smoothed over 0.3 s.
- **Custom uniform inputs.** Custom uniforms get `CommonUniforms.addNonDynamicUniforms`:
  `eyeBrightness`, `isEyeInWater`, camera uniforms and the rest.
- **Shadow colour targets.** `shadowcolor` samplers exist (IrisSamplers, ShadowRenderTargets).
- **Vanilla 26.3.** Pass order and cloud depth state as in B3 above.

## 5. Design notes

### A. Rim, bleed and shafts

- **Sky glow.**
  - Unchanged and still drawn on sky pixels only: thin bloom, mid glow, faint halo and the slow
    analytic ray lobes (RAY_VARIATION).
  - Blocks and clouds hide it.
  - The disc is drawn after the glow, so the glow never covers the sun square.
- **Rim.**
  - *Where.* Only on non-sky, non-cloud pixels right around the sun (`ambRimFalloff`), and only
    when the taps toward the sun find open sky. Edges turned away from the sun have no sky in that
    direction, so they get nothing: the test shows 0 on the side silhouette and 0 farther than
    300 px from the sun.
  - *Taps.* 3, 4 or 6 depth taps toward the sun's screen position. Offsets are 2-14 px at 1080p,
    scaled with the resolution and RIM_REACH. Smooth weights give a bright edge and a soft bleed.
  - *Sky mask.* Smooth: sky = 1, a cloud = 1 - opacity, terrain = 0 rising to 1 near the render
    distance.
  - *Normal weighting.* A depth-derived normal (closer-neighbour rule) weights the rim: full on
    faces turned to the sun, 65 % on backlit faces. A strict normal-versus-sun test would have
    removed your reference rim, because those stone faces point away from the sun (the camera
    looks up at them).
  - *Colour.* Golden, fitted to #D4B585.
  - *No pops.* Driven by the smooth V; inside the disc area the taps also look away from the
    centre.
- **Shafts (MEDIUM and up).**
  - composite builds a pre-filtered open-sky mask at quarter resolution (4 taps per pixel, box
    filter) in colortex5.a.
  - composite1 marches 12-16 fixed samples toward the sun over the bilinear mask. The ray is short
    (capped), weights are Gaussian-like, and there is no jitter.
  - final applies the shafts only on non-sky pixels. It uses a 4-tap depth-aware upsample, a
    smooth cone and fade, and a screen blend that can never exceed white.
  - Default 0.10: barely visible. Test: +5/255 at the edge under the sun, at most 1/255 far away.
- **Fades.** Sun behind the camera or off screen (NDC 1.0-1.35), below the horizon, rain and
  thunder (`ambSunGlowVisibility`), indoors (eye sky light), underwater, Nether and End: all smooth
  or tied to a state switch.
- **Why no artifacts.** No random numbers anywhere. Every tap position is a fixed function of the
  pixel and the sun position. The only per-pixel pattern is the existing invisible dither in the
  last step.
- **What it cannot do.**
  - True volumetric light through leaves (that needs the shadow map, which you excluded).
  - Shafts behind off-screen occluders.
  - Rims on edges whose sun-side sky is off screen.
- **Cost (estimates, not measured).**

  | Part | GTX 1050 Ti, 1080p | RTX 3050 |
  |---|---|---|
  | Rim, 3 taps (LOW) | ~0.04-0.08 ms, only near the sun | |
  | Rim, 4 taps + shafts (MEDIUM) | ~0.15-0.22 ms | ~0.05-0.08 ms |
  | V in the vertex shader | under 0.005 ms | |

### B. Clouds hide the sun

- **Primary method used (no fallback needed).** In vanilla 26.3 clouds are drawn after the sky,
  and gbuffers_skybasic draws the analytic sun behind everything. So alpha 1 is enough to
  overwrite the sun, the moon and the stars.
- **Distance fade.** Far clouds fade by colour toward the same sky function, so the horizon still
  matches. At the far edge of the cloud mesh they become the full sky, disc included. The marker
  opacity fades there too, so V, the rim and the shafts stay consistent.
- **Colours: opaque fit to your reference.** Base biome, midday, harness:

  | Cloud face | Pack | Your reference |
  |---|---|---|
  | Underside as seen from below | #D9CFDF | #DACEE0 |
  | Side faces | #D7DEF9 | #DCDCFF |
  | Top faces (not visible in it) | #E3D4DC | - |

  - Golden at a low sun (#F1C49F), warm-white in deserts, grey in rain.
  - CLOUD_OPACITY 0.65 still gives exactly the v5 translucent fit (#A0B1EE / #ACB7EE vs the v5
    targets #A1B0ED / #AAB4F2).
- **Sun behind a cloud.**
  - The disc is hidden; V = 0.000 and cover = 1.000 in the test.
  - The cloud gets a soft analytic patch (CLOUD_SUN_GLOW_THROUGH): #E9E1E6 at the sun, #E3DAE3 at
    80 px.
  - It is analytic in the angle, so a drifting cloud edge cannot flicker.
- **Fast vs Fancy.** Fast clouds are one flat layer (top and bottom colours, no side faces);
  Fancy clouds have 4-block boxes with side faces. Both are opaque with depth writes. With clouds
  off, nothing runs and nothing breaks.
- **Cost.** About 15 ALU per cloud pixel, plus one sky evaluation only at the far mesh edge. Under
  0.02 ms (estimate).
- **Limit.** Translucent "thin" clouds are gone unless you lower CLOUD_OPACITY.

### C. Dynamic shadow colours (terrain receivers)

- **Ambient.**
  - The palette sky light with the biome zenith tint, evaluated per vertex. The sky dome lights
    the shade, not the horizon haze.
  - Snowy biomes keep the clear blue sky light.
  - No new texture fetch.
- **Tint.**
  - Luminance-preserving hue push toward the ambient, a mild saturation boost with a neon clamp,
    and a surface response from the albedo and block.properties groups.
  - The same tint reaches back faces, so a shaded face and a cast shadow meet without a seam.
  - Harness, midday (lit-in-shade → player/mob shadow, then terrain at 0.6):

    | Surface | In shade | Player/mob | Terrain |
    |---|---|---|---|
    | Snow | #A0A2A5 | #97A2BB | #9BA2B2 |
    | Grass | #3D5E2A | #385F2B | #3A5F2B |
    | Sand | #918768 | #8D876E | |
    | Stone | #545454 | #51545C | |
    | Dirt | #59402C | #523C2B | |

  - Sunset: snow #9AA0C9 (violet-blue). Jungle: snow #86A7B6 (teal).
- **Player and mob shadows.**
  - `shadow_entities.fsh` writes R = 1 into shadowcolor0. Terrain reads it at the same snapped
    texel as `getShadow`, only on shadowed fragments: 2 fetches.
  - Darkness = mix(SHADOW_MIN_DARKNESS, SHADOW_MAX_DARKNESS, sunStrengthEff).
  - sunStrengthEff = sun elevation (moon 0.35) x your existing cloud-shadow value x weather.
  - Result: as dark as before in full sun, weaker under clouds, a faint soft shape in rain, never
    below the floor.
- **Untouched.** Shadow map generation, shape, resolution, grid and filtering. Water, the gloss,
  entities as receivers, the Nether and the End, caves, and the view with the camera underwater.
- **Cost.** About 40 ALU per terrain fragment and +1 palette column per terrain vertex: ~0.03-0.05
  ms (estimate).
- **Limits.**
  - Terrain shadows keep their darkness in rain, as before; only player/mob shadows follow the
    weather rule, as specified.
  - Entities receiving shadows are unchanged (scope).
  - LOW has no entity shadows at all.

### D. Underwater caustics

- **Surface height.**
  - Computed once per frame on the CPU: `vclWaterSurfaceY = smooth(floor(cameraY) + 14.889 -
    eyeBrightness.y / 16, 0.3, 0.3)`.
  - Water has light opacity 1, so in an open column the top water block sits (14 - eye sky light)
    blocks above the eye block. A source block's surface is 8/9 up.
- **Per pixel.** Caustics need: receiver depth > 0 (smooth), sky light below 15 (not touching
  air), the same depth fades and wall fade as outside, absorption, the shadow map, cloud shadow,
  sun, rain and night fades, a distance tied to the water fog, and UNDERWATER_CAUSTIC_STRENGTH
  0.8.
- **Order.** Applied before the underwater fog.
- **Crossing the surface.** A fade over the first 0.4 blocks of camera depth. The outside route
  already fades out as the eye nears the surface, so both are 0 at the boundary and nothing pops.
- **Fallbacks.** If the custom uniform fails, or the eye has no sky light in an ocean,
  UNDERWATER_SEA_LEVEL is used. The first case is a safety net; the second rarely matters.
- **Failure cases.**
  - Under a roof or overhang the estimate reads too high, so caustics are dimmer; the shadow map
    removes them where the sun is blocked anyway.
  - In cave pools there is no sky light, so they are off.
  - Flowing water and waterfalls (surface lower or sloped): small errors, or faded by depth.
  - In third person the eye is not the camera.
- **Cost.** Same per pixel as the outside route, only while underwater: ~0.08-0.12 ms on a GTX
  1050 Ti in LOW when the floor fills the screen (estimate).

## 6. Files

- **New.**
  - `lib/sun_rays.glsl`
  - `composite1.vsh`, `composite1.fsh`
  - `shadow_entities.vsh`, `shadow_entities.fsh`. These are new shadow programs: same projection,
    distortion and alpha test as shadow.*, plus the flag. ENTITY_SHADOW_FLAG off makes the output
    identical to shadow.fsh.
- **Changed.**
  - `lib/settings.glsl`
  - `lib/ambience.glsl`: cloud opaque fit, rim colour, cloud glow, shadow ambient.
  - `lib/sun_rays.glsl` users: `final.vsh` (area taps, cloud cover) and `final.fsh` (rim, shafts,
    debug).
  - `composite.fsh`: mask in alpha.
  - `gbuffers_clouds.fsh`
  - `lib/gbuffers.vsh`: one terrain-only output.
  - `lib/gbuffers_forward.fsh`
  - `shaders.properties`
  - `lang/en_us.lang`
- **Shared files where the change is gated.**
  - `lib/gbuffers_forward.fsh` and `lib/gbuffers.vsh` are shared with water and entities. Every
    new line there is inside `TERRAIN_LAYER` / `TERRAIN_GBUFFER`, except the split of the
    cloud-shadow block, whose result is identical.
  - Water, textured_lit (entities, gloss) and shadow.* behave exactly as before.
- **Unchanged (byte-identical to the backup).**
  - shadow.vsh/fsh, gbuffers_water.vsh/fsh, lib/water_reflection.glsl
  - gbuffers_terrain.*, gbuffers_textured_lit.*, gbuffers_skybasic.*, gbuffers_clouds.vsh,
    composite.vsh
  - block.properties, lib/shadow_distortion.glsl, textures/clouds.png

### Options

- **Renamed.** EDGE_RIM_STRENGTH → RIM_STRENGTH. Your old value resets to the fitted 0.80.
- **New booleans.** SUN_SHAFTS, CLOUDS_BLOCK_SUN, SHADOW_COLORS, ENTITY_SHADOW_FLAG, LIGHT_DEBUG.
- **New values.**
  - Rim and shafts: RIM_STRENGTH 0.80, RIM_REACH 1.50, RIM_TAPS 4, SHAFT_STRENGTH 0.10,
    SHAFT_LENGTH 0.30, SHAFT_SOFTNESS 0.50, SHAFT_SAMPLES 12.
  - Clouds: CLOUD_SUN_GLOW_THROUGH 0.45.
  - Shadow colours: SHADOW_COLOR_QUALITY 2, SHADOW_COLOR_SATURATION 0.15, SHADOW_HUE_PUSH 0.50,
    SHADOW_MIN_DARKNESS 0.25, SHADOW_MAX_DARKNESS 1.00, ENTITY_SHADOW_COLOR_STRENGTH 1.00,
    TERRAIN_SHADOW_COLOR_STRENGTH 0.60.
  - Underwater: UNDERWATER_CAUSTIC_STRENGTH 0.80, UNDERWATER_SEA_LEVEL 63.
  - Debug: LIGHT_DEBUG_MODE 1-17.
- **Changed defaults.** CLOUD_OPACITY 0.65 → 1.00 (0.95 added to the list); CAUSTICS_UNDERWATER_FLOOR
  off → on.
- **Menu.**
  - Ambience → Sun Rays (was "Sun and Sky Glow") and Clouds.
  - New top-level Shadow Colors.
  - Water → Caustics → Underwater Caustics.
  - Debug → LIGHT_DEBUG.

### Presets (all 233 options in every preset)

| Preset | Rays | Clouds | Shadow colours | Underwater caustics |
|---|---|---|---|---|
| ULTRA LOW | Analytic glow only (no rim, no shafts) | Opaque | Ambient tint only (quality 1) | Off |
| LOW | + rim, 3 taps | Opaque | + surface response (quality 2) | Floors only (walls off as before) |
| MEDIUM (default) | + shafts (12 samples, 0.10), rim 4 taps | Opaque | + separate player/mob shadows | On |
| HIGH | Rim 6 taps, 14 shaft samples | Opaque | As MEDIUM | On |
| CINEMATIC | Rim 6 taps, 16 shaft samples | Opaque | As MEDIUM | On |

## 7. Debug views (LIGHT_DEBUG_MODE)

| Mode | Shows | What to expect |
|---|---|---|
| 1 | V in yellow and cloud cover in blue, full screen | smooth changes |
| 2 | Shaft open-sky mask | soft, no grain |
| 3 | Rim alone | only on edges turned to the sun, around it |
| 4 | Shafts alone (x4) | |
| 5 | Clouds: red = marker opacity, green = depth | |
| 6 | Hidden by cloud: red over the sun square, blue over the moon, cyan at night | |
| 7 | sunStrengthEff | |
| 8 | Shadow colours split screen | left without, right with |
| 9 | Ambient colour used for shadows | |
| 10 | Shadow caster | red = entity, blue = terrain |
| 11 | Camera in water, plus the surface-fade bar | |
| 12 | Camera depth below the surface | grey = depth / 16 |
| 13 | Height against the estimated surface | blue below, red above, white line at the surface |
| 14 | Water surface in front | white when seen from below |
| 15 | Depth fade | |
| 16 | Underwater fog transmittance | |
| 17 | Caustic light | |

## 8. Test results I could run

- **Compile.**
  - 103 option sets x 10 programs = **1030 compiled and linked, 0 failures**. The option sets cover
    all presets, all 17 LIGHT_DEBUG views, toggles off and other combinations.
  - WebGL2 is not desktop GL 3.30 compatibility; Iris may still report something.
- **Render test, rim** (the pyramid scene, sun just above the apex, same size and FOV as your
  image):

  | Offset below the edge | Pack | Your reference |
  |---|---|---|
  | +0 | #BEAB92 | #D3B689 |
  | +3 | #A59C96 | #C6A882 |
  | +12 | #838698 | #AD9A8E |
  | +30 | #777D98 | #8A8289 |

  - The edge and its shape match well. The wider warm area is weaker than in the reference because
    the veil keeps its approved strength; raise VEIL_STRENGTH to 0.45-0.60 to get closer.
  - Rim on a side silhouette: 0. Far from the sun: 0.
- **Smoothness.**
  - V changes at most 3.5 % per 0.05 degree of sun motion.
  - The rim stays at 60-61/255 at every step as the sun sinks behind the apex, including while its
    centre crosses the edge.
- **Grain.** Flat-sky luma SD 0.53 with the dither (0.39 without), the same as v5.
- **Clouds.** V = 0.000 and cover = 1.000 behind the slab. The pixel at the sun centre is cloud
  #E9E1E6 (glow patch), no disc.
- **Shadow colours.** As in 5C.
- **Not run.** In-game look, real FPS, Iris buffer flipping for composite1, shadowcolor0 behaviour,
  the custom uniform at run time, and everything with the camera underwater.

## 9. Test plan (in game)

**Setup.** Same world and seed. HUD hidden (F1). FOV 70, 12 chunks, MEDIUM unless stated.

### A. Rays

1. Stand so the sun sits just behind a stepped stone peak, like the reference.
   - Expect a thin golden rim on the step edges under the sun, fading over a few pixels.
   - Expect nothing on the side edges, and no glow over the stone farther than about 1.5 sun sizes.
2. Repeat behind a tree trunk, behind leaves (faint shafts in the gaps), a single block, and
   between two blocks.
3. Turn 360 degrees slowly, then quickly. Expect no grain, flicker, shimmer or halo, and no rings
   in the halo (LIGHT_DEBUG 1 shows V moving smoothly).
4. Sun at the screen edge, then just off screen: rim and shafts fade out smoothly. Look away: no
   effects.
5. Sunrise and sunset: the rim turns orange. In rain everything fades strongly.
6. Resolutions 720p, 1080p, 1440p, 4K; GUI scales; FOV 30-110: the rim keeps the same relative
   width.

### B. Clouds

1. Let a cloud drift over the sun. Expect the disc fully hidden, a soft bright patch on the cloud,
   no pop at the cloud edge, and V and cover changing smoothly (LIGHT_DEBUG 1, 6).
2. Gaps between clouds: faint shafts (MEDIUM).
3. At night the moon and stars disappear behind clouds.
4. Distant clouds melt into the horizon with no band. Repeat with Fast clouds, Fancy clouds and
   clouds off.

### C. Shadows

1. Player and a mob on grass, snow, sand, stone, wood and dirt, at midday, golden hour and sunset.
2. Repeat under a cloud shadow, in rain, and in jungle, desert and snowy biomes.
3. Expect natural tints, never black; player shadows weaker under clouds and faint in rain;
   terrain shadows only gently changed (LIGHT_DEBUG 8 split, 10 flag, 7 strength).

### D. Caustics underwater

1. Swim in a shallow pool and in deep water. Look at the floor and walls, then up at the surface:
   no caustics on it, nor through the "window" (LIGHT_DEBUG 13, 14).
2. Cross the surface up and down repeatedly: no pop (LIGHT_DEBUG 11).
3. Under a roof (dimmer or none), in a cave pool (none), at night (none), in rain (much weaker),
   far from spawn.
4. Press F3 at 1, 2 and 5 blocks below an open surface: the sky light should read 14, 13 and 10.
   LIGHT_DEBUG 12 should show depth/16.

### E. Performance

- Compare FPS with the toggles on and off: SUN_SHAFTS, SUN_EDGE_RIM, SHADOW_COLORS,
  CAUSTICS_UNDERWATER_FLOOR.
- All the numbers above are estimates.

### F. Regression

- Toggle everything off (SUN_SHAFTS, CLOUDS_BLOCK_SUN with CLOUD_OPACITY 0.65, SHADOW_COLORS,
  CAUSTICS_UNDERWATER_FLOOR) and compare with v6. Water, shadow shape and grid, entity gloss,
  biome palettes and the rest must match.

## 10. Screenshots I would like from you

- **Conditions.** Same coordinates and camera for before and after. F1. FOV 70. 1080p.
- **Before shots.** Use the backup pack.
- **The shots.**
  1. Sun behind a stone peak.
  2. Sun behind a cloud.
  3. Player on grass, sun at about 45 degrees.
  4. Player on snow, same sun.
  5. Player in a cloud shadow.
  6. Underwater floor with caustics.
  7. The surface seen from below.
- **Also useful.** LIGHT_DEBUG 1, 3, 10 and 13 for shots 1, 3 and 6. If anything fails to load,
  send `latest.log`.
