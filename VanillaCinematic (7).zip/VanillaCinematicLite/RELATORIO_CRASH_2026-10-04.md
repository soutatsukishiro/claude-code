# Relatório do crash: 04/10/2026

## Sintoma
O jogo fechava ao entrar no mundo com o shaderpack ativo. Há 3 relatórios de crash idênticos
(`crash-reports/crash-2026-10-04_17.22.34`, `17.27.34` e `17.28.07`):

```
Description: Uploading texture
java.lang.IllegalStateException: Close the existing render pass before performing additional commands
  at ...ReloadableTexture.doLoad
  at ...TextureManager.getTexture
  at net.irisshaders.iris.pipeline.CustomTextureManager.lambda$createCustomTexture$1
  ...
-- Uploaded texture --
  Resource location: minecraft:textures/environment/clouds.png
```

## Causa
- Na rodada anterior eu adicionei ao `shaders.properties` a linha
  `customTexture.vclClouds = minecraft:textures/environment/clouds.png`. Ela serve para as sombras das
  nuvens lerem as células das nuvens vanilla.
- O seu jogo é o **Minecraft 26.3**, não o 1.21.1. Nessa versão, o `CloudRenderer` lê o `clouds.png` na
  CPU e nunca o envia para a GPU como textura registrada.
- Por isso, o Iris 1.11.7 só carregava a imagem no primeiro desenho que usava a textura, com um render
  pass já aberto. O motor de renderização do 26.3 proíbe enviar uma textura nesse momento, e o jogo fechava.
- **Não era erro de compilação.** O `latest.log` mostra que o pipeline foi criado e todos os programas
  compilaram.
- **Responsabilidade:** o erro foi meu. Usei uma textura do jogo carregada sob demanda, sem saber que o
  26.3 não registra essa imagem.

## Correção
1. **Cópia do `clouds.png` dentro do pack.** Copiei o `clouds.png` original do seu próprio jar do 26.3
   para `shaders/textures/clouds.png`. É uma cópia para uso pessoal: apague-a antes de compartilhar o
   pack com outras pessoas, porque é um arquivo da Mojang.
2. **Carregamento ao criar o pipeline.** O `shaders.properties` agora usa
   `customTexture.vclClouds = textures/clouds.png`. O Iris carrega PNGs do próprio pack quando cria o
   pipeline, antes de qualquer desenho. Esse é o caminho usado por outros packs com texturas próprias.
3. **Toggle de segurança.** A nova opção `VANILLA_CLOUD_CELLS` (menu Ambiência → Cloud Shadows) controla
   essa textura. Desligada, o pack não carrega textura nenhuma e as sombras usam células procedurais.
   Se algum dia a textura voltar a dar problema, desligar essa opção é a saída.

## Outros problemas corrigidos na mesma revisão
- **Opções que o Iris descartava.** Várias opções estavam declaradas duas vezes, e o Iris descartava 17
  delas. Algumas (bloom, raios, grade do céu) ficavam sempre ligadas, até no ULTRA LOW. Agora cada opção
  tem uma única declaração.
  - O log do teste das 17:27 confirma: das 17 opções, só 3 ainda não eram resolvidas, e essas 3 também
    foram corrigidas.
  - Efeito visível: **o ULTRA LOW e o LOW vão parecer diferentes**, porque agora desligam de verdade o
    que o preset pede (e ficam mais rápidos).
- **Brilho de borda dos mobs.** `FRESNEL_STRENGTH` tinha duas definições. Desde a v3.2, a borda de brilho
  do player e dos mobs estava 14× mais forte. A opção da borda virou `GLOSS_FRESNEL` (0,07).
- **Sombras de entidades.** `shadowEntities = ENTITY_SHADOWS` era ignorado. Agora o properties usa
  `#ifdef` com true/false.

## Verificação
- **WebGL2 (navegador):** compilei e linkei todos os programas em GLSL ES 3.00, que é mais rígido que o
  GLSL 330. Foram 35 conjuntos de opções (padrão, os 5 presets, Ambiência desligada, combinações e todos
  os modos de debug): 245 de 245 passaram. Também confirmei que o teste detecta um erro inserido de
  propósito.
- **No jogo:** não consigo rodar o jogo daqui, então a correção do carregamento da textura ainda precisa
  ser confirmada por você.
- **Backup:** a versão anterior a toda esta rodada está em `backup/2026-10-04_before_ambience/`.
