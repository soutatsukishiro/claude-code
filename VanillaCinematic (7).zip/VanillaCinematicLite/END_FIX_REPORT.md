# End fix (Update 3.1): céu cortado e flashes no estilo Vibrant Visuals

Backup de tudo o que mudou: `backup/2026-10-06_before_end_fix/`. Os arquivos de antes estão lá
completos; para voltar, basta copiá-los por cima.

## 1. Capacidade e privacidade

Nesta sessão não tenho nenhuma ferramenta que veja ou capture a janela do Minecraft, e não capturei
nada. Trabalhei com:

- o print que você mandou;
- os jars do Minecraft 26.3 e do Iris 1.11.7 já instalados (só leitura do bytecode);
- uma página de teste local que roda os programas reais do pack.

Não li o seu log do Iris nem nenhum outro arquivo seu. O pedido está na seção 12.

## 2. O céu cortado: diagnóstico

**O que o seu print mostra** (medido nos pixels):

| Região | Cor | Observação |
|---|---|---|
| Céu de cima | #130F18 a #160F1C | Gradiente da paleta do pack até #391D4B perto da borda. |
| Faixa de baixo | #7563A6 a #7664A7 | Chapada (desvio 0,2 em 200 × 60 px), do horizonte até a borda. |

- A borda **não é uma curva**. São três segmentos retos com quinas, e cada lado cobre uns 45° de
  azimute. A borda fica a uns 4 a 6° acima do horizonte.
- Isso é a silhueta de um octógono, não uma linha de elevação constante.

**Causa** (verificada nos jars):

1. O Minecraft 26.3 deu luz do céu ao End: `the_end.json` tem `has_skylight: true` (no 1.21.1 era
   `false`). Isso existe para o clarão do flash entrar no lightmap.
2. O Iris 1.11.7 desenha, em toda dimensão com luz do céu, um "horizonte" próprio
   (`IrisRenderingPipeline.onBeginClear` → `HorizonRenderer`).
   - É um leque de triângulos que vai de 16 blocos abaixo do olho até um octógono 16 blocos acima,
     com raio igual à distância de renderização (no máximo 256).
   - A borda fica, portanto, a atan(16 / raio) ≈ 5° acima do horizonte.
   - Ele é desenhado com o programa `gbuffers_skybasic` do pack.
3. O `gbuffers_skybasic` do pack pinta o céu do Overworld. No End, isso virou uma faixa clara e
   chapada sobre o céu. O `final` ainda somava a paleta violeta por cima, e o resultado é o lilás do
   print.

**Reprodução na página de teste** (o leque desenhado como no jogo), mesma coluna da tela:

| Elevação | Antes | Depois |
|---|---|---|
| 7° | #361C4B | #361C4B |
| 6° | #CBCAFF (faixa) | #371C4C |
| 3° | #CFCCFF | #3B1E50 |
| 0° | #D0CDFF | #3B1F4F |

- Maior salto de luma entre linhas vizinhas: 103 antes, 6,9 depois (6,9 é só o grão da textura).
- Na página de teste a faixa sai mais clara que no seu print porque o sol de teste está ao meio-dia.
  A forma e a posição são as mesmas.

**Correção:**

- `gbuffers_skybasic` descarta tudo no End. O vanilla nunca usa esse programa no End, então só o
  leque do Iris some. No Overworld e no Nether nada muda.
- O `final` monta o céu do End a partir da direção da vista:
  - a mesma textura, `textures/end_sky.png`, uma cópia idêntica do arquivo do 26.3;
  - o mesmo mapeamento do jogo, lido do bytecode de `SkyRenderer.buildEndSky`: seis faces a 100
    blocos, 16 repetições por face, filtro nearest, cor 40/255.
- Assim o céu não depende do que o jogo ou o Iris desenhou.
- **Conferência:** contra uma caixa rasterizada do jeito do jogo, em 8 direções, 0,48% dos pixels
  diferem (máximo 26/255, só escolhas de texel nas bordas) e as médias são iguais (18,68 a 18,71).
- **O que ainda aparece por cima do céu:** só o que é mais claro do que o céu do End jamais fica
  (acima de 0,14): fogos de artifício, feixes, os raios de morte do dragão.
  - Perto do flash, enquanto o jogo desenha o sprite dele, nada é mantido (o Vibrant Visuals não
    mostra o sprite).
  - Halos translúcidos muito fracos contra o céu do End (abaixo de 0,14) não aparecem. Sobre o
    terreno, aparecem normalmente.

## 3. Por que os flashes não apareciam

Verifiquei no jar do Iris 1.11.7:

- `endFlashIntensity` e `endFlashPosition` chegam ao pack.
- Os uniforms customizados podem lê-los.
- A posição do flash não depende de `endFlashShadows`.

Ou seja, o pack recebia o flash. Há três causas prováveis, e só você consegue confirmar a primeira:

1. **O relógio do End parado.** No 26.3 o flash segue o relógio do End
   (`ClientLevel.tick` → `EndFlashState.tick(getDefaultClockTime())`). O `ServerClockManager.tick`
   só avança os relógios com `/gamerule advance_time true`.
   - Se o tempo estava congelado (por exemplo, para os prints do Overworld), não há flash nenhum,
     nem no vanilla.
   - **Confira esse gamerule primeiro.**
2. **O flash do pack era fraco e estreito.**
   - O brilho no céu chegava a menos da metade da sua referência no centro e caía à metade em ~8°
     (na referência, ~20°).
   - O pack também tirava o clarão do lightmap do jogo, trocando-o por uma luz direcional moderada.
   - Como a direção do flash é aleatória, fora da vista sobrava pouco para notar.
3. **O sprite do jogo.** No seu print o céu de cima é liso, sem o grão da textura vanilla. Pode ser
   que o Iris nem desenhe a caixa e o sprite do End no seu jogo. O céu novo não depende disso.

## 4. Pesquisa: os flashes do End no Vibrant Visuals

Segundo a Minecraft Wiki (páginas End flash, Vibrant Visuals e Vibrant Visuals/Configurations):

- **No Java e no Bedrock comum:** um sprite roxo no céu e o lightmap tingido de roxo. Adicionado no
  Java 1.21.9 (snapshot 25w33a).
- **No Vibrant Visuals:** cada flash é uma **luz direcional global roxa**, RGB 228 93 255 (#E45DFF),
  intensidade 3 lux.
  - Ilumina objetos e cria **sombras no sentido oposto** e **reflexos**.
  - **Entra e sai em fade.** Um a cada 30 s, em pontos aleatórios acima do horizonte.
  - **O sprite clássico não é desenhado:** só o "tingimento brilhante da névoa volumétrica".
  - Durante o flash fica visível uma **névoa volumétrica roxa densa**.
  - O céu do End usa "atmosféricos" pretos ou roxo-escuros por cima da textura vanilla: zênite RGB
    22 17 36, horizonte 1 1 5.
  - Os flashes podem ser desligados nas opções.
- **Relato de jogadores** (Sportskeeda): pulsos de luz roxa vindos de pontos diferentes, "como um
  farol", com um ronco distante.

**Como o pack reproduz isso agora:**

| Vibrant Visuals | Pack |
|---|---|
| Luz direcional #E45DFF | `endFlashColor()` = #E45DFF (variação desligada por padrão). |
| Sombras opostas | `FLASH_SHADOWS` com `endFlashShadows` do Iris: MEDIUM, HIGH, CINEMATIC. LOW e ULTRA LOW não, pelo orçamento. |
| Fade in / fade out | O envelope é a meia-senoide do jogo. Sem pulso duplo (`FLASH_PULSE` 0). |
| Sem sprite, só a névoa brilhando | Céu reconstruído sem o sprite. Brilho de névoa largo em volta do flash, a mesma função no céu e na névoa sobre o terreno. |
| Névoa roxa densa | `FLASH_FOG_BOOST` 3,0 (a névoa do End fica 3× mais densa no pico). |
| Reflexos | Brilhos na micro-textura (`FLASH_GLINTS`) e no brilho plástico de entidades. Não há reflexo espelhado. |

**Não reproduzido de propósito:**

- Os "atmosféricos" do céu do Vibrant Visuals, com o horizonte quase preto. Você não pediu para mudar
  o céu entre flashes, então mantive a paleta do Update 3 (pergunta 2).
- Os 3 lux: o Vibrant Visuals usa outra escala de exposição. Calibrei pela sua referência de pico.

## 5. Calibração do brilho contra a sua referência

A referência é o print de pico do Update 3 (`ref20`): centro do brilho em (720, 568), medido para
cima, ângulo calculado com FOV de 70°. A página de teste tem o flash 15° acima do horizonte, em
MEDIUM. Média 5 × 5 px:

| Ângulo | Referência | Novo | Antes | Novo, entre flashes |
|---|---|---|---|---|
| 0° | #9A5DA1 | #9C5CA0 | #CE8AFF | #261339 |
| 4,9° | #92589B | #905694 | #A470D5 | #201132 |
| 9,7° | #814C87 | #824D87 | #7952A0 | #1E1030 |
| 15,9° | #683E6F | #693F6F | #482F63 | #1D102D |
| 19,6° | #59355F | #593660 | #35224B | #1B102A |
| 23,1° | #4D2E52 | #4B2E51 | #271939 | #190F26 |
| 29,6° | #3D2441 | #34213B | #1B1127 | #150D20 |

- Erro médio de luma do novo contra a referência: **1,3 de 255** em 10 ângulos.
- O "antes" na página de teste ainda tinha o sprite do jogo somado, por isso o centro dele é forte e
  estreito. No seu jogo, se o sprite não aparece (seção 3), restava só o brilho estreito.

**O flash no tempo** (curva vanilla por tick, 60 fps, flash na vista):

- Luma média 47,9 → 68,9 no pico (× 1,44).
- Uma única subida e descida (1 reversão).
- Maior mudança entre quadros: 0,41.
- Com o pulso duplo antigo (0,30), a maior mudança era 0,63.

**Durante a luta com o dragão**, o pico fica bem mais fraco (canal máximo 135 contra 255).

**Um detalhe:** um bloco de ferro virado para o flash chega ao branco-rosado (canal 255). É uma
textura muito clara sob a luz #E45DFF, mais saturada que a cor anterior. Se incomodar,
`FLASH_INTENSITY` 0,75.

## 6. Arquivos

| Arquivo | Mudança | Linhas |
|---|---|---|
| `shaders/gbuffers_skybasic.fsh` | No End, descarta: some o leque do horizonte do Iris. | 122 → 131 |
| `shaders/final.fsh` | Céu do End reconstruído pela direção; o que é mais claro que o céu fica por cima, com o sprite filtrado; novo brilho no céu e na névoa; sprite analítico removido da névoa; debug 10 virou checagem do céu. | 2208 → 2220 |
| `shaders/lib/dimension_ambience.glsl` | `endVanillaSky()` (mapeamento do jogo); cor #E45DFF; novo `endFlashGlow()`; variação de força só com `FLASH_COLOR_VARIATION`. | 368 → 404 |
| `shaders/textures/end_sky.png` | Novo: cópia idêntica do 26.3 (SHA-256 4E3AC740…). | 12 378 bytes |
| `shaders/shaders.properties` | `customTexture.vclEndSky` e os novos valores do flash em todos os presets (gerado pelo `genprops8.ps1`). | 668 → 678 |
| `shaders/lib/settings.glsl` | Padrões e descrições; `FLASH_HALO_SIZE` ganhou 0,30 e 0,40. | 721 |
| `shaders/lang/en_us.lang` | Quatro nomes de opções. | 396 |
| `README.md` | Nova seção e dicas atualizadas. | 1344 → 1371 |

**Nenhum outro arquivo foi tocado.** `gbuffers_forward.fsh`, `final.vsh`, `composite*` e
`shadow*` continuam iguais: a luz nas superfícies, as sombras e os feixes pegam a nova cor por
`endFlashColor()`.

## 7. Prova de identidade

Método: as mesmas cenas renderizadas com a árvore de antes (cópia feita antes de qualquer edição) e
com a nova. Cada caso foi renderizado 6 vezes por versão, alternando, com 2,5 s de intervalo.
Compara-se o conjunto de estados (imagem final 8-bit + colortex0 em float) e os dois shadow maps.
O controle é a versão antiga contra uma segunda cópia dela mesma.

| Caso | Resultado |
|---|---|
| Controle (antigo MEDIUM × cópia dele): dia, sol baixo, noite, chuva | IDÊNTICO |
| Overworld, padrões e os 5 presets × dia, sol baixo, noite, chuva (24 casos) | IDÊNTICO, shadow maps iguais |
| Nether (chão e teto) e câmera debaixo d'água, padrões / LOW / CINEMATIC | IDÊNTICO |
| End com `END_AMBIENCE` desligado, entre flashes e durante um flash, padrões / LOW / CINEMATIC | IDÊNTICO |
| Overworld MEDIUM × MEDIUM com todos os sliders do flash mudados | IDÊNTICO |
| End com o leque do Iris desenhado (`END_AMBIENCE` desligado) | DIFERE por projeto: a faixa some (98 380 pixels mudam) |

Resultado: **tudo idêntico**, exceto a correção pretendida. Com `END_AMBIENCE` ligado o End muda
inteiro, como pedido.

## 8. Desempenho

**Estimado, não medido.** Contas de instruções para uma 1050 Ti em 1080p; os timers de GPU desta
página de teste são ruído, como no Update 3.

- **End entre flashes, LOW:**
  - A textura reconstruída custa cerca de +0,025 ms (≈ 25 operações + 1 leitura de textura por pixel
    de céu, com metade da tela sendo céu).
  - Em compensação, o `gbuffers_skybasic` não calcula mais o céu do Overworld no leque do Iris.
    Quando o horizonte está na vista, isso economiza até ~0,04 ms.
  - Total: ~0,04 a 0,06 ms (antes ~0,04). Orçamento: 0,05 ms. Pode passar ~0,01 ms olhando para o
    alto, onde não há leque para economizar.
- **End durante o flash, LOW:**
  - O brilho novo usa 2 exponenciais em vez de 3, e a névoa perdeu o sprite analítico e o lóbulo.
  - Total: ~0,16 a 0,19 ms (antes ~0,17 a 0,20). Orçamento: 0,20 ms.
- **Overworld, Nether, debaixo d'água:** 0 (código idêntico ou nunca executado).

## 9. Opções e presets

Valores novos em todos os presets (ULTRA LOW a CINEMATIC):

| Opção | Antes | Agora |
|---|---|---|
| `FLASH_PULSE` | 0,30 | 0,00 |
| `FLASH_COLOR_VARIATION` | 1,00 | 0,00 |
| `FLASH_FOG_BOOST` | 2,5 | 3,0 |
| `FLASH_HALO_SIZE` | 0,45 | 0,40 |

- Os interruptores por preset não mudaram: ULTRA LOW continua sem flash; LOW sem sombras, feixes e
  brilhos; MEDIUM e acima com tudo.
- `FLASH_COLOR_VARIATION` agora controla cor **e** força por flash (0 = sempre igual, como no
  Vibrant Visuals).
- `END_DEBUG_MODE` 10:
  - metade esquerda: o que o jogo e o Iris desenharam no céu;
  - metade direita: o céu reconstruído.
  - Fora da antiga faixa, as duas metades devem bater (se o jogo desenhar a caixa).

## 10. Teste no jogo

1. `/gamerule advance_time true`, preset MEDIUM, ilha principal do End.
2. Olhe o horizonte em volta. Não deve haver faixa clara: a textura granulada do End vai contínua
   até o horizonte e abaixo dele.
3. Espere um flash (um a cada 30 s; o som vem ~1,5 s depois do início, da direção dele). Deve
   aparecer:
   - um brilho roxo grande na névoa, para o lado do som;
   - pilares distantes sumindo nele;
   - superfícies viradas para o flash em roxo;
   - sombras opostas (MEDIUM e acima).
   - Não deve aparecer um quadrado de sprite.
4. Se nada acontecer em 1 minuto, ligue `END_DEBUG` modo 1.
   - Se a barra roxa (intensidade do jogo) nunca se move, o jogo não está fazendo flashes: confira o
     gamerule.
   - Se ela se move e a tela não muda, me mande um print e o log.
5. Solte um foguete com elytra contra o céu: o rastro deve aparecer.
6. Overworld e Nether: nada mudou.

## 11. O que não dá para verificar sem o jogo

- A ordem real em que o Iris desenha o leque e a caixa no seu jogo, e se a caixa e o sprite são
  desenhados. O céu novo não depende disso.
- Se `advance_time` está desligado no seu mundo.
- Os custos reais na 1050 Ti.

## 12. Pedidos (com o seu consentimento; capture só a janela do Minecraft)

1. Um print do mesmo lugar do print cortado, depois da correção.
2. Um print de um flash no pico, olhando para ele.
3. `END_DEBUG` modo 1 durante um flash, e modo 10 olhando o horizonte.
4. O log do Iris (`logs/latest.log` do perfil), se aparecer qualquer erro de shader.

## 13. Perguntas

1. O `/gamerule advance_time` estava desligado no seu mundo?
2. O céu entre flashes: manter a paleta violeta atual (horizonte #3A1E4E) ou usar a do Vibrant
   Visuals (zênite #161124, escurecendo até quase preto no horizonte)?
3. Sombras do flash também no LOW? Custam um shadow pass inteiro durante cada flash, o que estoura o
   orçamento de 0,20 ms do LOW.

Fontes: [End flash (Minecraft Wiki)](https://minecraft.wiki/w/End_flash),
[Vibrant Visuals (Minecraft Wiki)](https://minecraft.wiki/w/Vibrant_Visuals),
[Vibrant Visuals/Configurations (Minecraft Wiki)](https://minecraft.wiki/w/Vibrant_Visuals/Configurations),
[Sportskeeda: flashes no End com Vibrant Visuals](https://sportskeeda.com/minecraft/minecraft-player-finds-strange-flashes-end-vibrant-visuals-turned).
