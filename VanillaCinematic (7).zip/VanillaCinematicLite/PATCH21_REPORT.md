# Patch 2.1: sky pixel fix (part B) and adaptive eyes (part A)

Backup of every file this patch touches: `backup/2026-10-05_before_patch21/` (the whole
`shaders/` folder and `README.md`).

All numbers marked "harness" come from the pack's real programs (gbuffers_skybasic,
gbuffers_clouds, composite, composite1, composite2, final) compiled in a WebGL2 test page
(ANGLE / Direct3D 11) on synthetic scenes. The `shaders.properties` custom uniforms are evaluated
from the file itself, with the `smooth()` behaviour read from the Iris 1.11.7 jar. Nothing here
was rendered by Minecraft.

## 1. Capability check

- I have no screen capture or computer-use tool for the Minecraft window in this session, and I
  captured nothing.
- What I used:
  - your two attached images, measured pixel by pixel;
  - the 26.3 client jar and the Iris 1.11.7 jar, read for vanilla and Iris behaviour;
  - the WebGL test page.
- The in-game screenshots I would like to have are listed in section 13.

## 2. Your sky screenshot (1181 x 562)

What I see:
- a daytime sky (#5E90E3 to #6699ED);
- opaque pink-white clouds with brighter top faces;
- the brightest part of the sky toward the upper right, where the sun is;
- the crosshair at (588, 303);
- the held block at the lower right.

The stray pixels, measured:

| Group | Position | Size | Colour | Opacity over the sky |
|---|---|---|---|---|
| Dash | x 151-158, y 116-119 | 8 x 4 px | #3A5E8B core on sky #5F92E2 | 0.43-0.45 (green and blue channels) |
| Dot 1 | x 1155-1158, y 77-80 | 4 x 4 px | #33619A / #405C8E | 0.42-0.45 |
| Dot 2 | x 1164-1167, y 77-80 | 4 x 4 px | same | same |

The screenshot has JPEG-like ringing, so the red channel is less reliable.

Your question: stars, noise, NaN or buffer leftovers? None of those. They are the pack's own
**fake birds** (`GOLDEN_FAKE_BIRDS` in final.fsh, on in MEDIUM, HIGH and CINEMATIC).

The proof (section 4) puts the real final.fsh at the moment of your screenshot. It reproduces:
- the dash at x 150.7-159.3, y 115.0-119.3;
- the dots at x 1153.9-1158.2 and 1162.5-1166.9, y 76.2-80.5;
- an opacity of 0.427 / 0.429.

That matches your screenshot to within a pixel or two.

Why they look like stray pixels and not birds:
- The bird is a thin V shape, but it is sampled only once per 7 x 7-pixel cell.
- So each bird lights 0 to 3 isolated squares, never a bird.
- The squares sit at fixed screen heights (78, 84 and 88 % of the screen height).
- They drift sideways slowly (0.25 % of the screen width per second, about 5 pixels per second
  at 1080p).
- They come and go as a bird's cells line up with the grid. The third bird was invisible in
  your frame: at that moment none of its cell centres fell on the V.

**The pale semi-transparent squares from earlier screenshots** are a different feature, most
likely the pollen motes (`ATMOSPHERIC_PARTICLES`, composite.fsh):
- 32 x 32-pixel screen cells, drawn only on open sky;
- warm (+0.06 x (1.0, 0.84, 0.62)), about 15 levels brighter than the sky;
- refreshed 1.5 times per second;
- only in forest, taiga, jungle and swamp biomes;
- cut into different sizes by clouds and terrain.

I could not check this against those screenshots (I don't have them). The pollen motes are a
listed "particles" feature that shares the quarter-resolution buffer, so I did not change them.
To confirm, check whether the squares:
1. appear only in those biomes;
2. stay fixed to the screen while you turn;
3. jump every 0.7 s;
4. vanish with `PARTICLE_AMOUNT` 0.

## 3. The reference scene "small cave looking outside"

Measured in your second image (1561 x 784):

| Region | Your estimate | Measured |
|---|---|---|
| Near-black interior (55.5 % of the frame) | #0A0C14 | #030304, L8 4.0, linear Y 0.0012 |
| Dim walls (22.9 %) | #1A2030 | #0B0D12 to #0D1018, L8 13-16, Y 0.0043-0.0053 |
| Rim stone (7.5 %) | #4A5A7A | #232B41 (left) to #3B4769 (right), L8 43-71 |
| Window sky | #6A96EA | #6C92DF to #6E97E8, L8 143-148 |
| Window snow | #DDE6F6 | #8F9BCB, L8 156 (a pale blue-grey, not near white) |
| Window stone | | #5B658B, L8 102 |
| Window share (L8 60 or more) | about 20 % | 14.2 % |
| Window vs walls | 15-20 x by eye | 9 x in screen values, about 57 x in linear luminance (vs the dim walls), about 300 x vs the black walls |

I confirm your interpretation: this is the **unadapted state (t = 0)**. The current build has no
adaptation, so any frame it renders is "t = 0". The walls carry almost no texture: the black part
has a standard deviation of 1.0 code, the dim walls 4.9.

For the tests I built a matching cave in the test page:
- 5 wide, 4 high, about 11 deep;
- the camera 7 blocks inside, looking at the opening;
- snowy plains outside at noon.

How close it is to your frame:
- Its luminance histogram is 45 / 35 / 9.5 / 4.2 / 5.5 % against your 55.5 / 22.9 / 7.5 / 8.6 /
  5.6 %.
- The rim, snow and stone are within a few levels of yours.
- My deep walls are a little brighter (L8 6.8 vs 3.7).
- My window sky is paler (L8 219): a harsher test for clipping.

## 4. Diagnosis of the sky bugs

| # | Cause checked | File, function | Present? | Evidence | Severity | Fix |
|---|---|---|---|---|---|---|
| birds | Screen-space fake birds | final.fsh, `targetBirdMask` and the `GOLDEN_FAKE_BIRDS` block | **YES, the cause** | Reproduced at your screenshot's moment (position, size, opacity); fix off vs on differs only inside the predicted bird cells (147 of 147 pixels); the in-game outlier view flags 133 pixels with the fix off, 0 with it on | Visible stray pixels, MEDIUM and up | `SKY_PIXEL_FIX` compiles them out |
| a | Vanilla stars in daytime | 26.3 `SkyRenderer.renderSunMoonAndStars`, `RenderPipelines.STARS`; gbuffers_skybasic stars branch | No | Vanilla draws stars only when star brightness > 0, with `OVERLAY` blending = (SRC_ALPHA, ONE): additive, can never darken. In late afternoon (sun below about 22 degrees) vanilla draws faint stars and the pack outputs black for them, which adds nothing. | none | safety net only |
| b | Procedural stars | final.fsh, `evaluateProceduralStars` | No | Night fade is exactly 0 for a sun above 3.4 degrees; every factor is ≥ 0 and the term is added, so it cannot darken; the hash is in [0, 1); fix on/off identical at night (0 pixels differ) | none | none |
| c | NaN, infinity, negative values | lib/ambience.glsl sky functions | No | `ambAngle` uses a clamped asin; every normalize uses `inversesqrt(max(..., 1e-6))`; divisions are guarded; `ambienceSkyTerms` returns `max(sky, 0)`; the invalid-value view shows 0 pixels in 5 scenes | none | a safety net anyway (section 5) |
| d | Exact sky test (depth == 1) | every sky test in final, composite, final.vsh | No | All tests use > 0.99999 (or ≥ 0.99995 for the pollen); view 11 shows where an exact test would differ | none | none |
| e | Cloud edges or depth | gbuffers_clouds and the marker | Not for these pixels | The stray pixels are far from any cloud | none | none |
| f | Quarter-resolution buffer | composite and composite1, colortex5 | No | Every texel is written every frame (RGB + A); clamp-to-edge; never stale | none | none |
| g | Precision (8-bit buffers) | colortex0 RGBA16F, colortex5 RGBA16F, colortex1 RGBA8 (info only) | No | The only 8-bit step is the final screen write | none | none |
| h | Sun or moon quad, sunrise fan, void disc | shaders.properties `sun=false`, skybasic discards | No | The vanilla sun is not drawn; the moon below the horizon is masked (celestial term × smoothstep(0.035, 0.07, y)); fan and void are discarded | none | none |
| i | Dither overshoot | lib/ambience.glsl `ambDither` (static IGN, triangular, ±0.75/255) | No | Amplitude below one 8-bit step; IGN stays precise at 4K coordinates | none | none |
| pale squares | Pollen motes | composite.fsh `ATMOSPHERIC_PARTICLES` | Probably (earlier screenshots) | Matches the description (32-px cells, sky only, warm, 1.5 Hz); not confirmable without those screenshots | Visible, by design | not changed (frozen particles); see section 15 |

**How to classify it yourself** (the birds' answers in brackets):
- Freeze time (`/gamerule advance_time false`) and keep the camera still: do they move? [yes,
  sideways, about 5 px/s at 1080p].
- Rotate the camera: do they stay at the same screen height? [yes: screen-space, (b)].
- Watch at night: do they vanish? [yes; not stars, which rotate with the sky (a)].
- Do they flicker every frame? [no: not NaN or temporal noise (c)].
- Change the resolution (720p and 1440p): does their size in pixels stay the same? [yes, always
  7 px: a screen-pixel grid, not a low-resolution buffer (e)].
- Turn `GOLDEN_FAKE_BIRDS` off, or `MATCH_STRENGTH` 0: do they disappear? [yes].

## 5. Part B: the fix

1. **Root cause.** `SKY_PIXEL_FIX` (on in every preset) undefines `GOLDEN_FAKE_BIRDS` in
   settings.glsl, so the bird code is compiled out.
   - The bird code in final.fsh itself is unchanged.
   - The bird option and its three sliders stay in the menu; they work again only with the fix off.
2. **Safety net** (lib/sky_guard.glsl), in gbuffers_skybasic (which feeds the bloom) and at the end
   of final's sky block:
   - A sky colour is valid when every channel is a finite number in [-0.01, 64).
   - Only an invalid value is replaced: by the plain palette gradient in skybasic, by the
     analytic sky in final, or by black.
   - No blur, no neighbours, no dither; valid values pass through bit for bit.
   - The -0.01 lower edge leaves alone the legacy sky path's own signed dither (Nether/End and
     Ambience off).
3. **Nothing else changed**: no colours, glow, rays, veil, rim, shafts, clouds, star density or
   quality settings.

**Identity test (harness).**
- **Conditions:** fix on vs off at 7 times of day (sunrise 2°, 30°, noon, 150°, sunset 178°,
  dusk -6°, night, dawn -4°), plus a pyramid with a cloud over the sun, rain, a thunderstorm,
  night with stars, and looking away from the sun.
- **Resolutions and FOV:** 1280x720, 1920x1080 and 2560x1440 at FOV 30, 70 and 110, and 3840x2160
  once. That is 117 conditions plus the 4K one.
- **Result: 0 pixels differ outside the bird cells in every condition.** Each build against
  itself differs in 0 pixels, so the comparison is exact.
- **Night:** 0 pixels differ. The stars are untouched.
- **Outlier scan:** sky pixels darker than all four neighbours 8 px away. By day: 49 to 182 with
  the fix off, 0 with it on. At night the scan also finds pixels surrounded by stars; those are
  the same with the fix on and off.
- **Old (backup) vs new** with both new features off: bit-identical in ULTRA LOW, LOW, MEDIUM and
  CINEMATIC (noon, night, pyramid with a cloud, night with stars).
- **Not run:** biomes and altitude are uniforms the birds and the guard do not read. A long
  "observation time" has no meaning in the harness.
- **Costs:** a few comparisons per sky pixel, at most 0.004 ms with a full-sky frame on a
  1050 Ti (estimate). Removing the birds saves about 30 operations per sky pixel, so the net is
  about 0 ms.

## 6. Part A: adaptive eyes, design

### 6.1 Reference level and units

- **The reference** = gain exactly 1.0, the stage skipped, the image bit for bit the previous
  one. It holds when all of these are true:
  - sky light at the eye is 13 or more (open sky, under a tree, beside a wall);
  - the sun is above the horizon (golden hour included);
  - no rain;
  - no block light needed.
- **Inputs:** `eyeBrightness` (vanilla light level × 16 at the eye block, raw, every frame;
  checked in the jar), `sunAngle`, `rainStrength` and `biome_precipitation`.
- **Units:** the pack works in screen values, with no linear-light stage.
  - The sliders give linear-light gains: ADAPT_MAX_BRIGHTEN 2.2 = 2.2 × the light = 1.43 × the
    screen value.
  - final.vsh converts once per frame (g^(1/2.2)), so no per-pixel pow.

### 6.2 Measurement policy (how mixed lighting is handled)

1. **The driver (tier 1, all presets) is the light at the camera, never the view.**
   - Darkness in stops = cover over the camera beyond a 1.6-stop open-sky band + the night sky
     (3 stops at full moon to 4 at new moon) + rain (0.35 stop).
   - Torchlight adds light: a full-level torch counts 2 stops below daylight.
   - Standing in a cave with sky light near 0 means "adapt to dark", even when the screen is
     mostly a bright window.
   - It does not depend on where you look, so turning the head can never pump it.
2. **The refinement (tier 2, MEDIUM and up) is a small, slow correction.**
   - ADAPT_SCENE_TAPS fixed taps of colortex0, the scene before fog, grading and exposure, so it
     never measures its own result.
   - Sky and cloud taps are left out, so the sun and the sky never darken the world.
   - Each tap counts at most +2 stops (lava, a sun reflection). Sunlit snow counts, clamped.
   - Log-average with the centre group weighted by ADAPT_CENTER_WEIGHT. That weight falls back to
     1 when the centre is 1 to 3 stops brighter than the ring, so a bright window in the middle
     never dominates.
   - The measured level is low-passed (2 s). Compared with what the camera light predicts, the
     difference is clamped to ±ADAPT_SCENE_REFINE_LIMIT.
   - It has a 0.75-stop dead band and moves with ADAPT_TO_DARK_TIME, at most 0.6 stop per
     second, and is weighted by ADAPT_SCENE_LUMA_WEIGHT.
   - So it can move the gain by at most ±0.5 stop.
   - Extra gain from it is given only where the camera light already says "dark", in step with
     the eyes' own progress, and within the cap.
   - In daylight it can only add punch, never gain.
3. **Highlight protection.**
   - The existing tone map does not protect a gained window. Its soft clip still passes 1.5 for
     an input of 1.74, and ULTRA LOW has it off anyway.
   - So the exposure stage has its own roll-off: a rational shoulder on the largest channel
     above ADAPT_HIGHLIGHT_KNEE (0.70).
   - The hue is kept, it never reaches 1, and it never goes below the pixel's own value without
     the stage, so a near-white sky stays exactly as it was. It ramps in over the first +6 % of
     screen gain.
4. **Local lift (ADAPT_LOCAL_LIFT).** A soft toe on the gained luminance:
   L × (1 + y·L0² / (L + L0)²), with L0 = 0.06 and y = 0.8 × strength × dark amount.
   - The darkest pixels get up to 1.8 × more, a pixel at 0.06 a quarter of that, the window
     almost nothing.
   - It never reverses the order of brightness: the derivative stays positive for y < 27.

### 6.3 Dynamics

- **Smoothing (tier 1).** Iris `smooth()` is frame-rate independent: after t s the remaining
  distance is 2^(-t / (0.1 × time)), so 90 % takes 0.332 × time. It starts at the current value.
  - It smooths the fraction of dark adaptation, a = 1 - 2^(-darkness / 1.733).
  - final.vsh maps a to the gain with X = Xmax (1 - (1-a)^k), k = 1.25 · ADAPT_DARK_STRENGTH / Xmax.
    That is exactly the target curve, and the visible change takes the slider time.
  - Darkening uses ADAPT_TO_DARK_TIME (6 s), brightening ADAPT_TO_BRIGHT_TIME (1.2 s).
- **Over-bright moment.** The target is also smoothed over about 0.25 s. While the eyes lag behind
  it, BRIGHT_FLASH (0.5) of the lag shows, plus 0.6 × that many stops of extra bloom.
  - Stepping into a very bright place adds a brief dazzle (BRIGHT_FLASH × 0.35 stop × the rise).
- **Snap.** A camera jump of more than 12 blocks in one frame snaps the adaptation and holds the
  snap for about 1 s, through the `smooth()` time arguments set to 0. This covers world join,
  respawn, teleport and portals.
  - `previousCameraPosition` is (0, 0, 0) on a new pipeline, so the first frame always snaps.
- **No feedback loop.**
  - Tier 1 does not depend on the image.
  - Tier 2 measures the scene before the exposure.
  - Nothing can oscillate.

### 6.4 Where the gain is applied (final.fsh)

- **The place:** right after the veil, rim and shafts block, and before the golden and atmospheric
  grading, the vignette, the debug views, the dither and the 8-bit write.
- **Why there:** this is the first point where everything the eye sees is composed (scene, bloom,
  sky, fog, veil, rim, shafts), so one gain covers all of it. The sun glow and the sky are not
  multiplied separately.
- **The pack's tone map runs earlier:** before the fog and the sky rebuild, on scene pixels only.
  Putting the gain before it would have needed separate multiplications for the sky and the fog.
- **The bloom:** its threshold stays in pre-exposure units (composite reads colortex0 before the
  gain), so brightening a cave never makes more things bloom.
- **The input check:** the input is clamped to [0, 64], which drops negative values, NaN and
  infinities.
- **At the reference** the stage is skipped by one branch on a per-frame value.

### 6.5 Dark-end quality

- **Precision:** colortex0 (the scene) is RGBA16F and the only 8-bit step is the final write. The
  gain is applied before it, so it cannot amplify banding.
- **Extra dither:** ADAPT_DITHER (0.5/255 at the largest gain), static and the same pattern as
  SKY_DITHER, so it never crawls with the camera.
- **Black level:** ADAPT_SHADOW_LIFT (0.004) gives a cool lift of the black level in fully
  dark-adapted views.
- **Night-vision feel:** PURKINJE_STRENGTH (0.15) mixes at most 7.5 % of the deep darks toward a
  cool grey.
- **The blue tint is kept:** the gain multiplies all channels.
- **Torches stay warm and the brightest thing:** they are bright, so the toe and the night-vision
  feel do not touch them.

### 6.6 Environments and effects

| Situation | Behaviour |
|---|---|
| Underwater | The eye's sky light falls with depth; half-strength adaptation. Measured: 1.25 × at sky light 10, 1.47 × at 4. The fog look is only exposed, its colours are kept. |
| Lava or powder snow at the eye | No adaptation |
| Nether | ADAPT_NETHER_STRENGTH 0.3: 1.26 × away from lava, 1.15 × near lava (block light 15 counts as light). In MEDIUM the measured lava brightness lowers it further. |
| End | ADAPT_END_STRENGTH 0.3: 1.26 × |
| Blindness, Darkness | Gain 1 (`blindness`, `darknessFactor`, checked in the jar) |
| Night Vision | Gain 1: the game already brightens (`nightVision`) |
| Rain or thunder | Follows the overcast darkness: 1.12-1.14 × in open rain. Lightning cannot pump it: tier 1 does not see it, tier 2 is slow and rate-limited. |
| HUD | Not affected (drawn after final) |
| First-person hand | Exposed like the world |
| F1 | No change |

### 6.7 What it cannot do

- It is not true per-pixel local adaptation: the toe is a curve on brightness, not a local
  operator, so it has no halos and no local contrast.
- No HDR display output: it ends in 8 bits like before.
- It is not the exact physical eye response: the times are user choices, not rod and cone
  kinetics.
- Tier 2 sees only 9 to 25 points of the screen.
- The night limit uses the camera's sky light, so a big dark room under open sky at night counts
  as "outdoors at night".

## 7. Performance

Estimates from instruction counts for a 1050 Ti at 1080p (about 1.07 T scalar operations per
second). Nothing was measured: the browser cannot time GPU work.

| Part | Work | Estimate |
|---|---|---|
| Part B | A validity test per sky pixel (skybasic and final); birds removed | about 0 ms net (at most 0.004 ms with a full-sky frame) |
| Part A at the reference (normal daylight) | One branch on a per-frame value; about 37 custom-uniform expressions per frame on the CPU | about 0 ms |
| ULTRA LOW while brightened | About 20 operations per pixel (gain, roll-off, input clamp, dither) | about 0.04 ms |
| LOW and MEDIUM while brightened | About 40 operations per pixel | about 0.08 ms |
| MEDIUM and up, tier 2 | composite2: one pixel, 9-25 taps, plus one pass switch | about 0.005 ms |
| RTX 3050 (MEDIUM, 4.5 T operations per second) | | about 0.02 ms |

**Against your budgets.**
- **Tier 1 (≤ 0.02 ms):** my estimate is about 2 × over, only while brightened.
- **Tier 2 (≤ 0.06 ms):** my estimate is about 0.085 ms, roughly 40 % over.

I already trimmed the stage from about 65 to about 40 operations: one scalar roll-off, and one
shared weight for the black lift and the night-vision feel. Further cuts, each with a cost:

| Setting | Saves (operations per pixel) | Cost |
|---|---|---|
| `ADAPT_HIGHLIGHT_PROTECTION` off | about 15 | windows clip |
| `ADAPT_LOCAL_LIFT` off | about 6 | |
| PURKINJE_STRENGTH and ADAPT_SHADOW_LIFT at 0 | about 11 (compiled away) | |

## 8. Files

The complete files are on disk. Byte-identical to the backup, so unchanged:
- block.properties;
- composite and composite1 (vsh, fsh);
- gbuffers_clouds, gbuffers_terrain, gbuffers_textured_lit and gbuffers_water;
- gbuffers_skybasic.vsh;
- shadow and shadow_entities;
- lib: ambience, block_lighting, block_tables, gbuffers.vsh, gbuffers_forward, shadow_distortion,
  sun_rays and water_reflection;
- textures/clouds.png.

| File | Status | What |
|---|---|---|
| lib/sky_guard.glsl | new | validity test and fallback |
| lib/adaptive_eyes.glsl | new | uniforms, gain curve, tier-2 taps, per-frame state, exposure stage |
| composite2.vsh / composite2.fsh | new | the one-pixel pass (tier 2 history, debug graph) |
| gbuffers_skybasic.fsh | changed (109 → 122 lines) | **frozen sky program: only the guard.** The two outColor lines now write through a variable, plus one `if (!valid)` line, and the star output gets the same. Valid values are bit-identical (proven, section 5). |
| final.fsh | changed (1481 → 1818 lines) | **Frozen sky block: 3 additions only** (the `skyFallback` declaration, `skyFallback = skyNow`, the guard line after the birds); no sky line changed. Plus the exposure stage (one block after the rays), the extra dither (one line), and the SKY_DEBUG and ADAPT_DEBUG views (compiled out). |
| final.vsh | changed (270 → 312 lines) | the per-frame adaptation numbers |
| lib/settings.glsl | changed (559 → 608 lines) | the new options; `#undef GOLDEN_FAKE_BIRDS` under SKY_PIXEL_FIX |
| shaders.properties | changed (354 → 465 lines) | tier-1 custom uniforms; composite2 enable; `size.buffer.colortex6`; the "Adaptive Eyes" screen; presets |
| lang/en_us.lang | changed | new labels; the GOLDEN_FAKE_BIRDS label now says "only with the sky pixel fix off" |

**Touched although outside "remove stray-pixel causes / add an exposure stage", and why:**
1. **`GOLDEN_FAKE_BIRDS` is overridden** by SKY_PIXEL_FIX: the birds are the stray pixels.
2. **A new pass and a 1 × 1 buffer** for tier 2 (composite2, colortex6, RGBA16F, never cleared).
   - Custom uniforms cannot read the GPU, so the smoothed scene value needs a texel that survives
     the frame.
   - colortex5's texels are all used by bloom and shafts.
   - colortex6 is touched only by composite2 (write) and final.vsh (read), so the
     quarter-resolution buffer is untouched.
3. **The `ADAPT_TO_BRIGHT_TIME` unit is milliseconds** (1200), shown as "1.2 s" in the menu.
   Iris applies only `#if` in shaders.properties, and its preprocessor compares the integer part
   of a number (checked in the jar: 1.2 and 1.6 both read as 1).
4. **ULTRA LOW keeps `ADAPT_HIGHLIGHT_PROTECTION` on**, against your preset list.
   - Without it, the daylight window clipped to flat white (100 % of the sky at 3 s in the
     harness).
   - That breaks "the window must not clip", and ULTRA LOW has no tone map to soften it.
   - It costs about 15 operations per pixel, only while brightened. One line in the generator
     reverts it if you prefer.

**Removed or renamed options: none.**

## 9. Options and presets

**New options.**
- **Booleans:** SKY_PIXEL_FIX, SKY_DEBUG, ADAPTIVE_EYES, ADAPT_SCENE_LUMA, ADAPT_LOCAL_LIFT,
  ADAPT_HIGHLIGHT_PROTECTION, ADAPT_DEBUG.
- **Sliders:** SKY_DEBUG_MODE, ADAPT_DARK_STRENGTH (1.00), ADAPT_MAX_BRIGHTEN (2.2),
  ADAPT_NIGHT_LIMIT (1.5), ADAPT_TO_DARK_TIME (6 s), ADAPT_TO_BRIGHT_TIME (1200 ms),
  BRIGHT_FLASH (0.50), BRIGHT_PUNCH (1.00), BRIGHT_PUNCH_REFERENCE_SHIFT (0.00, changes the
  approved look when raised), ADAPT_SHADOW_LIFT (0.004), PURKINJE_STRENGTH (0.15),
  ADAPT_SCENE_LUMA_WEIGHT (0.50), ADAPT_SCENE_REFINE_LIMIT (1.0), ADAPT_SCENE_TAPS (9),
  ADAPT_CENTER_WEIGHT (0.50), ADAPT_NETHER_STRENGTH (0.30), ADAPT_END_STRENGTH (0.30),
  ADAPT_DITHER (0.50), ADAPT_LOCAL_LIFT_STRENGTH (1.00), ADAPT_HIGHLIGHT_KNEE (0.70),
  ADAPT_DEBUG_MODE.
- That is 28 options. Every preset defines all 307 options (generated).

**Where they appear:**
- the new "Adaptive Eyes" screen, in your order;
- SKY_PIXEL_FIX in "Sky and Stars";
- both debug switches in the debug screen.

| Preset | Adaptive eyes |
|---|---|
| ULTRA LOW | tier 1 only; no over-bright moment, no punch, no local lift, no night-vision feel, no black lift; highlight roll-off on (section 8) |
| LOW | tier 1 + over-bright moment, punch, local lift, roll-off, night-vision feel |
| MEDIUM (default) | + tier 2 with 9 taps |
| HIGH | 16 taps |
| CINEMATIC | 25 taps |

SKY_PIXEL_FIX is on in every preset.

## 10. Test results (harness)

**Compilation.** 155 builds with 0 failures: 5 presets × 31 variants (default, eyes off, fix off,
tier 2 off, all features on, 12 sky views, 10 eye views, 9/16/25 taps). Programs: skybasic,
clouds, composite, composite1, composite2, final. Each preset's custom uniforms (90-91
definitions) parse and evaluate.

**Identity at the reference.** In all 25 cases (5 presets × 5 daylight scenes: sun 3°, 16°, 40°
with a cloud, noon, looking away from a 50° sun):
- ADAPTIVE_EYES on equals off bit for bit;
- the new build with the fix off equals the old build.

Tier 2 runs and measures (R = -0.39), but correctly adds nothing.

**Reference cave** (camera sky light 0, noon). Linear luminance, then 8-bit L:

| | Gain (linear, screen) | Black walls | Dim walls | Rim | Window sky | Window snow (detail sd) |
|---|---|---|---|---|---|---|
| t = 0 | 1.00 | Y 0.0018, L 6.1 | Y 0.0063, L 17.5 | L 46 | L 222 | L 153 (14.8) |
| MEDIUM 3 s | 1.41, 1.17 | 0.0029, 9.4 | 0.0099, 23.9 | 58 | 220 | 162 (8.9) |
| MEDIUM 6 s | 1.65, 1.25 | 0.0033, 10.7 | 0.0114, 26.2 | 62 | 220 | 167 (7.9) |
| MEDIUM 10 s | 1.73, 1.28 | 0.0035, 11.1 | 0.0119, 26.9 | 64 | 220 | 168 (7.7) |
| LOW 3 s | 1.73, 1.28 | 0.0035, 11.2 | 0.0119, 26.9 | 64 | 219 | 169 (7.6) |
| LOW 6 s | 2.02, 1.38 | 0.0040, 12.5 | 0.0136, 29.3 | 69 | 219 | 172 (6.9) |
| LOW 10 s | 2.13, 1.41 | 0.0041, 12.9 | 0.0143, 30.1 | 71 | 219 | 173 (6.7) |

- **Wall luminance at 6 s** vs t = 0: × 1.8 (MEDIUM) and × 2.2 (LOW), against your target of
  "roughly 2 to 3". It still reads as a dark cave, cool blue-grey.
- **The window** keeps its blue sky (unchanged: the roll-off holds it at its own value) and its
  snow texture (sd 7-9), with no clipping.
- **MEDIUM is a little lower** because tier 2 finds this harness cave 0.6 stop brighter than the
  camera light predicts. Its walls are brighter than in your screenshot (L 6.8 vs 3.7 for the
  black part). The floor of that prediction was fitted to your screenshot (its taps average
  -5.6 stops), so on your real cave tier 2 should be about 0 and MEDIUM about equal to LOW.
- **Torch inside:** 1.64 × (less gain than pitch black, since the eyes adapt to the torch). The
  walls brighten more in visible terms (+12 levels vs +7 to 9), and the torch-lit walls stay
  warm (#302721).
- **Night:** outside 1.5 × (the limit); in the cave 2.2 ×. The black walls stay black (L 2.5 →
  3.8); the night sky stays night-blue (#1F2B4E → #26345D).

**Leaving and coming back** (MEDIUM, linear gain):

| Moment | Gain |
|---|---|
| At the opening | 1.35 (0.28 stop over-bright) |
| +0.25 s | 1.21 |
| +0.5 s | 1.13 |
| +1 s | 1.05 |
| +2 s | 1.007 |
| Back in: +0 / +0.5 / +1 / +2 / +4 / +6 s | 1.00 / 1.06 / 1.19 / 1.44 / 1.73 / 1.90 |

No sky pixel clips during the over-bright moment. Coming back in, the view is darker first, then
brightens slowly.

**Timing and stability.**

| Test | Result |
|---|---|
| Frame rate (the gain at each moment up to 6 s) | 30, 60 and 144 FPS within 0.2 % |
| 90 % of the final gain | 5.9 s at 60 and 144 FPS; 6.6 s at 30 FPS, whose final gain is 2 % higher (tier 2's dead band stops at a slightly different point) |
| Back in daylight, 10 % of the cave gain | 0.97-0.99 s at 30, 60 and 144 FPS |
| Doorway, turning between room and outside every 0.5 s | gain 1.285-1.301 (±0.6 % linear, ±0.3 % on screen) |
| Turning between wall and window 4 times per second inside | constant |
| Stepping across the light boundary every second | 1.000-1.061; follows the real light at the camera, no feedback |
| Lightning (scene 3 × brighter for 0.15 s) | 0 change |
| World join inside the cave | 2.2 × from the first frame |
| World join outdoors | 1.0 |
| Teleport into the cave | 1.96 × at once, 2.2 × after 0.5 s |
| Blindness, Darkness, Night Vision, eye in lava | 1.0 |
| Under a tree (sky light 13) | 1.000 (reference) |
| Under an overhang (12) | 1.20 |
| Snow field and desert at noon | gain 1.0, punch 1.0 |
| Plains at noon | nothing |

The JS copy of the gain maths used for these logs matches the GPU: the debug bar reads 0.589,
the copy 0.589.

## 11. CHANGELOG (Patch 2.1)

**Fixed**
- The stray dark dots and dashes in the daytime sky.
  - **Cause:** the fake birds of GOLDEN_FAKE_BIRDS (MEDIUM, HIGH, CINEMATIC), whose V shape
    degenerated into 0-3 isolated 7-pixel squares per bird.
  - **Fix:** removed by `SKY_PIXEL_FIX`.
  - **Effect:** no other sky pixel changes, at any time of day.
- New safety net: an invalid sky value (NaN, infinity, garbage) can no longer reach the bloom or
  the screen. Valid values are unchanged.

**Added**
- Adaptive eyes: dark adaptation in caves, interiors, deep water and at night.
  - About 6 s to 90 %; up to 2.2 × (linear) in caves, 1.5 × outdoors at night, 0.3 × strength in
    the Nether and the End.
  - Driven by the light at the camera (tier 1), refined by the measured scene in MEDIUM and up
    (tier 2).
- A short soft over-bright moment with a small bloom boost when stepping into the light; it
  settles in about 1 s.
- A gentle punch (+6 % contrast, +8 % vibrance) in very bright places.
- Highlight roll-off, so a daylight window keeps its detail.
- Local lift of dark areas, a tiny cool black lift, an optional night-vision feel, and extra
  static dither while brightened.
- An instant snap on world join, respawn, teleport and portals.
- Sky debug views 1-12 and adaptive-eyes debug views 1-10.

**Visible differences**
- Unchanged:
  - ordinary outdoor daylight (bit for bit);
  - the sun, moon, clouds, fog, water, shadows, block lighting and vegetation at the reference.
- Changed on purpose:
  - caves, interiors and nights brighten over a few seconds;
  - rain brightens by about 6 % on screen;
  - the punch appears in snowy, icy, desert, badlands and beach biomes at midday under open sky;
  - the fake birds are gone.

**Performance (estimated, not measured)**
- About 0 ms in normal daylight.
- While brightened: about 0.04 ms (ULTRA LOW) and about 0.085 ms (MEDIUM) on a 1050 Ti at
  1080p; about 0.02 ms on an RTX 3050.

## 12. Debug views and their expected look

**SKY_DEBUG** (sky pixels; the rest is the dimmed image):

| Mode | Expected look |
|---|---|
| 1. Analytic sky alone | smooth |
| 2. Palette gradient | smooth |
| 3. Golden tint, halo and haze (× 4) | smooth, strongest toward the sun and the horizon |
| 4. Sun glow and disc | glow round the sun, zero elsewhere |
| 5. Moon glow (× 4) | glow round the moon, zero elsewhere |
| 6. Vanilla stars and moon sprite (× 4) | night only; black by day |
| 7. Procedural stars (× 8) | night only; black by day |
| 8. Fake birds and quarter-resolution layer | red cells = where the birds are this moment (with the fix they are removed); yellow = bloom wash and pollen (× 8) |
| 9. Invalid values | magenta = final colour, red = colortex0, orange = colortex5; expected: none |
| 10. Isolated pixels vs neighbours 8 px away | magenta = darker than all four (expected: none); cyan = brighter (stars, sun and moon discs) |
| 11. Sky mask | grey = sky, black = not sky, white = where an exact depth test would disagree with the pack's |
| 12. colortex5 | left half RGB × 4, right half alpha |

**ADAPT_DEBUG:**

| Mode | Expected look |
|---|---|
| 1. Graph of the last 12.7 s | Ticks each second. White = gain applied, blue = the light's goal, orange = tier 2 around the mid line, yellow = over-bright. In a cave the white line rises over about 6 s toward blue. |
| 2. Gain bar | from 1 to ADAPT_MAX_BRIGHTEN, plus a blue screen tint |
| 3. Bars | the eyes (green), the goal (blue), tier 2 with its limit ticks (orange), the final gain (white) |
| 4. Scene taps | green = measured, red = sky or cloud left out, larger = centre group |
| 5. Measured scene level | grey screen; bars: measured vs predicted (-10 to +2 stops), red tick = daylight reference |
| 6. Over-bright and punch | bars |
| 7. Split screen | left without the stage, right with it |
| 8. Dark banding test | output codes × 6: a fine static grain in cave walls is right, wide clean bands would be banding |
| 9. Local lift | grey = the toe's extra factor |
| 10. Highlight roll-off | left = gain without the roll-off (red where it clips); right = the real stage (no red expected in a window) |

## 13. In-game test plan and screenshots

Use F1, a fixed FOV, render distance, GUI scale and resolution, and the same seed and coordinates
before and after. Freeze time with `/gamerule advance_time false` and `/time set`.

**Part B**
1. Your sky view from the screenshot (MEDIUM), at noon, sunset and dusk:
   - before: the backup, or SKY_PIXEL_FIX off;
   - after: the fix on.
   - Expected: identical except the bird squares.
2. The same at night with stars: identical.
3. SKY_DEBUG 10 for 30 s at noon with a still camera, then rotating: no magenta.
4. SKY_DEBUG 9 in rain and at sunset: no colour.
5. 720p and 1440p, FOV 30 and 110, rain and thunder, with clouds on and off, in two biomes and at
   y = 200. Please note how long you watched each.

**Part A**
1. **Identity:** ADAPTIVE_EYES off vs on in open daylight in a plains biome. The screenshots must
   be identical.
2. **The reference cave** (5 × 4 × 10, opening to snowy plains, noon, clear, no torch):
   - stand 7-8 blocks in, looking at the opening;
   - screenshots at 0, 3, 6 and 10 s, and the same with ADAPTIVE_EYES off;
   - expected: walls readable by 3 s, about 2 × brighter by 6 s, still a dark cave; the window
     keeps snow texture.
3. **Exit:** walk out, screenshots at 0, 0.5 and 2 s after the opening. Expected: about 1.3 ×
   over-bright, back to normal by about 1.5 s.
4. **Re-entry:** walk back in, screenshots at 0, 0.5, 2 and 6 s. Expected: darker first, then
   slowly brighter.
5. **Variants:** a torch inside; sunset; night; rain; a desert and a jungle outside.
6. **Doorway:** stand in the cave mouth, turn between room and outside 10 times. Expected: no
   pumping (watch ADAPT_DEBUG 1: the white line stays flat).
7. **Other places:** underwater (shallow and deep), a cave pool, the Nether near and away from
   lava, the End, a thunderstorm with lightning, Blindness (`/effect`), Darkness.
8. **Joining and moving:** world join inside a cave and outdoors, respawn, `/tp` into a cave, a
   portal trip. Expected: no slow blink.
9. **Frame rate:** limit it to 30, 60 and 144 FPS and time the cave entry with ADAPT_DEBUG 1.
10. **Banding:** ADAPT_DEBUG 8 at the darkest cave after 10 s: a fine grain, no bands.
11. **Regression at noon outdoors:** the sun, moon, fog, water, shadows, plastic on the player,
    clouds and block lighting all as before.

**Screenshots I would like** (only with your permission, only the Minecraft window, I keep
nothing else):
- the sky before and after at noon, sunset and night;
- the cave at 0, 3, 6 and 10 s, eyes on and off;
- the exit at 0, 0.5 and 2 s;
- night outdoors, eyes on and off;
- the doorway with ADAPT_DEBUG 1 visible after 10 turns;
- the Iris log after loading the pack.

## 14. Not verified without the game

- **The Iris runtime:**
  - the viewport and `gl_FragCoord` of composite2 on the 1 × 1 colortex6 (size parsing is
    verified in the jar);
  - that `colortex6Clear = false` keeps the value across frames, and what it holds on creation
    (the code treats anything but w = 1 as empty and snaps);
  - whether Iris recreates or reuses the pipeline on a dimension change. Either way the jump
    detector or a fresh pipeline should snap.
- **The light data:** whether `eyeBrightness` is valid on the very first frames after joining. A
  1 s snap window covers a few bad frames.
- **The expression parser:** Iris's own parser accepting every custom-uniform expression. I
  checked the function names and the uniform names in the jar, and evaluated the expressions
  with my own evaluator, not Iris's. The Iris log will say if one is rejected.
- **The tier-2 calibration** (ADAPT_Y_REF 0.15, ADAPT_FLOOR 2^-6) comes from one screenshot.
- **GPU cost** and real GL drivers: only ANGLE / Direct3D 11 compiled the shaders. NaN dropped
  by `max()` and `clamp()` is the NVIDIA behaviour; AMD and Intel may differ, but the sky guard
  uses comparisons, which reject NaN everywhere.
- **The pale squares** (pollen motes) are not confirmed.

## 15. Inherited settings noticed (reported, not changed)

- **No unused options:** every option in settings.glsl is read by a program, by Iris
  (shadowMapResolution, shadowDistance, shadowDistanceRenderMul, the shadowtex nearest flags) or by
  shaders.properties (ENTITY_SHADOWS).
- **The fake birds:** `GOLDEN_FAKE_BIRDS` with FAKE_BIRD_AMOUNT, FAKE_BIRD_SIZE and FAKE_BIRD_SPEED
  now have an effect only with SKY_PIXEL_FIX off.
- **The pollen:** `ATMOSPHERIC_PARTICLES` with PARTICLE_AMOUNT is screen-space squares on open sky
  and the likely pale squares. To remove them, set PARTICLE_AMOUNT 0 or turn the option off.
- **Legacy paths:** `SKY_GRADE`, `ATMOSPHERIC_HAZE`, `BIOME_TINT_STRENGTH`, HAZE_DENSITY,
  HAZE_HEIGHT_FALLOFF and GOLDEN_TARGET_HAZE act only where the Ambience colours or fog are off.
  For SKY_GRADE that includes the Nether and End sky.
- **Debug placeholders:** some views are kept as black placeholders for removed features
  (ATMOS_DEBUG 2, VV_DEBUG 2, TARGET_DEBUG 2 and 6).
- **`eyeBrightnessHalfLife` is not set**, so Iris's default smoothing applies to
  `eyeBrightnessSmooth`, which the fog, veil, rim and pollen use. The adaptive eyes use the raw
  `eyeBrightness` and their own smoothing.
