# Update 2A: moon rays (report)

One change: the moon gets the sun's soft light system (glow, veil, edge rim, faint shafts, cloud
occlusion) in cool night colours. Nothing else is redesigned.

- Backup of everything before this update: `backup/2026-10-05_before_update2a/` (the whole
  `shaders/` folder, README.md, UPDATE1_REPORT.md).
- New toggle: `MOON_RAYS`. Off = the previous build, bit for bit (see section 9).
- Everything below marked "measured" was measured with the pack's real programs in a WebGL test
  harness (section 9). Everything marked "estimate" was not measured.

## 1. Capability check

I have no screen capture or computer-use tool that can see the Minecraft window in this session,
so I captured nothing from the game and ran nothing in it. Instead I:

- read the game and Iris code (26.3 client jar, Iris 1.11.7 jar);
- measured the 26.3 moon textures;
- rendered test scenes with the pack's own programs in a browser test harness.

Please take the screenshots in section 12 (with your permission rules: Minecraft window only,
nothing else kept).

## 2. How the sun and the moon worked before this update

### 2.1 The sun system (unchanged in look)

| Part | Where | What it does |
|---|---|---|
| Sky, sun disc, sun glow | `gbuffers_skybasic` -> `ambienceSkyFull` (lib/ambience.glsl) | Palette sky, wide halo, thin bloom and mid glow (`ambCelestialGlow`) and the analytic sun square, written into colortex0 (RGBA16F). The vanilla sun is off (`sun = false`). |
| Sky rebuild | `final.fsh` | Rebuilds the same sky on visible sky pixels. Keeps what vanilla drew on top (moon, stars) as the positive difference. |
| Per-frame values | `final.vsh` | Palette, sun direction, sun screen position, on-screen fade, and sun visibility V with cloud cover from 9-29 fixed area taps (depth plus cloud marker). |
| Veil, rim, shafts | `final.fsh` | Veil: analytic in the angle to the sun, times V. Rim: sun-directed depth taps (`raysRimGather`) and depth normal. Shafts: depth-aware upsample of the quarter-res march. |
| Shaft mask and march | `composite` / `composite1` (quarter res, colortex5.a) | Open-sky mask, then a deterministic radial march toward the sun. |
| Clouds | `gbuffers_clouds` | Opaque (Update 1), sun glow-through patch, haze toward the sky glow. |

- **Uniforms:**
  - `sunPosition`;
  - `moonPosition` (only for varyings that nothing used);
  - `gbufferModelView(Inverse)`, `gbufferProjection(Inverse)`;
  - `eyeBrightnessSmooth`, `rainStrength`, `thunderStrength`;
  - `moonPhase` (old moon glow and procedural star fade);
  - `far`, `viewWidth`/`viewHeight`, `hasSkylight`, `hasCeiling`, `isEyeInWater`, `atmosOverworld`.
- **Buffers:**
  - colortex0: scene;
  - colortex1: water marker, and the cloud marker (A = 1, R = 0, G = opacity);
  - colortex5 (quarter): RGB = bloom, shallow-water shafts and pollen; A = shaft mask, then the shafts;
  - depthtex0.
- **Sliders:** SUN_GLOW, SUN_STYLE, SUN_GLOW_STRENGTH, SUN_HALO_SIZE, SUN_HALO_STRENGTH, SUN_RAYS,
  RAY_VARIATION, SUN_VEIL, VEIL_STRENGTH, SUN_EDGE_RIM, RIM_STRENGTH, RIM_REACH, RIM_TAPS,
  SUN_SHAFTS, SHAFT_STRENGTH, SHAFT_LENGTH, SHAFT_SOFTNESS, SHAFT_SAMPLES, SUN_VISIBILITY_TAPS,
  SKY_DITHER, CLOUD_SUN_GLOW_THROUGH, FOG_SUN_SCATTER.

**Hard-coded for the sun:**

- **Size:** `AMB_SUN_HALF` (0.075) inside the disc, bloom, veil and rim falloffs, plus a literal
  0.075 in `raysShaftFalloff`.
- **Reach and length:** `RIM_REACH` inside `raysRimGather`, `SHAFT_LENGTH` inside `raysShaftMarch`.
- **Colours:** warm white turning gold with `ambSunTwilight` (`ambSunGlowColor`), gold rim
  (`ambRimColor`), shafts in the glow colour.
- **Below the horizon:** `ambSunGlowVisibility` fades between -3.4 and +2.3 degrees.
- **Daylight-only conditions:**
  - composite writes the mask only if `vSunInFront > 0.5 && vSunElevation > -0.08`;
  - composite1 and final need `vSunInFront`.
- **Stars:** fade with the sun elevation (procedural: 1 - smoothstep(-0.22, 0.06); vanilla:
  1 - smoothstep(-0.25, 0.05)). The procedural stars are also dimmed globally by the moon phase.

### 2.2 The moon (verified in the 26.3 client jar and Iris 1.11.7 jar)

**How the game draws it:**

- The day timeline (`data/minecraft/timeline/day.json`) keys `moon_angle` 180->540 and
  `sun_angle` 0->360 with the same easing, so the moon is always exactly opposite the sun.
- `SkyRenderer.renderMoon` draws a 20/100 quad rotated by the moon angle. It uses one of eight
  32 x 32 phase sprites from the `celestials` atlas (`textures/environment/celestial/moon/*.png`).
  There is no 4 x 2 `moon_phases.png` atlas any more.
- The bright disc is the middle 8 x 8 texels, so its half size on the quad plane is 0.05
  (`AMB_MOON_HALF`). A faint ring is baked around it, out to 1.75 half sizes.
- The moon is drawn additively with alpha = 1 - rain, after the sun and before the stars.
- The quad's local x runs along world Z with the texture mirrored (vertex order and UVs in
  `buildMoonPhases`), so a phase's lit side points toward world +Z (waning) or -Z (waxing).

**What Iris provides:**

- `moonPosition` = (0, 100, 0) rotated by the game's `MOON_ANGLE` (`CelestialUniforms.getCelestialPosition`).
  It is the real moon, so in vanilla it equals -sunPosition.
- `moonPhase` = `MoonPhase.index` of the `visual/moon_phase` attribute, updated per tick.
  0 = full, 1 = waning gibbous, 2 = third quarter, 3 = waning crescent, 4 = new,
  5 = waxing crescent, 6 = first quarter, 7 = waxing gibbous. It changes at tick 0 of each day,
  6:00, when the moon is at the horizon.

**How the pack drew the moon:**

- The pack has no `gbuffers_skytextured`/`textured`/`basic`, so Iris's fallback program draws
  the vanilla moon into colortex0 over the palette sky. final keeps it as the positive
  difference. (Assumed, not observed: the previous build relies on the same thing.)
- **Moon glow before:** the `g.moon` term of `ambCelestialGlow`:
  - two exponentials on the square, mixed toward (0.78, 0.86, 1.00), clamped at 0.60;
  - placed at -sunDirection, not at `moonPosition`;
  - drawn over the disc too, which washed out the craters and lit the dark part of a crescent;
  - linear phase brightness `|4 - phase| / 4` (full 1, quarter 0.5, new 0);
  - kept 15 % of the glow in full rain, while vanilla hides the moon.
- **Behind clouds:** opaque clouds hide it (Update 1), with no patch. **Behind blocks:** depth
  hides it, with no rim or veil. **Off screen:** the analytic glow is simply off screen.
- **Night sky (measured, base biome):**
  - palette night row: zenith #070C1E, mid #0E1630, horizon #1A2440;
  - around a 40-degree moon: #0E162F at 10-30 disc sizes;
  - the old glow at the disc edge: #4B5C88.

### 2.3 Shadows at night (reported only, not changed)

- **Shadow light:** Iris's `shadowLightPosition` switches to the moon when the sun angle passes
  180 degrees (`CelestialUniforms.isDay`), so the shadow map is rendered from the moon.
- **Terrain:** `lib/gbuffers_forward.fsh` uses `shadowLightPosition` for N.L and the shadow
  test. At night the moon's shadows darken the vanilla sky light by up to 34 % (times
  litBySky and N.L), the same rule as by day.
- **Cloud shadows:** off at night (`ambCloudShadowFade`).

## 3. Sun versus moon

| Element | Sun (unchanged) | Moon (new) |
|---|---|---|
| Position | `sunPosition` | `moonPosition` (opposite the sun in vanilla) |
| Disc half size | 0.075 | 0.05 |
| Thin bloom | 0.47 exp(-d / 0.125 h), warm white to gold | 0.16 exp(-d / 0.10 h), #F4F7FF at the edge to #DCE6FF |
| Mid glow | 0.37 exp(-d / 0.65 h), soft ray lobes | 0.11 exp(-d / 0.50 h), round (no lobes), #A9BCF0 |
| Wide halo | SUN_HALO_STRENGTH 0.10, radius SUN_HALO_SIZE 0.30 rad; sky x 1.3 + 0.04 | MOON_HALO_STRENGTH 0.50, radius MOON_HALO_SIZE 0.15 rad; local sky x 1.6 plus 3.5 % of #A9BCF0 |
| On the disc | sun square drawn over the glow | no glow: the disc hides it (vanilla sprite untouched) |
| Strength | SUN_GLOW_STRENGTH, x 0.85-1.30 when low | MOON_GLOW_STRENGTH x MOON_LIGHT_INTENSITY x phase (1 / 0.69 / 0.52 / 0.25 / 0.12) |
| Shape by phase | n/a | quality 2: bloom and mid glow weaker beside the dark side (measured one-sidedness 0.53 / 0.69 / 0.55) |
| Day/night fade | -3.4..+2.3 deg sun elevation | night (sun +6..-8 deg) x sky darkness (half at about -8, full from -12) x moon altitude (-2.3..+3.4 deg); exactly 0 while the sun is above +2.3 deg |
| Weather | x (1 - 0.85 rain, biome-aware), x (1 - 0.9 thunder) | x (1 - rain, raw: the vanilla moon fades with it everywhere), x (1 - 0.9 thunder) |
| Golden-hour tint | yes (`ambSunTwilight`) | none; biome tint (MOON_BIOME_TINT_STRENGTH), MOON_COLOR_COOLNESS |
| Veil | VEIL_STRENGTH 0.30, glow colour | MOON_VEIL_STRENGTH 0.06, #7C92D8 |
| Rim | RIM_STRENGTH 0.80, gold, reach RIM_REACH | MOON_RIM_STRENGTH 0.25, #BCD0FF, reach 0.75 x RIM_REACH (thinner) |
| Shafts | SHAFT_STRENGTH 0.10, glow colour, cone to about 45 deg, length SHAFT_LENGTH | MOON_SHAFT_STRENGTH 0.015, #8EA6E8, cone x 0.75, length x 0.75, only above 2.9 deg (full from 11.5 deg) |
| Visibility V | fixed area taps at the sun's size | the same taps at the moon's size |
| Cloud patch | CLOUD_SUN_GLOW_THROUGH 0.45 | CLOUD_MOON_GLOW_THROUGH 0.20, #DCE6FF |
| Stars | fade with sun elevation | unchanged, plus a soft local dimming near the moon (MOON_STAR_DIMMING) |
| Indoors (eye sky light), underwater, Nether, End | faded / off | the same |

## 4. Code review

Severity: **B** = blocks a moon version, **M** = visible inconsistency or artifact risk,
**L** = minor, **I** = information only.

| # | File / function | Sev. | Finding | Fix |
|---|---|---|---|---|
| 1 | final.fsh, veil/rim/shaft block | B | Everything is sun-only: `vSunWorld`, `vSunUV`, `vSunVisibility`; `ambSunGlowVisibility` (zero at night); falloffs with `AMB_SUN_HALF` baked in; gather with `RIM_REACH`; shaft cone with a literal 0.075. | One `CelestialLight` struct and `celestialVeil` / `celestialRim` / `celestialShafts` (lib/sun_rays.glsl). The sun passes its old constants in the old order of operations. |
| 2 | composite.fsh, shaft mask | B | The mask is written only for `vSunInFront && vSunElevation > -0.08`, so never at night. | The mask is the same for any light; it is now written for the shaft owner of this frame. |
| 3 | composite1.fsh | B | Marches only toward `vSunUV`. | Marches toward the owner: the sun with `SHAFT_LENGTH`, the moon with 0.75 x. |
| 4 | final.vsh | B | V only for the sun. | The same tap functions run once more at the moon's size, only when the moon is in front (never in the same frame as the sun's in vanilla). |
| 5 | Temporal state of V | I | There is none: V is recomputed every frame from fixed spatial taps (bilinear area taps). There is no history to share, reset or flash at the handover. | Nothing needed. |
| 6 | colortex5 alpha | M | One channel, so one source per frame. The source must be decided identically in three passes. | `ambMoonShaftOwner()` uses the same uniforms in composite.vsh, composite1.vsh and final.vsh. The owner can change only where both strengths are 0. |
| 7 | ambience.glsl `ambCelestialGlow` (old moon term) | M | Moon placed at -sunDirection; glow drawn on the disc; linear phase; 15 % glow left in rain; shown from the moment the moon rises (still twilight). | Replaced when MOON_RAYS is on (`ambMoonGlowApply`); the old term remains when MOON_RAYS is off. |
| 8 | gbuffers_clouds.fsh | M | The patch references only the sun; the haze target and the far-edge fade used the old moon glow, which would no longer match the sky. | Moon patch added; haze and edge use `ambienceSkyGlowMoon` / `ambienceSkyFullMoon`. |
| 9 | Draw order | I | Sky pass (sky, sun off, moon, stars additive), then terrain, then clouds (depth-tested, written after). Opaque clouds overwrite moon and stars: occlusion is free. | Nothing needed. |
| 10 | gbuffers_skybasic stars | L | Stars fade only by time and rain; nothing near the moon. | Soft local dimming in the star stage (vanilla stars) and in final (procedural stars). |
| 11 | Output dither | M | +-0.75 LSB triangular is fine by day but marginal in dark gradients (measured: one 8-bit value held for 24 px along the halo). | Night boost in dark regions only (NIGHT_SKY_DITHER), down to 9 px. By day the dither line is the previous expression exactly. |
| 12 | ambiencePaletteBiome, warm-biome golden tint (existing bug, **not changed**) | M | `warmBiome * (1 - smoothstep(-0.10, 0.18, sunDir.y))` is 1 all night, so plains, forest (0.24) and savanna (0.55) keep a golden sky tint at night. Measured plains night sky #1E2132 vs base #0D152F, greyer and brighter. | Suggested (needs your OK): multiply by `smoothstep(-0.16, -0.005, sunDir.y)`, like the twilight term. |
| 13 | settings.glsl debug-forcing lines (existing design) | L | A forcing line cannot re-enable an option you switched off in the menu: as far as I know Iris rewrites every declaration line of an option. The moon debug views needed the moon code. | MOON_DEBUG is undefined when MOON_RAYS is off (no compile error; the debug view just stays off). |
| 14 | composite.vsh/fsh | L | `vMoonUV`, `vMoonElevation`, `vMoonInFront` were computed but unused (leftover from the old rays). | Left as is (harmless); the moon owner is a new flat varying. |
| 15 | Name `SUN_VISIBILITY_TAPS` | L | Now also the moon's tap count. | Kept the name, so nothing is renamed. |
| 16 | Iris shadow light at night | I | See 2.3. | Not changed, as requested. |

No bug found in the sun's glow, veil, rim or shaft code itself.

## 5. Design notes

**Why it cannot produce artifacts.**

- **Deterministic everywhere:**
  - analytic glow (smooth exponentials of the angle and of the distance to the square);
  - fixed rim and visibility taps scaled with the resolution;
  - fixed-offset shaft march with Gaussian weights and a depth-aware upsample;
  - no noise, no jitter, no frame history, no shadow map.
  - The static dither is the only per-pixel pattern, and it does not move.
- **The disc:** the glow stops at the disc's edge, antialiased over one pixel. The vanilla
  sprite (phase, square, pixel art) is never painted over, and the dark part of a crescent
  stays dark.
- **No pops:**
  - Every fade is a smoothstep of the sun or moon elevation, the screen position, the eye sky
    light or V.
  - V changes in small bilinear ramps, as for the sun.
  - The shaft buffer changes owner only where both strengths are zero.
- **One light per frame:** the sun and the moon are opposite, so at most one is in front of the
  camera. The screen-space work (V taps, rim, shafts) never runs for both.
  - At the handover only the analytic sky terms can both be non-zero, on sky pixels: a few ALU
    each, and the moon's term is skipped whenever its light is 0 (by day, in rain).
  - That is how the two-source part stays cheap.

**Cost** (estimates for a GTX 1050 Ti at 1080p; nothing measured on real hardware):

| Part | Cost |
|---|---|
| Moon glow in the sky pass and the final sky rebuild | about 15 ALU per sky pixel more than the old moon glow, only at night (uniform branch) |
| Moon rim | only pixels within about 3.5 disc sizes of an on-screen moon, 3-6 taps |
| Moon V taps | vertex shader, one tap set per frame |
| Star dimming, cloud patch, dither boost | a few ALU each |

| Preset | Night | Day |
|---|---|---|
| LOW (glow + rim) | about 0.03-0.04 ms | 0 (all moon terms skipped) |
| MEDIUM (+ veil and shafts) | + about 0.005 ms for the veil | 0 |

- MEDIUM's moon shafts reuse the sun's shaft pass and buffer, which before this update did no
  work at night. The night cost is about the sun's daytime shaft cost, never both.

**What it cannot do:**

- **No true moonlight shafts through leaves:** like the sun's, the shafts are a screen-space
  march over the open-sky mask, not shadow-map rays.
- **The glow does not follow the crescent shape exactly:** it stays round, weighted toward the
  lit side (quality 2).
- **No rim where the sky is not visible on screen** behind the edge.
- **No moon glow in water reflections:** the water was locked, and its Tier-1 sky reflection
  had no moon glow before either.
- **The moon's colour does not change with altitude** (the sun's turns golden; the moon has no
  equivalent).

## 6. Files

**Changed (complete files in the pack folder, no placeholders):**

- `shaders/lib/settings.glsl`: moon options, debug forcing, derived switches (`AMB_MOON_VISIBILITY`, `RAYS_EDGE_RIM`, `RAYS_SHAFTS`).
- `shaders/lib/ambience.glsl`:
  - moon section: phase table, night weight, sky darkness, tint, `AmbMoon`, glow, sky functions with the moon, cloud patch, star dimming, shaft owner;
  - size-parameterised veil and rim falloffs.
- `shaders/lib/sun_rays.glsl`: light-agnostic gather, march and cone; `CelestialLight` and its veil/rim/shaft functions.
- `shaders/final.vsh`, `shaders/final.fsh`: moon per-frame values and V; sun and moon through `CelestialLight`; moon sky glow; star dimming; night dither; MOON_DEBUG views.
- `shaders/composite.vsh`, `shaders/composite.fsh`: shaft owner and mask condition.
- `shaders/composite1.vsh`, `shaders/composite1.fsh`: march toward the owner.
- `shaders/gbuffers_skybasic.vsh`, `shaders/gbuffers_skybasic.fsh`: moon glow in the sky, star dimming.
- `shaders/gbuffers_clouds.vsh`, `shaders/gbuffers_clouds.fsh`: moon patch, moon-aware haze and edge.
- `shaders/shaders.properties`: regenerated with the new options, screen and presets.
- `shaders/lang/en_us.lang`: labels.
- `README.md`: Update 2A section appended.
- `UPDATE2A_REPORT.md`: this file.

**Unchanged (byte-identical to the backup, checked by hash):**

- `gbuffers_terrain.*`, `gbuffers_water.*`, `gbuffers_textured_lit.*`;
- `shadow.*`, `shadow_entities.*`;
- `lib/gbuffers.vsh`, `lib/gbuffers_forward.fsh`;
- `lib/water_reflection.glsl`, `lib/shadow_distortion.glsl`;
- `block.properties`, `textures/clouds.png`.

The terrain, water and entity programs include `lib/ambience.glsl`, but call none of the changed
or new functions, so their output is unchanged.

**No other files touched:**

- fog: no fog function changed;
- biome palettes: untouched;
- water and shadows: no water or shadow file changed;
- entity gloss, materials, vegetation, bloom (its code; its input around the moon is slightly
  different, section 8), particles: untouched.

**Sun-related code that was refactored** (all verified bit-identical, section 9):

| File | Function | Change |
|---|---|---|
| lib/sun_rays.glsl | `raysRimGather` | + `reach` (the sun passes `RIM_REACH`) |
| lib/sun_rays.glsl | `raysShaftMarch` | + `shaftLength` (`SHAFT_LENGTH`) |
| lib/sun_rays.glsl | `raysShaftFalloff` | + `halfSize`, `spread` (0.075, 1.0) |
| lib/sun_rays.glsl | guards | `SUN_EDGE_RIM` / `SUN_SHAFTS` -> `RAYS_EDGE_RIM` / `RAYS_SHAFTS` (same as before when the moon options are off) |
| lib/ambience.glsl | `ambVeilFalloff`, `ambRimFalloff` | now call `ambVeilFalloffSized` / `ambRimFalloffSized` with the sun's constants |
| final.fsh | sun veil/rim/shafts | inline code -> `finalSunLight()` + `celestialVeil/Rim/Shafts`, same constants and order |
| final.fsh | output dither | the night boost is a separate line that runs only at night |
| composite.fsh, composite1.fsh | shaft mask / march | the sun's condition and march are the same; the moon is an additional branch |
| gbuffers_skybasic.fsh | view direction | moved into `skyViewDirection()` |

## 7. Options, screens, presets

**New screen "Moon Rays"** (sub-screen at the end of Ambience > Sun Rays). It lists: MOON_RAYS,
MOON_LIGHT_INTENSITY, MOON_GLOW_STRENGTH, MOON_GLOW_QUALITY, MOON_HALO_SIZE, MOON_HALO_STRENGTH,
MOON_PHASE_INTENSITY, MOON_VEIL, MOON_VEIL_STRENGTH, MOON_EDGE_RIM, MOON_RIM_STRENGTH, MOON_SHAFTS,
MOON_SHAFT_STRENGTH, MOON_COLOR_COOLNESS, MOON_BIOME_TINT_STRENGTH, CLOUD_MOON_GLOW_THROUGH,
MOON_STAR_DIMMING, NIGHT_SKY_DITHER. MOON_DEBUG and MOON_DEBUG_MODE are on the Debug screen.

| Option | Default | Values |
|---|---|---|
| MOON_RAYS / MOON_VEIL / MOON_EDGE_RIM / MOON_SHAFTS | on | on/off. The last three are compiled out without MOON_RAYS. |
| MOON_LIGHT_INTENSITY | 1.00 | 0-1.50 (master) |
| MOON_GLOW_STRENGTH | 1.00 | 0-1.50 |
| MOON_GLOW_QUALITY | 2 | 1 round, 2 phase-aware |
| MOON_HALO_SIZE | 0.15 | 0.08-0.30 rad |
| MOON_HALO_STRENGTH | 0.50 | 0-0.80 |
| MOON_PHASE_INTENSITY | 1.00 | 0-1 |
| MOON_VEIL_STRENGTH | 0.06 | 0-0.20 |
| MOON_RIM_STRENGTH | 0.25 | 0-0.50 |
| MOON_SHAFT_STRENGTH | 0.015 | 0-0.060 |
| MOON_COLOR_COOLNESS | 0.50 | 0 cool white ... 1 blue-violet |
| MOON_BIOME_TINT_STRENGTH | 0.30 | 0-1 |
| CLOUD_MOON_GLOW_THROUGH | 0.20 | 0-0.60 |
| MOON_STAR_DIMMING | 0.50 | 0-1 |
| NIGHT_SKY_DITHER | 0.33 | 0 (off) - 1 |
| MOON_DEBUG / MOON_DEBUG_MODE | off / 1 | 1-13 |

**Quality:**

- The moon's own quality slider is MOON_GLOW_QUALITY.
- Its rim, shafts and visibility share the sun's quality sliders (RIM_TAPS, SHAFT_SAMPLES,
  SUN_VISIBILITY_TAPS), because the same code and passes draw both.

**Presets.** Every preset defines all 253 options (233 before + 20 new), with "!" for disabled
booleans.

| Preset | Moon setup |
|---|---|
| ULTRA_LOW | MOON_RAYS, quality 1, !MOON_VEIL !MOON_EDGE_RIM !MOON_SHAFTS (analytic glow only) |
| LOW | quality 2, MOON_EDGE_RIM (3 taps, like the sun's), !MOON_VEIL !MOON_SHAFTS |
| MEDIUM (default) | glow, veil, rim (4 taps), very faint shafts (12 samples) |
| HIGH | the same with rim 6 taps, 14 shaft samples, 21 visibility taps |
| CINEMATIC | the same with rim 6 taps, 16 shaft samples, 29 visibility taps |

- **Programs:** `program.composite1.enabled` and `program.composite.enabled` now also list
  `MOON_SHAFTS || MOON_DEBUG`.
- **Removed or renamed options:** none.
- **Inherited or unused settings in shaders.properties** (reported, not rewritten): no option is
  unused, every option is on a screen, no screen names an undeclared option, and every preset is
  complete.
  - Stale debug modes kept for compatibility: ATMOS_DEBUG_MODE 2, VV_DEBUG_MODE 2 and
    TARGET_DEBUG_MODE 2 and 6 show black (their old rays were removed in v5).
  - See also code review #12 (golden tint at night) and #15 (the tap-count name).

## 8. Colours: suggestions, what I kept, what I measured

Measured in the harness: a full moon 40 degrees up, base biome, default options, 960 x 540,
FOV 70. Sky colours are along a line from the moon's centre, in disc half sizes (H).

| Element | Your suggestion | Used | Measured old -> new |
|---|---|---|---|
| Moon core | #F4F7FF | kept, as the inner edge of the bloom | disc centre #DCEFFF -> #9BA9D1, bright texel 0.5 H #FFFFFF -> #E5F8FF. The disc is now the vanilla sprite over the sky; before, the old glow was painted under it. |
| Thin bloom | #DCE6FF | kept | 1.05 H #4B5C88 -> #405181, 1.2 H #364670 -> #2F3F6F |
| Mid glow | #A9BCF0 | kept | 1.5 H #263459 -> #23325C, 2 H #1B2749 -> #1A264D |
| Wide halo | about #4A5C98 near the moon on a #1C2A5C zenith | **changed:** a x 1.6 lift of the local sky plus 3.5 % of #A9BCF0 (see below) | 3 H #101834 -> #101938, 6 H #0C142C -> #0D152E, far sky (30 H) #0E162F -> #0F172F |
| Veil | #7C92D8 | kept | +7 to +8 levels on night stone right under the moon, +2 at 64 px |
| Rim | #BCD0FF | kept | silhouette edge under the moon #11141C -> #2F3545; rim alone +33, +20, +11, +11, +5, +4, 0 at 0, 1, 2, 3, 4, 6, 8 px |
| Shafts | #8EA6E8 | kept | at most 1-2 levels (very faint, as asked) |
| Violet tint option | slider | MOON_COLOR_COOLNESS | |

- **Why the halo changed:** the pack's night sky is much darker than #1C2A5C (#0E162F around
  the moon, night zenith palette #070C1E). #4A5C98 would be about 5 x the sky's brightness and
  would break the calm night.
- **Glow strength:** weights 0.16 / 0.11, which are 0.34 x / 0.30 x the sun's 0.47 / 0.37.
  Peak sky luminance just outside the disc: moon 72.9, sun 200.4 (8-bit luma), so **moon/sun =
  0.36**. The old moon glow peaked at 82.6.
- **Glow size:** bloom and mid falloffs 0.005 / 0.025 rad (the sun's 0.0094 / 0.049 rad, about
  0.5 x). Halo radius 0.15 rad (the sun's 0.30).
- **Phases:**

| Phase | Your suggestion | Used |
|---|---|---|
| Full | 1.0 | 1.0 (kept) |
| Gibbous | not given | 0.69 (measured) |
| Quarter | 0.55 | 0.52 (measured on the 26.3 sprites) |
| Crescent | 0.30 | 0.25 (measured) |
| New | 0.12 | 0.12 (kept; the measured 0.19 is only the new moon's dark outline) |

  Measured glow 1.3 H beside the disc (right / left; right = world +Z):

| Phase | Right / left |
|---|---|
| Full | #283866 / #2A3B68 |
| Waning gibbous | #23335F / #20305B |
| Third quarter | #21305A / #1D2C56 |
| Waning crescent | #1D2B54 / #1B2A52 |
| New | #1A2951 / #1B2951 |
| Waxing crescent | #1B2A52 / #1D2C55 |
| First quarter | #1D2C55 / #22315C |
| Waxing gibbous | #1F2F5A / #253560 |

  The glow leans to the lit side, and the dark centre of a crescent stays #172449 (sky plus
  dark texel).

- **Biome nights:** the moon's own tint at the default 0.30 is deliberately small (measured at
  1.3 H, base #283866):

| Biome | Measured | Change |
|---|---|---|
| Jungle | #263863 | greener |
| Desert | #293864 | warmer |
| Snowy / taiga | #283A67 | icier |
| Swamp | #27375F | dimmer green-grey |
| Dark forest | #273761 | dimmer |
| Ocean | #283965 | about the same |

  - The halo itself inherits the biome night palette, so it is never grey.
  - Plains read #394469 because of the existing golden-tint bug (#12), not the moon.
- **Bloom:** the bloom code is unchanged. Its input near the moon changed: the disc is no longer
  brightened by a glow underneath, so the moon produces slightly less bloom. Sum around the moon:
  the glow mix is clamped (halo at most 60 %, bloom plus mid glow at most 45 %), and the peak is
  0.36 x the sun's.

## 9. Test results

**Identity (measured).**

- **Method:**
  - Harness `update2a.html`; it served the backup tree and the new tree side by side and ran the
    real `gbuffers_skybasic`, `gbuffers_clouds`, `composite`, `composite1` and `final` programs.
  - Scene: a ray-traced stepped stone pyramid, an optional cloud box drawn by the real cloud
    program, the vanilla moon sprite drawn as SkyRenderer does, and vanilla-like stars.
  - Compared bit for bit: the 8-bit output plus the colortex0 and colortex5 float buffers.
  - This browser occasionally returns one of two slightly different frames for the same program
    and inputs (seen old vs old as well). So each build rendered 3-8 frames, and a case counts as
    identical when an old and a new frame match exactly. Both builds produced the same set of
    frames.

| Comparison | Result |
|---|---|
| MOON_RAYS off vs old, 8 scenes (5 day, dusk, 2 night) x 5 option sets (defaults, ULTRA_LOW, LOW, MEDIUM, CINEMATIC) | 40 / 40 bit-identical |
| MOON_RAYS on vs old, 5 day scenes (sun 16 deg over the apex, 40 deg with a cloud over the sun, 3 deg golden, 2.5 deg just above the cut-off, looking away with stars) x 5 option sets | 25 / 25 bit-identical |
| MOON_DEBUG 13 (sun identity view) | black by day, at night and at dusk |

The suite was run again on the final code: 65 / 65 identical.

- **One fix needed along the way:** with MOON_RAYS on, the night dither boost first changed 4
  daytime pixels by 1/255 (last-bit rounding). It is now a separate night-only line, and the day
  is identical.

**Compile (measured, WebGL2/ANGLE):**

- 137 option sets x 10 programs = 1,370 programs compiled and linked, **0 failures**.
- The option sets: defaults, the 5 presets, all debug views (MOON_DEBUG 1-13, LIGHT_DEBUG 1-17,
  SUN_DEBUG 1-16 and the others), and moon-specific mixes:
  - moon off; glow only;
  - moon shafts or rim without the sun's rays;
  - Ambience colours off; translucent clouds;
  - forced snowy and jungle; biome off;
  - the water-own-palette variant (most varyings); minimum and maximum sliders.
- One failure was found and fixed on the way: MOON_DEBUG with MOON_RAYS off (code review #13).

**Moon look (measured, see section 8 for the colours):**

- **Night brightness:** whole frame +0.3 % (mean luma 23.11 -> 23.18); far from the moon +0.4 %.
- **Rim:** only on edges turned to the moon. 0 on the side silhouette and 0 farther than 300 px.
  Nothing else changes farther than 300 px from the moon (at most 1 level, the dither).
- **Cloud over the moon:**
  - centre old #4A4750 -> new #676773 (silver patch), +2 H #5B5964, +4 H #514F59;
  - V = 0.000 with cloud cover 1.000; half covered V 0.11 / cover 0.89; open sky V 1.000.
- **Handover, looking east at the rising moon:**
  - moon contribution (new - old luma, 2 H beside the moon), by sun elevation: +8 to +2 deg 0;
    0 deg 0.1; -2 deg -1.6; -4 deg -0.7; -6 deg +3.3; -10 deg +4.4; -12 deg +4.2; -16 deg +1.1;
  - largest change per 0.25 deg of sun movement: 1.2 levels;
  - the negative values at -2..-4 deg: the old glow showed in twilight, the new one waits for a
    dark sky;
  - looking west at the setting sun: new = old down to -10 deg; after that only the dither boost
    differs (mean 0.003-0.06 levels per pixel).
- **Moon rising** (altitude -4..10 deg) and **moon leaving the screen** (yaw 0..60): smooth, with
  no step; the largest frame-energy step comes from the glow region leaving the frame.
- **Stars near the moon:** brightest star at 2-4 H 140 -> 124, at 4-8 H 119 -> 118, beyond that
  unchanged.
- **Full rain at night:** no moon glow, matching vanilla's hidden moon. The old build kept a faint
  one (#16181D -> #131519 at 1.3 H).
- **Banding:** longest run of one 8-bit value along the halo: 280 px without dither, 24 px with
  SKY_DITHER, 9 px with the night boost. Flat night sky luma SD 0.55 with dither.
- **Debug views 1-13:** all compile and show what the README's MOON_DEBUG list describes.
  - Glow, veil, rim and shaft views are black by day.
  - Veil, rim and V read 0 behind an opaque cloud.

**Not measured:** FPS or GPU time (no access to the game or your GPU).

## 10. CHANGELOG (Update 2A)

**Added:**

- **Moon light:**
  - MOON_RAYS: the moon's glow (thin bloom, mid glow, wide halo), phase-scaled from measured
    sprite brightness, phase-aware shape (quality 2), biome and coolness tint;
  - MOON_VEIL, MOON_EDGE_RIM, MOON_SHAFTS: the sun's veil, rim and shafts for the moon, faint
    and cool.
- **Shared ray code:**
  - `CelestialLight` abstraction: one set of veil/rim/shaft functions for both lights;
  - moon visibility V (the sun's taps at the moon's size);
  - one shaft source per frame with a shared owner decision.
- **Night details:**
  - CLOUD_MOON_GLOW_THROUGH: silver patch on clouds in front of the moon;
  - MOON_STAR_DIMMING: soft local star dimming near the moon (vanilla and procedural stars);
  - NIGHT_SKY_DITHER: extra static dither in dark regions at night.
- **Menu and debug:** MOON_DEBUG (13 views, including a sun identity check); the "Moon Rays"
  screen; all moon options in every preset.

**Changed (visible, only at night with MOON_RAYS on):**

- **Glow shape and colour:** the moon glow is cooler, a little weaker right at the disc edge,
  with a wide faint halo.
- **The disc:** no glow on the disc, so craters show and the dark part of a crescent stays dark.
  The disc centre reads #9BA9D1 instead of #DCEFFF; bright texels stay near white.
- **Phases:** a new moon barely glows (was 0 with the old linear rule; now 0.12), gibbous 0.69
  (was 0.75).
- **Dusk and rain:** no moon glow at dusk until the sky darkens; none in rain (like the vanilla
  moon).
- **Clouds and stars:** far clouds near the moon melt into the new glow; stars right next to the
  moon are a little dimmer.
- **Dither:** dark night regions get a slightly stronger, static dither.

**Refactored, no visible change:** see section 6 (verified bit-identical, section 9).

**Fixed:** nothing in the sun code (no bug found there).

**Found, not changed:** the warm-biome golden sky tint stays on all night (code review #12).

**Performance:** estimate about 0.03-0.04 ms at night in LOW on a GTX 1050 Ti at 1080p, 0 by
day. MEDIUM shafts at night cost about what the sun's shafts cost by day (one source per frame).
Not measured on real hardware.

## 11. Test plan (in game)

Use a creative world with `/gamerule advance_time false` (26.3 renamed doDaylightCycle; checked in the jar), F1 to hide the HUD, and the same
FOV, render distance, GUI scale and resolution for every before/after pair. "Before" =
MOON_RAYS off (identical to the previous build); "after" = MOON_RAYS on. Times are approximate:
26.3 eases the sun and moon angles, so adjust by a few hundred ticks.

1. **Identity.**
   - MOON_RAYS off vs the previous build: day (`/time set 6000`) and night (`/time set 18000`),
     the same image.
   - MOON_RAYS on vs off at `/time set 1000`, `6000`, `11000`: the same image.
   - MOON_DEBUG 13: black at any time.
2. **Full cycle:** `/time set 11500`, then `/gamerule advance_time true` and watch to 13500,
   then `/time set 22000` to 24000.
   - Expected: the moon's glow appears only as the sky turns dark blue, after the sun's glow is
     gone. No pop, flash, double glow or flicker.
   - MOON_DEBUG 1 shows the two weight curves.
3. **Phases** (moon high at 18000 + day x 24000):

   | Phase | Command |
   |---|---|
   | Full | `/time set 18000` |
   | Waning gibbous | `/time set 42000` |
   | Third quarter | `/time set 66000` |
   | Waning crescent | `/time set 90000` |
   | New | `/time set 114000` |
   | Waxing crescent | `/time set 138000` |
   | First quarter | `/time set 162000` |
   | Waxing gibbous | `/time set 186000` |

   - Expected: the glow scales about 1 / 0.69 / 0.52 / 0.25 / 0.12.
   - With quality 2 it leans to the lit side of the sprite. **If it leans to the dark side, tell
     me:** the side sign comes from the bytecode and could not be observed.
4. **Occluders:** a stepped stone peak, a tree trunk, leaves, a single block, a gap between two
   blocks, with the moon about 20-40 degrees up (around `/time set 14500` looking east).
   - Expected: a thin pale-blue rim only on edges turned to the moon, nothing elsewhere, no glow
     over blocks, no halos, no grain.
   - MOON_DEBUG 8 for the rim alone.
5. **Cloud crossing the moon** (`advance_time false`; the clouds keep drifting).
   - Expected: the moon fully hidden, a soft silver patch on the cloud, smooth.
   - MOON_DEBUG 6 and 10 show V and the cloud cover.
6. **Edges of the view:** moon at the screen edge and just off screen; looking away; moonrise at
   about 12000-13000 in the east and moonset at about 23000-24000 in the west.
   - Expected: smooth fades.
7. **Resolutions, FOV and conditions:**
   - 720p, 1080p, 1440p, 4K; GUI scales; FOV 30 and 110: the rim width scales with the
     resolution.
   - Rain and thunder: the moon and its glow fade together.
   - Indoors: the veil, rim and shafts fade with the sky light at your eyes; the sky glow stays.
   - Underwater, Nether, End: no moon rays.
8. **Biomes at night:** jungle, desert, snowy plains, swamp, ocean, plains, dark forest.
   - Expected: small tint differences (section 8). Raise MOON_BIOME_TINT_STRENGTH to see them
     better.
9. **Banding:** MOON_DEBUG 12 on a clear night.
   - Expected: on the left, wide clean stripes in the halo; on the right, fine static grain.
   - NIGHT_SKY_DITHER 0 to compare.
10. **Performance:** F3 frame time, or an FPS counter, at night looking at the moon, MOON_RAYS on
    vs off (LOW and MEDIUM).
    - Expected: under about 0.05 ms in LOW on a 1050 Ti (estimate); day: no difference.
11. **Regression:** sun, fog, water, shadows, plastic gloss, ambience palettes and clouds by day,
    MOON_RAYS on vs off. Expected: identical.

## 12. Screenshot list

Please capture these yourself, Minecraft window only, F1, same settings for each pair. Take each
before (MOON_RAYS off) and after (MOON_RAYS on):

1. Night, full moon about 40 degrees up, looking at it.
2. The moon behind a stone peak (or any stepped block silhouette).
3. The moon behind a cloud.
4. A horizon view at night with the moon low (about 10 degrees).
5. A jungle night with the moon in view.
6. A snowy plains night with the moon in view.
7. A daytime pair (sun about 30 degrees up, same camera) to show the sun is unchanged.
8. Optional: MOON_DEBUG 1, 3, 12 and 13.

If anything fails to load: `logs/latest.log`.

## 13. What I could not verify without the game

- The in-game look and brightness. The harness emulates the vanilla moon, the stars and the Iris
  pass order; it is not Minecraft.
- The lit-side direction of the phase-aware glow. It comes from the moon quad's vertex order and
  UVs in the bytecode; the harness uses the same assumption, so it cannot catch a sign error.
- That Iris's fallback program draws the vanilla moon into colortex0, as before. The previous
  build already relied on it.
- How Iris applies a menu value to the debug-forcing lines (code review #13).
- Bit-exactness on your NVIDIA/AMD/Intel driver.
  - It was verified on ANGLE/Direct3D 11. The sun's math runs in the same order with the same
    constants, so I expect identical output.
  - A driver that fuses multiply-adds differently could in theory flip a rare pixel by 1/255.
- Performance on a GTX 1050 Ti or RTX 3050.
