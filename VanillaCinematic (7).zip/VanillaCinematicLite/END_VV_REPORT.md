# Update 4 (End VV): o End do Vibrant Visuals, brilho de fontes de luz, Vitrail

> **Atualizado pela 4.1** ([END_VV_4_1_REPORT.md](END_VV_4_1_REPORT.md)): o céu agora tem um grão leve
> (`END_SKY_GRAIN` 25), a névoa do flash é volumétrica e o `FLASH_FOG_BOOST` mudou de sentido. Onde este
> relatório diz "céu liso" ou "a névoa fica 2× mais densa no flash", vale o da 4.1.

Backup: `backup/2026-10-07_before_end_vv/` (os arquivos de antes, completos). Para voltar, copie-os
por cima e apague os arquivos novos: `shaders/gbuffers_spidereyes.vsh`, `shaders/gbuffers_spidereyes.fsh`,
`shaders/entity.properties` e `shaders/item.properties`.

## 1. Como trabalhei

- Não tenho o jogo nesta sessão. Não renderizei nada no Minecraft.
- **Medi** os pixels das suas quatro imagens.
- **Li** o código do pack inteiro e a documentação e o código-fonte do Vitrail (GitHub
  avpbynf/Vitrail-Shaders, commit de 27/09/2026).
- **Compilei** todos os programas com o glslang (o compilador de referência do GLSL):
  - nos 5 presets, com as opções exatas de cada um;
  - com cada debug do End e com as variações de saída do terreno.
  - Tudo compila. O pack original também compilava nos 5 presets.
- **Calibrei** o céu, o halo do flash e o brilho dos olhos com modelos numéricos das mesmas fórmulas
  do shader, comparados com as suas referências.

## 2. O que as referências mostram (medido)

Médias de 5×5 a 20×10 px, valores de tela (sRGB).

| Elemento | Imagem 1 (seu jogo) | Referências 2–4 (Vibrant Visuals) |
|---|---|---|
| Céu no alto | #17101E a #1F112F | #0E0916 (ainda assim a ~60°) |
| Céu a ~10° | #391D4B | #0C0813 |
| Céu no horizonte | faixa lilás chapada #7664A7 com borda reta | #0A060E, contínuo |
| Grão da textura do céu | – | nenhum: desvio de luma 0,8 a 1,6 em 200×200 px (só compressão) |
| Chão de end stone | #706965 (cinza-violeta) | #4D492F (amarelo-oliva escuro) |
| Pilar de obsidiana | violeta | #0F0B16, quase preto |
| Centro do halo do flash | – | #683A70 sobre o fundo #100B18 |
| Cor do halo (acima do fundo) | – | (1,00, 0,53, 0,98) |
| Olho do enderman | sem brilho | #F4B8FF, com halo de ~12 px |
| Cristal do End | – | branco (241, 244, 255), halo curto |

- **Imagem 3** (luz da esquerda, fora da tela): só a face esquerda do pilar próximo fica roxa (#2B1A31
  contra #150C1A). O chão não muda.
- **Dragão vivo:** nas três referências há cristais nas torres e, na imagem 3, o próprio dragão. Então
  o visual pedido é o do End **durante a luta**.

## 3. Por que os bugs aconteciam

### 3.1 O flash não aparecia antes de matar o dragão

Foram duas causas somadas.

1. **O jogo não desenha céu nenhum durante a luta.** A barra do dragão é a única do jogo que pede
   "névoa de mundo", e com ela o `LevelRenderer` não monta o passe do céu:
   - nem o do jogo, nem o do pack;
   - sem caixa do End e sem o sprite do flash.
   - O Vitrail documenta isso em "Sky and shadows" ("a boss stops it").
   - A pesquisa também confirma: no Bedrock o flash fica escondido atrás da névoa do dragão.
2. **O próprio pack apagava o flash na luta.** O Update 3 multiplicava:
   - o brilho do flash no céu e na névoa por `1 - vclDragon` (zero durante a luta);
   - a luz do flash nas superfícies por 1/3.
   - Ou seja, com o dragão vivo o pack zerava o brilho de propósito.

**Correção:**

- O céu do End do pack já era montado no `final`, sem depender do que o jogo desenha, então funciona
  mesmo sem o passe do céu.
- A luta agora não muda nada, como nas suas referências.
- `END_DRAGON_FOG` (desligado por padrão) traz o comportamento antigo.

### 3.2 O céu cortado

- **A faixa da imagem 1** (#7664A7, borda reta a ~5°) tem exatamente as cores medidas no relatório da
  correção 3.1 (`END_FIX_REPORT.md`, seção 2).
  - Então a imagem 1 parece ser da versão anterior à 3.1.
  - A causa daquela faixa (o "horizonte" do Iris desenhado com `gbuffers_skybasic`) já está corrigida
    no seu zip e continua corrigida.
- **O que ainda tornava o céu "cortado"** é a falta de transição que você descreveu:
  - O horizonte da paleta antiga era violeta claro (#3A1E4E), bem mais claro que o resto do céu e
    que o chão ao longe.
  - A névoa entre flashes era forte (46 % a 100 blocos) e da mesma cor clara.
  - Somando a textura granulada do céu, a borda da ilha e o fundo ficavam em tons diferentes.
- **Agora:**
  - O céu é o gradiente liso e escuro das referências.
  - A névoa usa **a mesma função** do céu (a cor do céu naquela direção). A borda da ilha, o terreno
    distante e a distância de renderização somem no céu sem borda, faixa ou degrau de cor.

## 4. O que mudou

### 4.1 Céu do End (`lib/dimension_ambience.glsl`, `final.fsh`)

| Elevação | Cor nova |
|---|---|
| Vazio, 30° abaixo | #07040A |
| Horizonte | #0A060E |
| ~10° | #0C0813 |
| ~30° e acima | #0E0916 |
| Zênite | #100A19 |

- **O zênite:** a wiki dá #161124 para o zênite do Vibrant Visuals, mas isso é mais claro que qualquer
  pixel de céu das referências. No modelo, o alto da imagem 2 (≈60°) saía com luma 20 contra 12 no
  print. Por isso fica #100A19.
- **Sem textura:** `END_SKY_GRAIN` (0, 25, 50 ou 100 %) devolve o grão da textura vanilla por cima do
  gradiente liso.
- **O que continua aparecendo por cima do céu:** fogos de artifício, feixes e os raios da morte do
  dragão, como na 3.1.

### 4.2 Névoa do End (`final.fsh`)

- **Cor:** a do céu naquela direção.
- **Densidade:** 17 % a 100 blocos entre flashes. Na referência, o chão mantém a cor até a borda da
  ilha.
- **Durante o flash:** fica `FLASH_FOG_BOOST` 2× mais densa e brilha na direção do flash.
- **Na distância de renderização** o terreno funde com o céu (`HORIZON_BLEND`, como antes).

### 4.3 O halo do flash

Ajustado em cerca de 3 500 células de céu da imagem 2 (grade de 20 px), ignorando o pilar e os
cristais.

| Parâmetro | Antes | Agora |
|---|---|---|
| Forma | 0,82 Gauss + 0,14 exp + 0,04 constante | 0,85 Gauss + 0,15 exp, sem constante (o resto do céu não clareia, como na referência) |
| `FLASH_HALO_SIZE` | 0,40 | 0,34 (≈19,5°; metade do brilho a ~15°) |
| Pico do halo | 0,50 | 0,40 |
| Cor do halo | (0,93, 0,57, 0,81) | (0,94, 0,53, 0,98), mais azulada |

**Erro do modelo contra a imagem 2** (186 células de 80 px à direita do pilar):

- média −0,4 de 255 em luma, rms 3,1, máximo 8,7;
- longe do flash (>40°): rms 2,3.

O campo de visão da referência não é conhecido:

- com 70°, o melhor raio seria 0,31;
- com 80°, seria 0,40;
- 0,34 fica no meio;
- se o halo parecer largo ou estreito no seu FOV, mude `FLASH_HALO_SIZE`.

A luz do flash nas superfícies (#E45DFF, sombras opostas, brilhos) não mudou. Ela só deixou de ser
cortada na luta.

### 4.4 A luz do End nos blocos e entidades (`lib/gbuffers_forward.fsh`)

- **Antes:** o tom violeta (`END_AMBIENT_HUE` 1,16 / 0,89 / 1,61 com força 0,75) transformava o end
  stone em cinza-violeta (#706965).
- **Agora:** luz quente-neutra e mais escura.
  - Calculada a partir da imagem 1: luz necessária = alvo ÷ luz atual, com a textura do end stone
    #DCDF9E.
  - `END_AMBIENT_HUE` = (1,151, 0,957, 0,978), `END_AMBIENT_TINT` 1,00, `END_AMBIENT_BRIGHTNESS`
    0,67.
  - O end stone deve sair perto de #4D492F e a obsidiana quase preta.
- A luz de tochas e lanternas mantém a cor e o brilho de antes.

### 4.5 Brilho das fontes de luz (`EMISSIVE_GLOW`, novo)

| Fonte | Como |
|---|---|
| Olhos (enderman, aranha, phantom, dragão) | Programa novo `gbuffers_spidereyes`. Antes o jogo os desenhava sozinho, sem brilho. Olho mais claro com núcleo branco: um roxo de textura como #CC00FA vira ≈ #FFB6FF (referência: #F4B8FF). |
| Cristais do End, blazes, glow squids, magma cubes, allays, orbes de XP, projéteis brilhantes | `entity.properties` (número 9). |
| Itens que emitem luz (tochas, lanternas, glowstone, end rods, froglights, balde de lava, blaze rod, nether star, cristal do End...) na mão, no chão ou em molduras | `item.properties` (número 9). |
| Blocos emissores (classe 9 do `block.properties`) | Já marcados. Agora também brilham em volta. |

- **Só os texels claros brilham:** a chama e não o cabo, o núcleo do cristal e não a moldura.
- **Mobs e itens emissores** nunca ficam mais escuros que a própria textura.
- **Como funciona:**
  - Um alvo novo, `colortex3` (R11F_G11F_B10F, limpo a cada quadro, com mipmaps), recebe o que cada
    emissor emite.
  - O `composite` junta isso em ¼ de resolução: centro e dois anéis de 6 amostras, a 6 e 13 px em
    1080p, escalados com a altura da tela. Pesos 0,20 / 0,30 / 0,50.
  - O `final` soma o brilho junto com o bloom, antes da névoa. Assim um brilho distante esmaece com o
    emissor.
- **Calibração nos olhos da imagem 4:**

| Distância do olho | Referência | Modelo |
|---|---|---|
| 6 px | +17 níveis | +16 |
| 12 px | +7 | +7 |
| 18 px | +4 | +4 |

- **Esta é a única mudança fora do End.** No Overworld e no Nether, olhos, tochas e itens luminosos
  também passam a brilhar, como no Vibrant Visuals. Para tirar: desligue `EMISSIVE_GLOW` (Glow and
  Emissive).

### 4.6 Arquivos

| Arquivo | Mudança |
|---|---|
| `shaders/lib/dimension_ambience.glsl` | Seção do End reescrita: céu e névoa do VV, novo halo, luz do End, `endDragonFight()` |
| `shaders/final.fsh` | Céu e névoa do End pela função nova; a luta só conta com `END_DRAGON_FOG`; lê o brilho; debug 10 mostra o céu novo |
| `shaders/lib/gbuffers_forward.fsh` | Luz do End; fonte de brilho de blocos, mobs e itens |
| `shaders/lib/gbuffers.vsh` | Lê `entityId` e `currentRenderedItemId` (só em `gbuffers_textured_lit`) |
| `shaders/gbuffers_terrain.fsh`, `gbuffers_textured_lit.fsh/.vsh` | Saída `colortex3` |
| `shaders/composite.fsh` | Alvo `colortex3` e o brilho em ¼ de resolução |
| `shaders/gbuffers_spidereyes.vsh/.fsh` | **Novos:** olhos brilhantes |
| `shaders/entity.properties`, `shaders/item.properties` | **Novos:** mobs e itens que brilham |
| `shaders/lib/settings.glsl`, `shaders/shaders.properties`, `shaders/lang/en_us.lang` | Opções novas, padrões novos nos 5 presets, menus, nomes |
| `README.md` | Seção "Update 4" |

**Não tocados:**

- `gbuffers_skybasic` (o descarte do horizonte do Iris no End continua);
- `gbuffers_water`, `gbuffers_clouds`, `composite1`, `composite2`;
- `final.vsh`, `shadow*`, `lib/ambience.glsl` e os demais.

## 5. Vitrail (Vulkan)

Li a documentação (tradução, céu e sombras, uniforms, formato do pack) e conferi no código-fonte.

**O que o pack usa e o Vitrail fornece:**

- **Uniforms:** 163 dos 164 que o pack declara (a exceção vem logo abaixo), inclusive `endFlashIntensity`, `endFlashPosition`,
  `previousEndFlashIntensity`, `heavyFog`, `entityId`, `currentRenderedItemId` e `renderStage`.
- **Uniforms customizados:** todas as funções (`smooth`, `if`, `in`, `frac`, `fmod`, `exp2`, `log2`...)
  e `biome_category`.
- **Diretivas:** `size.buffer`, `customTexture`, `blend.*`, `program.*.enabled`, `endFlashShadows`,
  `sun`, `shadowEntities`, `entity.properties`, `item.properties`.
- **Alvos:** o formato R11F_G11F_B10F e `colortexNMipmapEnabled`.

**Única exceção: `cloudTime`.** O Vitrail não fornece esse uniform e o entrega como zero.

- No Vitrail, as sombras das nuvens e o reflexo das células de nuvem ficam parados.
- Só no Overworld. Nada no End.
- O pack não usa `cloudTime` em uniforms customizados, então nenhum deles é descartado por isso.

**Regras de tradução seguidas no código novo:**

- **Saídas:** cada programa declara as saídas de 0 sem buracos e as escreve em ordem crescente.
  - O Vitrail numera as saídas pela ordem do primeiro uso.
  - Conferi os 5 programas com mais de uma saída: todos certos.
- **Locais literais:** `layout(location = N)` com número escrito, sem macro, porque o tradutor lê os
  locais no texto.
- **Olhos sem flicker:** são posicionados com a mesma conta do corpo (model-view e depois projeção).
  Assim caem na mesma profundidade até o último bit.
- **Mipmaps de `colortex3`:** são lidos com `textureLod` e nível explícito.
- **`smoothstep`:** nenhum `smoothstep` com bordas invertidas (indefinido no SPIR-V). Os dois que havia
  no End antigo saíram, e não sobra nenhum no pack.
- **Inicialização:** nenhuma variável é lida antes de ser escrita, e não há `const` com valor não
  constante.

**O céu do End fica certo no Vitrail também:**

- Com o dragão vivo, o Vitrail também não desenha céu.
- O céu do pack não depende disso, porque é montado no `final` a partir da direção da vista.

**O que não pude verificar:** a tradução real do Vitrail (é um mod Java, precisa do jogo). Compilei com
glslang no perfil OpenGL. O tradutor reescreve para Vulkan sozinho, carregando o pack.

## 6. Custo (estimado, não medido; GTX 1050 Ti, 1080p)

| Item | Custo |
|---|---|
| Céu do End | um pouco mais barato: um gradiente no lugar de uma leitura de textura e duas funções de paleta |
| `EMISSIVE_GLOW`: escrita do `colortex3` (4 bytes/px no terreno e nas entidades) | ~0,08 a 0,12 ms |
| `EMISSIVE_GLOW`: cadeia de mipmaps | ~0,03 a 0,05 ms |
| `EMISSIVE_GLOW`: brilho em ¼ de resolução (13 leituras) | ~0,02 ms |
| `EMISSIVE_GLOW`: total | ~0,13 a 0,19 ms |

- `EMISSIVE_GLOW` fica desligado no ULTRA LOW e ligado do LOW para cima.
- Os olhos: um programa a mais, só onde há olhos na tela.

## 7. Opções e presets

| Opção | Antes | Agora | Menu |
|---|---|---|---|
| `END_AMBIENT_TINT` | 0,75 (violeta) | 1,00 (luz VV) | The End |
| `END_AMBIENT_BRIGHTNESS` | – | 0,67 | The End |
| `END_SKY_BRIGHTNESS` | – | 1,00 | The End |
| `END_SKY_GRAIN` | – | 0 % | The End |
| `END_DRAGON_FOG` | (sempre ligado) | desligado | The End |
| `FLASH_HALO_SIZE` | 0,40 | 0,34 | The End |
| `FLASH_FOG_BOOST` | 3,0 | 2,0 | The End |
| `END_FOG_DENSITY` 1 | 46 % a 100 blocos | 17 % a 100 blocos | The End |
| `EMISSIVE_GLOW` | – | ligado (LOW a CINEMATIC) | Glow and Emissive |
| `EMISSIVE_GLOW_STRENGTH` | – | 1,00 | Glow and Emissive |

- Os 5 presets definem todas as opções novas.
- Editei as linhas `profile.*` direto. O script `genprops8.ps1` não estava no zip: se você gerar os
  presets de novo com ele, inclua esses valores.

## 8. Teste no jogo

1. Preset MEDIUM, ilha principal do End, `/gamerule advance_time true` (sem isso não há flash, nem no
   vanilla).
2. **Com o dragão vivo**, olhe o horizonte.
   - O céu deve estar escuro e liso, quase preto no horizonte.
   - A borda da ilha e o fundo devem sumir no céu sem faixa nem degrau.
3. **Espere um flash** (um a cada 30 s; o som vem ~1,5 s depois, da direção dele). Deve aparecer:
   - um halo roxo-magenta suave no céu, com o centro perto de #683A70;
   - os pilares na frente do halo escuros;
   - as faces viradas para o flash levemente roxas.
4. **Endermen:** olhos rosa-esbranquiçados com um halo curto. **Cristais:** brancos, com um pouco de
   brilho.
5. **Chão de end stone:** amarelo-oliva escuro, não cinza-violeta.
6. Se algo ficar diferente, use os debugs do End:
   - `END_DEBUG` 4: o halo sozinho;
   - `END_DEBUG` 10: céu desenhado à esquerda, céu do pack à direita;
   - `END_DEBUG` 12: a luta detectada.
7. **No Vitrail:** o mesmo teste. As sombras das nuvens do Overworld ficam paradas (`cloudTime`).

## 9. Limites

- **Brilho geral:** os valores vêm das referências e de uma conta sobre a imagem 1. A adaptação dos
  olhos do pack (`ADAPT_END_STRENGTH` 0,30) pode clarear um pouco uma cena muito escura. Se o End ficar
  mais claro que as referências, ponha 0.
- **FOV da referência:** é desconhecido. O tamanho do halo em pixels depende do seu FOV (seção 4.3).
- **Itens e entidades no Iris 1.11.7:** que o `currentRenderedItemId` e o `entityId` chegam ao
  `gbuffers_textured_lit` vem do comportamento documentado do Iris e do Vitrail. Não testei no jogo.
- **Vitrail:** a tradução real não foi executada aqui (seção 5).

Fontes:

- [Vitrail Shaders (GitHub)](https://github.com/avpbynf/Vitrail-Shaders): docs `translation.md`,
  `sky-and-shadows.md`, `internals/uniforms.md` e o código-fonte;
- [Vitrail Shaders (Modrinth)](https://modrinth.com/mod/vitrail-shaders);
- [Sportskeeda: o flash do End no Vibrant Visuals](https://www.sportskeeda.com/minecraft/strange-end-effect-vibrant-visuals-hint-minecraft-end-update-future);
- [Sportskeeda: flashes no End com o Vibrant Visuals](https://sportskeeda.com/minecraft/minecraft-player-finds-strange-flashes-end-vibrant-visuals-turned).
