# Update 4.2 (End VV): o que faltava para ficar igual ao Vibrant Visuals

Backup: `backup/2026-10-07_before_end_vv_4_2/`. Para voltar, copie os arquivos de lá por cima.

## O que as duas imagens mostram (medido)

A imagem 7 é o Vibrant Visuals e a imagem 8 é o seu Java. Valores em luma (0–255) e cor média:

| Ponto | Vibrant Visuals (imagem 7) | Seu Java (imagem 8) |
|---|---|---|
| Obsidiana dos pilares | 15, quase lisa (desvio da textura 1,0), #130D19 | 8, textura bem visível (desvio 2,0), #0B070F |
| Céu no alto | 18 (#190F1E) | 14 (#120B1B) |
| Brilho do flash | largo, clareia o céu inteiro; a 400 px do centro ainda está com ~50 % | mais estreito: ~29 % a 400 px |
| Halo do cristal | +15 / +8 / +3 a 32 / 48 / 64 px | some por volta de 25 px |
| Olho do enderman | rosa claro (#F4B8FF em outra referência VV) | branco puro (255, 255, 255) |
| Chão de end stone | 74 perto, 78 longe | 73 |
| Grão do céu | desvio 0,57–0,69, correlação 0,52 | parecido (o da 4.1) |

- **A obsidiana é a maior diferença.** No VV o pilar fica quase da cor do céu e a textura fica achatada. Isso
  é luz do céu espalhada no ar na frente do pilar, somada em luz quase linear:
  - ela levanta muito o preto e quase nada o end stone, que é claro;
  - ela achata a textura escura pelo fator (h/saída)^1,5, o que dá ~0,8 contra o 1,0 medido.

## O que mudou

1. **Névoa ambiente** (`END_AMBIENT_HAZE`, padrão 1,00).
   - A luz do céu daquela direção é somada ao ar na frente do terreno (gama 2,5), antes da névoa fina e da
     borda de longe.
   - Fração da luz do céu: 71 % a 15 blocos e 83 % a 30. Nada perto da câmera.
   - Estimativa: o pilar esquerdo da cena do VV sai ~15 (VV: 15) e o céu alto ~19 (VV: 18). O end stone muda
     +0,3 %.
   - 0 volta ao visual da 4.1.
2. **Brilho do flash mais largo.** Reajustado nas imagens 2, 6 e 7 juntas: 60 % núcleo, 30 % cauda, 10 % de
   lavagem fraca no céu todo. Erro conjunto: 4,0 contra 4,3; na imagem 7, 2,7 contra 3,3.
3. **Halo largo de emissores grandes** (`EMISSIVE_GLOW`).
   - Dois anéis a 36 e 60 px sobre as médias de 16 e 32 px.
   - O cristal ganha um halo de ~60 px como no VV. Simulação: +13 / +6 / +2 a 32 / 48 / 64 px.
   - Fontes pequenas, como os olhos, quase não mudam (+1 a 30 px).
4. **Olhos rosa-claros.** O olho vai metade do caminho até um rosa pálido do próprio brilho antes de ser
   clareado: ~#FFB0FF, sem estourar para branco.

## Limites

- Não testei no jogo.
- O FOV e as distâncias das referências são estimados.
- A luz de tochas e do fogo dentro das gaiolas está mais forte no seu print do que no VV (gaiola 98 contra
  57). Não mexi: as distâncias são diferentes e não dá para comparar com segurança.
