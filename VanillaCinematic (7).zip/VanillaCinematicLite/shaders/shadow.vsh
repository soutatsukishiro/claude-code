#version 330 compatibility

#include "/lib/settings.glsl"
#include "/lib/shadow_distortion.glsl"

#ifdef FLASH_SHADOWS
// Update 3, the End only: Iris builds the End's shadow matrices from the vanilla End flash
// (endFlashShadows = true in shaders.properties), so the projection below is unchanged. Between flashes
// nothing reads the End's shadow map, so its geometry is moved outside the clip volume and the pass
// rasterizes nothing there. In the Overworld and the Nether atmosEnd is 0: nothing changes.
uniform float atmosEnd;
uniform float vclFlash;
#endif

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    gl_Position = ftransform();
    gl_Position.xyz = distortShadowClip(gl_Position.xyz);
#ifdef FLASH_SHADOWS
    if (atmosEnd > 0.5 && vclFlash <= 0.0005) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif
}
