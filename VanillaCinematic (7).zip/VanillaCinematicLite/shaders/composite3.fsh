#version 330 compatibility

// Update 5: the fake GI's gather at half resolution (GI_RESOLUTION 2, the HIGH and CINEMATIC presets). At quarter
// resolution the same gather is a second output of composite (it shares that pass and its glow mip chain); at half
// resolution it needs a target of its own size, so it is this pass, after composite2 and before final. It reads
// colortex0 (the lit scene before fog, bloom and exposure), the depth and the glow buffer's mips, and writes only
// colortex4 (0.5 x 0.5, RGBA16F, never cleared: every texel is written each frame). shaders.properties runs it only
// with GI_RESOLUTION 2; were it run anyway, it would write nothing.

#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
#ifdef GI_EMITTERS
// The glow buffer (gbuffers, EMISSIVE_GLOW) and its mip chain: asked for here as well, because Vitrail gives a
// chain only to the program that asks for it (Iris keeps the one composite built; asking again rebuilds it, about
// 0.03 ms at 1080p on an RTX 3050-class GPU, estimated).
uniform sampler2D colortex3;
const bool colortex3MipmapEnabled = true;
#endif
/*
const int colortex3Format = R11F_G11F_B10F;
const int colortex4Format = RGBA16F;
const bool colortex4Clear = false;
*/

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPositionFract;
uniform int isEyeInWater;
uniform float atmosOverworld;

#ifdef GI_HALF
#define GI_GATHER
#include "/lib/fake_gi.glsl"
#endif

/* RENDERTARGETS: 4 */
layout(location = 0) out vec4 giOut;

void main() {
#ifdef GI_HALF
    giOut = fakeGiGather(gl_FragCoord.xy, 0.5);
#if defined(GI_DEBUG) && (GI_DEBUG_MODE <= 4 || GI_DEBUG_MODE == 7 || GI_DEBUG_MODE == 8 || GI_DEBUG_MODE == 9 || GI_DEBUG_MODE == 14 || GI_DEBUG_MODE == 15 || GI_DEBUG_MODE == 18)
    giOut.rgb = gGiDebug;
#endif
#else
    discard;
#endif
}
