#version 330 compatibility

// Full-screen quad of the quarter-resolution shaft pass, with the sun's screen position (and the
// moon's, with the source that owns the shafts this frame, when MOON_SHAFTS is on), and the End
// flash's (the flash shafts, or the flash fog's volumetric shadow, Update 4.1).

#include "/lib/settings.glsl"

uniform mat4 gbufferProjection;
uniform vec3 sunPosition;

#ifdef MOON_SHAFTS
uniform vec3 moonPosition;
uniform int moonPhase;
// Needed by lib/ambience.glsl.
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
#include "/lib/ambience.glsl"
#endif

out vec2 vTexCoord;
out vec2 vSunUV;
out float vSunInFront;
#ifdef MOON_SHAFTS
out vec2 vMoonUV;
// > 0 while the moon owns the shaft buffer (the same decision as composite and final).
flat out float vMoonShaftOwner;
#endif
#if defined(END_FLASH_SHAFTS) || defined(FLASH_FOG_SHADOWS)
// Update 3: the End flash's screen position (xy) and whether it owns the shafts (z), the same
// decision as composite.vsh (Update 4.1: also for the flash fog's volumetric shadow).
uniform vec3 endFlashPosition;
uniform float vclFlash;
uniform float atmosEnd;
flat out vec3 vFlashShaft;
#endif
#ifdef FLASH_FOG_SHADOWS
// Update 4.1: the edge fade of the flash fog's shadow (composite1.fsh).
flat out float vFlashFogFade;
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
#ifdef MOON_SHAFTS
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    float moonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = moonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec3 moonDir = ambCelestialDirection(moonPosition);
    vMoonShaftOwner = ambMoonShaftOwner(moonInFront, ambMoonLight(moonDir, ambCelestialDirection(sunPosition), moonPhase),
                                        moonDir, vSunInFront, ambCelestialDirection(sunPosition).y);
#endif
#if defined(END_FLASH_SHAFTS) || defined(FLASH_FOG_SHADOWS)
    vec4 flashClip = gbufferProjection * vec4(endFlashPosition, 1.0);
    bool flashOn = atmosEnd > 0.5 && vclFlash > 0.001 && dot(endFlashPosition, endFlashPosition) > 1.0 && flashClip.w > 0.001;
#ifdef FLASH_FOG_SHADOWS
    // Update 4.1: no march while the flash cannot show (FLASH_INTENSITY 0).
    flashOn = flashOn && FLASH_INTENSITY > 0.0;
#endif
    vec2 flashUV = flashOn ? flashClip.xy / flashClip.w * 0.5 + 0.5 : vec2(-2.0);
    flashOn = flashOn && all(greaterThan(flashUV, vec2(-0.6))) && all(lessThan(flashUV, vec2(1.6)));
    vFlashShaft = vec3(flashUV, flashOn ? 1.0 : 0.0);
#endif
#ifdef FLASH_FOG_SHADOWS
    vec2 flashEdge = max(flashUV, 1.0 - flashUV);
    vFlashFogFade = flashOn ? (1.0 - smoothstep(1.3, 1.6, flashEdge.x)) * (1.0 - smoothstep(1.3, 1.6, flashEdge.y)) : 0.0;
#endif
}
