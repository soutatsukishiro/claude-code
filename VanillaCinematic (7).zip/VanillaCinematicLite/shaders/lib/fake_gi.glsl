// Update 5: fake global illumination (screen space) and the chromatic light falloff.
//
// Three parts, each behind its own define so a program compiles only what it uses:
//   always        the light code the terrain program writes into colortex0's alpha (encode / decode);
//   GI_GATHER     the low-resolution gather (composite at quarter resolution, composite3 at half);
//   GI_COMBINE    the depth-aware upsample that final applies before the bloom, the fog and the tone map.
//
// The light code. The pack renders forward: colortex0 holds the lit colour and nothing else knows the
// albedo or the light. The terrain program therefore writes into colortex0's alpha (free: terrain is
// drawn without blending and nothing read that alpha) one 16-bit float that carries
//   q    the light the albedo received, E = luma(lit colour before highlights) / luma(albedo), as log2 over
//        GI_LOG_SPAN stops from 2^GI_LOG_MIN in 128 steps (1/10 of a stop, at most 3.6 % off);
//   b    the block light level in half levels (0 .. 14.5);
//   sun  1 where the direct sun or moon dominates (the indirect light and the AO stay small there);
//   emit 1 on the bright texels of light sources (they receive nothing).
// It is written as a normal half-precision number from 2 up, 2^(k - 15) x (1 + m / 1024), k = 16 .. 30,
// m = 0 .. 1023: 15 x 1024 = 15360 values = 128 x 30 x 2 x 2, each one exact in RGBA16F (no rounding, never
// infinity; the largest is 65504). Always above 1, so it passes any alpha test Iris adds to cutout terrain
// (leaves, grass, flowers), which tests this output alpha. Entities, items, particles and the hand keep their
// texture alpha (0 .. 1); water, glass and other translucents drawn over terrain blend the alpha into another
// value, and the gather drops those pixels by depth (depthtex0 in front of depthtex1). So an alpha above 1.5
// is terrain and anything up to 1 is an entity.
#ifndef FAKE_GI_GLSL
#define FAKE_GI_GLSL

const float GI_LOG_MIN = -9.0;
const float GI_LOG_SPAN = 13.0;

float giLuma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float giEncode(float light, float blockLevel, float sunlit, float emitter) {
    int q = int(clamp(floor((log2(max(light, 1.0e-6)) - GI_LOG_MIN) * (127.0 / GI_LOG_SPAN) + 0.5), 0.0, 127.0));
    int b = int(clamp(floor(blockLevel * 2.0 + 0.5), 0.0, 29.0));
    int index = ((q * 30 + b) * 2 + (sunlit > 0.5 ? 1 : 0)) * 2 + (emitter > 0.5 ? 1 : 0);
    int k = index / 1024 + 16;
    int m = index - (k - 16) * 1024;
    return exp2(float(k - 15)) * (1.0 + float(m) * (1.0 / 1024.0));
}

struct GiCode {
    float light;     // E (1 where unknown)
    float level;     // block light level 0 .. 14.5 (15 where unknown: no limit)
    float sunlit;    // 0 or 1
    float emitter;   // 0 or 1
};

GiCode giDecode(float a) {
    GiCode c;
    c.light = 1.0;
    c.level = 15.0;
    c.sunlit = 0.0;
    c.emitter = 0.0;
    float x = a;
    if (x < 1.5) return c;
    // The exponent from log2, corrected by the mantissa (log2 and exp2 may be a few ulps off on the GPU;
    // every stored value is exact, so the guards never meet a real value).
    float e = floor(log2(x));
    float f = x * exp2(-e);
    if (f < 0.99976) {
        e -= 1.0;
        f *= 2.0;
    } else if (f >= 1.99976) {
        e += 1.0;
        f *= 0.5;
    }
    int k = int(e) + 15;
    int m = int(floor((f - 1.0) * 1024.0 + 0.5));
    if (k < 16 || k > 30) return c;
    int index = (k - 16) * 1024 + clamp(m, 0, 1023);
    int emit = index - (index / 2) * 2;
    index /= 2;
    int sun = index - (index / 2) * 2;
    index /= 2;
    int b = index - (index / 30) * 30;
    int q = index / 30;
    c.light = exp2(float(q) * (GI_LOG_SPAN / 127.0) + GI_LOG_MIN);
    c.level = float(b) * 0.5;
    c.sunlit = float(sun);
    c.emitter = float(emit);
    return c;
}

// A colour option written as 0xRRGGBB.
vec3 giHexColor(int c) {
    return vec3(float((c >> 16) & 255), float((c >> 8) & 255), float(c & 255)) * (1.0 / 255.0);
}

// The same colour at luminance 1 (only its hue and saturation count).
vec3 giHue(vec3 c) {
    return c / max(giLuma(c), 1.0e-4);
}

// Saturation control: s = 0 grey, 1 unchanged; the luminance is kept and no channel goes negative.
vec3 giSaturate(vec3 c, float s) {
    float l = giLuma(c);
    return max(mix(vec3(l), c, s), vec3(0.0));
}

#ifdef CHROMATIC_LIGHT
// Layer 4, the block-light colour ramp (gbuffers, lib/gbuffers_forward.fsh). The block light's colour by its
// level (0 .. 15, continuous: smooth lighting interpolates the level across each face, so no band follows the
// block grid): the far colour up to level 4, the mid colour around level 8, the near colour from level 12, with
// smooth blends (RAMP_SMOOTHNESS widens them). Luminance 1: the ramp recolours the light, the brightness stays
// the game's (in the End see giRampGain).
vec3 giRampHue(float level, vec3 nearColor, vec3 midColor, vec3 farColor) {
    float s = float(RAMP_SMOOTHNESS);
    float toMid = smoothstep(6.0 - 2.0 * s, 6.0 + 2.0 * s, level);
    float toNear = smoothstep(10.5 - 1.5 * s, 10.5 + 1.5 * s, level);
    return mix(mix(giHue(farColor), giHue(midColor), toMid), giHue(nearColor), toNear);
}

// The End's block light reaches about 7.5 blocks below the crystal's cage in your Vibrant Visuals screenshot
// (measured: the light on the obsidian speckles falls as ((level - 4) / 7.5)^1.5, gone at level 4), where the
// game's light curve still gives a sixth of it: this gain (1 from level 10 down to 0 at level 4, the measured
// shape over the game's curve) takes the rest away, so the far field is the End's own ambient.
float giRampGainEnd(float level) {
    return pow(clamp((level - 4.0) / 6.0, 0.0, 1.0), 0.8);
}

// Layer 3, the static far-field ambient: a dim light where the sky does not reach, the same everywhere (added
// light, multiplied by the albedo like all light). Overworld caves cool blue-grey, the Nether deep red-brown,
// the End the measured blue-violet of your screenshot's far field (hue 240; tiny, the End's ambient is
// END_AMBIENT_BRIGHTNESS). In lightmap units: 0.010 is about a third of the game's darkest light.
vec3 giStaticAmbient(float overworld, float nether, float end) {
    vec3 color = vec3(0.78, 0.86, 1.00) * 0.010 * overworld + vec3(1.00, 0.62, 0.48) * 0.006 * nether +
                 vec3(0.80, 0.80, 1.00) * 0.003 * end;
    float l = giLuma(color);
    return mix(vec3(l), color, float(AMBIENT_TINT)) * float(STATIC_AMBIENT_STRENGTH);
}

// The emitter classes of the addendum (Emitter Colors screen). The gather sees colours, not block IDs, so
// the class of a visible light is recognised by the hue of its glow: each class has a near colour (its own
// light, by default close to what the texture emits) and a mid colour (the warmer light that reaches
// farther: the fire under the End crystal, the red edge of lava light, the blue of soul fire).
const int GI_CLASSES = 7;
vec3 giClassNear(int i) {
    if (i == 0) return giHexColor(EMITTER_NEAR_COLOR_CRYSTAL);
    if (i == 1) return giHexColor(EMITTER_NEAR_COLOR_FIRE);
    if (i == 2) return giHexColor(EMITTER_NEAR_COLOR_LAVA);
    if (i == 3) return giHexColor(EMITTER_NEAR_COLOR_LAMP);
    if (i == 4) return giHexColor(EMITTER_NEAR_COLOR_SOUL);
    if (i == 5) return giHexColor(EMITTER_NEAR_COLOR_ROD);
    return giHexColor(EMITTER_NEAR_COLOR_REDSTONE);
}
vec3 giClassMid(int i) {
    if (i == 0) return giHexColor(EMITTER_MID_COLOR_CRYSTAL);
    if (i == 1) return giHexColor(EMITTER_MID_COLOR_FIRE);
    if (i == 2) return giHexColor(EMITTER_MID_COLOR_LAVA);
    if (i == 3) return giHexColor(EMITTER_MID_COLOR_LAMP);
    if (i == 4) return giHexColor(EMITTER_MID_COLOR_SOUL);
    if (i == 5) return giHexColor(EMITTER_MID_COLOR_ROD);
    return giHexColor(EMITTER_MID_COLOR_REDSTONE);
}
// Chroma of a colour as a 2D vector (red-green, yellow-blue opponents); its length is the saturation.
vec2 giChroma(vec3 c) {
    vec3 h = c / max(max(c.r, max(c.g, c.b)), 1.0e-4);
    return vec2(h.r - h.g, 0.5 * (h.r + h.g) - h.b);
}
// Near and mid colours for a visible light of colour c: a smooth blend of the classes whose near colour has
// a similar hue (no pop as the hue drifts), and the white classes (end rods) where c is nearly grey. The
// near colour keeps half of the light's own colour (EMITTER_NEAR_* tints it, it does not replace it).
void giClassColors(vec3 c, out vec3 nearHue, out vec3 midHue) {
    vec2 s = giChroma(c);
    float sl = length(s);
    vec3 nearSum = vec3(0.0);
    vec3 midSum = vec3(0.0);
    float wSum = 0.0;
    for (int i = 0; i < GI_CLASSES; ++i) {
        vec3 n = giClassNear(i);
        vec2 k = giChroma(n);
        float kl = length(k);
        // Hue agreement for coloured lights, saturation agreement for the near-white ones.
        float hue = kl > 0.12 && sl > 0.06 ? pow(max(dot(s, k) / (sl * kl), 0.0), 12.0) : 0.0;
        float white = (1.0 - smoothstep(0.06, 0.16, kl)) * (1.0 - smoothstep(0.08, 0.20, sl));
        float w = max(hue, white) + 1.0e-4;
        nearSum += giHue(n) * w;
        midSum += giHue(giClassMid(i)) * w;
        wSum += w;
    }
    nearHue = mix(giHue(c), nearSum / wSum, 0.5);
    midHue = midSum / wSum;
}
#endif

#ifdef GI_GATHER
// ---------------------------------------------------------------------------------------------------------
// The gather. Needs from the including program: depthtex0, depthtex1, colortex0, colortex3 (with its mip
// chain, when the emissive bounce is on), gbufferProjection, gbufferProjectionInverse, gbufferModelView,
// gbufferModelViewInverse, cameraPositionFract, isEyeInWater, atmosEnd, atmosNether, atmosOverworld.
//
// One low-resolution pixel stands for the full-resolution pixel at its centre (the representative). Its
// position and normal come from the depth buffer (five depth reads); GI_SAMPLES taps on a fixed golden-angle
// spiral of GI_RADIUS blocks around it (converted to pixels by the projection at its depth, so the footprint
// is the same in blocks at 720p and 4K) read the depth, the lit colour and the glow buffer's mip at the tap.
// The pattern is rotated and its radii shifted by a fixed 4 x 4 tile of the low-resolution pixels (the same every
// frame, nothing temporal); the next quarter-resolution pass (composite1, or composite4 at half resolution) averages
// each 4 x 4 block by depth (fakeGiBlur), so every pixel sees all 16 patterns: 16 x GI_SAMPLES directions, no
// bands where the taps cross an edge, no grain left.
//   - indirect light: each tap is a patch of the visible surface (its share of the disc's area, in blocks);
//     its lit colour lights the receiver with the patch's form factor: cos at the receiver x cos at the patch
//     / (d^2 + GI_FALLOFF_DIST^2), within GI_RADIUS (smooth cut). The patch's own normal is exact on block
//     faces (the coordinate along it is an integer) and taken as half-facing elsewhere, so a wall facing away
//     sends nothing, and two floors at the same height exchange nothing;
//   - colour bleeding: that light keeps the patch's colour (COLOR_BLEEDING_STRENGTH);
//   - AO: the same taps, those above the receiver's tangent plane within AO_RADIUS (smooth in distance and
//     angle), darken only the receiver's ambient and indirect light, never the direct sun;
//   - emitters: the glow buffer (colortex3: light sources, glowing mobs and the End crystal) is read at the mip
//     level that covers the tap's share of the disc, so a torch is caught whatever the taps' exact positions
//     (no flicker), and its light is bounded by the block light at the receiver (light that Minecraft does not
//     carry there, behind a wall, is not added either).
// The result is a multiplier for the receiver's lit colour: added light / E (final multiplies; the albedo
// is in the lit colour), minus the AO's share of the ambient. Alpha: the representative's linear depth, or -1.

uniform mat4 gbufferModelView;

// The 4 x 4 tile: a Bayer order, so neighbouring pixels take patterns far apart.
const int GI_TILE[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);

const vec2 GI_DIRS[16] = vec2[16](vec2(0.93937, 0.34290), vec2(-0.92429, 0.38169), vec2(0.42371, -0.90580),
    vec2(0.29943, 0.95412), vec2(-0.86529, -0.50128), vec2(0.97664, -0.21487), vec2(-0.57501, 0.81815),
    vec2(-0.12866, -0.99169), vec2(0.76475, 0.64433), vec2(-0.99914, 0.04147), vec2(0.70872, -0.70549),
    vec2(-0.04604, 0.99894), vec2(-0.64082, -0.76769), vec2(0.99109, 0.13320), vec2(-0.82077, 0.57125),
    vec2(0.21934, -0.97565));

// Brightest a non-emitting patch counts (soft): sunlit white blocks bounce, but never like a lamp.
const float GI_BOUNCE_KNEE = 1.2;
// Emitter radiance per unit of the glow buffer (its blocks hold 0.55 x the texel, mobs 0.80 x).
const float GI_EMIT_SCALE = 2.0;
// The mid layer's share of a light's output (layer 2: the secondary light is dimmer than the light itself).
const float GI_MID_SHARE = 0.7;
// The light never multiplies a pixel by more than this (the End's dark obsidian next to a crystal gets about
// 1.5 to 3 x; past this it would read as a lamp, not as bounced light).
const float GI_MAX_GAIN = 6.0;

vec3 giViewAt(vec2 uv, float depth) {
    vec4 v = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}

vec3 giViewPx(ivec2 px, vec2 fullSize) {
    float d = texelFetch(depthtex0, px, 0).r;
    return giViewAt((vec2(px) + 0.5) / fullSize, d);
}

// Normal of the face a world position lies on, from the position alone: on a full block face the coordinate
// along the face's normal is an integer and the other two are not. w = confidence (0 on slabs at .5, stairs,
// plants, fences, entities and block edges, where the caller uses its fallback).
vec4 giBlockNormal(vec3 playerPos, float viewDepth) {
    vec3 p = cameraPositionFract + playerPos;
    vec3 f = abs(fract(p + 0.5) - 0.5);
    float tol = 0.003 + 0.0004 * viewDepth;
    vec3 n;
    float fMin;
    float fNext;
    if (f.x <= f.y && f.x <= f.z) {
        n = vec3(playerPos.x > 0.0 ? -1.0 : 1.0, 0.0, 0.0);
        fMin = f.x;
        fNext = min(f.y, f.z);
    } else if (f.y <= f.z) {
        n = vec3(0.0, playerPos.y > 0.0 ? -1.0 : 1.0, 0.0);
        fMin = f.y;
        fNext = min(f.x, f.z);
    } else {
        n = vec3(0.0, 0.0, playerPos.z > 0.0 ? -1.0 : 1.0);
        fMin = f.z;
        fNext = min(f.x, f.y);
    }
    float confidence = (1.0 - smoothstep(tol, 2.0 * tol, fMin)) * smoothstep(0.02, 0.05, fNext);
    return vec4(n, confidence);
}

#if defined(GI_DEBUG)
// What the gather writes instead of the light in the debug views that show its own terms.
vec3 gGiDebug = vec3(0.0);
#endif

// fragCoord: this low-resolution pixel's gl_FragCoord.xy; lowScale: GI resolution / screen resolution.
vec4 fakeGiGather(vec2 fragCoord, float lowScale) {
    vec2 fullSize = vec2(textureSize(depthtex0, 0));
    ivec2 rep = clamp(ivec2(fragCoord / lowScale), ivec2(0), ivec2(fullSize) - 1);
    float depth = texelFetch(depthtex0, rep, 0).r;
    // Sky (never a receiver: its light is the ambient's job) and the first-person hand (its depth is squeezed
    // to an eighth, MC_HAND_DEPTH, so no world position can be read from it): nothing.
    if (depth > 0.99999 || depth < 0.56) return vec4(0.0, 0.0, 0.0, -1.0);
    vec2 uvRep = (vec2(rep) + 0.5) / fullSize;
    vec3 P = giViewAt(uvRep, depth);
    float z = -P.z;
    vec4 outValue = vec4(0.0, 0.0, 0.0, z);
    // Water, glass, ice and every other translucent surface in front of the terrain: they receive nothing (the
    // lit colour there is a blend of two surfaces; their own reflections and tints stay exactly as before).
    if (texelFetch(depthtex1, rep, 0).r > depth + 1.0e-6) return outValue;

    vec4 sceneRep = texelFetch(colortex0, rep, 0);
    bool terrain = sceneRep.a > 1.5;
    GiCode code = giDecode(sceneRep.a);
    if (code.emitter > 0.5) return outValue;
    // Entities, items and particles have no code: their light is estimated from their lit colour with a
    // typical albedo, and final scales them by GI_ON_ENTITIES. On terrain, the code's light is held to at least
    // half the lit colour (the albedo is at most 1): rain or a particle blended over the terrain changes the
    // alpha into another code, and a much darker one would inflate the multiplier there.
    float light = terrain ? max(code.light, 0.5 * giLuma(sceneRep.rgb)) : max(giLuma(sceneRep.rgb) / 0.35, 0.02);

    // Receiver normal: from the depth buffer, each axis on the side with the smaller depth step (no edge
    // smear), snapped to the exact block face where the position says it lies on one.
    ivec2 lim = ivec2(fullSize) - 1;
    vec3 pR = giViewPx(min(rep + ivec2(1, 0), lim), fullSize);
    vec3 pL = giViewPx(max(rep - ivec2(1, 0), ivec2(0)), fullSize);
    vec3 pU = giViewPx(min(rep + ivec2(0, 1), lim), fullSize);
    vec3 pD = giViewPx(max(rep - ivec2(0, 1), ivec2(0)), fullSize);
    vec3 dx = abs(pR.z - P.z) < abs(P.z - pL.z) ? pR - P : P - pL;
    vec3 dy = abs(pU.z - P.z) < abs(P.z - pD.z) ? pU - P : P - pD;
    vec3 N = cross(dx, dy);
    N *= inversesqrt(max(dot(N, N), 1.0e-12));
    if (dot(N, P) > 0.0) N = -N;
    vec3 playerRep = mat3(gbufferModelViewInverse) * P + gbufferModelViewInverse[3].xyz;
    vec4 blockN = giBlockNormal(playerRep, z);
    if (blockN.w > 0.0) {
        N = normalize(mix(N, mat3(gbufferModelView) * blockN.xyz, blockN.w));
    }

    // The disc: GI_RADIUS blocks at this depth, in full-resolution pixels; within a quarter of the screen
    // height (near the camera the disc shrinks in blocks instead of growing in pixels).
    float projScale = gbufferProjection[1][1] * 0.5 * fullSize.y;
    float radiusPx = clamp(float(GI_RADIUS) * projScale / max(z, 0.05), 2.0 / lowScale, 0.25 * fullSize.y);
    float radiusBlocks = radiusPx * z / projScale;
    // Each tap stands for a ring of the disc: area 2 pi t R^2 / N (blocks^2 at the tap's own depth below).
    float tapArea = 6.2831853 / float(GI_SAMPLES);
    // This pixel's pattern in the 4 x 4 tile: a rotation and a shift of the radii within their rings.
    int tile = GI_TILE[(int(fragCoord.x) & 3) + 4 * (int(fragCoord.y) & 3)];
    float tileAngle = float(tile) * 2.3999632;
    vec2 tileRot = vec2(cos(tileAngle), sin(tileAngle));
    float tileShift = (float(tile) + 0.5) / 16.0;

    vec3 bounce = vec3(0.0);
    float occlusion = 0.0;
    float aoWeight = 0.0;
    float validTaps = 0.0;
    vec3 emitNear = vec3(0.0);
    float emitMid = 0.0;
    vec3 emitColor = vec3(0.0);
    float invAoR2 = 1.0 / (float(AO_RADIUS) * float(AO_RADIUS));
    float fall2 = float(GI_FALLOFF_DIST) * float(GI_FALLOFF_DIST);
    float wrap = float(LIGHT_WRAP);

#if defined(GI_EMITTERS) && defined(CHROMATIC_LIGHT)
    // Per-channel falloff exponents (layer 1): red falls slowest, blue fastest; weaker in the Overworld,
    // where the sun is the main light, than in the End and the Nether, where the emitters are.
    float chromaDim = atmosOverworld > 0.5 ? 0.5 : 1.0;
    vec3 kChroma = 2.0 * mix(vec3(1.0), vec3(CHROMATIC_FALLOFF_R, CHROMATIC_FALLOFF_G, CHROMATIC_FALLOFF_B),
                             float(CHROMATIC_FALLOFF_STRENGTH) * chromaDim);
#endif

    for (int i = 0; i < GI_SAMPLES; ++i) {
        float t = (float(i) + tileShift) / float(GI_SAMPLES);
        vec2 dir2 = vec2(GI_DIRS[i].x * tileRot.x - GI_DIRS[i].y * tileRot.y, GI_DIRS[i].x * tileRot.y + GI_DIRS[i].y * tileRot.x);
        vec2 tapPx = vec2(rep) + 0.5 + dir2 * (t * radiusPx);
        vec2 tapUV = tapPx / fullSize;
        // Screen border: taps fade out over the last 3 % of the screen (no seam where the disc leaves it).
        vec2 border2 = smoothstep(vec2(0.0), vec2(0.03), tapUV) * smoothstep(vec2(0.0), vec2(0.03), 1.0 - tapUV);
        float border = border2.x * border2.y;
        if (border <= 0.0) continue;
        ivec2 tp = ivec2(tapPx);
        float tapDepth = texelFetch(depthtex0, tp, 0).r;
        // Sky: no occluder, no light (the sky light is in the receiver's own light already); the hand: nothing.
        if (tapDepth > 0.99999 || tapDepth < 0.56) continue;
        vec3 Pt = giViewAt((vec2(tp) + 0.5) / fullSize, tapDepth);
        vec3 D = Pt - P;
        float dist2 = dot(D, D);
        float dist = sqrt(dist2) + 1.0e-4;
        vec3 dir = D / dist;
        float cosR = dot(N, dir);
        validTaps += border;

        // The patch of surface this tap stands for, in blocks^2: its share of the disc on screen, at its own depth,
        // over the cosine between its face and the view (a floor seen at a grazing angle covers more ground per
        // pixel); the face from the block grid where the position lies on one, else taken as half-turned.
        float zt = -Pt.z;
        vec3 playerT = mat3(gbufferModelViewInverse) * Pt + gbufferModelViewInverse[3].xyz;
        vec4 tn = giBlockNormal(playerT, zt);
        vec3 tnView = mat3(gbufferModelView) * tn.xyz;
        float facing = mix(0.6, abs(dot(tnView, Pt)) / max(length(Pt), 1.0e-4), tn.w);
        float tapPatch = tapArea * t * (radiusPx * radiusPx) * (zt * zt) / (projScale * projScale * max(facing, 0.15));
        float receive = max(cosR + wrap, 0.0) / (1.0 + wrap);
        float range = 1.0 - smoothstep(radiusBlocks * 0.80, radiusBlocks * 1.15, dist);

        // AO: occluders above the tangent plane, within AO_RADIUS, weaker toward its edge (over the taps that fall
        // within AO_RADIUS at all, so a wide GI_RADIUS does not thin it out). Full block faces count a fifth: the
        // vanilla corner shading already darkens where block meets block (not twice); mobs, plants, fences, slabs
        // and stairs count fully (the contact shadows vanilla has not).
        float aoFall = max(1.0 - dist2 * invAoR2, 0.0) * border;
        occlusion += max(cosR - float(AO_BIAS), 0.0) * aoFall * (1.0 - 0.8 * tn.w);
        aoWeight += aoFall;

        // Indirect light and colour bleeding from lit terrain patches (entities and covered pixels send none).
        vec4 tapColor = texelFetch(colortex0, tp, 0);
        if (tapColor.a > 1.5 && texelFetch(depthtex1, tp, 0).r <= tapDepth + 1.0e-6) {
            vec3 Lp = tapColor.rgb / (1.0 + giLuma(tapColor.rgb) * (1.0 / GI_BOUNCE_KNEE));
            float send = mix(0.5, max(dot(tnView, -dir), 0.0), tn.w);
            bounce += Lp * (receive * send * tapPatch * range * border / (dist2 + fall2));
        }

#ifdef GI_EMITTERS
        // Emitters: the glow buffer's mip covering this tap's share of the disc (a stable area average).
        float footprint = radiusPx * sqrt(tapArea * t);
        float lod = clamp(log2(max(footprint, 1.0)), 0.0, 7.0);
        vec3 e = textureLod(colortex3, tapUV, lod).rgb * GI_EMIT_SCALE;
        float eL = giLuma(e);
        if (eL > 1.0e-5) {
            // Lights shine all around (a little even onto faces turned slightly away).
            float receiveE = max(cosR + 0.35, 0.0) / 1.35;
            float w = receiveE * tapPatch * border / 3.1415927;
            vec3 Dw = mat3(gbufferModelViewInverse) * D;
            float manhattan = abs(Dw.x) + abs(Dw.y) + abs(Dw.z);
            float dE = dist;
#if FALLOFF_METRIC == 1
            // Manhattan distance in blocks, as Minecraft (and Vibrant Visuals) spread light.
            dE = manhattan;
#endif
            // No light through walls: Minecraft's block light at the receiver says whether the light reached it by
            // the straight way. A light block's own face carries its emission level (its code); unblocked, the
            // receiver would have that level minus the block steps between them, and where it has three or more
            // levels less, the light went around something (a wall, a floor) and the screen-space light is not
            // added. Entities (the End crystal sits on its fire) carry no level: no test.
            if (terrain && tapColor.a > 1.5) {
                GiCode tapCode = giDecode(tapColor.a);
                w *= smoothstep(-3.0, -0.5, code.level - (tapCode.level + 0.5 - manhattan));
            }
#ifdef CHROMATIC_LIGHT
            // Layer 2, two radii. The near layer is the light's own colour, falling fast past EMITTER_NEAR_RADIUS
            // and per channel (layer 1): 1 / (1 + (d / R)^(2 k)) with k = 2 x CHROMATIC_FALLOFF_R/G/B, so red
            // lasts longest and blue goes first. The mid layer is its warmer secondary light (coloured after the
            // loop): weaker at the source, a 1/d^2 tail, gone past twice EMITTER_MID_RADIUS. Both are
            // irradiances: the patch over R^2 at short range, the patch over d^2 at long range.
            vec3 x = vec3(dE / float(EMITTER_NEAR_RADIUS));
            vec3 attNear = 1.0 / (1.0 + pow(x * x, kChroma));
            emitNear += e * attNear * (w / (float(EMITTER_NEAR_RADIUS) * float(EMITTER_NEAR_RADIUS)));
            emitColor += e * w;
#if EMITTER_MID_RADIUS > 0
            float xm = dE / float(EMITTER_MID_RADIUS);
            emitMid += eL * w * GI_MID_SHARE / (float(EMITTER_MID_RADIUS) * float(EMITTER_MID_RADIUS) * (1.0 + xm * xm)) *
                       (1.0 - smoothstep(1.5, 2.0, xm));
#endif
#else
            // One layer: the light's own colour, 1 / (1 + (d / EMISSIVE_RADIUS)^2) over EMISSIVE_RADIUS^2.
            float xe = dE / float(EMISSIVE_RADIUS);
            emitNear += e * (w / (float(EMISSIVE_RADIUS) * float(EMISSIVE_RADIUS) * (1.0 + xe * xe)));
#endif
        }
#endif
    }

    // Normalisation: the taps sample the disc's area, so the sums are already form factors; the 1/pi of a
    // diffuse patch is applied here, and the indirect light is scaled by the sliders.
    vec3 indirect = bounce * (float(BOUNCE_LIGHT_STRENGTH) / 3.1415927);
    // Colour bleeding: the bounced light keeps COLOR_BLEEDING_STRENGTH of its colour (0 = neutral).
    indirect = giSaturate(indirect, float(COLOR_BLEEDING_STRENGTH));
    float ao = 1.0 - clamp(occlusion / max(aoWeight, 0.5) * 2.0, 0.0, 1.0);
    // A gentle curve: corners darken, open surfaces keep all of it.
    ao = ao * ao * (3.0 - 2.0 * ao);

    vec3 emissive = vec3(0.0);
    float emitConfidence = 0.0;
#ifdef GI_EMITTERS
#ifdef CHROMATIC_LIGHT
    vec3 nearHue;
    vec3 midHue;
    giClassColors(emitColor, nearHue, midHue);
    // The class colour, with the per-channel falloff's hue shift kept (the ratio of the attenuated colour to
    // the light's own), at the attenuated light's luminance.
    vec3 shift = giHue(emitNear) / max(giHue(emitColor), vec3(1.0e-3));
    vec3 nearLight = giLuma(emitNear) * giHue(nearHue * shift);
    emissive = nearLight;
#if EMITTER_MID_RADIUS > 0
    emissive += midHue * emitMid;
#endif
#else
    emissive = emitNear;
#endif
    emissive *= float(EMISSIVE_BOUNCE_STRENGTH);
    emitConfidence = clamp(giLuma(emissive) * 8.0, 0.0, 1.0);
#endif

    // The indirect and emitted light, with the AO: corners get less, but bright neighbours still fill them a
    // little (half of the AO only). Sunlit receivers get a third of the bounce (no washed-out sunny side).
    float aoIndirect = mix(1.0, ao, 0.5);
    vec3 added = (indirect * mix(1.0, 0.35, code.sunlit) + emissive) * aoIndirect;
    added = giSaturate(added, float(BOUNCE_SATURATION)) * float(FAKE_GI_STRENGTH);
    // AO on the ambient part of the receiver's own light (never on the direct sun).
    float aoAmbient = float(AO_STRENGTH) * (1.0 - ao) * (1.0 - 0.75 * code.sunlit);
    vec3 multiplier = added / max(light, 1.0e-3) - vec3(aoAmbient);

    // Distance (GI_MAX_DISTANCE, faded like the fog), underwater, and the bounds.
    float fade = 1.0 - smoothstep(float(GI_MAX_DISTANCE) * 0.75, float(GI_MAX_DISTANCE), length(P));
    if (isEyeInWater == 1) fade *= float(GI_UNDERWATER);
    else if (isEyeInWater > 1) fade = 0.0;
    multiplier = clamp(multiplier * fade, vec3(-0.6), vec3(GI_MAX_GAIN));
    outValue.rgb = multiplier;

#if defined(GI_DEBUG)
#if GI_DEBUG_MODE == 1
    gGiDebug = mat3(gbufferModelViewInverse) * N * 0.5 + 0.5;
#elif GI_DEBUG_MODE == 2
    gGiDebug = vec3(clamp(z / float(GI_MAX_DISTANCE), 0.0, 1.0));
#elif GI_DEBUG_MODE == 3
    gGiDebug = vec3(validTaps / float(GI_SAMPLES));
#elif GI_DEBUG_MODE == 4
#ifdef GI_EMITTERS
    gGiDebug = textureLod(colortex3, uvRep, 2.0).rgb * GI_EMIT_SCALE;
#endif
#elif GI_DEBUG_MODE == 7
    gGiDebug = vec3(ao);
#elif GI_DEBUG_MODE == 8
    gGiDebug = (indirect - vec3(giLuma(indirect))) * 8.0 + 0.5;
#elif GI_DEBUG_MODE == 9
    gGiDebug = emissive * aoIndirect;
#elif GI_DEBUG_MODE == 14
#if defined(GI_EMITTERS) && defined(CHROMATIC_LIGHT)
    gGiDebug = nearLight * float(EMISSIVE_BOUNCE_STRENGTH) * 4.0;
#endif
#elif GI_DEBUG_MODE == 15
#if defined(GI_EMITTERS) && defined(CHROMATIC_LIGHT) && EMITTER_MID_RADIUS > 0
    gGiDebug = midHue * emitMid * float(EMISSIVE_BOUNCE_STRENGTH) * 4.0;
#endif
#elif GI_DEBUG_MODE == 18
    gGiDebug = vec3(emitConfidence);
#endif
#endif
    return outValue;
}
#endif

#ifdef GI_BLUR
// ---------------------------------------------------------------------------------------------------------
// The low-resolution blur that resolves the gather's 4 x 4 tile (composite1 at quarter resolution, composite4 at half):
// the 4 x 4 block around each texel (every pattern exactly once), each texel weighted by how well its depth fits the
// plane through this texel (the slope from its nearest neighbours), so the light never crosses a depth edge and a
// floor seen at a grazing angle still averages along itself. Needs colortex4.
vec4 fakeGiBlur(ivec2 p) {
    ivec2 lim = textureSize(colortex4, 0) - 1;
    vec4 c = texelFetch(colortex4, p, 0);
    if (c.a <= 0.0) return c;
    vec4 taps[16];
    for (int k = 0; k < 16; ++k) {
        taps[k] = texelFetch(colortex4, clamp(p + ivec2((k & 3) - 2, (k >> 2) - 2), ivec2(0), lim), 0);
    }
    // Neighbours at (-1, 0), (1, 0), (0, -1), (0, 1): k = 9, 11, 6, 14 (k = 10 is this texel).
    float sxL = c.a - taps[9].a;
    float sxR = taps[11].a - c.a;
    float syD = c.a - taps[6].a;
    float syU = taps[14].a - c.a;
    float sx = abs(sxL) < abs(sxR) ? sxL : sxR;
    float sy = abs(syD) < abs(syU) ? syD : syU;
    vec3 sum = vec3(0.0);
    float weightSum = 0.0;
    for (int k = 0; k < 16; ++k) {
        float expected = c.a + sx * float((k & 3) - 2) + sy * float((k >> 2) - 2);
        float rel = abs(taps[k].a - expected) / (0.02 * c.a + 0.03);
        float w = taps[k].a > 0.0 ? 1.0 / (1.0 + rel * rel * rel * rel) : 0.0;
        sum += taps[k].rgb * w;
        weightSum += w;
    }
    return vec4(sum / max(weightSum, 1.0e-4), c.a);
}
#endif

#ifdef GI_COMBINE
// ---------------------------------------------------------------------------------------------------------
// Final: the low-resolution multiplier at this pixel. Most pixels take the bilinear value (one read) when the
// bilinear depth agrees with the pixel's own depth (expected along its plane from the screen derivatives);
// at depth edges the four texels are weighted by how well each one's depth fits this pixel's plane, and
// where none fits, the nearest in depth is taken if it is close (thin objects), otherwise nothing. No halo,
// no light across a silhouette, no blocky steps. Needs colortex4 and gbufferProjectionInverse.

float gGiLeak = 0.0;   // 1 where no texel fitted (leak test view)

// The low-resolution texel j stands for the full-resolution pixel floor((j + 0.5) / scale).
vec3 fakeGiUpsample(vec2 uv, float pixelZ, float dzdx, float dzdy, vec2 fullSize) {
    vec2 lowSize = vec2(textureSize(colortex4, 0));
    float scale = lowSize.x / fullSize.x;
    vec4 bilinear = texture(colortex4, uv);
    vec2 slope = vec2(abs(dzdx), abs(dzdy));
    // Tolerance: 3 % of the depth, plus the depth change across one low-resolution texel on this plane.
    float tolerance = 0.03 * pixelZ + (slope.x + slope.y) / scale;
    if (bilinear.a > 0.0 && abs(bilinear.a - pixelZ) < tolerance) return bilinear.rgb;

    vec2 lp = uv * lowSize - 0.5;
    vec2 base = floor(lp);
    vec2 f = lp - base;
    vec3 sum = vec3(0.0);
    float weightSum = 0.0;
    vec3 nearestValue = vec3(0.0);
    float nearestError = 1.0e9;
    vec2 pixel = uv * fullSize;
    ivec2 lim = ivec2(lowSize) - 1;
    for (int k = 0; k < 4; ++k) {
        ivec2 o = ivec2(k & 1, k >> 1);
        ivec2 texel = clamp(ivec2(base) + o, ivec2(0), lim);
        vec4 s = texelFetch(colortex4, texel, 0);
        if (s.a <= 0.0) continue;
        vec2 repPixel = floor((vec2(texel) + 0.5) / scale) + 0.5;
        vec2 dp = repPixel - pixel;
        float expected = pixelZ + dzdx * dp.x + dzdy * dp.y;
        float error = abs(s.a - expected);
        float wb = (o.x == 1 ? f.x : 1.0 - f.x) * (o.y == 1 ? f.y : 1.0 - f.y);
        float rel = error / (0.015 * pixelZ + 0.02);
        float w = wb / (1.0 + rel * rel * rel * rel);
        sum += s.rgb * w;
        weightSum += w;
        if (error < nearestError) {
            nearestError = error;
            nearestValue = s.rgb;
        }
    }
    if (weightSum > 0.05) return sum / weightSum;
    gGiLeak = 1.0;
    return nearestError < 0.08 * pixelZ ? nearestValue : vec3(0.0);
}
#endif

#endif
