#include "/lib/settings.glsl"
#include "/lib/shadow_distortion.glsl"

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform float alphaTestRef;
uniform float rainStrength;
uniform float wetness;
uniform float frameTimeCounter;
uniform float fogStart;
uniform float fogEnd;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float atmosOverworld;
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform int isEyeInWater;
// Also needed by lib/ambience.glsl (cloud shadows, palettes) and by the debug split views.
uniform vec3 cameraPositionFract;
uniform ivec3 cameraPositionInt;
uniform float thunderStrength;
uniform vec3 sunPosition;
uniform float viewWidth;

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_SHADOWS) || defined(WAVE_LIGHTING)
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
#endif
#if defined(UNDERWATER_AMBIENCE) || defined(NETHER_AMBIENCE) || defined(END_AMBIENCE) || defined(CHROMATIC_LIGHT)
// Update 3: the dimension weights (custom uniforms, 0 or 1, switched at once like atmosOverworld).
// Update 5: also the chromatic light's ramp and static ambient (one colour set per dimension).
uniform float atmosNether;
uniform float atmosEnd;
#endif

#if defined(PIXEL_CAUSTICS) || defined(WATER_DEPTH_TINT)
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
#endif

#if defined(PIXEL_CAUSTICS) || defined(WAVE_LIGHTING)
uniform sampler2D shadowtex1;
#endif

#ifdef PIXEL_CAUSTICS
uniform ivec2 eyeBrightnessSmooth;
#endif

#if defined(WATER_LAYER) && defined(WAVE_LIGHTING)
// Sprite centre and half-extent in atlas UV (from mc_midTexCoord), so the wave
// pseudo-normal taps never read a neighbouring atlas sprite.
in vec2 vMidTexCoord;
in vec2 vSpriteHalf;
#endif

in vec2 vTexCoord;
in vec2 vLightCoord;
in vec4 vColor;
in vec3 vNormalView;
in vec3 vWorldPosition;
in vec3 vPlayerPosition;
in vec4 vShadowClip;
in vec3 vViewPosition;
in vec3 vWorldNormal;
in float vIsFluid;
in float vSunElevation;
in float vViewDistance;
in float vIsFoliage;
in float vIsThin;
in float vMaterialGroup;

#ifdef AMBIENCE_COLORS
flat in vec3 vAmbSunLight;
flat in vec3 vAmbSkyLight;
#endif
#if defined(TERRAIN_LAYER) && defined(SHADOW_COLORS)
// Ambient sky light for the shadow colours (lib/gbuffers.vsh).
flat in vec3 vAmbShadowLight;
#endif
#if defined(TERRAIN_LAYER) && defined(SHADOW_ENTITY_FLAG_READ)
// Entity flag of the nearest shadow caster (R = 1 written by shadow_entities.fsh).
uniform sampler2D shadowcolor0;
#endif
#if defined(TERRAIN_LAYER) && defined(PIXEL_CAUSTICS) && defined(CAUSTICS_UNDERWATER_FLOOR)
// Water surface above an underwater camera (custom uniform from the sky light at the eye) and
// the sky light at the eye itself (x 16), for the camera-underwater caustic route.
uniform float vclWaterSurfaceY;
uniform ivec2 eyeBrightness;
#endif
#if defined(ENTITY_LAYER) && defined(EMISSIVE_GLOW)
// Update 4: 1 on light-emitting mobs and items (lib/gbuffers.vsh).
flat in float vGlowKind;
#endif
#if defined(WATER_LAYER) && defined(WATER_REFLECTION_IMPROVEMENT)
flat in vec3 vAmbZenith;
flat in vec3 vAmbMid;
flat in vec3 vAmbHorizon;
flat in vec3 vAmbGlow;
flat in vec3 vAmbCloudTop;
flat in vec3 vAmbCloudUnder;
flat in float vAmbGolden;
#endif

#include "/lib/ambience.glsl"
// Update 3: underwater fog and surface, Nether light, End ambience and flash.
#include "/lib/dimension_ambience.glsl"
#if defined(FAKE_GI) || defined(CHROMATIC_LIGHT)
// Update 5: the light code for the fake GI (terrain), the colour ramp and the static ambient.
#include "/lib/fake_gi.glsl"
#endif
#if defined(TERRAIN_LAYER) && defined(FAKE_GI)
// Update 5: what this terrain fragment writes into colortex0's alpha (lib/fake_gi.glsl, giEncode).
float gGiCode = 1.0;
#endif
#if defined(TERRAIN_LAYER) && defined(GI_DEBUG) && (GI_DEBUG_MODE == 10 || GI_DEBUG_MODE == 16 || GI_DEBUG_MODE == 17)
// Update 5 diagnostics written by the terrain program (final shows them as they are).
vec3 gGiTerrainDebug = vec3(0.0);
#endif
#if (defined(TERRAIN_LAYER) || defined(WATER_LAYER)) && defined(CHROMATIC_LIGHT) && defined(GI_MICRODETAIL_RESPONSE)
// Update 5, layer 5: the micro-detail's torch glints take the colour of the block light here (the ramp's
// colour at this level) instead of the fixed warm torch colour.
vec3 gGiTorchHue = vec3(1.00, 0.72, 0.42);
#define BLK_TORCH_HUE gGiTorchHue
#endif

#if defined(TERRAIN_LAYER) || defined(WATER_LAYER)
// Update 2B block lighting: directional face light and micro-detail. Block surfaces are everything
// in the terrain program (blocks, block entities, leaves, plants) and everything but the water
// itself in the translucent program (ice, glass, slime, honey).
#include "/lib/block_lighting.glsl"
#ifdef TERRAIN_LAYER
#define BLK_SURFACE true
#else
#define BLK_SURFACE (vIsFluid < 0.5)
#endif
#if defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL)
#define BLK_ACTIVE
#endif
#endif
#if defined(TERRAIN_LAYER) && (defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL))
flat in vec4 vBlkFace;
#endif
#if defined(TERRAIN_LAYER) && defined(CHROMATIC_LIGHT)
// Update 5: the block-light colour ramp of this pixel's level (lib/gbuffers.vsh).
in vec3 vGiRamp;
#endif
#if defined(TERRAIN_LAYER) && defined(BLOCK_MICRO_DETAIL)
flat in vec4 vBlkDetail;
flat in vec4 vBlkAmount;
flat in vec4 vBlkColor;
flat in vec3 vBlkShape;
#endif
#if defined(WATER_LAYER) && (defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL))
flat in int vBlkMaterial;
#endif

#if defined(WATER_LAYER) && defined(WATER_REFLECTION_IMPROVEMENT)
// Palette sky handed over by the vertex shader (the columns the reflection uses).
AmbPalette ambFragmentPalette() {
    AmbPalette p;
    p.zenith = vAmbZenith;
    p.mid = vAmbMid;
    p.horizon = vAmbHorizon;
    p.fogNear = vAmbHorizon;
    p.cloudTop = vAmbCloudTop;
    p.cloudEdge = vAmbCloudTop;
    p.cloudUnder = vAmbCloudUnder;
    p.sunLight = vec3(1.0);
    p.skyLight = vec3(1.0);
    p.glow = vAmbGlow;
    p.golden = vAmbGolden;
    return p;
}
#endif

vec3 safeNormalize(vec3 value) {
    return value * inversesqrt(max(dot(value, value), 0.000001));
}

float fastGlossCurve(float x) {
    float x2 = x * x;
    float x4 = x2 * x2;
    float x8 = x4 * x4;
    float x16 = x8 * x8;
#if HIGHLIGHT_SIZE <= 12
    return x8 * x4;
#elif HIGHLIGHT_SIZE <= 16
    return x16;
#elif HIGHLIGHT_SIZE <= 20
    return x16 * x4;
#elif HIGHLIGHT_SIZE <= 24
    return x16 * x8;
#elif HIGHLIGHT_SIZE <= 28
    return x16 * x8 * x4;
#elif HIGHLIGHT_SIZE <= 32
    return x16 * x16;
#elif HIGHLIGHT_SIZE <= 36
    return x16 * x16 * x4;
#elif HIGHLIGHT_SIZE <= 42
    return x16 * x16 * x8;
#else
    return x16 * x16 * x16;
#endif
}

float fastPowerFive(float x) {
    float x2 = x * x;
    return x2 * x2 * x;
}

float fastPowerFortyEight(float x) {
    float x2 = x * x;
    float x4 = x2 * x2;
    float x8 = x4 * x4;
    float x16 = x8 * x8;
    float x32 = x16 * x16;
    return x32 * x16;
}

float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

float getShadow(vec4 shadowClip, float ndotl, vec3 playerPosition, vec3 normalWorld) {
#ifdef PIXEL_SHADOWS
    // Snap the receiver on a world-anchored 16-texel/block plane before projection.
    // cameraPositionFract preserves the block-grid phase without large-float jitter.
    vec3 worldPhase = cameraPositionFract + playerPosition;
    vec3 absNormal = abs(normalWorld);
    float cells = float(SHADOW_PIXEL_GRID);
    if (absNormal.y >= max(absNormal.x, absNormal.z)) {
        worldPhase.xz = floor(worldPhase.xz * cells) / cells;
    } else if (absNormal.x >= absNormal.z) {
        worldPhase.zy = floor(worldPhase.zy * cells) / cells;
    } else {
        worldPhase.xy = floor(worldPhase.xy * cells) / cells;
    }
    vec3 snappedPlayer = worldPhase - cameraPositionFract + normalWorld * 0.008;
    shadowClip = shadowProjection * shadowModelView * vec4(snappedPlayer, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
#endif
    vec3 ndc = shadowClip.xyz / max(shadowClip.w, 0.00001);
    vec3 coord = ndc * 0.5 + 0.5;
    if (coord.x < 0.0 || coord.x > 1.0 || coord.y < 0.0 || coord.y > 1.0 || coord.z < 0.0 || coord.z > 1.0) {
        return 1.0;
    }

    float bias = 0.00065 + (1.0 - clamp(ndotl, 0.0, 1.0)) * 0.00085;
    vec2 texel = vec2(1.0 / float(shadowMapResolution));
#ifdef PIXEL_SHADOWS
    coord.xy = clamp((floor(coord.xy * float(shadowMapResolution)) + 0.5) * texel,
                     texel * 0.5, vec2(1.0) - texel * 0.5);
#endif
    // Interleave a tiny half-pixel kernel shift across the screen; no noise fetch or trig.
    vec2 jitter = (fract(gl_FragCoord.xy * 0.5) - vec2(0.25)) * 0.5;
    float visible = 0.0;
#if SHADOW_QUALITY == 1
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy).r);
    return visible;
#elif SHADOW_QUALITY == 2
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-0.5, -0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.5, -0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-0.5,  0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.5,  0.5) + jitter)).r);
    return visible * 0.25;
#else
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0,  0.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0,  0.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0,  1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.0,  1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0,  1.0) + jitter)).r);
    return visible * 0.125;
#endif
}

#if defined(TERRAIN_LAYER) && defined(SHADOW_ENTITY_FLAG_READ)
// 1 when the nearest caster at this receiver's shadow texel is an entity: shadow_entities
// writes R = 1 into shadowcolor0, the terrain shadow program R = 0. The receiver goes through
// the same world-grid snap, projection and distortion as getShadow (whose shape, resolution
// and filtering stay untouched), and the flag only counts where that texel's caster really
// shadows the receiver. Two texel fetches, only on shadowed fragments.
float shadowCasterIsEntity(vec4 shadowClip, float ndotl, vec3 playerPosition, vec3 normalWorld) {
#ifdef PIXEL_SHADOWS
    vec3 worldPhase = cameraPositionFract + playerPosition;
    vec3 absNormal = abs(normalWorld);
    float cells = float(SHADOW_PIXEL_GRID);
    if (absNormal.y >= max(absNormal.x, absNormal.z)) {
        worldPhase.xz = floor(worldPhase.xz * cells) / cells;
    } else if (absNormal.x >= absNormal.z) {
        worldPhase.zy = floor(worldPhase.zy * cells) / cells;
    } else {
        worldPhase.xy = floor(worldPhase.xy * cells) / cells;
    }
    vec3 snappedPlayer = worldPhase - cameraPositionFract + normalWorld * 0.008;
    shadowClip = shadowProjection * shadowModelView * vec4(snappedPlayer, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
#endif
    vec3 coord = shadowClip.xyz / max(shadowClip.w, 0.00001) * 0.5 + 0.5;
    if (coord.x < 0.0 || coord.x > 1.0 || coord.y < 0.0 || coord.y > 1.0 || coord.z < 0.0 || coord.z > 1.0) return 0.0;
    float bias = 0.00065 + (1.0 - clamp(ndotl, 0.0, 1.0)) * 0.00085;
    ivec2 texel = clamp(ivec2(coord.xy * float(shadowMapResolution)), ivec2(0), ivec2(shadowMapResolution - 1));
    if (texelFetch(shadowtex0, texel, 0).r >= coord.z - bias) return 0.0;
    return step(0.5, texelFetch(shadowcolor0, texel, 0).r);
}
#endif

#if defined(TERRAIN_LAYER) && defined(SHADOW_COLORS)
// How strong the direct light is right now (1 = clear midday sun): a low sun and the moon are
// weaker, cloud shadows (the value computed for this fragment) and rain take most of it. It
// sets how dark player and mob shadows are.
float shadowSunStrength(float cloudVisibility) {
    float daySun = mix(0.45, 1.0, smoothstep(0.03, 0.30, vSunElevation));
    float light = mix(0.35, daySun, smoothstep(-0.03, 0.03, vSunElevation));
    float weather = (1.0 - 0.75 * ambRain()) * (1.0 - 0.40 * clamp(thunderStrength, 0.0, 1.0));
    return light * cloudVisibility * weather;
}

// Shadow colour: the shaded part of a surface takes the hue of the ambient sky light (luminance
// preserved, a little more saturated, neon clamp), so shadows follow the time of day, the
// weather and the biome. Quality 2 adds the surface response from the albedo and the
// block.properties groups: snow clearly blue, sand grey-lilac, stone cool grey-blue, grass
// blue-green, wood and dirt a little darker and slightly cool. weight = shaded share (0..1).
vec3 shadowColorResponse(vec3 lit, vec3 albedo, vec3 ambient, float weight) {
    vec3 hue = ambient / max(ambLuma(ambient), 1.0e-3);
    float push = SHADOW_HUE_PUSH;
    float saturation = SHADOW_COLOR_SATURATION;
    float darken = 0.0;
#if SHADOW_COLOR_QUALITY >= 2
    float albedoLuma = ambLuma(albedo);
    float albedoMax = max(albedo.r, max(albedo.g, albedo.b));
    float albedoSat = (albedoMax - min(albedo.r, min(albedo.g, albedo.b))) / max(albedoMax, 1.0e-3);
    float snow = smoothstep(0.62, 0.82, albedoLuma) * (1.0 - smoothstep(0.08, 0.20, albedoSat));
    float earth = step(3.5, vMaterialGroup) * (1.0 - step(4.5, vMaterialGroup));
    float sand = earth * smoothstep(0.42, 0.62, albedoLuma);
    float darkEarth = earth - sand;
    float stone = step(4.5, vMaterialGroup) * (1.0 - step(6.5, vMaterialGroup));
    float green = smoothstep(0.02, 0.10, albedo.g - max(albedo.r, albedo.b));
    push *= 1.0 + 0.9 * snow + 0.25 * stone + 0.20 * sand + 0.40 * green - 0.10 * darkEarth;
    saturation *= max(1.0 - 0.7 * snow - 0.8 * darkEarth + 0.15 * green, 0.0);
    darken = 0.06 * darkEarth;
#endif
    vec3 tinted = lit * mix(vec3(1.0), hue, clamp(push, 0.0, 2.0));
    float luma = ambLuma(lit);
    tinted *= luma / max(ambLuma(tinted), 1.0e-4);
    float tintedMax = max(tinted.r, max(tinted.g, tinted.b));
    float tintedSat = (tintedMax - min(tinted.r, min(tinted.g, tinted.b))) / max(tintedMax, 1.0e-3);
    // Dull colours gain the most; nothing already saturated is pushed further (no neon).
    float boost = saturation * (1.0 - tintedSat) * (1.0 - smoothstep(0.60, 0.85, tintedSat));
    tinted = max(mix(vec3(luma), tinted, 1.0 + boost), vec3(0.0)) * (1.0 - darken);
    return mix(lit, tinted, clamp(weight, 0.0, 1.0));
}
#endif

// Written by the caustic route, consumed by the water program's output blend:
// rgb = caustic light added to the floor before the water blend (floor units),
// a = floor scale k (screen term minus mosaic tone): floor' = floor * (1 - k) + rgb.
vec4 gCausticLight = vec4(0.0);
#ifdef EMISSIVE_GLOW
// Update 4: what this fragment emits into the glow buffer (colortex3; composite blurs it, final adds it).
vec3 gGlowSource = vec3(0.0);
// Glow source per kind, next to the eyes of gbuffers_spidereyes (0.60 of the eye's own colour, fitted to
// your reference's enderman eyes): the
// texture-masked emitters of the terrain (class 9 of block.properties: torches, lanterns, glowstone, end
// rods, fire, lava...) and the glowing mobs and items (End crystals, blazes, glow squids, held torches).
const float BLOCK_GLOW_GAIN = 0.55;
const float ENTITY_GLOW_GAIN = 0.80;
#endif
#if defined(LIGHT_DEBUG) && defined(TERRAIN_LAYER)
// Underwater-route diagnostic colour (LIGHT_DEBUG views 13, 15, 16, 17).
vec3 gUnderwaterDebug = vec3(0.0);
#endif
// Sun/moon light on the vanilla wave texels: added on the water surface (not transmitted),
// plus its debug colour. Consumed by gbuffers_water.
vec3 gWaveLight = vec3(0.0);
vec3 gWaveDebug = vec3(0.0);

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_WATER_SPARKLES)
// 210 blocks: 210 * TEXELS_PER_BLOCK is divisible by every cell size option
// (lcm(6, 7, 8, 10, 12, 14, 16) = 1680) and every mosaic size, so the Voronoi
// lattice and the mosaic tile without a seam.
const int CAUSTIC_WRAP_BLOCKS = 210;

vec3 causticWrapWorld(vec3 cameraRelativePosition) {
    // 30,000,180 = 210 * 142858 lies beyond the world border, so the integer remainder
    // only sees non-negative operands (GLSL leaves % undefined for negative values).
    vec3 cameraWrapped = vec3((cameraPositionInt + ivec3(30000180)) % ivec3(CAUSTIC_WRAP_BLOCKS));
    return mod(cameraWrapped + cameraPositionFract + cameraRelativePosition, float(CAUSTIC_WRAP_BLOCKS));
}
#endif

#if defined(PIXEL_CAUSTICS) || defined(WATER_DEPTH_TINT)
// Camera-relative position of the opaque surface behind this pixel (depthtex1).
vec3 causticPlayerFromDepth(ivec2 pixel, float depth, vec2 screenSize) {
    vec2 uv = (vec2(pixel) + 0.5) / screenSize;
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
}
#endif

#ifdef WATER_DEPTH_TINT
vec3 waterShallowTint() {
#if SHALLOW_TINT == 0
    return vColor.rgb;                 // vanilla biome water colour
#elif SHALLOW_TINT == 2
    return vec3(0.56, 0.80, 0.84);     // light teal (v3 default)
#elif SHALLOW_TINT == 3
    return vec3(0.62, 0.86, 0.92);     // clear cyan
#else
    return vec3(0.40, 0.78, 0.82);     // turquoise shallow bank
#endif
}

vec3 waterDeepTint() {
#if NEAR_WATER_TINT == 0
    return vColor.rgb * 0.60;          // darkened biome colour
#elif NEAR_WATER_TINT == 2
    return vec3(0.07, 0.16, 0.38);     // navy
#elif NEAR_WATER_TINT == 3
    return vec3(0.08, 0.33, 0.45);     // teal blue
#else
    return vec3(0.16, 0.34, 0.62);     // deep blue
#endif
}

vec3 waterFarTint() {
#if FAR_WATER_TINT == 0
    return fogColor;                   // follows the sky/fog colour
#elif FAR_WATER_TINT == 2
    return vec3(0.40, 0.52, 0.70);     // steel blue
#elif FAR_WATER_TINT == 3
    return vec3(0.42, 0.58, 0.64);     // teal grey
#else
    return vec3(0.52, 0.60, 0.78);     // lavender grey-blue (reference far water)
#endif
}
#endif

// Horizontal distance blend shared by the water tint, opacity and reflection.
float waterDistanceBlend() {
    return smoothstep(float(REFLECT_NEAR_DISTANCE), float(REFLECT_FAR_DISTANCE), length(vPlayerPosition.xz));
}

#if defined(WATER_LAYER) && defined(WATER_SKY_REFLECTION)
// Reflection colour (rgb) and per-texel reflectivity (a), the share of that reflectivity
// final may replace with the screen-space reflection, a wave-driven wobble for it, and a
// debug colour. Consumed by gbuffers_water.
vec4 gWaterReflection = vec4(0.0);
float gReflectionTier2 = 0.0;
float gWaterWobble = 0.5;
vec3 gReflectionDebug = vec3(0.0);
#endif

#ifdef PIXEL_CAUSTICS
const int CAUSTIC_PERIOD = CAUSTIC_WRAP_BLOCKS * TEXELS_PER_BLOCK;
const int CAUSTIC_CELLS = CAUSTIC_PERIOD / CELL_SIZE_TEXELS;
const vec2 CAUSTIC_ORBIT_DIR[8] = vec2[8](vec2(1.0, 0.0), vec2(0.7071, 0.7071), vec2(0.0, 1.0), vec2(-0.7071, 0.7071),
                                          vec2(-1.0, 0.0), vec2(-0.7071, -0.7071), vec2(0.0, -1.0), vec2(0.7071, -0.7071));

// Integer hash (lowbias32 finalizer): a handful of integer ALU ops, no texture.
uint causticHash(ivec2 cell, uint seed) {
    uint h = uint(cell.x) * 0x8DA6B343u ^ uint(cell.y) * 0xD8163841u ^ seed * 0xCB1AB31Fu;
    h ^= h >> 16u;
    h *= 0x7FEB352Du;
    h ^= h >> 15u;
    h *= 0x846CA68Bu;
    h ^= h >> 16u;
    return h;
}

// Feature point of one Worley cell, in integer texels, so every distance is exact and
// edges come out as clean staircases. The point is jittered inside its cell, then
// orbits by whole texels along an octagon at its own rate, so the network deforms
// step by step like a caustic instead of only scrolling.
ivec2 causticCellPoint(ivec2 cell, uint seed, float stepTime) {
    uint h = causticHash((cell + ivec2(CAUSTIC_CELLS)) % CAUSTIC_CELLS, seed);
    vec2 jitter = (vec2(float(h & 1023u), float((h >> 10u) & 1023u)) * (1.0 / 1023.0) - 0.5) * CELL_JITTER;
    ivec2 point = cell * CELL_SIZE_TEXELS + ivec2(floor((0.5 + jitter) * float(CELL_SIZE_TEXELS)));
#if CELL_ORBIT > 0
    float orbitRate = 1.6 * (0.7 + 0.6 * float((h >> 20u) & 255u) * (1.0 / 255.0));
    int orbitIndex = int(floor(stepTime * orbitRate)) + int(h >> 28u);
    point += ivec2(floor(CAUSTIC_ORBIT_DIR[orbitIndex & 7] * float(CELL_ORBIT) + 0.5));
#endif
    return point;
}

struct CausticSample {
    ivec2 cellId;        // nearest cell, wrapped (debug colours)
    float f1;            // distance to the nearest point, texels
    float edge;          // 2 x distance to the bisector of the two nearest points, texels
    float lineRaw;       // line mask before dropout
    float line;          // line mask after dropout
    float edgeBrightness; // per-edge twinkle value 0..1
    float mosaic;        // signed floor tone offset
    int level;           // 0 floor, 1 halo, 2 mid, 3 light, 4 peak
};

// Smooth periodic domain warp in texels. It bends the straight Voronoi edges into
// curves; the texel is still evaluated once at its centre, so the output stays hard
// pixels. Integer cycle counts over CAUSTIC_PERIOD keep it seamless at the wrap, and
// the arguments are reduced modulo the period before sin() for precision.
// Periods of about 4 and 3 cells: each edge spans a fraction of a wave, so it bows into
// an arc instead of zigzagging.
const int CAUSTIC_WARP_F1 = CAUSTIC_PERIOD / (CELL_SIZE_TEXELS * 4);
const int CAUSTIC_WARP_F2 = CAUSTIC_PERIOD / (CELL_SIZE_TEXELS * 3);
vec2 causticWarp(ivec2 t, float stepTime) {
    const float K = 6.28318530718 / float(CAUSTIC_PERIOD);
    float phase = stepTime * 0.35;
    float a = K * float((t.y * CAUSTIC_WARP_F1) % CAUSTIC_PERIOD);
    float b = K * float((t.x * CAUSTIC_WARP_F1) % CAUSTIC_PERIOD);
    float c = K * float(((t.x + t.y) * CAUSTIC_WARP_F2) % CAUSTIC_PERIOD);
    float d = K * float(((t.x - t.y + CAUSTIC_PERIOD) * CAUSTIC_WARP_F2) % CAUSTIC_PERIOD);
    vec2 w = vec2(sin(a + phase) + 0.5 * sin(c + 1.7),
                  sin(b - phase * 0.8 + 2.1) + 0.5 * sin(d + 0.4));
    return w * (CELL_CURVE / 1.5);
}

// Pixel-snapped, curved Voronoi edges on the integer texel grid of one face plane.
CausticSample causticPattern(vec2 faceCoord, uint faceSeed) {
    float stepTime = floor(frameTimeCounter * float(STEPS_PER_SECOND)) / float(STEPS_PER_SECOND);
    ivec2 t = ivec2(floor(faceCoord * float(TEXELS_PER_BLOCK)));
    // Very slow global drift in whole texels; float mod keeps negative directions in range.
    vec2 driftDir = vec2(cos(radians(float(DRIFT_DIRECTION))), sin(radians(float(DRIFT_DIRECTION))));
    ivec2 drift = ivec2(mod(floor(stepTime * DRIFT_SPEED * driftDir), float(CAUSTIC_PERIOD)));
    t = (t + drift) % CAUSTIC_PERIOD;
    vec2 tw = vec2(t) + causticWarp(t, stepTime);
    ivec2 baseCell = ivec2(floor(tw / float(CELL_SIZE_TEXELS)));

    // Three smallest squared distances and the two nearest cells and points.
    float best1 = 1.0e9;
    float best2 = 1.0e9;
    float best3 = 1.0e9;
    ivec2 id1 = baseCell;
    ivec2 id2 = baseCell;
    vec2 p1 = vec2(0.0);
    vec2 p2 = vec2(1.0);
#if VORONOI_QUALITY == 2
    for (int j = -1; j <= 1; ++j) {
        for (int i = -1; i <= 1; ++i) {
            ivec2 cell = baseCell + ivec2(i, j);
#else
    // LOW: only the 2x2 cells nearest to this texel. F1 is almost always right with
    // moderate jitter; F2 occasionally misses, which shows as short straight segments.
    vec2 local = tw - vec2(baseCell * CELL_SIZE_TEXELS);
    ivec2 side = ivec2(local.x * 2.0 >= float(CELL_SIZE_TEXELS) ? 1 : -1, local.y * 2.0 >= float(CELL_SIZE_TEXELS) ? 1 : -1);
    for (int j = 0; j <= 1; ++j) {
        for (int i = 0; i <= 1; ++i) {
            ivec2 cell = baseCell + side * ivec2(i, j);
#endif
            vec2 point = vec2(causticCellPoint(cell, faceSeed, stepTime));
            vec2 d = point - tw;
            float dist2 = dot(d, d);
            if (dist2 < best1) {
                best3 = best2; best2 = best1; id2 = id1; p2 = p1;
                best1 = dist2; id1 = cell; p1 = point;
            } else if (dist2 < best2) {
                best3 = best2; best2 = dist2; id2 = cell; p2 = point;
            } else if (dist2 < best3) {
                best3 = dist2;
            }
        }
    }

    CausticSample result;
    result.f1 = sqrt(best1);
    float f3 = sqrt(best3);
    // Exact distance to the bisector of the two nearest points: constant-width lines,
    // without the clumps that F2 - F1 grows where several borders meet.
    result.edge = (best2 - best1) / max(length(p2 - p1), 0.001);
    ivec2 wrapped1 = (id1 + ivec2(CAUSTIC_CELLS)) % CAUSTIC_CELLS;
    ivec2 wrapped2 = (id2 + ivec2(CAUSTIC_CELLS)) % CAUSTIC_CELLS;
    result.cellId = wrapped1;

    // Per-edge identity: the unordered pair of the two nearest cells.
    int lin1 = wrapped1.x + wrapped1.y * CAUSTIC_CELLS;
    int lin2 = wrapped2.x + wrapped2.y * CAUSTIC_CELLS;
    ivec2 edgeKey = ivec2(min(lin1, lin2), max(lin1, lin2));
    uint edgeHash = causticHash(edgeKey, faceSeed ^ 0x68E31DA4u);
    // Each edge re-rolls its brightness at its own phase (EDGE_TWINKLE changes per second).
    float twinkleEpoch = floor(stepTime * EDGE_TWINKLE + float(edgeHash & 255u) * (1.0 / 256.0));
    uint twinkleHash = causticHash(edgeKey + ivec2(int(twinkleEpoch) * 7919, 0), faceSeed ^ 0xB5297A4Du);
    // 3x3-texel stretches vary along each edge and carry the dropout gaps.
    uint stretchHash = causticHash(t / 3, twinkleHash);
    uint texelHash = causticHash(t, faceSeed ^ 0x27D4EB2Fu);

    float edgeValue = float(twinkleHash >> 8u) * (1.0 / 16777216.0);
    float stretchValue = float(stretchHash >> 8u) * (1.0 / 16777216.0);
    // The brightest stretches sit where borders meet or run close together (F3 near F1).
    // The stretch term is kept small so brightness changes softly along an edge.
    float junction = (f3 - result.f1) < LINE_WIDTH * 1.5 ? 0.18 : 0.0;
    result.edgeBrightness = clamp(0.8 * edgeValue + 0.2 * stretchValue + junction, 0.0, 1.0);

    bool lineRaw = result.edge < LINE_WIDTH;
    bool gap = float(stretchHash & 255u) * (1.0 / 256.0) < EDGE_DROPOUT;
    result.lineRaw = lineRaw ? 1.0 : 0.0;
    result.line = (lineRaw && !gap) ? 1.0 : 0.0;

    result.level = 0;
    if (lineRaw && !gap) {
        result.level = result.edgeBrightness > 0.62 ? 3 : 2;
        if (result.edgeBrightness > 0.80 && float((stretchHash >> 24u) & 255u) * (1.0 / 256.0) < PEAK_AMOUNT) result.level = 4;
    } else if (!gap && EDGE_HALO > 0.0 && result.edge < LINE_WIDTH + 2.0 && lin1 < lin2) {
        // Dimmer one-texel halo on one side only: the side of the lower cell id.
        result.level = 1;
    } else if (result.edge < LINE_WIDTH + 6.0 && float(texelHash >> 8u) * (1.0 / 16777216.0) < ISOLATED_PIXELS) {
        result.level = 3;
    }

    // Soft mosaic: nearest-neighbour value noise, three tones (dark 40 %, mid 40 %, light 20 %).
    uint tone = causticHash(t / MOSAIC_CELL_SIZE, faceSeed ^ 0x1B873593u) % 5u;
    result.mosaic = (tone < 2u ? -0.10 : (tone < 4u ? -0.03 : 0.04)) * MOSAIC_STRENGTH;
    return result;
}

// Light added to the floor per level (floor units, before the water blend). Solved so a
// floor under 0.25-opacity shallow water reproduces the swatches measured in the
// reference: base #7A97A7, line mid #A3B7BA, line light #B7CAC3, warm peak #C4CBBB.
vec3 causticLevelColor(int level) {
    const vec3 MID = vec3(0.266, 0.227, 0.165);
    const vec3 LIGHT = vec3(0.397, 0.357, 0.249);
    vec3 peak = mix(vec3(0.380, 0.400, 0.430), vec3(0.472, 0.393, 0.247), WARMTH);
    if (level == 0) return MID * (1.0 - CONTRAST) * 0.5;
    if (level == 1) return MID * EDGE_HALO;
    return level == 2 ? MID : (level == 3 ? LIGHT : peak);
}

// Face axis of the opaque hit: 0 = X, 1 = Y, 2 = Z.
// Primary, zero taps: full-block faces lie exactly on integer world planes, so the axis
// whose coordinate sits on an integer (within depth precision) is the normal axis.
// Fallback for block edges (two axes near an integer), slabs and plants: the closer
// depth neighbour per screen axis, which stays on the same plane, and a cross product.
int causticFaceAxis(vec3 hitPlayer, ivec2 pixel, float hitDepth, vec2 screenSize) {
    vec3 phase = cameraPositionFract + hitPlayer;
    vec3 planeDist = abs(phase - floor(phase + 0.5));
    float tolerance = 0.002 + 3.0e-6 * dot(hitPlayer, hitPlayer);
    float nearest = min(planeDist.x, min(planeDist.y, planeDist.z));
    float farthest = max(planeDist.x, max(planeDist.y, planeDist.z));
    float second = planeDist.x + planeDist.y + planeDist.z - nearest - farthest;
    int axis = planeDist.y <= nearest ? 1 : (planeDist.x <= nearest ? 0 : 2);
    if (nearest < tolerance && second > tolerance) return axis;

    ivec2 maxPixel = ivec2(screenSize) - 1;
    ivec2 pixelL = clamp(pixel - ivec2(1, 0), ivec2(0), maxPixel);
    ivec2 pixelR = clamp(pixel + ivec2(1, 0), ivec2(0), maxPixel);
    ivec2 pixelD = clamp(pixel - ivec2(0, 1), ivec2(0), maxPixel);
    ivec2 pixelU = clamp(pixel + ivec2(0, 1), ivec2(0), maxPixel);
    float depthL = texelFetch(depthtex1, pixelL, 0).r;
    float depthR = texelFetch(depthtex1, pixelR, 0).r;
    float depthD = texelFetch(depthtex1, pixelD, 0).r;
    float depthU = texelFetch(depthtex1, pixelU, 0).r;
    bool useL = abs(depthL - hitDepth) < abs(depthR - hitDepth);
    bool useD = abs(depthD - hitDepth) < abs(depthU - hitDepth);
    ivec2 pixelH = useL ? pixelL : pixelR;
    ivec2 pixelV = useD ? pixelD : pixelU;
    float depthH = useL ? depthL : depthR;
    float depthV = useD ? depthD : depthU;
    if (depthH > 0.99999 || depthV > 0.99999) return axis;
    vec3 n = abs(cross(causticPlayerFromDepth(pixelH, depthH, screenSize) - hitPlayer,
                       causticPlayerFromDepth(pixelV, depthV, screenSize) - hitPlayer));
    if (dot(n, n) < 1.0e-12) return axis;
    return n.y >= max(n.x, n.z) ? 1 : (n.x >= n.z ? 0 : 2);
}

vec3 causticFaceNormal(int axis, float faceSign) {
    return axis == 0 ? vec3(faceSign, 0.0, 0.0) : (axis == 1 ? vec3(0.0, faceSign, 0.0) : vec3(0.0, 0.0, faceSign));
}

// Top/bottom faces use (x, z), X faces (z, y), Z faces (x, y): planar, so the net is
// continuous across block edges on one plane and never stretches on walls.
vec2 causticFaceCoord(vec3 wrappedWorld, int axis) {
    return axis == 0 ? wrappedWorld.zy : (axis == 1 ? wrappedWorld.xz : wrappedWorld.xy);
}

// A different seed per orientation keeps perpendicular and opposite faces unrelated.
uint causticFaceSeed(int axis, float faceSign) {
    return uint(axis * 2 + (faceSign > 0.0 ? 1 : 0) + 1) * 0x9E3779B9u;
}

// Floor: direct sun term. Walls: dimmer, fading below the surface, with a minimum
// sun-facing response so they never go fully dark. Ceilings get no direct caustics.
// A negative waterColumn means "unknown" (underwater-camera route).
float causticFaceMask(int axis, float faceSign, float ndotl, float waterColumn) {
    if (axis == 1) return faceSign > 0.0 ? ndotl : 0.0;
#ifdef CAUSTICS_WALLS
    float wallDepth = waterColumn < 0.0 ? 1.0 : 1.0 - smoothstep(0.0, WALL_DEPTH_FADE, waterColumn);
    return WALL_STRENGTH * wallDepth * ((1.0 - WALL_SUN_FACTOR) + WALL_SUN_FACTOR * ndotl);
#else
    return 0.0;
#endif
}
#endif

#if defined(PIXEL_CAUSTICS) || defined(WAVE_LIGHTING)
float singleReceiverShadow(vec3 playerPosition, vec3 normalWorld, float ndotl) {
    // The caustic fade ends well before LOW's shadow distance; avoid invalid samples beyond it.
    if (dot(playerPosition, playerPosition) > shadowDistance * shadowDistance) return 1.0;
#ifdef PIXEL_SHADOWS
    vec3 worldPhase = cameraPositionFract + playerPosition;
    vec3 absNormal = abs(normalWorld);
    float cells = float(SHADOW_PIXEL_GRID);
    if (absNormal.y >= max(absNormal.x, absNormal.z)) {
        worldPhase.xz = floor(worldPhase.xz * cells) / cells;
    } else if (absNormal.x >= absNormal.z) {
        worldPhase.zy = floor(worldPhase.zy * cells) / cells;
    } else {
        worldPhase.xy = floor(worldPhase.xy * cells) / cells;
    }
    playerPosition = worldPhase - cameraPositionFract + normalWorld * 0.008;
#endif
    vec4 clip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    clip.xyz = distortShadowClip(clip.xyz);
    if (clip.w <= 0.00001) return 1.0;
    vec3 coord = clip.xyz / clip.w * 0.5 + 0.5;
    if (coord.x < 0.0 || coord.x > 1.0 || coord.y < 0.0 || coord.y > 1.0 || coord.z < 0.0 || coord.z > 1.0) return 1.0;
    float bias = 0.00065 + (1.0 - clamp(ndotl, 0.0, 1.0)) * 0.00085;
#ifdef PIXEL_SHADOWS
    vec2 shadowTexel = vec2(1.0 / float(shadowMapResolution));
    coord.xy = clamp((floor(coord.xy * float(shadowMapResolution)) + 0.5) * shadowTexel,
                     shadowTexel * 0.5, vec2(1.0) - shadowTexel * 0.5);
#endif
    // Opaque-only depth prevents the transparent water surface from shadowing itself.
    return step(coord.z - bias, texture(shadowtex1, coord.xy).r);
}
#endif

#if defined(WATER_LAYER) && defined(WAVE_LIGHTING)
// Measured from the 1.21.1 jar: water_still has mean luminance 0.694 with only four tones
// (0.647, 0.682, 0.761, 0.827); water_flow has 0.662. A mean of 0.68 sits between them, so
// only the two light tones count as crests.
const float WAVE_MEAN_LUMA = 0.68;
// Typical luminance step at a crest edge in those textures; scales the pseudo-normal tilt.
const float WAVE_GRADIENT_REF = 0.08;

float waveLuma(vec2 uv, vec2 duvDx, vec2 duvDy) {
    return dot(textureGrad(gtexture, uv, duvDx, duvDy).rgb, vec3(0.2126, 0.7152, 0.0722));
}

// Soft sun/moon light on the vanilla wave texels. The water texture, its animation and its
// colour are untouched; only light is returned, added on top in gbuffers_water.
vec3 waveCrestLight(vec3 rawColor, vec3 Nflat, vec3 Lview, vec2 lightCoord, float overworld,
                    vec3 dpDx, vec3 dpDy, vec2 duvDx, vec2 duvDy, out vec3 debugColor, out vec3 normalOut) {
    debugColor = vec3(0.0);
    // A. Crest mask from the current animation frame: luminance above the texture mean,
    // quantized to CREST_LEVELS steps (default base / soft / bright).
    float waveL = dot(rawColor, vec3(0.2126, 0.7152, 0.0722));
    float wave = waveL - WAVE_MEAN_LUMA;
    float crestRaw = smoothstep(0.03, 0.13, wave * CREST_CONTRAST);
    float crestSteps = float(CREST_LEVELS - 1);
    float crest = floor(crestRaw * crestSteps + 0.5) / crestSteps;

    // B1. Pseudo-normal from one-texel luminance differences. On the sprite's last row or
    // column the tap steps back instead of forward, so it never reads another atlas sprite.
    // textureGrad reuses the centre texel's mip choice: far away the mips flatten the
    // differences and the crest contrast, so the effect fades without crawling.
    vec2 atlasTexel = 1.0 / vec2(textureSize(gtexture, 0));
    vec2 spriteRel = vTexCoord - vMidTexCoord;
    float stepU = spriteRel.x + atlasTexel.x > vSpriteHalf.x ? -1.0 : 1.0;
    float stepV = spriteRel.y + atlasTexel.y > vSpriteHalf.y ? -1.0 : 1.0;
    float dhdu = (waveLuma(vTexCoord + vec2(stepU * atlasTexel.x, 0.0), duvDx, duvDy) - waveL) * stepU;
    float dhdv = (waveLuma(vTexCoord + vec2(0.0, stepV * atlasTexel.y), duvDx, duvDy) - waveL) * stepV;
    // Cotangent frame from screen derivatives of smooth interpolants (position, UV): follows
    // any face orientation and the rotated UVs of flowing water.
    vec3 dp2perp = cross(dpDy, Nflat);
    vec3 dp1perp = cross(Nflat, dpDx);
    vec3 T = dp2perp * duvDx.x + dp1perp * duvDy.x;
    vec3 B = dp2perp * duvDx.y + dp1perp * duvDy.y;
    float frameScale = inversesqrt(max(max(dot(T, T), dot(B, B)), 1.0e-30));
    T *= frameScale;
    B *= frameScale;
    vec3 Nwave = safeNormalize(Nflat - (WAVE_NORMAL_STRENGTH / WAVE_GRADIENT_REF) * (dhdu * T + dhdv * B));
    normalOut = Nwave;

    // B2-B3. Wrap diffuse and a Blinn-Phong glint against the sun (or moon). The view
    // Fresnel makes the glint path toward a low sun strong and the top-down view weak.
    vec3 Lworld = safeNormalize(mat3(gbufferModelViewInverse) * Lview);
    vec3 Vworld = safeNormalize(-vPlayerPosition);
    float diffuse = max(dot(Nwave, Lworld) * 0.5 + 0.5, 0.0);
    float shininess = 2.0 / (GLINT_SIZE * GLINT_SIZE) - 2.0;
    float NdotH = max(dot(Nwave, safeNormalize(Lworld + Vworld)), 0.0);
    float viewFresnel = 0.02 + 0.98 * fastPowerFive(1.0 - max(dot(Nflat, Vworld), 0.0));
    float glint = min(pow(NdotH, shininess) * (shininess + 2.0) * 0.125 * viewFresnel, 4.0);

    // B5. Sun height: strongest low and mid, moderate at noon, warm near the horizon; the
    // moon gives a faint cool response at night. All transitions are smoothstep.
    float sunUp = smoothstep(-0.02, 0.10, vSunElevation);
    float lowSun = 1.0 + 0.5 * (1.0 - smoothstep(0.25, 0.75, vSunElevation));
    float twilight = 1.0 - smoothstep(0.05, 0.35, vSunElevation);
    vec3 sunTint = mix(vec3(0.86, 0.90, 1.00), vec3(1.00, 0.76, 0.52), twilight);
    vec3 lightColor = sunTint * (sunUp * lowSun) + vec3(0.55, 0.65, 0.95) * ((1.0 - sunUp) * 0.12);

    // B6. Open sky, weather, distance and grazing fades; one opaque-only shadow lookup.
    float skyMask = smoothstep(0.30, 0.90, lightCoord.y);
    float weather = 1.0 - 0.85 * clamp(rainStrength, 0.0, 1.0);
    float distanceFade = 1.0 - smoothstep(24.0, 56.0, vViewDistance);
    float grazing = smoothstep(0.0, 0.08, dot(Nflat, Vworld));
    float outside = isEyeInWater == 0 ? 1.0 : 0.0;
    float mask = skyMask * weather * distanceFade * grazing * outside * overworld;
    float shadow = 0.0;
#ifndef WAVE_DEBUG
    if (mask * crest > 0.0005)
#endif
    {
        shadow = singleReceiverShadow(vPlayerPosition + Nflat * 0.02, Nflat, max(dot(Nflat, Lworld), 0.0));
    }

    // B7. Stepped sparkle: a few bright crest texels twinkle at STEPS_PER_SECOND.
    vec2 texelId = mod(floor(vTexCoord / atlasTexel), 256.0);
    vec2 blockId = mod(floor(vWorldPosition.xz), 64.0);
    float sparkleTick = floor(frameTimeCounter * float(STEPS_PER_SECOND));
    float sparkleHash = cheapHash(texelId + blockId * 16.0 + vec2(sparkleTick * 0.37, sparkleTick * 0.73));
    // Mostly driven by the glint, so the twinkle follows the sun and nearly vanishes with it behind you.
    float sparkle = step(1.0 - SPARKLE_AMOUNT * 0.5, sparkleHash) * step(0.99, crest) * (0.15 + glint);

    // B4. Crest light; zero on base texels, so the original water is unchanged there.
    vec3 light = crest * (diffuse * DIFFUSE_AMOUNT + glint * GLINT_AMOUNT + sparkle) *
                 lightColor * (mask * shadow * WAVE_LIGHT_STRENGTH);

#ifdef WAVE_DEBUG
#if WAVE_DEBUG_MODE == 1
    debugColor = vec3(waveL);
#elif WAVE_DEBUG_MODE == 2
    debugColor = vec3(clamp(0.5 + wave * 4.0, 0.0, 1.0));
#elif WAVE_DEBUG_MODE == 3
    debugColor = vec3(crestRaw);
#elif WAVE_DEBUG_MODE == 4
    debugColor = vec3(crest);
#elif WAVE_DEBUG_MODE == 5
    debugColor = vec3(clamp(0.5 + 2.0 * dot(Nwave, T), 0.0, 1.0), clamp(0.5 + 2.0 * dot(Nwave, B), 0.0, 1.0), dot(Nwave, Nflat));
#elif WAVE_DEBUG_MODE == 6
    debugColor = vec3(diffuse);
#elif WAVE_DEBUG_MODE == 7
    debugColor = vec3(clamp(glint, 0.0, 1.0));
#elif WAVE_DEBUG_MODE == 8
    debugColor = vec3(shadow, skyMask, mask);
#elif WAVE_DEBUG_MODE == 9
    debugColor = clamp(light * 2.0, 0.0, 1.0);
#endif
#endif
    return light;
}
#endif

#ifdef PIXEL_CAUSTICS
#ifdef CAUSTICS_DEBUG
vec3 causticDebugView(int axis, vec2 faceCoord, CausticSample pattern, float waterColumn,
                      float submerged, float receiverShadow, vec3 light) {
#if CAUSTICS_DEBUG_MODE == 1
    return axis == 0 ? vec3(1.0, 0.15, 0.10) : (axis == 1 ? vec3(0.15, 1.0, 0.20) : vec3(0.15, 0.35, 1.0));
#elif CAUSTICS_DEBUG_MODE == 2
    ivec2 texelId = ivec2(floor(faceCoord * float(TEXELS_PER_BLOCK)));
    ivec2 blockId = ivec2(floor(faceCoord));
    float checker = ((texelId.x + texelId.y) & 1) == 0 ? 0.30 : 0.85;
    return checker * (((blockId.x + blockId.y) & 1) == 0 ? vec3(1.0, 0.45, 0.40) : vec3(0.40, 0.60, 1.0));
#elif CAUSTICS_DEBUG_MODE == 3
    uint cellColor = causticHash(pattern.cellId, 0x5555u);
    return vec3(float(cellColor & 255u), float((cellColor >> 8u) & 255u), float((cellColor >> 16u) & 255u)) * (1.0 / 255.0);
#elif CAUSTICS_DEBUG_MODE == 4
    return vec3(clamp(pattern.f1 / float(CELL_SIZE_TEXELS), 0.0, 1.0));
#elif CAUSTICS_DEBUG_MODE == 5
    return vec3(clamp(pattern.edge / (0.5 * float(CELL_SIZE_TEXELS)), 0.0, 1.0));
#elif CAUSTICS_DEBUG_MODE == 6
    return vec3(pattern.lineRaw);
#elif CAUSTICS_DEBUG_MODE == 7
    return vec3(pattern.line);
#elif CAUSTICS_DEBUG_MODE == 8
    return vec3(pattern.edgeBrightness * pattern.lineRaw);
#elif CAUSTICS_DEBUG_MODE == 9
    return vec3(clamp(0.5 + pattern.mosaic * 4.0, 0.0, 1.0));
#elif CAUSTICS_DEBUG_MODE == 10
    return pattern.level == 0 ? vec3(0.06) : (pattern.level == 1 ? vec3(0.10, 0.18, 0.45) :
           (pattern.level == 2 ? vec3(0.15, 0.45, 1.0) : (pattern.level == 3 ? vec3(0.20, 0.90, 0.30) : vec3(1.0, 0.85, 0.35))));
#elif CAUSTICS_DEBUG_MODE == 11
    return vec3(clamp(waterColumn / 12.0, 0.0, 1.0));
#elif CAUSTICS_DEBUG_MODE == 12
    return vec3(submerged);
#elif CAUSTICS_DEBUG_MODE == 13
    return vec3(receiverShadow);
#elif CAUSTICS_DEBUG_MODE == 14
    return light;
#else
    return vec3(0.0);
#endif
}
#endif

#endif

#if defined(WATER_LAYER) && defined(WATER_SKY_REFLECTION)
#include "/lib/water_reflection.glsl"
#endif

vec4 shadeFragment(out vec3 causticsDebug) {
    causticsDebug = vec3(0.0);
#ifdef CAUSTICS_DEBUG
#if CAUSTICS_DEBUG_MODE == 15 && defined(WATER_LAYER)
    // White means mc_Entity classified this rendered fragment as water.
    causticsDebug = vec3(vIsFluid > 0.5 ? 1.0 : 0.0);
#endif
#endif
    vec4 rawTexel = texture(gtexture, vTexCoord);
    vec4 texel = rawTexel * vColor;
#if defined(BLK_ACTIVE) && defined(BLOCK_MICRO_DETAIL)
    // Texel footprint of the micro-detail: derivatives before any discard (uniform control flow).
    vec3 blkDpDx = dFdx(vPlayerPosition);
    vec3 blkDpDy = dFdy(vPlayerPosition);
#endif
#if defined(WATER_LAYER) && (defined(WAVE_LIGHTING) || defined(WATER_SKY_REFLECTION))
    // Screen derivatives are taken here, before any discard or branch (uniform control flow).
    vec3 waveDpDx = dFdx(vPlayerPosition);
    vec3 waveDpDy = dFdy(vPlayerPosition);
    vec2 waveDuvDx = dFdx(vTexCoord);
    vec2 waveDuvDy = dFdy(vTexCoord);
#endif
    if (texel.a < alphaTestRef) discard;

#if defined(WATER_LAYER) && (defined(PIXEL_CAUSTICS) || defined(WATER_DEPTH_TINT))
    // Opaque receiver behind this water fragment, shared by the depth tint and the caustics.
    // This fragment is where the view ray enters the water (the depthtex0 surface); the
    // receiver comes from depthtex1 (opaque only), never from the water surface itself.
    bool waterHitValid = false;
    ivec2 waterPixel = ivec2(gl_FragCoord.xy);
    vec2 waterScreen = vec2(textureSize(depthtex1, 0));
    float waterHitDepth = 1.0;
    vec3 waterHitPlayer = vec3(0.0);
    float waterColumn = 0.0;
    if (vIsFluid > 0.5 && isEyeInWater == 0) {
        waterHitDepth = texelFetch(depthtex1, waterPixel, 0).r;
        if (waterHitDepth < 0.99999) {
            waterHitPlayer = causticPlayerFromDepth(waterPixel, waterHitDepth, waterScreen);
            // Vertical water column in world blocks (cameraPosition cancels), floors and walls alike.
            waterColumn = vPlayerPosition.y - waterHitPlayer.y;
            waterHitValid = true;
        }
    }
#endif
#if defined(WATER_LAYER) && defined(WATER_DEPTH_TINT)
    if (vIsFluid > 0.5 && isEyeInWater == 0) {
        // Shallow water stays clear and turquoise so the floor shows through; with depth it
        // shifts to the near-water blue and opacity (about 8-12 blocks). With horizontal
        // distance it turns lighter and opaque, so the far surface hides the floor; the
        // reflection blend in gbuffers_water then takes it towards the sky colour. The vanilla
        // water texture survives as a faint brightness ripple.
        float deepMix = waterHitValid ? 1.0 - exp(-max(waterColumn - 1.0, 0.0) * ABSORPTION_STRENGTH) : 1.0;
        float distanceMix = waterDistanceBlend();
        float waterDetail = 0.80 + 0.35 * dot(rawTexel.rgb, vec3(0.2126, 0.7152, 0.0722));
        vec3 ownTint = mix(waterShallowTint(), waterDeepTint(), deepMix);
        texel.rgb = mix(ownTint, waterFarTint(), distanceMix * 0.7) * waterDetail;
        float nearOpacity = mix(WATER_OPACITY_NEAR, max(texel.a, 0.80), deepMix);
        texel.a = mix(nearOpacity, max(nearOpacity, WATER_OPACITY_FAR), distanceMix);
    }
#endif

    vec2 lightCoord = clamp(vLightCoord, vec2(0.0), vec2(1.0));
#ifdef END_FLASHES
    // Update 3, the End: Minecraft 26.3's lightmap adds the flash as a sky light without direction
    // (sky factor = the End's sky_light_factor 0 + the flash intensity, a third in the dragon fight), so
    // every sky-lit surface brightens about 4 x at the peak. The pack's flash (below) is that light with a
    // direction and shadows, so the lightmap is read at sky level 0 here: in the End that row is the light
    // without the flash at every sky level (ambient, torches, Night Vision, the brightness setting
    // included). Between flashes all rows are equal, so nothing changes then.
    vec3 vanillaLight = texture(lightmap, atmosEnd > 0.5 ? vec2(lightCoord.x, 1.0 / 32.0) : lightCoord).rgb;
#else
    vec3 vanillaLight = texture(lightmap, lightCoord).rgb;
#endif
#if (defined(FAKE_GI) || defined(CHROMATIC_LIGHT)) && (defined(TERRAIN_LAYER) || defined(WATER_LAYER))
    // Update 5: the block light level, continuous (smooth lighting interpolates it across each face), and the
    // share of this surface's light that is block light (layer 5, the near detail).
    float giLevel = clamp(lightCoord.x * 16.0 - 0.5, 0.0, 15.0);
    float giBlockShare = 0.0;
    // The block light is what the lightmap gives above its own block level 0 at the same sky level (the same
    // row the lines above read).
    float giRowY = lightCoord.y;
#ifdef END_FLASHES
    if (atmosEnd > 0.5) giRowY = 1.0 / 32.0;
#endif
    vec3 giNoBlock = texture(lightmap, vec2(1.0 / 32.0, giRowY)).rgb;
    vec3 giBlockLight = max(vanillaLight - giNoBlock, vec3(0.0));
    giBlockShare = giLuma(giBlockLight) / max(giLuma(vanillaLight), 1.0e-4);
#endif
#if defined(CHROMATIC_LIGHT) && defined(END_AMBIENCE) && defined(TERRAIN_LAYER)
    // Update 5: in the End the chromatic light takes over END_AMBIENT_TINT on blocks (below), so the End's ambient is
    // a static layer: the same dim violet light everywhere, no longer brightened where block light is high (layer 3:
    // not affected by the emitters), and the block light is the ramp's alone.
    bool giEndStatic = atmosEnd > 0.5 && vIsFluid < 0.5;
#endif
#if (defined(FAKE_GI) || defined(CHROMATIC_LIGHT)) && defined(TERRAIN_LAYER)
#ifdef CHROMATIC_LIGHT
    // Update 5, the chromatic light, on blocks of the terrain program (water, glass, ice, entities, items and particles
    // keep the game's block light colour: the water and the particles are frozen systems). Layer 4: the block light
    // takes the colour ramp of its level (near, mid, far colour; per vertex, lib/gbuffers.vsh) and keeps the game's
    // brightness (the End: also its shorter reach, giRampGainEnd); the Nether keeps NETHER_WARM_LIGHT, which is
    // already a ramp of this kind (not doubled). Layer 3: a dim static ambient where the sky does not reach.
    if (vIsFluid < 0.5) {
        float giRampAmount = atmosEnd > 0.5 ? float(RAMP_END_AMOUNT) : (atmosNether > 0.5 ? 0.0 : float(RAMP_OVERWORLD_AMOUNT));
        giRampAmount *= float(LIGHT_RAMP_STRENGTH);
        vec3 giRampedBlock = mix(giBlockLight, vGiRamp * giLuma(giBlockLight), giRampAmount);
#ifdef GI_MICRODETAIL_RESPONSE
        if (giRampAmount > 0.0) gGiTorchHue = mix(gGiTorchHue, giHue(vGiRamp) * giLuma(gGiTorchHue), giRampAmount);
#endif
        float giOverworld = atmosEnd < 0.5 && atmosNether < 0.5 ? 1.0 : 0.0;
        vec3 giAmbient = giStaticAmbient(giOverworld * (1.0 - smoothstep(0.10, 0.95, lightCoord.y)),
                                         atmosNether > 0.5 ? 1.0 : 0.0, atmosEnd > 0.5 ? 1.0 : 0.0);
#ifdef END_AMBIENCE
        if (giEndStatic) giNoBlock *= mix(vec3(1.0), END_AMBIENT_HUE * END_AMBIENT_BRIGHTNESS, float(END_AMBIENT_TINT));
#endif
        vanillaLight = giNoBlock + giRampedBlock + giAmbient;
        giBlockShare = giLuma(giRampedBlock) / max(giLuma(vanillaLight), 1.0e-4);
#ifdef GI_DEBUG
#if GI_DEBUG_MODE == 10
        // White where the colour of this surface's light comes from the ramp (the lightmap: works off-screen).
        gGiTerrainDebug = vec3(giRampAmount * giBlockShare);
#elif GI_DEBUG_MODE == 16
        gGiTerrainDebug = texel.rgb * giAmbient * 30.0;
#elif GI_DEBUG_MODE == 17
        gGiTerrainDebug = giRampedBlock;
#endif
#endif
    }
#endif
#endif
    vec3 base = texel.rgb * vanillaLight;
#ifdef NETHER_WARM_LIGHT
    // Update 3, the Nether: the block light takes the Nether palette's hue (deep red at low light,
    // orange near a source; teal in soul sand valleys); the vanilla lightmap stays the brightness. A
    // very subtle smooth flicker (the same for every pixel, from the CPU) on the block-lit part.
    float netherHere = atmosNether > 0.5 ? 1.0 : 0.0;
    float netherBlockShare = netherHere * smoothstep(0.05, 0.55, lightCoord.x);
    if (netherHere > 0.5) {
        base *= mix(vec3(1.0), netherBlockLightHue(lightCoord.x), NETHER_LIGHT_COLOR_WARMTH * netherBlockShare);
#ifdef NETHER_FLICKER
        base *= 1.0 + NETHER_LIGHT_FLICKER * vclNFlicker * netherBlockShare;
#endif
    }
#endif
#ifdef END_AMBIENCE
    // Update 4, the End: the dim ambient light of Vibrant Visuals, warm-neutral and darker than the
    // vanilla grey-green (your references: end stone #4D492F); torch light keeps its own colour and
    // brightness.
#if defined(CHROMATIC_LIGHT) && defined(TERRAIN_LAYER)
    // Update 5: on blocks with the chromatic light the tint is already in the End's static ambient (above).
    if (atmosEnd > 0.5 && !giEndStatic) base *= mix(vec3(1.0), END_AMBIENT_HUE * END_AMBIENT_BRIGHTNESS, END_AMBIENT_TINT * (1.0 - smoothstep(0.05, 0.55, lightCoord.x)));
#else
    if (atmosEnd > 0.5) base *= mix(vec3(1.0), END_AMBIENT_HUE * END_AMBIENT_BRIGHTNESS, END_AMBIENT_TINT * (1.0 - smoothstep(0.05, 0.55, lightCoord.x)));
#endif
#endif

    vec3 Nview = safeNormalize(vNormalView);
    vec3 Nworld = safeNormalize(vWorldNormal);
    vec3 Vview = safeNormalize(-vViewPosition);
    vec3 Lview = safeNormalize(shadowLightPosition);
#ifdef END_FLASHES
    // Update 3, the End flash. With FLASH_SHADOWS, Iris points shadowLightPosition and the shadow map
    // at the flash in the End (endFlashShadows); the pack's previous terms keep the light they had
    // there before (the fixed noon sun, sunPosition). The flash itself is a separate light below.
    bool endHere = atmosEnd > 0.5;
    float flashE = endHere ? endFlashEnvelope() : 0.0;
    vec3 flashLview = safeNormalize(endFlashPosition);
#ifdef FLASH_SHADOWS
    if (endHere) Lview = safeNormalize(sunPosition);
#endif
#endif
    vec3 Hview = safeNormalize(Lview + Vview);
    float day = smoothstep(-0.12, 0.14, vSunElevation);
    float nDotL = max(dot(Nview, Lview), 0.0);
    float litBySky = smoothstep(0.10, 0.95, lightCoord.y);
    float litByBlock = smoothstep(0.35, 1.0, lightCoord.x);
    float lightExposure = max(litBySky * 0.78, litByBlock * 0.10);
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;

    // MEDIUM: 4 reads only for sky-lit front faces. LOW uses 1; CINEMATIC uses 8.
    float shadow = 1.0;
    float shadowFacing = nDotL;
#ifdef LEAF_TRANSLUCENCY
    float leafBackDot = 0.0;
    if (vIsFoliage > 0.5) {
        leafBackDot = max(dot(-Nview, Lview), 0.0);
        shadowFacing = max(shadowFacing, leafBackDot);
    }
#endif
#ifdef BLK_ACTIVE
    // Update 2B: the light of this frame for the face model (terrain: from the vertex shader; ice
    // and glass: evaluated here, only on their pixels).
    bool blkOn = BLK_SURFACE;
#if defined(BLOCK_DEBUG) && BLOCK_DEBUG_MODE == 16
    blkOn = blkOn && gl_FragCoord.x >= 0.5 * viewWidth;   // split view: left half without
#endif
#ifdef TERRAIN_LAYER
    vec3 blkAmount = vBlkFace.xyz;
    float blkPlantBlend = vBlkFace.w;
#else
    vec3 blkAmount = vec3(1.0, 0.0, 0.0);
    float blkPlantBlend = 0.0;
    if (blkOn) blkAmount = blkFaceLightAmount();
#endif
#ifdef DIRECTIONAL_LIGHTING
    // Cross-shaped plants are lit through an up-blended normal from both sides, so their shadow is
    // looked up on both sides too (as the leaves do above); the lookup itself is unchanged.
    if (blkOn && blkPlantBlend > 0.0) shadowFacing = max(shadowFacing, max(dot(-Nview, Lview), 0.0));
#endif
#endif
    bool sunShadowMap = true;
#ifdef FLASH_SHADOWS
    // In the End the shadow map follows the flash: it is read for the flash below, not for the sun.
    sunShadowMap = !endHere;
#endif
    if (sunShadowMap && litBySky > 0.05 && shadowFacing > 0.05) {
        shadow = getShadow(vShadowClip, nDotL, vPlayerPosition, Nworld);
    }
#ifdef END_FLASHES
    // The flash's own N.L and shadow (only while a flash is on, only under the open sky). Iris builds
    // the shadow matrices from the flash direction, so vShadowClip and getShadow need no change.
    float flashNdotL = dot(Nview, flashLview);
    float flashShadow = 1.0;
#ifdef FLASH_SHADOWS
    if (flashE > 0.0 && litBySky > 0.05 && flashNdotL > 0.02) {
        flashShadow = getShadow(vShadowClip, flashNdotL, vPlayerPosition, Nworld);
    }
#endif
    // Shadowed areas keep the violet ambient: the shadow takes FLASH_SHADOW_STRENGTH of the flash light.
    float flashVis = mix(1.0, flashShadow, FLASH_SHADOW_STRENGTH);
#endif
#ifdef CLOUD_SHADOW_ENABLE
    // Cloud shadow, computed once per fragment and reused by every sun-dependent term: the
    // shadow factor below (direct sun share, warm/cool response, gloss, leaf back-light), the
    // wave crest light and the caustics. The vanilla sky/ambient light is never touched, so
    // the shadows stay soft and bluish. Skipped at night, in rain, indoors and on faces
    // turned away from the sun.
    float cloudShadow = 1.0;
    vec3 ambSun = ambSunDirection();
    if (overworld > 0.5 && litBySky > 0.05 && shadowFacing > 0.05 && ambCloudShadowFade(ambSun) > 0.0) {
        cloudShadow = ambienceCloudShadow(vPlayerPosition + Nworld * 0.05, ambSun);
    }
#endif
#if defined(TERRAIN_LAYER) && defined(SHADOW_COLORS)
    // Dynamic shadow colours (terrain receivers, Overworld, camera above water). The shadow
    // shape, resolution, grid and filtering stay exactly as getShadow returns them; only how dark
    // the shaded part becomes (entity shadows) and its colour (below) change.
    bool shadowColorsHere = overworld > 0.5 && isEyeInWater == 0;
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 8
    // Split view: left half without the shadow colours, right half with them.
    shadowColorsHere = shadowColorsHere && gl_FragCoord.x >= 0.5 * viewWidth;
#endif
    float cloudVisibility = 1.0;
#ifdef CLOUD_SHADOW_ENABLE
    cloudVisibility = cloudShadow;
#endif
    float mapShadow = shadow;
    float entityCast = 0.0;
    float entityVisibility = 1.0;
    float sunStrengthEff = shadowSunStrength(cloudVisibility);
#ifdef SHADOW_ENTITY_FLAG_READ
    if (shadowColorsHere && mapShadow < 0.999) {
        entityCast = shadowCasterIsEntity(vShadowClip, nDotL, vPlayerPosition, Nworld);
    }
#endif
    if (shadowColorsHere && entityCast > 0.5) {
        // Player and mob shadows: as dark as terrain shadows in full sun (SHADOW_MAX_DARKNESS),
        // weaker under cloud shadows, overcast and rain, never below SHADOW_MIN_DARKNESS.
        float entityDarkness = mix(SHADOW_MIN_DARKNESS, SHADOW_MAX_DARKNESS, sunStrengthEff);
        entityVisibility = 1.0 - (1.0 - mapShadow) * entityDarkness;
        shadow = entityVisibility;
    }
#endif
#ifdef CLOUD_SHADOW_ENABLE
    // Combined with the shadow map as a product: the two occluders are independent, so their
    // transmittances multiply (a minimum would hide a cloud inside soft shadow-map edges).
    // Water keeps its own base colour; its glints and caustics take the cloud shadow below.
    if (vIsFluid < 0.5) shadow *= cloudShadow;
#endif
#ifdef BLK_ACTIVE
    // Update 2B on block surfaces. Visibility of the direct light: the shadow map (with the entity
    // shadow strength) times the cloud shadow, exactly as computed above; where the shadow map was
    // not read (faces nearly edge-on to the light) only the cloud shadow, blended over the same
    // N.L range in which the read starts, so nothing steps when it switches on.
    vec3 blkNormal = Nworld;
    float blkVisibility = 1.0;
    float blkSkyWeight = 0.0;
    float blkNdotL = 0.0;
    float blkFace = 1.0;
    float blkSheen = 0.0;
    vec3 blkAdd = vec3(0.0);
    float blkKindShape = 0.0;
#if defined(FAKE_GI) || defined(CHROMATIC_LIGHT)
    // Update 5, layer 5: how much more light the lighter texels catch near a light source (see below).
    float giNearBoost = 0.0;
#endif
    if (blkOn) {
        vec3 blkLight = safeNormalize(mat3(gbufferModelViewInverse) * Lview);
        float blkCloud = 1.0;
#ifdef CLOUD_SHADOW_ENABLE
        if (vIsFluid < 0.5) blkCloud = cloudShadow;
#endif
        blkVisibility = mix(blkCloud, shadow, smoothstep(0.05, 0.12, shadowFacing));
        // Share of the light that comes from the sky (the face light never touches torchlight, and
        // light sources and lava, class 9, are not shaded by the sun).
#if FACE_LIGHTING_QUALITY == 2
        vec3 blkSkyOnly = texture(lightmap, vec2(1.0 / 32.0, lightCoord.y)).rgb;
        float blkSkyShare = clamp(dot(blkSkyOnly, vec3(0.2126, 0.7152, 0.0722)) /
                                  max(dot(vanillaLight, vec3(0.2126, 0.7152, 0.0722)), 1.0e-4), 0.0, 1.0);
#else
        float blkSkyShare = 1.0 - litByBlock * (1.0 - day);
#endif
        float blkEmissive = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup));
        blkSkyWeight = litBySky * blkSkyShare * overworld * (1.0 - blkEmissive);
        if (blkPlantBlend > 0.0) blkNormal = safeNormalize(mix(Nworld, vec3(0.0, 1.0, 0.0), blkPlantBlend));
        blkNdotL = dot(blkNormal, blkLight);
#ifdef DIRECTIONAL_LIGHTING
        blkFace = mix(1.0, blkFaceFactor(blkAmount, blkNormal, blkNdotL, blkVisibility), blkSkyWeight);
#endif
#ifdef BLOCK_MICRO_DETAIL
        BlkMaterial blkM;
#ifdef TERRAIN_LAYER
        blkM.detail = vBlkDetail;
        blkM.amount = vBlkAmount;
        blkM.color = vBlkColor;
        blkM.shape = vBlkShape;
#else
        blkM = blkMaterial(vBlkMaterial, Nworld);
#endif
        // Kind 0 (unmapped blocks, groups switched off): nothing to do (shape.z = flags + 32 x kind).
        if (blkM.shape.z > 31.5) {
#ifdef AMBIENCE_COLORS
            vec3 blkSunHue = vAmbSunLight / max(ambLuma(vAmbSunLight), 1.0e-3);
            vec3 blkZenith = vAmbSkyLight;
#else
            vec3 blkSunHue = mix(vec3(1.00, 0.97, 0.92), vec3(1.00, 0.76, 0.52), 1.0 - smoothstep(0.05, 0.35, vSunElevation));
            vec3 blkZenith = skyColor;
#endif
            vec3 blkLightHue = vSunElevation > 0.0 ? blkSunHue : BLK_MOON_COLOR;
            float blkTorch = litByBlock * (1.0 - 0.8 * litBySky * day);
            vec3 blkHorizon = fogColor;
            vec3 blkDetailLight = blkLight;
            float blkDetailNdotL = blkNdotL;
            float blkDetailVisibility = blkVisibility;
            float blkDetailK = overworld;
#ifdef END_AMBIENCE
            if (atmosEnd > 0.5) {
                // Update 3, the End: the faint sky reflection of the gloss blocks shows the End sky (it
                // showed the Overworld noon palette before); with FLASH_GLINTS the flash is the
                // light of the glints and the sheen (0 between flashes, like the sun at night).
                blkZenith = endFogColor(vec3(0.0, 1.0, 0.0));
                blkHorizon = endFogColor(vec3(1.0, 0.0, 0.0));
#ifdef FLASH_GLINTS
                vec3 blkFlashDir = safeNormalize(mat3(gbufferModelViewInverse) * flashLview);
                blkDetailLight = blkFlashDir;
                blkDetailNdotL = dot(blkNormal, blkFlashDir);
                blkDetailVisibility = flashShadow;
                blkLightHue = endFlashColor();
                blkDetailK = 1.5 * flashE;
#endif
            }
#endif
            BlkDetail blkD = blkMicroDetail(blkM, blkAmount, rawTexel, texel.rgb, blkNormal, blkDetailLight, blkDetailNdotL, blkDetailVisibility,
                                            litBySky * (1.0 - blkEmissive), smoothstep(0.30, 0.90, lightCoord.y), blkTorch,
                                            blkLightHue, blkZenith, blkHorizon, blkDpDx, blkDpDy, blkDetailK);
            blkSheen = blkD.sheen;
            blkAdd = blkD.add;
#if (defined(FAKE_GI) || defined(CHROMATIC_LIGHT)) && defined(GI_MICRODETAIL_RESPONSE)
            // Update 5, layer 5 (the micro-detail response): near a light source (block light level 9 to 13 and
            // up, the ramp's near colour) the texels lighter than their texture's mean (obsidian speckles, grains;
            // the same detail mask as the glints) catch more of that light, in its colour (the light's own colour
            // times the speckle's albedo); it fades with the light and is gone in the far field.
            float giDetail = smoothstep(blkM.detail.x, blkM.detail.y, dot(rawTexel.rgb, vec3(0.2126, 0.7152, 0.0722)));
            giNearBoost = giDetail * float(NEAR_DETAIL_RESPONSE) * smoothstep(9.0, 13.0, giLevel) * giBlockShare;
#endif
        }
        blkKindShape = blkM.shape.z;
#endif
    }
#endif
#if defined(BLK_ACTIVE) && defined(DIRECTIONAL_LIGHTING)
    if (blkOn) {
        // Directional face light on the sky-lit part of the lightmap. It replaces the previous
        // shadow darkening and directional lift on blocks; the shadow factor enters only through
        // the direct term, so faces turned away from the light are never darkened twice.
        base *= blkFace;
    } else {
#endif
    // Apply shadowing to vanilla skylight only; lightmap, block light, and vanilla AO remain.
    base *= 1.0 - (1.0 - shadow) * litBySky * nDotL * overworld * 0.34;

#ifdef PREVIOUS_SUN_LIFT
    // Small directional lift over existing skylight; vanilla block-light warmth remains untouched.
    // (Update 2B: its own switch, set as DIRECTIONAL_LIGHTING was before, so water, entities and
    // particles keep it unchanged; blocks take it only while the face lighting is off.)
    float directSun = litBySky * nDotL * shadow * day * (1.0 - rainStrength * 0.45) * overworld;
    float directMoon = litBySky * nDotL * shadow * (1.0 - day) * (1.0 - rainStrength * 0.65) * overworld * 0.22;
    base += base * DIRECTIONAL_LIGHT_STRENGTH *
            (vec3(1.00, 0.80, 0.56) * directSun + vec3(0.40, 0.58, 1.00) * directMoon);
#endif
#if defined(BLK_ACTIVE) && defined(DIRECTIONAL_LIGHTING)
    }
#endif
#if defined(BLK_ACTIVE) && defined(BLOCK_MICRO_DETAIL)
    // Sheen: the lighter texels of the lit side catch a little more light (before the colour
    // responses below, so they tint it like the rest of the surface).
    if (blkOn) base *= 1.0 + blkSheen;
#if (defined(FAKE_GI) || defined(CHROMATIC_LIGHT)) && defined(GI_MICRODETAIL_RESPONSE)
    if (blkOn) base *= 1.0 + giNearBoost;
#endif
#endif

#ifdef ATMOSPHERIC_GRADE
    // Warm daylight and cool shade stay subtle so the existing plastic response remains unchanged.
    vec3 warmDayTint = vec3(1.045, 0.990, 0.925);
    vec3 coolShadeTint = vec3(0.945, 0.980, 1.045);
#if defined(TERRAIN_LAYER) && defined(SHADOW_COLORS)
    // The fixed cool shade tint follows the ambient sky light instead (same strength).
    if (shadowColorsHere) coolShadeTint = mix(vec3(1.0), vAmbShadowLight / max(ambLuma(vAmbShadowLight), 1.0e-3), 0.45);
#endif
    float directSunMask = litBySky * nDotL * shadow * overworld;
    float coolShadowMask = litBySky * (1.0 - shadow) * overworld;
    base *= mix(vec3(1.0), warmDayTint, directSunMask * WARM_COOL_STRENGTH);
    base *= mix(vec3(1.0), coolShadeTint, coolShadowMask * WARM_COOL_STRENGTH);
#endif

#ifdef AMBIENCE_COLORS
    // Terrain light response (never on water, never on the gloss layer added below).
    if (vIsFluid < 0.5 && overworld > 0.5) {
        bool ambienceGrade = true;
#if defined(AMBIENCE_DEBUG) && AMBIENCE_DEBUG_MODE == 15
        ambienceGrade = gl_FragCoord.x >= 0.5 * viewWidth;   // split view: left half without
#endif
        if (ambienceGrade) {
            float ambSunMask = litBySky * nDotL * shadow * day;
            float ambShadeMask = litBySky * (1.0 - nDotL * shadow) * mix(0.4, 1.0, day);
            base = ambienceTerrainResponse(base, texel.rgb, ambSunMask, ambShadeMask, vAmbSunLight, vAmbSkyLight);
        }
    }
#endif

#if defined(TERRAIN_LAYER) && defined(SHADOW_COLORS)
    if (shadowColorsHere) {
        // Shares of the surface light: the direct sun reaching it, the part an entity's shadow
        // takes away, and the rest in shade (terrain and cloud shadows, faces turned away, which
        // get the same tint, so there is no seam where a shaded face meets a cast shadow).
        float entityShare = entityCast * nDotL * cloudVisibility * (1.0 - entityVisibility);
        float shadeShare = max(clamp(1.0 - nDotL * shadow, 0.0, 1.0) - entityShare, 0.0);
        float shadowWeight = litBySky * mix(0.4, 1.0, day) *
                             (TERRAIN_SHADOW_COLOR_STRENGTH * shadeShare + ENTITY_SHADOW_COLOR_STRENGTH * entityShare);
        base = shadowColorResponse(base, texel.rgb, vAmbShadowLight, shadowWeight);
    }
#endif

#ifdef END_FLASHES
    // Update 3, the End flash as a directional light on top of the dim End light (it replaces the game's
    // own purple sky light from the lightmap, which has no direction; see vanillaLight above): faces
    // turned to the flash get a violet light (the rim on the pillars), faces turned away and cast shadows
    // keep the ambient; only under the open sky. Torch and lantern light turns slightly purple.
    vec3 flashColor = vec3(0.0);
    vec3 flashLight = vec3(0.0);
    if (flashE > 0.0) {
        flashColor = endFlashColor();
        float flashWrap = max(flashNdotL, 0.0) * 0.92 + 0.08 * smoothstep(0.0, 0.12, flashNdotL);
        // Update 4.1: faces turned up (the ground) keep a quarter of it. With the volumetric flash fog the ground
        // toward the flash also turns violet through the air in front of it, and your Vibrant Visuals screenshots
        // show the lit ground under the glow only a little violet (#534940 against #4A4A2F; ours was #625040,
        // 83 to 85 luma against 72 to 76): a quarter fits the lit ground of images 2, 4 and 6 (luma rms 3.7,
        // against 8.7 with 70 %) and keeps image 2's lit / shadowed contrast on the ground (about 5 luma).
        float flashUpFace = 1.0 - 0.75 * smoothstep(0.50, 0.95, Nworld.y);
        flashLight = texel.rgb * flashColor * (FLASH_LIGHT_GAIN * flashUpFace * flashE * flashWrap * flashVis * litBySky);
        base *= mix(vec3(1.0), flashColor / max(dimLuma(flashColor), 1.0e-3), FLASH_BLOCKLIGHT_TINT * min(flashE, 1.0) * litByBlock);
        base += flashLight;
    }
#endif

    float specular = fastGlossCurve(max(dot(Nview, Hview), 0.0));
    float fresnel = fastPowerFive(1.0 - max(dot(Nview, Vview), 0.0));
    float glossMask = lightExposure * mix(0.22, 1.0, shadow) * (0.28 + 0.72 * nDotL);
    vec3 lightTint = mix(vec3(0.62, 0.74, 1.0), vec3(1.0, 0.86, 0.67), day);
    vec3 highlight = lightTint * (specular * GLOSS_STRENGTH + fresnel * GLOSS_FRESNEL) *
                     glossMask * PLASTIC_GLOSS_MIX;
#ifdef END_FLASHES
    if (flashE > 0.0) {
        // The plastic gloss of the player, mobs and items picks the flash up as a violet highlight
        // (blocks have no plastic gloss: it is cleared for them just below).
        vec3 flashH = safeNormalize(flashLview + Vview);
        float flashSpecular = fastGlossCurve(max(dot(Nview, flashH), 0.0));
        highlight += flashColor * (flashSpecular * GLOSS_STRENGTH + fresnel * GLOSS_FRESNEL) *
                     (flashE * flashVis * litBySky * max(flashNdotL, 0.0) * PLASTIC_GLOSS_MIX);
    }
#endif
#if defined(TERRAIN_LAYER) || defined(WATER_LAYER)
    // Update 2B: no plastic gloss on blocks (the micro-detail replaces it; the previous
    // MATERIAL_RESPONSE gloss is removed). The player, mobs and items keep it; so does the water.
    if (BLK_SURFACE) highlight = vec3(0.0);
#endif

#ifdef LEAF_TRANSLUCENCY
    if (vIsFoliage > 0.5 && overworld > 0.5) {
        float backLight = leafBackDot * litBySky * day * shadow;
        highlight += vec3(1.0, 0.78, 0.48) * backLight * LEAF_TRANSMISSION;
    }
#endif

#ifdef GOLDEN_TARGET_BACKLIGHT
    if (vIsFoliage > 0.5 && overworld > 0.5) {
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float targetLowSun = (1.0 - smoothstep(0.035, 0.40, abs(vSunElevation))) *
                             smoothstep(-0.18, 0.06, vSunElevation);
        float targetBackDot = max(dot(-Nview, Lview), 0.0);
        float targetBackLight = targetBackDot * litBySky * shadow * targetLowSun *
                                (1.0 - rainStrength * 0.55) * targetMatch;
        highlight += vec3(1.00, 0.63, 0.34) * targetBackLight * GOLDEN_BACKLIGHT_STRENGTH;
    }
#endif

#ifdef SUBSURFACE_TRANSMISSION
    if (vIsThin > 0.5 && overworld > 0.5) {
        float thinBackLight = max(dot(-Nview, Lview), 0.0) * litBySky * day * shadow;
        vec3 thinTint = vMaterialGroup > 7.5 ? vec3(0.48, 0.78, 0.92) : vec3(0.78, 0.92, 0.56);
        highlight += thinTint * thinBackLight * THIN_TRANSMISSION_STRENGTH;
    }
#endif

#if defined(BLK_ACTIVE) && defined(BLOCK_MICRO_DETAIL)
    // Micro-detail glints and sky reflection, limited so no channel goes past 1.15 (about 1.0
    // after the tone shoulder in final): no HDR sparkles for the bloom to blow up.
    if (blkOn) highlight += min(blkAdd, max(vec3(1.15) - base, vec3(0.0)));
#endif

    float skyExposure = smoothstep(0.42, 0.96, lightCoord.y);
    float topSurface = smoothstep(0.70, 0.96, Nworld.y);

#ifndef WATER_LAYER
#ifdef WET_GROUND
    // LOW: rain-only branch with polynomial hash/triangle ripple; no fragment trig.
    if (wetness > 0.001 && topSurface > 0.01 && skyExposure > 0.01 && overworld > 0.5) {
        float wetMask = wetness * skyExposure * topSurface;
        float puddleNoise = cheapHash(floor(vWorldPosition.xz * 0.7));
        vec2 ripplePos = fract(vWorldPosition.xz * 0.32) - vec2(0.5);
        vec2 absRipplePos = abs(ripplePos);
        float rippleDistance = max(absRipplePos.x, absRipplePos.y) + 0.4142 * min(absRipplePos.x, absRipplePos.y);
        float ripplePhase = fract(rippleDistance * 6.6845 - frameTimeCounter * 0.414);
        float rippleTri = 1.0 - abs(ripplePhase * 2.0 - 1.0);
        float ripple = rippleTri * rippleTri * (3.0 - 2.0 * rippleTri);
        wetMask *= 0.68 + puddleNoise * 0.22 + ripple * 0.10;

        float luma = dot(base, vec3(0.2126, 0.7152, 0.0722));
        base = mix(base, vec3(luma), wetMask * 0.09);
        base *= 1.0 - wetMask * 0.10;

        vec3 Vworld = safeNormalize(cameraPosition - vWorldPosition);
        vec3 reflectedWorld = reflect(-Vworld, Nworld);
        vec3 fakeSky = mix(fogColor, skyColor, smoothstep(-0.08, 0.60, reflectedWorld.y));
        // LOW: analytic sky/fog-color reflection; no screen-space or ray-marched reflection.
        base += fakeSky * wetMask * (0.035 + 0.025 * ripple);
        highlight += fakeSky * wetMask * (0.10 + 0.08 * ripple) * specular;
    }
#endif
#else
    if (vIsFluid > 0.5) {
        vec3 waveNormal = Nworld;
#ifdef WAVE_LIGHTING
        // The vanilla animated water texture is the only wave source. Its texels get a soft
        // sun/moon response (gWaveLight, added on the surface in gbuffers_water); the
        // procedural ripple normal and the plastic water gloss are not used, so with
        // WAVE_LIGHT_STRENGTH = 0 the water is the plain base water.
        highlight = vec3(0.0);
        gWaveLight = waveCrestLight(rawTexel.rgb, Nworld, Lview, lightCoord, overworld,
                                    waveDpDx, waveDpDy, waveDuvDx, waveDuvDy, gWaveDebug, waveNormal);
#ifdef CLOUD_SHADOW_ENABLE
        // Glints and wave sun light dim under cloud shadows (same per-fragment value).
        gWaveLight *= cloudShadow;
#endif
#else
        // LOW: triangle-wave normal ripple; vertex positions and foliage remain static.
        float waveX = fract(vWorldPosition.x * 0.68 + frameTimeCounter * 0.143);
        float waveZ = fract(vWorldPosition.z * 0.77 - frameTimeCounter * 0.111);
        vec3 rippleNormal = vec3((1.0 - abs(waveX * 2.0 - 1.0) * 2.0) * 0.045, 0.0,
                                 (1.0 - abs(waveZ * 2.0 - 1.0) * 2.0) * 0.045);
        Nworld = safeNormalize(Nworld + rippleNormal);
        Nview = safeNormalize((gbufferModelView * vec4(Nworld, 0.0)).xyz);
        Hview = safeNormalize(Lview + Vview);
        specular = fastGlossCurve(max(dot(Nview, Hview), 0.0));
        float waterDay = day * (1.0 - rainStrength * 0.78) * overworld;
        float sparkleDot = max(dot(Nview, Hview), 0.0);
        float sparkle = fastPowerFortyEight(sparkleDot);
        sparkle *= lightExposure;
        float sparkleAmount = 0.0;
#ifdef SHALLOW_WATER_LIGHTING
        sparkleAmount = SPARKLE_AMOUNT;
#endif
        highlight += vec3(0.56, 0.82, 1.0) * (specular * (GLOSS_STRENGTH + 0.08) * PLASTIC_GLOSS_MIX + sparkle * sparkleAmount) * (0.25 + 0.75 * waterDay);
#ifdef WATER_SKY_REFLECTION
        // With the reflection system on, water never gets the plastic gloss.
        highlight = vec3(0.0);
#endif
#endif

#ifdef WATER_SKY_REFLECTION
        if (isEyeInWater == 0 && dot(Nview, Vview) > 0.0) {
            // Tier 1 plus the distance/angle blend. The Fresnel term uses the flat normal
            // (stable); the reflected direction uses the wave pseudo-normal as a small tilt.
            // The colour is not mixed here: gbuffers_water mixes it over the water seen
            // through, and final may swap it for the screen-space reflection.
            vec3 Nflat = safeNormalize(vWorldNormal);
            vec3 viewWorld = safeNormalize(-vPlayerPosition);
            vec3 reflectDir = reflect(-viewWorld, waveNormal);
            float NdotV = max(dot(Nflat, viewWorld), 0.0);
            float f1 = 1.0 - NdotV;
            float f2 = f1 * f1;
            float fresnel = 0.02 + 0.98 * f2 * f2 * f1;
            float distanceTerm = waterDistanceBlend();
            float weather = clamp(rainStrength, 0.0, 1.0);
            float reflectivity = clamp(max(fresnel * FRESNEL_STRENGTH, distanceTerm * FAR_REFLECTIVITY), 0.0, 1.0) *
                                 WATER_REFLECTION_STRENGTH * (1.0 - 0.25 * weather) * (overworld > 0.5 ? 1.0 : 0.3);
#ifdef WATER_REFLECTION_IMPROVEMENT
            // Add-on (A/B with WATER_REFLECTION_IMPROVEMENT): palette sky and real cloud cells.
            vec3 reflectionSun = ambSunDirection();
            vec3 skyReflection = waterSkyReflectionImproved(reflectDir, reflectionSun, ambWrappedWorld(vPlayerPosition),
                                                            ambFragmentPalette(), CLOUD_REFLECTION * (1.0 - 0.7 * weather));
#if defined(PIXEL_CAUSTICS) || defined(WATER_DEPTH_TINT)
            // Shallow banks (under ~2 blocks of water) reflect very little, so the turquoise floor
            // and its caustics stay as they are.
            if (waterHitValid) reflectivity *= mix(0.35, 1.0, smoothstep(0.8, 2.2, waterColumn));
#endif
            // Weaker at night; none in the Nether (the End keeps the existing subtle 0.3).
            reflectivity *= mix(1.0, 0.75, 1.0 - smoothstep(-0.20, 0.05, reflectionSun.y));
            reflectivity *= (overworld < 0.5 && hasCeiling) ? 0.0 : 1.0;
#else
            vec3 skyReflection = waterSkyReflection(reflectDir, vSunElevation, CLOUD_REFLECTION * (1.0 - 0.7 * weather));
#endif
            // Under roofs and in caves the water does not see the open sky (final uses the
            // same factor from the stored sky light, so Tier 2 swaps in without a seam).
            skyReflection *= mix(0.12, 1.0, smoothstep(0.30, 0.90, lightCoord.y));

            // Vanilla wave streaks: crest texels catch more of the reflection and get paler with
            // distance; the dark gaps stay closer to the base water. Same crest threshold as the
            // wave lighting (texture mean 0.68), with its own mip bias.
            float lodScale = exp2(STREAK_LOD_BIAS);
            float streakLuma = dot(textureGrad(gtexture, vTexCoord, waveDuvDx * lodScale, waveDuvDy * lodScale).rgb,
                                   vec3(0.2126, 0.7152, 0.0722));
            float crest = floor(smoothstep(0.03, 0.13, (streakLuma - 0.68) * CREST_CONTRAST) * 2.0 + 0.5) * 0.5;
            float streakFade = (1.0 - STREAK_DISTANCE_FADE * smoothstep(float(REFLECT_FAR_DISTANCE), float(REFLECT_FAR_DISTANCE) * 3.0,
                                                                        length(vPlayerPosition.xz))) *
                               smoothstep(0.0, 0.06, NdotV);
            float streak = crest * STREAK_CONTRAST * mix(0.2, 1.0, distanceTerm) * streakFade;
            float gapDarken = 0.2 * (1.0 - crest) * distanceTerm * min(STREAK_CONTRAST, 1.0) * streakFade;
            float texelReflectivity = clamp(reflectivity * (1.0 - gapDarken) + (1.0 - reflectivity) * streak * 0.5, 0.0, 1.0);

            gWaterReflection = vec4(skyReflection * (1.0 + 0.30 * streak), texelReflectivity);
            // Final may replace the Tier-1 colour with the screen-space reflection on flat tops only.
            gReflectionTier2 = texelReflectivity * smoothstep(0.97, 0.995, Nflat.y);
            gWaterWobble = clamp(0.5 + (streakLuma - 0.68) * 6.0, 0.0, 1.0);
#ifdef REFLECTION_DEBUG
#if REFLECTION_DEBUG_MODE == 1
            gReflectionDebug = reflectDir * 0.5 + 0.5;
#elif REFLECTION_DEBUG_MODE == 2
            gReflectionDebug = skyReflection;
#elif REFLECTION_DEBUG_MODE == 6
            gReflectionDebug = vec3(fresnel);
#elif REFLECTION_DEBUG_MODE == 7
            gReflectionDebug = vec3(distanceTerm);
#elif REFLECTION_DEBUG_MODE == 8
            gReflectionDebug = vec3(texelReflectivity);
#elif REFLECTION_DEBUG_MODE == 9 && (defined(PIXEL_CAUSTICS) || defined(WATER_DEPTH_TINT))
            gReflectionDebug = vec3(clamp(waterColumn / 12.0, 0.0, 1.0));
#elif REFLECTION_DEBUG_MODE == 11
            gReflectionDebug = vec3(crest);
#endif
#endif
        }
#endif
#if defined(PIXEL_WATER_SPARKLES) && !defined(WAVE_LIGHTING)
        // Procedural glints; replaced by the crest sparkle when WAVE_LIGHTING is on.
        vec3 stableWaterWorld = causticWrapWorld(vPlayerPosition);
        vec2 sparkleCell = floor(stableWaterWorld.xz * float(TEXELS_PER_BLOCK)) / float(TEXELS_PER_BLOCK);
        float sparkleTick = floor(frameTimeCounter * float(STEPS_PER_SECOND)) / float(STEPS_PER_SECOND);
        float sparkleHash = cheapHash(sparkleCell + vec2(sparkleTick, -sparkleTick * 0.73));
        float pixelSparkle = step(1.0 - SPARKLE_AMOUNT * 0.10, sparkleHash) * sparkle * lightExposure;
        float exteriorSparkleFade = smoothstep(0.01, 0.20, -vPlayerPosition.y) *
                                    smoothstep(-0.02, 0.08, dot(Nview, Vview));
        pixelSparkle *= (isEyeInWater == 0 ? 1.0 : 0.0) * exteriorSparkleFade;
        highlight += vec3(0.76, 0.91, 1.0) * pixelSparkle * SPARKLE_AMOUNT * 0.12;
#endif
        base = mix(base, base * vec3(0.92, 1.02, 1.07), 0.12 * overworld);
    }
#endif

#if defined(TERRAIN_LAYER) && defined(FAKE_GI)
    {
        // Update 5: the light code for the fake GI (lib/fake_gi.glsl): the light the albedo received here (the
        // lit colour before highlights over the albedo, without the per-texel sheen and near detail, so it is
        // smooth across a face), the block light level, whether the direct sun or moon dominates, and whether
        // this is the bright part of a light source.
        float giAlbedo = max(dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722)), 1.0e-3);
        float giPerTexel = 1.0;
#if defined(BLK_ACTIVE) && defined(BLOCK_MICRO_DETAIL)
        if (blkOn) giPerTexel = 1.0 + blkSheen;
#ifdef GI_MICRODETAIL_RESPONSE
        if (blkOn) giPerTexel *= 1.0 + giNearBoost;
#endif
#endif
        float giLight = dot(base, vec3(0.2126, 0.7152, 0.0722)) / (giAlbedo * giPerTexel);
        float giSun = litBySky * overworld * shadow * smoothstep(0.02, 0.35, nDotL) * mix(0.35, 1.0, day);
        float giEmitter = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup)) *
                          smoothstep(EMISSIVE_THRESHOLD, 1.0, dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722)));
        gGiCode = giEncode(giLight, giLevel, step(0.5, giSun), step(0.5, giEmitter));
    }
#endif
    vec3 color = base + highlight;

#ifdef EMISSIVE_BLOCKS
    float emissiveGroup = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup));
    float sourceLuma = dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float emissiveMask = emissiveGroup * smoothstep(EMISSIVE_THRESHOLD, 1.0, sourceLuma);
    color += texel.rgb * emissiveMask * EMISSIVE_STRENGTH;
#endif
#ifdef EMISSIVE_GLOW
    {
        // Update 4: the glow source (Vibrant Visuals: light sources glow). Only the bright texels of an
        // emitter (the flame, not the stick; the crystal, not its frame), never darker than its texture.
        float glowLuma = dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722));
#ifdef TERRAIN_LAYER
        float glowBlock = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup));
        gGlowSource = texel.rgb * (glowBlock * smoothstep(EMISSIVE_THRESHOLD, 1.0, glowLuma) * BLOCK_GLOW_GAIN);
#endif
#ifdef ENTITY_LAYER
        if (vGlowKind > 0.5) {
            float glowMask = smoothstep(0.40, 0.85, glowLuma);
            color = max(color, texel.rgb * glowMask);
            gGlowSource = texel.rgb * (glowMask * ENTITY_GLOW_GAIN);
        }
#endif
    }
#endif
#ifdef NETHER_WARM_LIGHT
    // Update 3, the Nether: lava, fire, glowstone, shroomlight, magma and lit ores glow brighter (the
    // same texture mask as the emissive lift), never pushed past white; the bloom picks it up through
    // its usual threshold, so the two cannot stack into a blow-out.
    float netherEmissive = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup)) *
                           smoothstep(EMISSIVE_THRESHOLD, 1.0, dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722)));
    if (netherHere > 0.5) color = max(color, min(color + texel.rgb * (netherEmissive * NETHER_EMISSIVE_BOOST), vec3(1.0)));
#endif

#ifdef PIXEL_CAUSTICS
#if defined(WATER_LAYER)
    // Outside-camera route: runs on the visible water fragment, which is exactly where the
    // view ray enters the water (the depthtex0 surface), and shades the opaque hit behind
    // it from depthtex1. The light is handed to the water program's blend through
    // gCausticLight, so it lands on the floor before the water's own colour is added.
    float waterDistance = -vViewPosition.z;
    vec3 surfaceNormalWorld = safeNormalize(vWorldNormal);
    float surfaceFacing = dot(safeNormalize(vNormalView), Vview);
    // Top faces fade as the eye approaches the surface; side faces only need to face the camera.
    float outsideSurfaceFade = mix(1.0, smoothstep(0.01, 0.20, -vPlayerPosition.y), step(0.5, surfaceNormalWorld.y));
    float exteriorSurfaceGate = outsideSurfaceFade * step(0.0, surfaceFacing);

    if (waterHitValid && exteriorSurfaceGate > 0.001 && waterDistance < 48.0) {
        vec3 hitPlayer = waterHitPlayer;
        // Submerged-only: opaque hits above the entry point (shore blocks) get nothing.
        float submerged = step(0.02, waterColumn);
        int faceAxis = causticFaceAxis(hitPlayer, waterPixel, waterHitDepth, waterScreen);
        float towardCamera = faceAxis == 0 ? -hitPlayer.x : (faceAxis == 1 ? -hitPlayer.y : -hitPlayer.z);
        float faceSign = towardCamera >= 0.0 ? 1.0 : -1.0;
        vec3 faceNormal = causticFaceNormal(faceAxis, faceSign);
        vec2 faceCoord = causticFaceCoord(causticWrapWorld(hitPlayer), faceAxis);
        vec3 Lworld = mat3(gbufferModelViewInverse) * Lview;
        float faceNdotL = max(dot(faceNormal, Lworld), 0.0);

        float distanceMask = 1.0 - smoothstep(40.0, 48.0, waterDistance);
        float daylight = smoothstep(0.025, 0.24, vSunElevation);
        float dryWeather = 1.0 - clamp(rainStrength, 0.0, 1.0);
        float waterSkyLight = smoothstep(0.22, 0.92, lightCoord.y);
        float lightMask = submerged * distanceMask * daylight * dryWeather * waterSkyLight *
                          exteriorSurfaceGate * overworld *
                          causticFaceMask(faceAxis, faceSign, faceNdotL, waterColumn);
#ifdef CLOUD_SHADOW_ENABLE
        // Caustics dim under cloud shadows (the value computed once for this water fragment).
        lightMask *= cloudShadow;
#endif
        // Lines fade over CAUSTIC_FULL_DEPTH..CAUSTIC_FADE_DEPTH; the mosaic fades 1.5x slower.
        float lineMask = lightMask * (1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, waterColumn));
        float mosaicMask = lightMask * (1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH * 1.5, waterColumn));
#ifdef CAUSTICS_DEBUG
        bool evaluateCaustics = true;
#else
        bool evaluateCaustics = mosaicMask > 0.0005;
#endif
        if (evaluateCaustics) {
            CausticSample pattern = causticPattern(faceCoord, causticFaceSeed(faceAxis, faceSign));
            float receiverShadow = 1.0;
#ifndef CAUSTICS_DEBUG
            // With the mosaic off and CONTRAST at 1, calm floor pixels skip the shadow fetch.
            if (pattern.level > 0 || CONTRAST < 0.999 || MOSAIC_STRENGTH > 0.0)
#endif
            {
                // Walls test the water half a block in front of them: a wall facing away
                // from the sun is behind its own block in the light's view.
                float shadowOffset = faceAxis == 1 ? 0.02 : 0.5;
                receiverShadow = singleReceiverShadow(hitPlayer + faceNormal * shadowOffset, faceNormal, faceNdotL);
            }
            // Red is absorbed first, so deeper floors and walls turn bluer.
            vec3 absorption = exp(-max(waterColumn, 0.0) * ABSORPTION_STRENGTH * 0.08 * vec3(2.5, 1.0, 0.45));
            vec3 light = causticLevelColor(pattern.level) * absorption *
                         (lineMask * receiverShadow * CAUSTICS_STRENGTH);
            float mosaicTone = pattern.mosaic * mosaicMask * receiverShadow;
            // Half-strength screen keeps the floor texture readable under bright lines.
            gCausticLight = vec4(light, 0.5 * clamp(dot(light, vec3(1.0 / 3.0)), 0.0, 1.0) - mosaicTone);
#if defined(CAUSTICS_DEBUG) && CAUSTICS_DEBUG_MODE != 15
            causticsDebug = causticDebugView(faceAxis, faceCoord, pattern, waterColumn, submerged, receiverShadow, light);
#endif
        }
    }
#elif defined(TERRAIN_LAYER) && defined(CAUSTICS_UNDERWATER_FLOOR)
    // Camera-underwater route on terrain, using the exact geometric normal. The terrain pass
    // cannot see the water surface, so its height comes from the sky light at the eye
    // (vclWaterSurfaceY, shaders.properties): in an open water column the sky light drops one
    // level per block of water. Surfaces at or above that height (shore blocks, the world seen
    // through the surface from below) get nothing, and so do faces touching air under the open
    // sky (sky light 15); the water surface itself is never touched (water program). Same
    // pattern, colours, face projection, depth fade and absorption as the outside route, before
    // the underwater fog at the end of this function.
    if (isEyeInWater == 1 && overworld > 0.5) {
        float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
        float surfaceY = vclWaterSurfaceY;
        // Fallbacks: the custom uniform did not load, or no sky light reaches the eye in an ocean.
        if (abs(surfaceY) < 0.001) surfaceY = float(UNDERWATER_SEA_LEVEL) + 0.889;
#ifdef BIOME_AMBIENCE
        if (eyeBrightness.y < 8 && (bfOcean + bfWarmOcean) * bfScale > 0.5) surfaceY = float(UNDERWATER_SEA_LEVEL) + 0.889;
#endif
        float cameraDepth = surfaceY - cameraY;
        float receiverDepth = surfaceY - (cameraY + vPlayerPosition.y);
        // Crossing the surface: a short fade tied to the camera depth (the outside route fades
        // out the same way as the eye nears the surface from above), so nothing pops.
        float surfaceFade = smoothstep(0.05, 0.40, cameraDepth);
        float belowSurface = smoothstep(0.0, 0.10, receiverDepth);
        float notInAir = 1.0 - smoothstep(14.55, 14.95, lightCoord.y * 16.0 - 0.5);
        vec3 faceAbs = abs(vWorldNormal);
        int faceAxis = faceAbs.y >= max(faceAbs.x, faceAbs.z) ? 1 : (faceAbs.x >= faceAbs.z ? 0 : 2);
        float faceSign = (faceAxis == 0 ? vWorldNormal.x : (faceAxis == 1 ? vWorldNormal.y : vWorldNormal.z)) >= 0.0 ? 1.0 : -1.0;
        vec3 faceNormal = causticFaceNormal(faceAxis, faceSign);
        vec2 faceCoord = causticFaceCoord(causticWrapWorld(vPlayerPosition), faceAxis);
        vec3 Lworld = mat3(gbufferModelViewInverse) * Lview;
        float faceNdotL = max(dot(faceNormal, Lworld), 0.0);
        // No caustics beyond the underwater visibility (the vanilla water fog distance).
        float distanceMask = 1.0 - smoothstep(min(32.0, 0.55 * fogEnd), min(40.0, 0.85 * fogEnd), vViewDistance);
        float skyLight = smoothstep(0.18, 0.88, lightCoord.y);
        float daylight = smoothstep(0.025, 0.24, vSunElevation);
        float dryWeather = 1.0 - clamp(rainStrength, 0.0, 1.0);
        float causticMask = surfaceFade * belowSurface * notInAir * distanceMask * skyLight * daylight * dryWeather *
                            causticFaceMask(faceAxis, faceSign, faceNdotL, max(receiverDepth, 0.0)) * UNDERWATER_CAUSTIC_STRENGTH;
#ifdef CLOUD_SHADOW_ENABLE
        causticMask *= cloudShadow;
#endif
        // Deeper = dimmer: lines over CAUSTIC_FULL_DEPTH..CAUSTIC_FADE_DEPTH, the mosaic 1.5x slower.
        float lineMask = causticMask * (1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, receiverDepth));
        float mosaicMask = causticMask * (1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH * 1.5, receiverDepth));
#ifdef LIGHT_DEBUG
#if LIGHT_DEBUG_MODE == 13
        // Height against the estimated surface: blue below (darker deeper), red above, white
        // line at the surface.
        gUnderwaterDebug = receiverDepth > 0.0 ? vec3(0.1, 0.35, 1.0) * (1.0 - 0.8 * clamp(receiverDepth / 16.0, 0.0, 1.0)) : vec3(1.0, 0.2, 0.1);
        gUnderwaterDebug = mix(gUnderwaterDebug, vec3(1.0), 1.0 - smoothstep(0.0, 0.08, abs(receiverDepth)));
#elif LIGHT_DEBUG_MODE == 15
        gUnderwaterDebug = vec3((1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, receiverDepth)) * belowSurface * notInAir * surfaceFade);
#endif
#endif
#ifdef CAUSTICS_DEBUG
        bool evaluateCaustics = true;
#else
        bool evaluateCaustics = mosaicMask > 0.0005;
#endif
        if (evaluateCaustics) {
            CausticSample pattern = causticPattern(faceCoord, causticFaceSeed(faceAxis, faceSign));
            float receiverShadow = 1.0;
#ifndef CAUSTICS_DEBUG
            if (pattern.level > 0 || CONTRAST < 0.999 || MOSAIC_STRENGTH > 0.0)
#endif
            {
                float shadowOffset = faceAxis == 1 ? 0.02 : 0.5;
                receiverShadow = singleReceiverShadow(vPlayerPosition + faceNormal * shadowOffset, faceNormal, faceNdotL);
            }
            // Red is absorbed first on the way down, so deeper floors and walls turn bluer.
            vec3 absorption = exp(-max(receiverDepth, 0.0) * ABSORPTION_STRENGTH * 0.08 * vec3(2.5, 1.0, 0.45));
            vec3 light = causticLevelColor(pattern.level) * absorption * (lineMask * receiverShadow * CAUSTICS_STRENGTH);
            float floorScale = 0.5 * clamp(dot(light, vec3(1.0 / 3.0)), 0.0, 1.0) - pattern.mosaic * mosaicMask * receiverShadow;
            // Opaque receiver: apply the same screen blend and mosaic directly.
            color = color * (1.0 - floorScale) + light;
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 17
            gUnderwaterDebug = light * 2.0 + vec3(0.0, 0.0, max(-floorScale, 0.0) * 4.0);
#endif
#ifdef CAUSTICS_DEBUG
            causticsDebug = causticDebugView(faceAxis, faceCoord, pattern, receiverDepth, belowSurface, receiverShadow, light);
#endif
        }
    }
#endif
#endif

    // Update 3, underwater (camera in water): the absorption fog replaces the previous liquid haze
    // (at most 20 % of the vanilla fog colour, which left the water almost transparent). final applies
    // it once per pixel by depth (cheaper than here, where overdraw would pay it several times); here
    // the previous haze is skipped and the surface seen from below is drawn.
    bool uwFogHere = false;
#ifdef UNDERWATER_AMBIENCE
    uwFogHere = isEyeInWater == 1;
#if defined(UNDERWATER_DEBUG) && UNDERWATER_DEBUG_MODE == 9
    uwFogHere = uwFogHere && gl_FragCoord.x >= 0.5 * viewWidth;   // split view: left half without
#endif
    if (uwFogHere) {
        float uwDistance = length(vViewPosition);
        vec3 uwViewDir = vPlayerPosition / max(uwDistance, 1.0e-4);
#if defined(WATER_LAYER) && defined(SURFACE_FROM_BELOW)
        // The surface seen from below (the top face's underside): a luminous ceiling with the vanilla
        // wave streaks, and the Snell window. Faded in with the crossing like the fog. A horizontal water
        // face above the camera is seen from below whatever its vertex normal says (vanilla gives the
        // backward top face the normal +Y; a mesher that derives normals from the winding gives -Y).
        if (vIsFluid > 0.5 && abs(vWorldNormal.y) > 0.5 && uwViewDir.y > 0.0) {
            vec4 surface = uwSurfaceFromBelow(uwViewDir, dot(rawTexel.rgb, vec3(0.2126, 0.7152, 0.0722)), lightCoord.y);
            color = mix(color, surface.rgb, vclUwFade);
            texel.a = mix(texel.a, surface.a, vclUwFade);
        }
#endif
    }
#endif
#if !defined(ATMOSPHERIC_HAZE)
    // Preserve the pack's original fog when analytic haze is disabled (the Ambience fog in
    // final replaces it in the overworld, so it is never applied twice).
    float distanceToCamera = vViewDistance;
    float fogSpan = max(fogEnd - fogStart, 1.0);
    float haze = smoothstep(fogStart + fogSpan * 0.42, fogEnd, distanceToCamera) * 0.20 * overworld;
#ifdef AMBIENCE_FOG
    haze = 0.0;
#endif
    if (uwFogHere) haze = 0.0;
    color = mix(color, fogColor, haze);
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 16 && defined(TERRAIN_LAYER)
    gUnderwaterDebug = vec3(1.0 - (isEyeInWater == 1 ? haze : 1.0));
#endif
#else
    // The final analytic haze intentionally skips underwater cameras; keep vanilla water/lava fog here
    // (lava and powder snow always; water when the underwater ambience is off).
    if (isEyeInWater != 0 && !uwFogHere) {
        float distanceToCamera = vViewDistance;
        float fogSpan = max(fogEnd - fogStart, 1.0);
        float liquidFog = smoothstep(fogStart + fogSpan * 0.42, fogEnd, distanceToCamera) * 0.20;
        color = mix(color, fogColor, liquidFog);
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 16 && defined(TERRAIN_LAYER)
        // Underwater fog transmittance (1 = no fog): the caustics above were applied before it.
        gUnderwaterDebug = vec3(isEyeInWater == 1 ? 1.0 - liquidFog : 0.0);
#endif
    }
#endif
#if defined(LIGHT_DEBUG) && defined(TERRAIN_LAYER)
    // Terrain-side diagnostics, written as the colour (final shows them without grading).
#if LIGHT_DEBUG_MODE == 7 && defined(SHADOW_COLORS)
    color = vec3(sunStrengthEff);
#elif LIGHT_DEBUG_MODE == 9 && defined(SHADOW_COLORS)
    color = vAmbShadowLight;
#elif LIGHT_DEBUG_MODE == 10 && defined(SHADOW_COLORS)
    // Red = shadow cast by an entity, blue = cast by terrain (shadow map), black = lit.
    color = mix(vec3(0.15, 0.35, 1.0), vec3(1.0, 0.2, 0.1), entityCast) * ((1.0 - mapShadow) * step(0.05, litBySky));
#elif LIGHT_DEBUG_MODE == 13 || LIGHT_DEBUG_MODE == 15 || LIGHT_DEBUG_MODE == 16 || LIGHT_DEBUG_MODE == 17
    color = gUnderwaterDebug;
#endif
#endif
#if defined(TERRAIN_LAYER) && defined(GI_DEBUG) && (GI_DEBUG_MODE == 10 || GI_DEBUG_MODE == 16 || GI_DEBUG_MODE == 17)
    // Update 5 diagnostics written by the terrain program: 10 = where the light's colour comes from the ramp,
    // 16 = the static ambient alone (x 30), 17 = the ramped block light (the light, not the surface).
    color = gGiTerrainDebug;
#endif
#if defined(TERRAIN_LAYER) && defined(NETHER_DEBUG) && (NETHER_DEBUG_MODE == 4 || NETHER_DEBUG_MODE == 5)
    // Update 3 Nether diagnostics written by the terrain program (final shows them as they are):
    // 4 = the emissive mask of the boost, 5 = the block light hue (x 0.5) where block light counts.
    color = vec3(0.0);
#ifdef NETHER_WARM_LIGHT
#if NETHER_DEBUG_MODE == 4
    color = vec3(netherEmissive * netherHere);
#else
    color = netherBlockLightHue(lightCoord.x) * (0.5 * netherBlockShare);
#endif
#endif
#endif
#if defined(TERRAIN_LAYER) && defined(END_DEBUG) && (END_DEBUG_MODE == 6 || END_DEBUG_MODE == 7)
    // Update 3 End diagnostics written by the terrain program: 6 = the flash light term alone (x 4),
    // 7 = the flash shadow term (white = lit by the flash, black = in its shadow).
    color = vec3(0.0);
#ifdef END_FLASHES
#if END_DEBUG_MODE == 6
    color = flashLight * 4.0;
#else
    color = vec3(flashShadow);
#endif
#endif
#endif
#if defined(BLOCK_DEBUG) && defined(BLK_ACTIVE) && BLOCK_DEBUG_MODE != 16
    // Update 2B diagnostics on block surfaces (written as the colour; final grades them like the
    // scene). Mode 16 is the before/after split handled above.
    if (BLK_SURFACE) {
        float dbgWrap = blkWrap(blkNdotL);
#if BLOCK_DEBUG_MODE == 1
        color = blkNormal * 0.5 + 0.5;
#elif BLOCK_DEBUG_MODE == 2
        color = vec3(max(blkNdotL, 0.0));
#elif BLOCK_DEBUG_MODE == 3
        color = mix(vec3(0.10, 0.10, 0.16), vec3(1.00, 0.85, 0.40), smoothstep(0.0, 0.05, blkAmount.z * dbgWrap * blkVisibility * blkSkyWeight));
#elif BLOCK_DEBUG_MODE == 4
        color = vec3(blkAmount.y * blkVisibility * dbgWrap * blkSkyWeight);
#elif BLOCK_DEBUG_MODE == 5
        color = vec3(blkAmount.x * mix(BLK_HEMI_GROUND, 1.0, blkNormal.y * 0.5 + 0.5) * 0.5);
#elif BLOCK_DEBUG_MODE == 6
        color = vColor.rgb;
#elif BLOCK_DEBUG_MODE == 7
        int dbgKind = int(blkKindShape + 0.5) / 32;
        int dbgType = int(BLK_KIND_A[dbgKind].x + 0.5);
        vec3 dbgTypeColor = dbgType == 1 ? vec3(1.00, 0.85, 0.35) : (dbgType == 2 ? vec3(0.40, 0.85, 0.30) :
                            (dbgType == 3 ? vec3(0.30, 0.70, 1.00) : (dbgType == 4 ? vec3(0.10, 0.60, 0.40) : vec3(0.08))));
        color = dbgTypeColor * (dbgType == 0 ? 1.0 : 0.55 + 0.45 * fract(float(dbgKind) * 0.618));
#elif BLOCK_DEBUG_MODE == 8
        color = gBlkDebugId;
#elif BLOCK_DEBUG_MODE == 9
        color = vec3(gBlkDebugD);
#elif BLOCK_DEBUG_MODE == 10
        color = vec3(gBlkDebugRaw);
#elif BLOCK_DEBUG_MODE == 11
        color = vec3(gBlkDebugLevel);
#elif BLOCK_DEBUG_MODE == 12
        color = vec3(gBlkDebugFoot);
#elif BLOCK_DEBUG_MODE == 13
        color = vec3(gBlkDebugDist);
#elif BLOCK_DEBUG_MODE == 14
        color = vec3(gBlkDebugSheen * 4.0);
#elif BLOCK_DEBUG_MODE == 15
        color = (min(blkAdd, max(vec3(1.15) - base, vec3(0.0))) + base * blkSheen / (1.0 + blkSheen)) * 2.0;
#elif BLOCK_DEBUG_MODE == 17
        color = vec3(blkFace * 0.5);
#endif
    }
#endif
    return vec4(color, texel.a);
}
