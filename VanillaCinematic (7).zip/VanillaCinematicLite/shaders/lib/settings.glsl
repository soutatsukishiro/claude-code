// Shared Iris options. Disabled Boolean options remove their shader code at compile time.
// Iris rule: every option is declared on exactly ONE line ("#define X" or "//#define X").
// A second, conflicting declaration of the same name makes Iris drop the option (it then
// cannot be toggled from the menu or by a preset), so there are no duplicate lines here.
#define BLOOM // Quarter-resolution soft glow
#define WET_GROUND // Rain-reactive exposed ground
#define SHALLOW_WATER_LIGHTING // Existing shallow-water shafts and surface sparkle
#define PIXEL_CAUSTICS // Pixel-snapped Voronoi caustics on submerged surfaces
#define CAUSTICS_WALLS // Caustics on submerged side faces (walls, pillars, cliffs)
#define CAUSTICS_SCREEN_BLEND // Screen-style blend and mosaic via premultiplied water output; off = plain additive
#define WATER_DEPTH_TINT // Clear light-teal shallows that turn deep blue and opaque with depth
#define WATER_SKY_REFLECTION // Tier 1: analytic sky/cloud reflection with Fresnel and distance blend (no texture fetch)
#define WATER_SSR // Tier 2: screen-space planar reflection of terrain and clouds in final (needs Tier 1)
#define WATER_REFLECTION_IMPROVEMENT // Reflection add-on: palette sky, real cloud cells, fog-aware screen reflection, shallow/rain/night handling
//#define REFLECTION_DEBUG // Diagnostic views for the water reflection system
#define WAVE_LIGHTING // Soft sun/moon light on the vanilla animated wave texels
//#define WAVE_DEBUG // Diagnostic views for the wave lighting
//#define CAUSTICS_DEBUG // Diagnostic views for the caustic receiver
#define CAUSTICS_UNDERWATER_FLOOR // Caustics on the submerged floor and walls while the camera is underwater (never on the surface seen from below)
#define ATMOSPHERIC_HAZE // Analytic distance and height haze in final (used where the Ambience fog is off)
#define ATMOSPHERIC_GRADE // Warm sunlight, cool shade, and restrained vibrance
#define ATMOS_TONE_MAP // Existing cinematic shoulder and highlight finish
#define ATMOSPHERIC_PARTICLES // Sparse screen-space pollen motes
#define LEAF_TRANSLUCENCY // Subtle sun back-light on mapped leaves
#define ENTITY_SHADOWS // Render entities, block entities, and the player into the shadow map
#define PIXEL_SHADOWS // Stabilized world-grid position and nearest shadow texel
#define DIRECTIONAL_LIGHTING // Directional face lighting on blocks: the face turned to the sun (moon at night) is brighter, faces turned away get the sky ambient (Update 2B); off = the previous flat faces
#define PREVIOUS_SUN_LIFT // The previous small directional sun/moon lift: on water, the player, mobs and particles; on blocks only while DIRECTIONAL_LIGHTING is off
#define SUBSURFACE_TRANSMISSION // Back-light tint for leaves, plants, and translucent blocks
#define EMISSIVE_BLOCKS // Texture-masked boost for tagged terrain emitters
#define EMISSIVE_GLOW // Vibrant Visuals glow around light sources: glowing mob eyes (enderman, spider, phantom, dragon), End crystals and glowing mobs, light-emitting blocks and held or dropped light-emitting items
#define SKY_GRADE // View-direction sky gradient and color finish in final (used where the Ambience colours are off)
#define ATMOS_VIGNETTE // Subtle final-pass edge falloff
#define PROCEDURAL_STARS // Sparse sky-anchored stars in the final sky treatment
//#define PIXEL_WATER_SPARKLES // Sparse world-grid glints on the water surface
//#define ATMOS_DEBUG // Diagnostic views for sky, haze, biome blend, and bloom
//#define VV_DEBUG // Nine diagnostic views; extra MRT code exists only in this mode

// Ambience: environment colours, clouds, cloud shadows and layered fog.
#define AMBIENCE_COLORS // Time-of-day and biome palettes for sky, fog, clouds and terrain light; the sky meets the fog at the horizon
#define AMBIENCE_CLOUDS // Soft sky-tinted cloud lighting (gbuffers_clouds); off = vanilla cloud colours
#define AMBIENCE_FOG // Layered height fog with banks, sun scattering and distance layering (replaces the distance haze)
#define FOG_SCATTERING // Brighter, warmer haze toward the sun; cooler opposite it (sky and fog together)
#define FOG_ON_WATER // The Ambience fog also covers water at its distance; off = water keeps the previous haze
//#define FOG_BANDED_LOOK // Quantize the fog amount into a few dithered steps
#define CLOUD_SHADOW_ENABLE // Soft drifting shadows of the vanilla clouds on the ground
#define VANILLA_CLOUD_CELLS // Cloud shadows/reflection read the vanilla cloud cells (shaders/textures/clouds.png), aligned with the visible clouds; off = procedural cells
//#define HIDE_VANILLA_CLOUDS // Hide the vanilla clouds (use when VANILLA_CLOUD_CELLS is off)
//#define AMBIENCE_DEBUG // Diagnostic views for fog, sky, clouds, cloud shadows, reflections and grading

// Biome ambience: sky, fog and cloud colours and fog character per biome family (camera biome).
#define BIOME_AMBIENCE // Per-biome sky, fog and cloud colours and fog character, blended once per frame on the CPU
#define BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION // The water's sky reflection and its fog-aware screen reflection follow the biome
#define BIOME_PRECIPITATION // Biomes without rain (desert, savanna, badlands) keep a clear sky in rain; snowfall is brighter than rain
//#define BIOME_DESERT_DUST // Slight extra dust near the ground in deserts, badlands and savanna
//#define BIOME_DEBUG // Diagnostic views: family weights, palette swatches, horizon match, density, transition, palette table

// Sun, sky glow and soft rays: analytic and deterministic (no noise, no jitter, no shadow map).
#define SUN_GLOW // Analytic glow around the sun and moon: thin bloom, mid glow and a faint wide halo
#define SUN_RAYS // Gentle uniform rays: a slow, soft angular modulation of the mid glow (no noise)
#define SUN_VEIL // Warm light veil over terrain and clouds near the sun, scaled by how much of the sun is visible
#define SUN_EDGE_RIM // Thin warm rim and soft bleed on block edges turned to the sun, right around it (sun-directed depth taps)
#define SUN_SHAFTS // Very faint shafts through gaps (leaves, between blocks, between clouds): quarter-resolution radial march, no noise
//#define SUN_DEBUG // Diagnostic views for the sun glow, veil, rim, sky, horizon match, fog and dither

// Update 1: clouds hide the sun, dynamic shadow colours.
#define CLOUDS_BLOCK_SUN // Clouds hide the sun, moon and stars (opaque body, distance fade by colour, soft glow around a hidden sun); off = the previous translucent clouds
#define SHADOW_COLORS // Shadows take the hue of the ambient sky light and react to the surface (terrain receivers)
#define ENTITY_SHADOW_FLAG // Player and mob shadows get their own strength (shadow_entities writes an entity flag into shadowcolor0); off = one rule for all shadows
//#define LIGHT_DEBUG // Diagnostic views for the sun rays, cloud occlusion, shadow colours and underwater caustics

// Update 2A: the moon gets the sun's light system in cool night colours (one light source per frame).
#define MOON_RAYS // Moon glow and halo in cool night colours, faded by phase, weather and clouds; enables the moon veil, rim and shafts below; off = the previous moon glow
#define MOON_VEIL // Faint cool veil over terrain and clouds near the visible moon
#define MOON_EDGE_RIM // Faint cool rim on block edges turned to the moon (the sun rim's depth taps)
#define MOON_SHAFTS // Very faint cool shafts through gaps toward the moon (the sun shafts' pass and buffer; one source per frame)
//#define MOON_DEBUG // Diagnostic views for the moon light, the sun/moon handover and the sun identity check

// Update 2B: micro-detail lighting on blocks (the face lighting is DIRECTIONAL_LIGHTING above).
#define BLOCK_MICRO_DETAIL // Micro-detail light on selected blocks: only small details catch the light (sand grains, obsidian speckles, lit leaf texels, furrows), from the vanilla texture; replaces the plastic gloss on blocks
#define GLITTER_BLOCKS // Glitter: sand, red sand, snow, powder snow, gravel, calcite, diorite, deepslate, soul sand and soil (a few grains catch the sun)
#define SHEEN_BLOCKS // Sheen: farmland furrows, clay, mud, grass blocks, moss, dirt, stone, cobblestone, andesite, logs, planks, mushrooms (the lighter texels catch the sun)
#define GLOSS_BLOCKS // Gloss: ice, obsidian, amethyst, blackstone, basalt, quartz and polished stone, prismarine, glass, metal blocks and ores (sharp glints, faint sky reflection)
#define FOLIAGE_SPARKLE // Foliage: leaves, vines, glow lichen, moss carpet, lily pads, mangrove roots, grass, ferns and flowers (sun-caught texels; static, no wind)
//#define BLOCK_DEBUG // Diagnostic views for the face lighting and the micro-detail

// Patch 2.1, part B: stray pixels in the sky.
#define SKY_PIXEL_FIX // Removes the stray dark pixels in the daytime sky (they were the fake birds of GOLDEN_FAKE_BIRDS) and guards the sky against invalid values (NaN, infinity); off = the previous sky, birds included
//#define SKY_DEBUG // Diagnostic views for the sky: layers, stars, invalid values, outliers, sky mask, quarter-resolution buffer

// Patch 2.1, part A: adaptive eyes (auto exposure in final, driven by the light at the camera).
#define ADAPTIVE_EYES // Eye adaptation: the view slowly brightens in caves, interiors and at night, a short soft over-bright moment when you step into the light, a gentle punch in very bright places; normal outdoor daylight is unchanged
#define ADAPT_SCENE_LUMA // Refine the adaptation with the measured brightness of the scene (16 fixed taps, a one-pixel pass); off = the light at the camera only
#define ADAPT_LOCAL_LIFT // Dark pixels get a little more lift than bright ones (a soft toe), so cave walls become readable without blowing out a bright window
#define ADAPT_HIGHLIGHT_PROTECTION // Bright areas roll off softly while the view is brightened, so a daylight window keeps its detail instead of clipping to white
//#define ADAPT_DEBUG // Diagnostic views for the adaptive eyes

// Update 3: the three special environments (each part runs only in its environment).
#define UNDERWATER_AMBIENCE // Underwater (camera in water only): absorption fog (red first, then green, then blue), darker water with depth, biome water colour, brighter toward the surface and the light; off = the previous almost transparent water
#define UNDERWATER_SHAFTS // Soft light shafts from the surface (analytic, nearly free): lit and dark regions under the open sky by day
#define UNDERWATER_SHAFTS_TIER2 // Shadow-aware shafts: a quarter-resolution march with the shadow map, so terrain and floating blocks cut dark gaps (needs UNDERWATER_SHAFTS)
#define SURFACE_FROM_BELOW // The water surface seen from below is a bright blue ceiling with the vanilla wave streaks (not transparent, not a mirror)
#define SNELL_WINDOW // The surface from below: the sky shows through a window of about 48.6 degrees overhead, a darker mirror outside it (needs SURFACE_FROM_BELOW)
//#define UNDERWATER_DEBUG // Diagnostic views for the underwater ambience
#define NETHER_AMBIENCE // Nether: dense biome-tinted fog (one colour function for the fog, the far distance and the ceiling)
#define NETHER_WARM_LIGHT // Nether: warm block light (deep red at low light, orange near sources; teal in soul sand valleys) and brighter emissive blocks
#define NETHER_FLICKER // Nether: a very subtle smooth flicker of the block light (NETHER_LIGHT_FLICKER)
#define LAVA_SEA_HAZE // Nether: warmer, brighter haze near the lava sea level (Y = 31)
//#define NETHER_DEBUG // Diagnostic views for the Nether ambience
#define END_AMBIENCE // The End: calm dark violet sky and fog between flashes, a cool violet ambient light, distant islands fading into purple haze
#define END_FLASHES // The End: the vanilla End flash (Minecraft 26.3) as Vibrant Visuals shows it: a purple directional light (#E45DFF) on surfaces, violet fog that lights up toward the flash, in the sky and in the air in front of the scene (no flash sprite); synced with the game's own flash and its sound
#define FLASH_SHADOWS // The End: flash shadows, cast opposite the flash (Iris orients the shadow map along the flash, End only)
#define END_FLASH_SHAFTS // The End: soft purple shafts through gaps toward the flash (the sun shafts' pass, End only; replaced by the flash fog's own shadows while FLASH_FOG_SHADOWS is on)
#define FLASH_FOG_SHADOWS // The End: the flash fog is volumetric: things between you and the flash keep the fog in front of them dark (screen-space volumetric shadow at quarter resolution, no shadow map; on LOW it adds one quarter-resolution pass in every dimension, a copy outside an End flash)
#define FLASH_GLINTS // The End: the flash lights the micro-detail of obsidian, end stone and metals (violet glints)
#define FLASH_PHOTOSENSITIVITY_LIMIT // Caps the flash's double pulse and its peak (no strobing); off = the full FLASH_PULSE
//#define END_DEBUG // Diagnostic views for the End ambience and the flash

// Golden-hour screenshot match. Each effect is independently compiled out when disabled.
#define GOLDEN_TARGET_SKY // Golden-hour zenith/horizon palette blend
#define GOLDEN_TARGET_HAZE // Extra amber distance haze and a cheap sun-facing phase term (only where the Ambience fog is off)
#define GOLDEN_TARGET_GRADE // Warm low-sun grade and gentle shadow lift
#define GOLDEN_TARGET_BACKLIGHT // Additional warm foliage/grass/flower edge light
#define GOLDEN_BLOCKY_BLOOM // Pixelate the existing quarter-resolution bloom source
#define GOLDEN_SOFT_VIGNETTE // Optional target-style vignette contribution
#define GOLDEN_FAKE_BIRDS // Procedural screen-space bird silhouettes; visual fake, not entities
//#define TARGET_DEBUG // Golden-hour diagnostics (compiled out when disabled)

#define GLOSS_STRENGTH 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.38 0.45] Plastic gloss strength (player, mobs, items; no longer on blocks)
#define HIGHLIGHT_SIZE 28 // [12 16 20 24 28 32 36 42 48] Highlight size (higher values make a tighter highlight)
#define GLOSS_FRESNEL 0.07 // [0.00 0.03 0.05 0.07 0.09 0.12 0.16 0.20] Fresnel rim of the plastic gloss (player and mobs)
#define PLASTIC_GLOSS_MIX 1.00 // [0.00 0.25 0.50 0.75 1.00] Blend out the original plastic gloss layer (player, mobs, items; no longer on blocks)
#define SHADOW_QUALITY 1 // [1 2 3] Shadow filtering: 1 tap, 4 taps, or 8 taps
#define SHADOW_PIXEL_GRID 16 // [8 16 32] World texels per block for stabilized shadow receivers
#define DIRECTIONAL_LIGHT_STRENGTH 0.08 // [0.00 0.03 0.05 0.08 0.12 0.18] Extra light on a block face turned straight to the sun, over the flat light (the brightest face)
#define WATER_REFLECTION_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Master water reflectivity multiplier
#define THIN_TRANSMISSION_STRENGTH 0.07 // [0.00 0.03 0.05 0.07 0.11 0.16] Back-light through thin materials
#define EMISSIVE_STRENGTH 0.42 // [0.00 0.15 0.28 0.42 0.60 0.85] Tagged emitter lift
#define EMISSIVE_THRESHOLD 0.58 // [0.30 0.42 0.58 0.70 0.82] Texture brightness needed for emissive lift
#define EMISSIVE_GLOW_STRENGTH 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50 2.00] Glow around light sources, eyes, crystals and light-emitting items (1 = the enderman eyes of your reference)
#define RAY_INTENSITY 0.18 // [0.00 0.05 0.10 0.18 0.22 0.30 0.40] Existing shallow-water shaft intensity
#define RAY_LENGTH 0.55 // [0.20 0.35 0.45 0.55 0.62 0.75 0.90] Existing shallow-water shaft reach
#define CAUSTICS_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50] Caustic intensity; 1.0 = measured reference swatches
#define VORONOI_QUALITY 2 // [1 2] Cell search: 1 = 2x2 (LOW), 2 = full 3x3
#define TEXELS_PER_BLOCK 16 // [8 16 32] Caustic texels per block; 16 matches vanilla textures
#define CELL_SIZE_TEXELS 8 // [6 7 8 10 12 14 16] Voronoi point spacing in texels; 8 matches the measured reference
#define CELL_CURVE 2.50 // [0.00 1.00 1.50 2.00 2.50 3.00 4.00] Smooth warp in texels that bends straight cell edges into curves
#define CELL_JITTER 0.85 // [0.30 0.50 0.60 0.75 0.85 1.00] Point randomness inside each cell; lower = more regular
#define LINE_WIDTH 0.90 // [0.75 0.90 1.00 1.25 1.50 2.00] Line width in texels (constant, measured from the cell bisector)
#define EDGE_HALO 0.35 // [0.00 0.25 0.35 0.45 0.65] One-sided dim halo next to lines; 0 = off
#define EDGE_DROPOUT 0.05 // [0.00 0.04 0.05 0.08 0.12 0.20] Share of 3-texel line stretches left as gaps
#define EDGE_TWINKLE 1.0 // [0.0 0.5 1.0 2.0 3.0] Per-edge brightness changes per second; 0 = static
#define ISOLATED_PIXELS 0.010 // [0.000 0.005 0.010 0.020 0.040] Chance of a lone bright texel near the lines
#define PEAK_AMOUNT 0.30 // [0.00 0.15 0.30 0.45 0.60 1.00] Share of the brightest stretches turned into the cream peak
#define WARMTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Peak colour: cool white to warm cream
#define CONTRAST 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00] 1 = calm floor gets no line light; lower adds a faint fill
#define MOSAIC_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Soft floor tone patches (-10 % / -3 % / +4 % at 1.0)
#define MOSAIC_CELL_SIZE 3 // [2 3 4] Mosaic patch size in texels
#define STEPS_PER_SECOND 8 // [2 4 6 8 10 12] Flip-book animation steps per second
#define CELL_ORBIT 2 // [0 1 2 3] Radius in texels of each point's stepped orbit; 0 = no deformation
#define DRIFT_SPEED 0.5 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0] Slow global drift in texels per second
#define DRIFT_DIRECTION 45 // [0 45 90 135 180 225 270 315] Global drift direction in degrees
#define CAUSTIC_FULL_DEPTH 2.0 // [0.0 1.0 2.0 3.0 4.0] Full-strength caustics through this depth in blocks
#define CAUSTIC_FADE_DEPTH 11.0 // [6.0 8.0 9.0 10.0 11.0 12.0 14.0] Lines fade to zero at this depth; the mosaic at 1.5x
#define WALL_STRENGTH 0.45 // [0.00 0.25 0.35 0.45 0.55 0.70 0.85 1.00] Wall caustics relative to the floor
#define WALL_DEPTH_FADE 6.0 // [2.0 4.0 6.0 8.0 10.0 12.0] Wall caustics fade to zero this many blocks below the surface
#define WALL_SUN_FACTOR 0.65 // [0.00 0.25 0.50 0.65 0.80 1.00] Sun-facing weight on walls; 1 - value is the minimum
#define WAVE_LIGHT_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00 1.40 2.00] Overall sun light on wave crests; 0 = plain base water
#define DIFFUSE_AMOUNT 0.25 // [0.00 0.10 0.25 0.40 0.60] Soft wrap-diffuse light on crests facing the sun
#define GLINT_AMOUNT 0.35 // [0.00 0.15 0.35 0.50 0.75 1.00] Sun glint on crests (strong toward a low sun)
#define GLINT_SIZE 0.20 // [0.10 0.15 0.20 0.30 0.40] Glint roughness; larger = wider, softer sun path
#define CREST_CONTRAST 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] How many texture texels count as crests
#define CREST_LEVELS 3 // [2 3 4] Crest brightness levels including the unlit base
#define WAVE_NORMAL_STRENGTH 0.12 // [0.00 0.06 0.12 0.18 0.25] Pseudo-normal tilt from the wave texture
#define WAVE_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10] Luma / wave / crest raw / crest / normal / diffuse / glint / shadow+sky / crest light / split screen
#define FRESNEL_STRENGTH 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] Angle-based (Fresnel) water reflectivity
#define FAR_REFLECTIVITY 0.85 // [0.00 0.40 0.60 0.75 0.85 0.95] Reflectivity reached at REFLECT_FAR_DISTANCE
#define REFLECT_NEAR_DISTANCE 6 // [2 4 6 8 12 16] Horizontal distance (blocks) where the distance blend starts
#define REFLECT_FAR_DISTANCE 60 // [30 40 50 60 80 100 128] Horizontal distance (blocks) where it is complete
#define REFLECTION_BLUR 3 // [1 3 5] Vertical taps of the screen-space reflection (1 = sharp)
#define REFLECTION_STRETCH 2 // [1 2 3 4 6] Screen pixels between the vertical taps
#define REFLECTION_WOBBLE 1.0 // [0.0 0.5 1.0 1.5 2.0] Vertical wobble of the reflection driven by the vanilla wave texels
#define WATER_SSR_REFINE 1 // [1 2 3] Planar refinement steps of the screen-space reflection (3 = Tier 3 quality)
#define CLOUD_REFLECTION 0.25 // [0.00 0.15 0.25 0.35 0.50 0.75] Faint cloud reflection (Tier 1)
#define STREAK_CONTRAST 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] How strongly wave crests catch the reflection
#define STREAK_DISTANCE_FADE 0.60 // [0.00 0.30 0.60 0.80 1.00] Fade of the streaks into the haze at the far end
#define STREAK_LOD_BIAS 0.0 // [-1.0 -0.5 0.0 0.5 1.0] Mip bias for the streak mask; higher = calmer far streaks
#define HORIZON_BLEND 1.00 // [0.00 0.25 0.50 0.75 1.00] Fade of terrain and water into the sky colour at the render distance (previous haze)
#define REFLECTION_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12] Reflect dir / tier 1 / tier 2 / tier 2 valid / UV / Fresnel / distance / reflectivity / column / opacity / crest / before-after fog
#define SHALLOW_TINT 1 // [0 1 2 3] Shallow water colour (< ~2 blocks): vanilla biome / turquoise / light teal / clear cyan
#define NEAR_WATER_TINT 1 // [0 1 2 3] Water colour near the camera at normal depth: dark biome / deep blue / navy / teal blue
#define FAR_WATER_TINT 1 // [0 1 2 3] Water's own colour far away, under the reflection: fog colour / lavender blue / steel blue / teal grey
#define WATER_OPACITY_NEAR 0.30 // [0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60] Water opacity near the camera in shallow water
#define WATER_OPACITY_FAR 0.90 // [0.50 0.70 0.80 0.90 0.95 1.00] Water opacity reached at REFLECT_FAR_DISTANCE
#define ABSORPTION_STRENGTH 0.25 // [0.10 0.15 0.20 0.25 0.32 0.40 0.55] Per-block shift to deep tint/opacity; also caustic absorption
#define SPARKLE_AMOUNT 0.12 // [0.00 0.05 0.08 0.12 0.18 0.25 0.35] Water surface sparkle amount
#define HAZE_DENSITY 0.0020 // [0.0005 0.0010 0.0018 0.0020 0.0024 0.0025 0.0035 0.0050] Distance haze density (previous haze)
#define HAZE_HEIGHT_FALLOFF 0.025 // [0.000 0.010 0.025 0.040 0.060] Thin haze with altitude (previous haze)
#define WARM_COOL_STRENGTH 0.10 // [0.00 0.04 0.08 0.10 0.14 0.20] Sun and shade color split
#define VIBRANCE_STRENGTH 0.08 // [0.00 0.04 0.08 0.12 0.18 0.25] Safe green vibrance
#define BIOME_TINT_STRENGTH 0.22 // [0.00 0.08 0.16 0.22 0.32 0.45] Previous biome haze tint (only where the Ambience fog or colours are off)
#define TONE_SHOULDER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Existing cinematic shoulder strength
#define BLOOM_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.07 0.10 0.14] Bloom strength
#define BLOOM_THRESHOLD 0.72 // [0.45 0.60 0.72 0.82 0.92] Bloom cutoff
#define PARTICLE_AMOUNT 0.06 // [0.00 0.03 0.06 0.10 0.16 0.24] Screen-space pollen amount
#define LEAF_TRANSMISSION 0.08 // [0.00 0.03 0.06 0.08 0.12 0.18] Leaf back-light strength
#define VIGNETTE_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.065 0.08 0.12] Vignette strength
#define CAUSTICS_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15] Axis / texel grid / cell ids / F1 / edge / line raw / line / edge level / mosaic / levels / column / submerged / shadow / final / water flag
#define ATMOS_DEBUG_MODE 1 // [1 2 3 4 5 6] Sunlit / (removed rays: black) / fog / biome / sky / bloom
#define VV_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9] Sunlit / (removed rays: black) / fog / biome / shadow / emissive / material / water / bloom
#define SKY_QUALITY 2 // [1 2] Coarse or fine procedural star grid
#define SKY_GRADIENT_STRENGTH 0.32 // [0.00 0.16 0.28 0.32 0.42 0.48 0.55 0.64] Analytic sky blend strength (previous sky grade)
#define STAR_AMOUNT 0.35 // [0.00 0.15 0.22 0.25 0.35 0.45 0.50 0.55 0.75] Procedural star density

// Sun and sky glow sliders.
#define SUN_STYLE 0 // [0 1] 0 = vanilla square (exact vanilla size and pixel rings, brighter), 1 = soft round disc of the same area
#define SUN_GLOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Thin bloom hugging the sun and the mid glow
#define SUN_HALO_SIZE 0.30 // [0.15 0.20 0.30 0.40 0.55 0.70] Wide halo radius in radians (0.30 = about 17 degrees); also the falloff of the sun scattering in the haze
#define SUN_HALO_STRENGTH 0.10 // [0.00 0.05 0.10 0.20 0.30 0.45] Wide halo: the sky gets lighter around the sun (0.10 = the sun reference)
#define RAY_VARIATION 0.14 // [0.00 0.06 0.10 0.14 0.18 0.25] Soft ray lobes in the mid glow; 0 = perfectly round glow
#define VEIL_STRENGTH 0.30 // [0.00 0.10 0.20 0.30 0.45 0.60] Warm veil over terrain and clouds near the visible sun
#define RIM_STRENGTH 0.80 // [0.00 0.20 0.35 0.50 0.65 0.80 1.00] Warm rim on silhouette edges turned to the sun (0.80 = fitted to the reference rim)
#define RIM_REACH 1.50 // [0.50 0.75 1.00 1.25 1.50 2.00 2.50] Rim taps reach: 1.00 = 2 to 14 pixels at 1080p (scaled with the resolution); 1.50 = the reference bleed; higher = wider soft bleed
#define RIM_TAPS 4 // [3 4 6] Sun-directed depth taps per rim pixel: 3 (LOW), 4, 6 (finest)
#define SHAFT_STRENGTH 0.10 // [0.00 0.05 0.10 0.15 0.20 0.30 0.45] Shafts through gaps; low = barely visible, like the reference
#define SHAFT_LENGTH 0.30 // [0.15 0.20 0.30 0.40 0.50] March length as a share of the distance to the sun (capped at half of it in screen heights)
#define SHAFT_SOFTNESS 0.50 // [0.25 0.35 0.50 0.70 1.00] Width of the Gaussian-like sample weights; higher = longer, softer shafts
#define SHAFT_SAMPLES 12 // [12 14 16] Fixed samples per quarter-resolution pixel (no jitter)
#define SUN_VISIBILITY_TAPS 13 // [9 13 21 29] Fixed depth taps around the sun for its visibility (vertex shader, once per frame)
#define SKY_DITHER 0.75 // [0.00 0.50 0.75 1.00 1.50] Static, invisible dither in 1/255 steps against banding; 0 = off (for testing)
#define SUN_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Angle / thin bloom / mid glow / wide halo / ray lobes / visibility / veil / rim / gradient / horizon-fog diff / cloud terms / fog amount / fog scatter / fog banks / dither x16 / banding test

// Moon sliders (Update 2A). The moon shares the sun's quality sliders (RIM_TAPS, SHAFT_SAMPLES,
// SUN_VISIBILITY_TAPS, SKY_DITHER): the same code and passes draw both.
#define MOON_LIGHT_INTENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Master for everything the moon adds (glow, halo, veil, rim, shafts, cloud patch, star dimming); 0 = none
#define MOON_GLOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Thin bloom and mid glow around the moon (1 = about 0.3 x the sun's glow at half its size)
#define MOON_GLOW_QUALITY 2 // [1 2] 1 = round glow; 2 = phase-aware glow (weaker beside the dark side of the disc)
#define MOON_HALO_SIZE 0.15 // [0.08 0.10 0.15 0.20 0.25 0.30] Wide moon halo radius in radians (0.15 = about 9 degrees, half the sun's)
#define MOON_HALO_STRENGTH 0.50 // [0.00 0.15 0.25 0.35 0.50 0.65 0.80] Wide halo: the night sky gets lighter around the moon
#define MOON_PHASE_INTENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00] How much the phase dims the moon light: 0 = every phase like a full moon, 1 = the measured lit share of the disc
#define MOON_VEIL_STRENGTH 0.06 // [0.00 0.03 0.06 0.10 0.15 0.20] Cool veil near the visible moon (0.06 = 0.2 x the sun's veil)
#define MOON_RIM_STRENGTH 0.25 // [0.00 0.10 0.15 0.20 0.25 0.30 0.40 0.50] Cool rim on edges turned to the moon (0.25 = about 0.3 x the sun's rim)
#define MOON_SHAFT_STRENGTH 0.015 // [0.000 0.010 0.015 0.025 0.040 0.060] Moon shafts through gaps (0.015 = 0.15 x the sun's shafts)
#define MOON_COLOR_COOLNESS 0.50 // [0.00 0.25 0.50 0.75 1.00] Moon colours: 0 = neutral cool white, 0.5 = cool blue, 1 = blue-violet
#define MOON_BIOME_TINT_STRENGTH 0.30 // [0.00 0.15 0.30 0.50 0.75 1.00] Biome tint of the moon light (jungle teal, desert warmer, snowy icy blue, swamp dim green-grey)
#define CLOUD_MOON_GLOW_THROUGH 0.20 // [0.00 0.10 0.20 0.30 0.45 0.60] Soft silver patch on a cloud in front of the moon (replaces the sky glow there)
#define MOON_STAR_DIMMING 0.50 // [0.00 0.25 0.50 0.75 1.00] Stars fade softly near the moon glow (only near the moon, never across the sky)
#define NIGHT_SKY_DITHER 0.33 // [0.00 0.33 0.50 0.75 1.00] Extra anti-banding dither in dark regions at night (x SKY_DITHER); 0 = off (for testing)
#define MOON_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13] Day weights / moon position / thin bloom / mid glow / halo / moon visibility / veil / rim / shafts x32 / cloud over the moon / moon total / dark banding test / sun identity check

// Block lighting sliders (Update 2B, change A: directional face lighting).
#define FACE_LIGHTING_QUALITY 2 // [1 2] Sky and torch share of the light: 1 = estimated, 2 = exact from the lightmap (one extra lightmap read)
#define FACE_CONTRAST 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] How much darker faces turned away from the sun get in clear daylight (1 = about 1.4 to 1.55 x between the lit and the shaded side)
#define SHADE_FLOOR 0.45 // [0.30 0.35 0.40 0.45 0.50 0.60 0.70] Minimum light of a shaded face, as a share of the flat light: faces never go darker
#define DIRECTIONAL_WRAP 0.08 // [0.00 0.04 0.08 0.12 0.16 0.25] Soft wrap of the sun light around the edge between lit and shaded
#define MOON_FACE_CONTRAST 0.30 // [0.00 0.15 0.30 0.45 0.60] Face contrast from the moon at night, as a share of the day contrast (also scales the night glints)
#define PLANT_NORMAL_UP_BLEND 0.70 // [0.00 0.25 0.50 0.70 0.85 1.00] Cross-shaped plants are lit as if facing up (no dark backs, no flicker)
#define AMBIENT_AMOUNT_BIAS 0.00 // [-0.10 -0.05 0.00 0.05 0.10] Small lift (+) or cut (-) of the sky ambient on shaded faces in sunlight

// Block micro-detail sliders (Update 2B, change B).
#define MICRO_DETAIL_QUALITY 2 // [1 2] 1 = glints only on sand and red sand (no per-texel hash elsewhere), leaves without waxy glints; 2 = every group
#define GLITTER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Glitter blocks: glint brightness
#define SHEEN_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Sheen blocks: brightness of the lit lighter texels
#define GLOSS_BLOCK_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Gloss blocks: glints, sheen and sky reflection (GLOSS_STRENGTH is the entity plastic)
#define FOLIAGE_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Leaves and foliage: sun-caught texels and waxy glints
#define GLINT_DENSITY_SCALE 1.00 // [0.25 0.50 0.60 0.75 1.00 1.50 2.00] How many texels can glint (never more than MAX_GLINT_COVERAGE)
#define BLOCK_GLINT_SIZE 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] Glint size: lower = sharper and rarer, higher = softer and more often lit
#define GLINT_ANGLE_STEPS 12 // [8 12 16 24 32] Glints switch in steps of the view angle: fewer = calmer, more = smoother motion
#define DETAIL_THRESHOLD 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] How much lighter than its texture a texel must be to catch the light (higher = fewer)
#define MAX_GLINT_COVERAGE 0.12 // [0.04 0.08 0.12 0.16 0.20 0.30] Largest share of texels per face that can ever glint
#define GLINT_FADE_START 16 // [8 12 16 24 32] Glints start to fade at this distance (blocks)
#define GLINT_FADE_END 48 // [24 32 48 64 96] Glints are gone at this distance (blocks)
#define TORCH_GLINT 0.05 // [0.00 0.05 0.10 0.20 0.35] Tiny warm glints where torchlight lights the block
#define BLOCK_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17] Normal / N.L / sun-facing / direct / ambient / vanilla face shade / material / texel id / detail D / glint raw / glint levels / footprint fade / distance fade / sheen / micro-detail / before-after split / face light

// Sky diagnostics (Patch 2.1, part B).
#define SKY_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12] Sky only / gradient / halo + haze / sun glow + disc / moon glow / vanilla stars + moon / procedural stars / fake birds + pollen / invalid values / outliers / sky mask exact vs epsilon / quarter-resolution buffer

// Adaptive eyes sliders (Patch 2.1, part A). Gains are in linear light (2.2 = 2.2 x the light, about 1.43 x the screen value).
#define ADAPT_DARK_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] How strongly the view follows the darkness (1 = half a stop of gain per stop of darkness, up to the limits)
#define ADAPT_MAX_BRIGHTEN 2.2 // [1.0 1.4 1.8 2.2 2.6 3.0 4.0] Largest brightening in caves and dark interiors (linear light)
#define ADAPT_NIGHT_LIMIT 1.5 // [1.0 1.2 1.5 1.8 2.2] Largest brightening outdoors at night, so night stays night (linear light)
#define ADAPT_TO_DARK_TIME 6 // [2 3 4 6 8 10 15] Seconds to adapt to the dark (90 %)
#define ADAPT_TO_BRIGHT_TIME 1200 // [400 600 800 1200 1600 2400] Milliseconds to adapt to the light (90 %); the over-bright moment settles in this time (shaders.properties can only compare whole numbers)
#define BRIGHT_FLASH 0.50 // [0.00 0.25 0.50 0.75 1.00] Over-bright moment when you step into the light: share of the eyes' lag that shows (0 = none), with a matching small bloom boost
#define BRIGHT_PUNCH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00] Extra contrast (+6 %) and vibrance (+8 %) in very bright places (snow, desert, beaches at midday); 0 = off
#define BRIGHT_PUNCH_REFERENCE_SHIFT 0.00 // [0.00 0.25 0.50 0.75 1.00] Share of the punch given to ordinary daylight too; above 0 this CHANGES the approved daytime look
#define ADAPT_SHADOW_LIFT 0.004 // [0.000 0.002 0.004 0.008 0.012] Tiny cool lift of the black level in fully dark-adapted views (screen value)
#define PURKINJE_STRENGTH 0.15 // [0.00 0.10 0.15 0.25 0.40] Night vision feel: slight desaturation and cool shift in very dark adapted views
#define ADAPT_SCENE_LUMA_WEIGHT 0.50 // [0.00 0.25 0.50 0.75 1.00] How much the measured scene brightness can move the adaptation
#define ADAPT_SCENE_REFINE_LIMIT 1.0 // [0.5 0.75 1.0 1.5] Hard limit of that correction, in stops
#define ADAPT_SCENE_TAPS 9 // [9 16 25] Fixed scene taps per frame (one pixel pass)
#define ADAPT_CENTER_WEIGHT 0.50 // [0.00 0.25 0.50 0.75 1.00] What you look at counts more than the screen edge (reduced when the centre is a bright window)
#define ADAPT_NETHER_STRENGTH 0.30 // [0.00 0.15 0.30 0.50 0.75 1.00] Adaptation strength in the Nether
#define ADAPT_END_STRENGTH 0.30 // [0.00 0.15 0.30 0.50 0.75 1.00] Adaptation strength in the End
#define ADAPT_DITHER 0.50 // [0.00 0.25 0.50 0.75 1.00] Extra static anti-banding dither while brightened (1/255 steps at the largest gain)
#define ADAPT_LOCAL_LIFT_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00] Extra lift of the darkest pixels (1 = up to 1.8 x more in the darkest areas, almost none on bright ones)
#define ADAPT_HIGHLIGHT_KNEE 0.70 // [0.50 0.60 0.70 0.80 0.90] Screen value where the highlight roll-off starts while the view is brightened
#define ADAPT_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10] Exposure graph / gain / targets / scene taps / scene luminance / over-bright + punch / split without-with / dark banding test / local lift mask / highlight roll-off

// Underwater sliders (Update 3).
#define UNDERWATER_VISIBILITY 36 // [16 20 24 28 32 36 40 48 64] Blocks of water after which only 5 % of blue light is left (open ocean; swamps about 0.42 x, warm oceans 1.25 x)
#define UNDERWATER_FOG_DENSITY 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] Multiplier of the absorption (higher = murkier)
#define UNDERWATER_DEPTH_DARKENING 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] Darker water with the camera depth: 0 = surface colour at any depth, 1 = navy at about 15 blocks and almost black beyond 40
#define UNDERWATER_VIEW_BRIGHTNESS 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] Brighter water looking up and toward the light, darker looking down and away
#define UNDERWATER_BIOME_TINT_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Biome water colour (warm oceans turquoise, cold navy, rivers cyan, swamps murky green); 0 = open ocean everywhere
#define UW_SHAFT_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Brightness of the underwater light shafts
#define UW_SHAFT_LENGTH 24 // [12 16 24 32 48] How far from the camera the shafts are gathered (blocks)
#define UW_SHAFT_SOFTNESS 0.50 // [0.25 0.50 0.75 1.00] Blur of the shadow-aware shafts (tier 2)
#define UW_SHAFT_CONTRAST 1.00 // [0.50 0.75 1.00 1.25 1.50] Lit regions against the darker gaps between them
#define UW_SHAFT_DRIFT_SPEED 0.30 // [0.00 0.10 0.20 0.30 0.45 0.60] Drift of the light pattern (blocks per second)
#define UW_SHAFT_PATTERN_SCALE 12 // [6 8 12 16 24] Size of the soft light cells (blocks)
#define UW_SHAFT_STEPS 8 // [8 10 12] Fixed steps of the shadow-aware march (tier 2, no jitter)
#define SNELL_WINDOW_SOFTNESS 6 // [2 4 6 8 12] Soft edge of the Snell window (degrees)
#define SURFACE_FROM_BELOW_BRIGHTNESS 1.00 // [0.50 0.75 1.00 1.25 1.50] Brightness of the surface seen from below
#define UNDERWATER_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9] Eye in water + fade / depth / transmittance / view brightness / tier 1 shafts / tier 2 shafts / pattern / Snell window / split without-with

// Nether sliders (Update 3).
#define NETHER_FOG_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00] Nether fog density (1 = about 93 % fog at 70 blocks in the crimson forest)
#define NETHER_FOG_BIOME_TINT 1.00 // [0.00 0.25 0.50 0.75 1.00] Biome fog colours (crimson, warped teal, soul cyan, basalt grey); 0 = nether wastes everywhere
#define NETHER_LIGHT_COLOR_WARMTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Warm hue of the block light (deep red at low light, orange near sources)
#define NETHER_EMISSIVE_BOOST 0.35 // [0.00 0.15 0.25 0.35 0.50 0.70] Extra brightness of lava, fire, glowstone, shroomlight, magma (bloom included, never past white)
#define NETHER_LIGHT_FLICKER 0.03 // [0.00 0.02 0.03 0.04 0.06] Flicker amplitude of the block light (smooth, about 7 Hz)
#define NETHER_LAVA_HAZE 1.00 // [0.00 0.50 0.75 1.00 1.50 2.00] Warm glow of the haze near the lava sea
#define NETHER_DEBUG_MODE 1 // [1 2 3 4 5 6] Fog amount / fog colour / biome weights / emissive mask / block light hue / lava haze

// End sliders (Update 3). The flash schedule is the game's own (one flash per 30 s window, 5 to 19 s
// long), so there are no gap, duration or elevation sliders.
#define FLASH_INTENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Master for everything the flash does
#define FLASH_SKY_GLOW_STRENGTH 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] The flash's glow in the fog toward the flash, in the sky and on distant terrain (1 = your Vibrant Visuals references, centre #683A70)
#define FLASH_HALO_SIZE 0.34 // [0.25 0.30 0.34 0.38 0.40 0.45 0.60 0.80] Radius of the flash glow (radians; 0.34 = about 19.5 degrees, half brightness near 15 degrees, your Vibrant Visuals references)
#define FLASH_FOG_BOOST 2.0 // [1.0 1.5 2.0 2.5 3.0 4.0] How fast the fog in front of things fills with the flash glow (2 = half of the sky's glow at 24 blocks of lit air, your Vibrant Visuals screenshots)
#define FLASH_FOG_TAPS 32 // [16 24 32 48 64] Most depth taps per quarter-resolution pixel for the flash fog's shadow, during a flash only (one every 8 px at 1080p up to this count; about 0.2 ms at 32 on a GTX 1060-class GPU at 1080p)
#define FLASH_SHAFT_STRENGTH 0.12 // [0.00 0.05 0.08 0.12 0.18 0.25] Purple shafts through gaps toward the flash (only with FLASH_FOG_SHADOWS off)
#define FLASH_BLOCKLIGHT_TINT 0.15 // [0.00 0.10 0.15 0.25 0.40] Torch and lantern light turns slightly purple during a flash
#define FLASH_SHADOW_STRENGTH 0.85 // [0.00 0.50 0.70 0.85 1.00] How much the flash shadows take away (shadowed areas keep the violet ambient)
#define FLASH_COLOR_VARIATION 0.00 // [0.00 0.50 1.00] Hue and strength variation between flashes (0 = always the Vibrant Visuals colour #E45DFF at the same strength; 1 = #CC66FF to #FC54FF, 0.85 to 1.15 x)
#define FLASH_PULSE 0.00 // [0.00 0.15 0.30 0.45 0.60] Double pulse on the rising half of a flash (Vibrant Visuals has none: 0; capped at 0.20 with the photosensitivity limit)
#define END_AMBIENT_TINT 1.00 // [0.00 0.25 0.50 0.75 1.00] Vibrant Visuals End light on blocks and entities: dim and warm-neutral, end stone #4D492F (0 = the vanilla grey-green lightmap)
#define END_AMBIENT_HAZE 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] The End's ambient haze: the sky's light in the air in front of dark things, so obsidian pillars and mobs sit about at the sky's brightness and look flat as in Vibrant Visuals (0 = the Update 4.1 look)
#define END_AMBIENT_BRIGHTNESS 0.67 // [0.50 0.58 0.67 0.75 0.85 1.00] Brightness of that End light (0.67 = your references; 1 = the vanilla brightness)
#define END_FOG_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00] End haze density between flashes (1 = about 17 % at 100 blocks, the reference's ground keeps its colour to the island's edge)
#define END_SKY_BRIGHTNESS 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] Brightness of the End sky and its fog (1 = your references: #0A060E at the horizon, #0E0916 higher up)
#define END_SKY_GRAIN 25 // [0 10 15 20 25 35 50 100] Light grain of the End sky, as in Vibrant Visuals (percent of the vanilla End sky texture's contrast; 25 = your Vibrant Visuals screenshot, 0 = perfectly smooth)
//#define END_DRAGON_FOG // During the Ender Dragon fight: hide the flash glow, a third of the flash light, a thicker fog (the Update 3 look); off = the fight changes nothing, as on your references
#define END_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12] Scheduler / flash direction / intensity / flash glow / flash fog (red: share, green: lit share) / flash light / flash shadow / shadow map / shadow light check / sky check (left: drawn by the game and Iris, right: rebuilt) / flash shafts (FLASH_FOG_SHADOWS off) / dragon fog

// Update 5: fake global illumination (screen space: indirect light, colour bleeding, the first bounce, AO combined
// with the indirect light, light wrapping, the light of emitters) and its addendum, the chromatic light falloff.
// With FAKE_GI and CHROMATIC_LIGHT off every program compiles exactly as in Update 4.2.
#define FAKE_GI // Fake global illumination: light bounces from lit surfaces and light sources onto their neighbours, with colour bleeding and soft ambient occlusion (one low-resolution pass; off = exactly Update 4.2)
#define GI_MICRODETAIL_RESPONSE // The lighter texels of a block (obsidian speckles, grains) catch the light near a light source more, in its colour, fading with it (the Update 2B micro-detail tied to the local light)
#define CHROMATIC_LIGHT // Chromatic light falloff: a light changes hue as it fades (End crystal: pink, then red, then the blue-violet ambient), a block-light colour ramp that also works off-screen, a static ambient floor
//#define FOG_TINT_NEAR_EMITTER // The fog in front of things near a visible light takes the light's colour (Vibrant Visuals tints its fog near coloured lights); off by default
//#define GI_DEBUG // Diagnostic views for the fake GI and the chromatic light
#define FAKE_GI_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Master strength of the fake GI (bounce and emitter light; the AO has its own)
#define BOUNCE_LIGHT_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00 1.50 2.00] Light bounced from lit surfaces onto their neighbours (the first bounce)
#define COLOR_BLEEDING_STRENGTH 0.50 // [0.00 0.25 0.50 0.75 1.00] How much of a surface's colour its bounced light carries (grass faintly green, red wool faintly red; 0 = neutral bounce)
#define EMISSIVE_BOUNCE_STRENGTH 1.00 // [0.00 0.30 0.60 0.80 1.00 1.50 2.00] Light of visible light sources (lava, fire, glowstone, lanterns, the End crystal) on the surfaces around them, in their colour
#define GI_RADIUS 3.0 // [2.0 2.5 3.0 3.5 4.0 5.0 6.0] Reach of the gather in blocks (the taps cover this disc around each pixel)
#define GI_SAMPLES 8 // [4 6 8 12 16] Taps per low-resolution pixel (the cost grows with it)
#define GI_RESOLUTION 1 // [1 2] Resolution of the gather: quarter (shares the quarter-resolution pass) or half (its own pass, 4 x the pixels)
#define GI_FALLOFF_DIST 1.0 // [0.50 0.75 1.00 1.50 2.00] Reference distance of the bounce falloff, 1 / (1 + (d / this)^2), in blocks
#define GI_MAX_DISTANCE 56 // [32 48 56 64 96 128] The fake GI fades out toward this distance in blocks
#define EMISSIVE_RADIUS 4.0 // [2.0 3.0 4.0 5.0 6.0 8.0] Reference distance of the emitter light falloff in blocks (with CHROMATIC_LIGHT off; with it, the near and mid radii below)
#define BOUNCE_SATURATION 0.80 // [0.00 0.40 0.60 0.80 1.00 1.20] Saturation of all added light (keeps strong colours from flooding)
#define LIGHT_WRAP 0.20 // [0.00 0.10 0.20 0.30 0.50] Bounced light wraps a little around edges (soft gradients, no hard cut where a face turns away)
#define AO_STRENGTH 0.30 // [0.00 0.15 0.30 0.45 0.60 0.80 1.00] Ambient occlusion on the ambient and indirect light only (never the direct sun; the vanilla corner AO stays as it is)
#define AO_RADIUS 1.25 // [0.75 1.00 1.25 1.50 2.00] Reach of the ambient occlusion in blocks
#define AO_BIAS 0.10 // [0.00 0.05 0.10 0.15 0.25] Ignores nearly flat neighbours (less AO on bumpy ground)
#define GI_ON_ENTITIES 0.35 // [0.00 0.15 0.35 0.50 0.75 1.00] How much the player, mobs, items and particles receive (they never send bounce light)
#define GI_UNDERWATER 0.30 // [0.00 0.15 0.30 0.50 1.00] Fake GI with the camera underwater (applied before the absorption fog)
#define GI_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20] Normals / linear depth / valid taps / emitters / raw indirect / upsampled indirect / AO / colour bleeding / emitter light / off-screen fallback / split with/without / dark end / leak test / near layer / mid layer / static ambient / colour ramp / blend confidence / hue of the indirect light / falloff curves
#define CHROMATIC_FALLOFF_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] How much each colour channel of a light falls off at its own rate (0 = one rate, no hue change; the Overworld takes half)
#define CHROMATIC_FALLOFF_R 0.80 // [0.50 0.60 0.70 0.80 0.90 1.00] Falloff rate of red (lower = reaches farther)
#define CHROMATIC_FALLOFF_G 1.00 // [0.80 0.90 1.00 1.10 1.20] Falloff rate of green
#define CHROMATIC_FALLOFF_B 1.30 // [1.00 1.10 1.20 1.30 1.50 1.75] Falloff rate of blue (higher = fades first)
#define FALLOFF_METRIC 1 // [0 1] Distance used by the emitter light: straight line, or Manhattan (block steps, as Minecraft and Vibrant Visuals spread light)
#define EMITTER_NEAR_RADIUS 2.5 // [1.5 2.0 2.5 3.0 4.0] Radius of a light's own colour (near layer) in blocks
#define EMITTER_MID_RADIUS 5 // [0 3 4 5 6 8] Radius of its warmer secondary light (mid layer) in blocks; 0 = one layer only
#define STATIC_AMBIENT_STRENGTH 0.50 // [0.00 0.25 0.50 0.75 1.00 1.50] A dim, always-present ambient light where the sky does not reach: cool blue-grey in Overworld caves, deep red-brown in the Nether (the End's is END_AMBIENT_BRIGHTNESS)
#define AMBIENT_TINT 1.00 // [0.00 0.50 1.00] Colour of that ambient (0 = neutral grey)
#define LIGHT_RAMP_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Block light changes colour with its level: near, mid and far colour (works for lights off-screen too; the Nether keeps NETHER_WARM_LIGHT)
#define RAMP_OVERWORLD_AMOUNT 0.40 // [0.00 0.20 0.40 0.60 0.80 1.00] Colour ramp in the Overworld (subtle: a torch goes slightly from warm to cool)
#define RAMP_END_AMOUNT 1.00 // [0.00 0.25 0.50 0.75 1.00] Colour ramp in the End (Vibrant Visuals: pink near the crystal's fire, red farther, gone into the violet ambient about 7 blocks out)
#define RAMP_NEAR_COLOR 0xFFE6C4 // [0xFFF4E6 0xFFE6C4 0xFFD8A8 0xFFC890] Overworld block light near a source (levels 12 to 15)
#define RAMP_MID_COLOR 0xFFB872 // [0xFFD8A8 0xFFB872 0xFF9E5C 0xFF8848] Overworld block light at mid levels (7 to 9)
#define RAMP_FAR_COLOR 0xA8B4E0 // [0xFFB872 0xD8D0C8 0xA8B4E0 0x8C9CE0] Overworld block light at low levels (1 to 4)
#define END_RAMP_NEAR_COLOR 0xFFC0C4 // [0xFFE0E8 0xFFC0C4 0xF4A8D8 0xD98CFF] End block light near a source (your Vibrant Visuals pillar: pink-warm)
#define END_RAMP_MID_COLOR 0xFF9C6B // [0xFFB070 0xFF9C6B 0xFF7A50 0xE0603A] End block light at mid levels (the red band)
#define END_RAMP_FAR_COLOR 0xD0D0FF // [0xD0D0FF 0xB0A0FF 0x9C8CE8] End block light at low levels (into the blue-violet ambient)
#define RAMP_SMOOTHNESS 1.00 // [0.50 0.75 1.00 1.50 2.00] Width of the transitions between the ramp's colours (larger = smoother)
#define NEAR_DETAIL_RESPONSE 0.50 // [0.00 0.25 0.50 0.75 1.00 1.50] How strongly the lighter texels catch the light near a source (with GI_MICRODETAIL_RESPONSE)
#define EMITTER_NEAR_COLOR_CRYSTAL 0xF0A0FF // [0xF0A0FF 0xD98CFF 0xFF9CE8 0xFFC0F0] End crystal light (near)
#define EMITTER_MID_COLOR_CRYSTAL 0xFF8A5C // [0xFFB070 0xFF8A5C 0xE0603A 0xC070FF] End crystal secondary light (its fire)
#define EMITTER_NEAR_COLOR_FIRE 0xFFD9A0 // [0xFFF0D0 0xFFD9A0 0xFFC080 0xFFA860] Torch, campfire and fire light (near)
#define EMITTER_MID_COLOR_FIRE 0xFF9A50 // [0xFFB070 0xFF9A50 0xFF7A3A 0xE0602A] Torch, campfire and fire secondary light
#define EMITTER_NEAR_COLOR_LAVA 0xFF9040 // [0xFFB060 0xFF9040 0xFF7030 0xFF5A20] Lava light (near)
#define EMITTER_MID_COLOR_LAVA 0xE0502A // [0xFF7030 0xE0502A 0xC03A20 0xA02818] Lava secondary light
#define EMITTER_NEAR_COLOR_LAMP 0xFFE6B8 // [0xFFF4E0 0xFFE6B8 0xFFD8A0 0xE0F4FF] Glowstone, lantern and sea lantern light (near)
#define EMITTER_MID_COLOR_LAMP 0xFFC080 // [0xFFD8A8 0xFFC080 0xFFA860 0xB8D8FF] Glowstone, lantern and sea lantern secondary light
#define EMITTER_NEAR_COLOR_SOUL 0x7FE8FF // [0xB0F4FF 0x7FE8FF 0x50D0FF 0x40B0E0] Soul fire and soul torch light (near)
#define EMITTER_MID_COLOR_SOUL 0x4FA8E0 // [0x7FC8F0 0x4FA8E0 0x3A80D0 0x5060C0] Soul fire and soul torch secondary light
#define EMITTER_NEAR_COLOR_ROD 0xFFF4F0 // [0xFFFFFF 0xFFF4F0 0xFFE8E0 0xF0E0FF] End rod light (near)
#define EMITTER_MID_COLOR_ROD 0xE8D8FF // [0xFFF4F0 0xE8D8FF 0xD0C0FF 0xFFE0C8] End rod secondary light
#define EMITTER_NEAR_COLOR_REDSTONE 0xFF5040 // [0xFF7060 0xFF5040 0xFF3A30 0xE02820] Redstone light (near)
#define EMITTER_MID_COLOR_REDSTONE 0xC02A20 // [0xE04030 0xC02A20 0xA02018 0x801810] Redstone secondary light

// Biome ambience sliders.
#define BIOME_SKY_STRENGTH 0.85 // [0.00 0.25 0.50 0.70 0.85 1.00] Biome tint of the mid sky
#define BIOME_FOG_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Biome tint of the horizon and the fog (one colour)
#define BIOME_CLOUD_TINT_STRENGTH 0.80 // [0.00 0.25 0.50 0.80 1.00] Biome tint of the clouds
#define BIOME_ZENITH_SHIFT 0.35 // [0.00 0.15 0.25 0.35 0.50 0.75 1.00] How much the zenith follows the biome (the sky stays blue)
#define BIOME_DENSITY_MULTIPLIER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] How much the biome fog density, height falloff and sun-scatter multipliers apply
#define BIOME_TRANSITION_TIME 10 // [4 6 8 10 12 16] Seconds the ambience takes to follow a new biome
#define BIOME_WARM_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of desert, savanna and badlands
#define BIOME_COLD_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of snowy lowlands, taiga and snowy peaks
#define BIOME_HUMID_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of jungle and swamp
#define BIOME_OCEAN_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of oceans, rivers and beaches
#define FORCE_BIOME_PREVIEW 0 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Debug: force one biome family (0 = off; numbers in the README)
#define BIOME_DEBUG_MODE 1 // [1 2 3 4 5 6] Family weights / palette swatches / horizon-fog diff / fog density / transition / palette table

// Ambience sliders.
#define ENV_WARMTH 0.50 // [0.00 0.25 0.50 0.75 1.00] Warm sunlight on lit surfaces
#define ENV_SHADOW_COOLNESS 0.60 // [0.00 0.25 0.40 0.60 0.80 1.00] Cool, soft sky light in shade (warm sand and rock resist it)
#define ENV_VIBRANCE 0.15 // [0.00 0.08 0.15 0.25 0.35] Gentle vibrance on dull colours, with a neon clamp
#define ENV_SNOW_TINT 0.60 // [0.00 0.30 0.60 1.00] Slight blue on snow and ice, with a highlight shoulder
#define ENV_DISTANCE_DESATURATION 0.60 // [0.00 0.30 0.45 0.60 0.80 1.00] Far terrain loses saturation inside the fog
#define ENV_LAVENDER 1.00 // [0.00 0.50 1.00 1.50] Lavender tone of the haze and horizon
#define CLOUD_OPACITY 1.00 // [0.40 0.50 0.55 0.65 0.75 0.85 0.95 1.00] Opacity of the cloud body; 1 = the sun, moon and stars are hidden behind clouds, 0.65 = the previous translucent look
#define CLOUD_SUN_GLOW_THROUGH 0.45 // [0.00 0.15 0.30 0.45 0.60 0.80] Soft bright patch on a cloud around the sun behind it (replaces the sky glow there)
#define CLOUD_TINT 1.00 // [0.00 0.50 0.75 1.00] Sky-derived cloud colour versus the vanilla cloud colour
#define CLOUD_BRIGHTNESS 1.00 // [0.80 0.90 1.00 1.10 1.20] Lit cloud faces: mix of the horizon colour toward lavender white
#define CLOUD_EDGE_HIGHLIGHT 0.50 // [0.00 0.25 0.50 0.75 1.00] Lighter, denser cloud side faces, which read as thin outlines
#define CLOUD_UNDERSIDE_DARKNESS 0.55 // [0.00 0.25 0.40 0.55 0.70 0.85 1.00] Cooler, deeper cloud undersides
#define CLOUD_SUN_LIGHT 0.20 // [0.00 0.10 0.20 0.30 0.45] Soft brightening of cloud faces turned to the sun
#define CLOUD_SHADOW_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00] Darkness of the cloud shadows (direct sun only)
#define CLOUD_SHADOW_SOFTNESS 0.50 // [0.00 0.25 0.50 0.75 1.00] Penumbra width (quality 2); 1 = a full 12-block ramp
#define CLOUD_SHADOW_GRID 2 // [0 1 2 4] Block grid the shadow edges step on; 0 = smooth
#define CLOUD_SHADOW_QUALITY 2 // [1 2] 1 = one fetch, hard cells; 2 = four fetches, soft edges
#define FOG_DENSITY 0.010 // [0.002 0.004 0.006 0.008 0.010 0.012 0.015 0.020] Fog density per block at the base height
#define FOG_HEIGHT_FALLOFF 0.035 // [0.010 0.020 0.035 0.050 0.070 0.100] How fast the fog thins with height
#define FOG_BASE_HEIGHT 63 // [40 50 63 70 80 96] World height of the densest fog layer
#define FOG_START 32 // [0 16 24 32 40 48 64] Blocks kept clear around the camera
#define FOG_END 1.00 // [0.70 0.80 0.90 1.00] Share of the render distance where the fog becomes opaque
#define FOG_BANK_QUALITY 1 // [0 1 2] Fog banks: 0 = off, 1 = one smooth noise sample, 2 = two smooth samples (more detail)
#define FOG_BANK_STRENGTH 0.30 // [0.00 0.15 0.30 0.45 0.65] Thickness variation of the fog banks (kept small: no visible grain)
#define FOG_BANK_SCALE 48 // [24 32 48 64 96 128] Fog bank cell size in blocks
#define FOG_DRIFT_SPEED 0.40 // [0.00 0.20 0.40 0.80 1.50] Fog bank drift in blocks per second
#define FOG_SUN_SCATTER 0.60 // [0.00 0.30 0.60 0.90 1.20] Haze glow around the sun (same falloff as the wide halo)
#define FOG_LEVELS 10 // [8 10 12] Fog steps for the banded look
#define AMBIENCE_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Fog / fog colour / banks / scatter / perspective / cloud mask / cloud shadow / cloud UV / sky / sky-fog diff / refl colour / refl valid / refl fog / refl split / grade split / cloud alignment

// Shadow colour sliders (terrain receivers; entities, water and the gloss are untouched).
#define SHADOW_COLOR_QUALITY 2 // [1 2] 1 = ambient tint only, 2 = + surface response (snow bluer, sand lilac, stone cool, grass blue-green, wood and dirt darker) and saturation
#define SHADOW_COLOR_SATURATION 0.15 // [0.00 0.08 0.15 0.25 0.35] Mild, luminance-preserving saturation boost in shade (neon clamp)
#define SHADOW_HUE_PUSH 0.50 // [0.00 0.25 0.50 0.75 1.00] Hue push of shaded colours toward the ambient sky light
#define SHADOW_MIN_DARKNESS 0.25 // [0.00 0.15 0.25 0.35 0.50] Entity shadow darkness left under clouds, overcast and rain (share of the full darkness)
#define SHADOW_MAX_DARKNESS 1.00 // [0.60 0.70 0.80 0.90 1.00] Entity shadow darkness in full sun (1 = as dark as terrain shadows, the previous look)
#define ENTITY_SHADOW_COLOR_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Shadow colour on player and mob shadows
#define TERRAIN_SHADOW_COLOR_STRENGTH 0.60 // [0.00 0.30 0.45 0.60 0.80 1.00] Shadow colour on terrain shadows and shaded faces (gentle: the approved terrain look)

// Underwater caustic sliders.
#define UNDERWATER_CAUSTIC_STRENGTH 0.80 // [0.00 0.40 0.60 0.80 1.00 1.20] Caustics seen with the camera underwater, relative to the outside view
#define UNDERWATER_SEA_LEVEL 63 // [56 60 62 63 64 66 70] Fallback water surface height when no sky light reaches the eye (oceans)
#define LIGHT_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17] V+cloud cover / sky mask / rim / shafts / cloud mask+depth / hidden by cloud / sun strength / shadow split / shadow ambient / entity flag / eye in water / camera depth / surface height / water flag / depth fade / fog transmittance / caustic light

#define MATCH_STRENGTH 65 // [0 10 20 25 35 42 50 65 80 82 100] 0=current pack, 100=full golden-hour reference
#define GOLDEN_HAZE_STRENGTH 0.22 // [0.00 0.08 0.14 0.22 0.30 0.42 0.55] Added target haze blend
#define GOLDEN_HAZE_PHASE 0.35 // [0.00 0.10 0.20 0.35 0.50 0.70] Sun-facing haze glow
#define GOLDEN_GRADE_STRENGTH 0.12 // [0.00 0.04 0.08 0.12 0.18 0.24] Extra golden-hour scene grade
#define GOLDEN_SHADOW_LIFT 0.025 // [0.000 0.010 0.020 0.025 0.040 0.060] Low-sun warm shadow lift
#define GOLDEN_BACKLIGHT_STRENGTH 0.10 // [0.00 0.04 0.07 0.10 0.15 0.22] Warm mapped-foliage edge light
#define GOLDEN_BLOOM_BLOCKINESS 0.75 // [0.00 0.25 0.50 0.75 1.00] Pixelation of existing bloom source
#define GOLDEN_BLOOM_PIXEL_SIZE 16 // [8 12 16 20 24 32] Screen-pixel bloom-source grid
#define GOLDEN_VIGNETTE_STRENGTH 0.025 // [0.00 0.010 0.020 0.025 0.040 0.060] Extra edge falloff
#define GOLDEN_SKY_TINT_STRENGTH 0.70 // [0.00 0.20 0.40 0.55 0.70 0.85 1.00] Golden-hour sky tint
#define FAKE_BIRD_AMOUNT 0.65 // [0.00 0.20 0.40 0.65 0.85 1.00] Sparse procedural bird visibility
#define FAKE_BIRD_SIZE 7 // [4 5 6 7 8 10] Bird silhouette width in screen pixels
#define FAKE_BIRD_SPEED 0.0025 // [0.0000 0.0010 0.0025 0.0040 0.0060] Screen drift per frame-time second
#define TARGET_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8] Sun glow (new) / (removed: black) / sky / fog / phase / (removed rays: black) / bloom / grade

const int shadowMapResolution = 1536; // [768 1024 1280 1536 2048 3072] Shadow map resolution
const float shadowDistance = 80.0; // [48.0 64.0 72.0 80.0 88.0 96.0] Shadow distance in blocks
const float shadowDistanceRenderMul = 1.0;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;

// Debug views force the features they inspect. These lines repeat the option names with the
// same default, so Iris merges them with the declarations above.
#if defined(REFLECTION_DEBUG) && !defined(WATER_SKY_REFLECTION)
#define WATER_SKY_REFLECTION
#endif
#if defined(REFLECTION_DEBUG) && !defined(WATER_SSR)
#define WATER_SSR
#endif
#if defined(WATER_SSR) && !defined(WATER_SKY_REFLECTION)
#undef WATER_SSR
#endif
#if defined(WAVE_DEBUG) && !defined(WAVE_LIGHTING)
#define WAVE_LIGHTING
#endif
#if defined(CAUSTICS_DEBUG) && !defined(PIXEL_CAUSTICS)
#define PIXEL_CAUSTICS
#endif

#ifdef TARGET_DEBUG
#ifndef GOLDEN_TARGET_SKY
#define GOLDEN_TARGET_SKY
#endif
#ifndef GOLDEN_TARGET_HAZE
#define GOLDEN_TARGET_HAZE
#endif
#ifndef GOLDEN_TARGET_GRADE
#define GOLDEN_TARGET_GRADE
#endif
#ifndef GOLDEN_BLOCKY_BLOOM
#define GOLDEN_BLOCKY_BLOOM
#endif
#ifndef BLOOM
#define BLOOM
#endif
#endif

#if defined(ATMOS_DEBUG)
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#if ATMOS_DEBUG_MODE == 6 && !defined(BLOOM)
#define BLOOM
#endif
#endif

#if defined(VV_DEBUG)
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#ifndef BLOOM
#define BLOOM
#endif
#ifndef PIXEL_SHADOWS
#define PIXEL_SHADOWS
#endif
#ifndef EMISSIVE_BLOCKS
#define EMISSIVE_BLOCKS
#endif
#endif

#if defined(AMBIENCE_DEBUG)
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#if (AMBIENCE_DEBUG_MODE >= 6 && AMBIENCE_DEBUG_MODE <= 8) && !defined(CLOUD_SHADOW_ENABLE)
#define CLOUD_SHADOW_ENABLE
#endif
#if (AMBIENCE_DEBUG_MODE >= 11 && AMBIENCE_DEBUG_MODE <= 14) && !defined(WATER_SSR) && defined(WATER_SKY_REFLECTION)
#define WATER_SSR
#endif
#endif

#if defined(SUN_DEBUG)
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#ifndef SUN_GLOW
#define SUN_GLOW
#endif
#if SUN_DEBUG_MODE == 5 && !defined(SUN_RAYS)
#define SUN_RAYS
#endif
#if (SUN_DEBUG_MODE == 6 || SUN_DEBUG_MODE == 7) && !defined(SUN_VEIL)
#define SUN_VEIL
#endif
#if SUN_DEBUG_MODE == 8 && !defined(SUN_EDGE_RIM)
#define SUN_EDGE_RIM
#endif
#endif

#if defined(BIOME_DEBUG)
#ifndef BIOME_AMBIENCE
#define BIOME_AMBIENCE
#endif
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#endif

#if defined(LIGHT_DEBUG)
#if (LIGHT_DEBUG_MODE == 2 || LIGHT_DEBUG_MODE == 4) && !defined(SUN_SHAFTS)
#define SUN_SHAFTS
#endif
#if (LIGHT_DEBUG_MODE == 1 || LIGHT_DEBUG_MODE == 3) && !defined(SUN_EDGE_RIM)
#define SUN_EDGE_RIM
#endif
#if LIGHT_DEBUG_MODE >= 7 && LIGHT_DEBUG_MODE <= 10 && !defined(SHADOW_COLORS)
#define SHADOW_COLORS
#endif
#if LIGHT_DEBUG_MODE >= 11
#ifndef PIXEL_CAUSTICS
#define PIXEL_CAUSTICS
#endif
#ifndef CAUSTICS_UNDERWATER_FLOOR
#define CAUSTICS_UNDERWATER_FLOOR
#endif
#endif
#endif

#if defined(MOON_DEBUG)
#ifndef MOON_RAYS
#define MOON_RAYS
#endif
#if (MOON_DEBUG_MODE == 6 || MOON_DEBUG_MODE == 7) && !defined(MOON_VEIL)
#define MOON_VEIL
#endif
#if MOON_DEBUG_MODE == 8 && !defined(MOON_EDGE_RIM)
#define MOON_EDGE_RIM
#endif
#if MOON_DEBUG_MODE == 9 && !defined(MOON_SHAFTS)
#define MOON_SHAFTS
#endif
#endif

// Internal switches derived from the options above (not menu options).
// The moon's veil, rim and shafts are part of MOON_RAYS: off removes all of them. Its debug
// views need the moon code too (the forcing line above cannot bring MOON_RAYS back once it is
// switched off in the menu, because Iris rewrites every declaration line of an option).
#ifndef MOON_RAYS
#undef MOON_VEIL
#undef MOON_EDGE_RIM
#undef MOON_SHAFTS
#undef MOON_DEBUG
#endif
// Biome amount of the water's own Tier-1 reflection palette (gbuffers.vsh), and a separate
// biome-free palette in final for the screen reflection when the water must not follow it.
#if defined(BIOME_AMBIENCE) && defined(BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION)
#define AMB_WATER_BIOME 1.0
#else
#define AMB_WATER_BIOME 0.0
#endif
#if defined(BIOME_AMBIENCE) && !defined(BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION)
#define AMB_WATER_OWN_PALETTE
#endif
// BIOME_TRANSITION_TIME is used in shaders.properties only (the smoothing time of the
// biome uniforms); this reference keeps it visible to Iris.
#if BIOME_TRANSITION_TIME > 0
#endif
#if defined(WATER_REFLECTION_IMPROVEMENT) && !defined(WATER_SKY_REFLECTION)
#undef WATER_REFLECTION_IMPROVEMENT
#endif
// The cloud cell texture is read by the cloud shadows and by the improved cloud reflection.
#if defined(VANILLA_CLOUD_CELLS) && (defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT))
#define AMB_CLOUD_TEXTURE
#endif
// The sun visibility (fixed depth taps in final.vsh) feeds the veil and the edge rim.
#if defined(SUN_VEIL) || defined(SUN_EDGE_RIM)
#define AMB_SUN_VISIBILITY
#endif
// The moon's visibility (the same taps, at the moon's size) feeds its veil and rim.
#if defined(MOON_VEIL) || defined(MOON_EDGE_RIM)
#define AMB_MOON_VISIBILITY
#endif
// Shared ray code: the rim gather and the shaft pass serve the sun and the moon.
#if defined(SUN_EDGE_RIM) || defined(MOON_EDGE_RIM)
#define RAYS_EDGE_RIM
#endif
#if defined(SUN_SHAFTS) || defined(MOON_SHAFTS)
#define RAYS_SHAFTS
#endif
// Iris lists a Boolean option only if some shader source tests it with #ifdef/#ifndef
// (#if defined() does not count). These options are otherwise used only in #if expressions
// or in shaders.properties, so they get an explicit, empty reference here.
#ifdef ENTITY_SHADOWS
#endif
#ifdef PIXEL_WATER_SPARKLES
#endif
#ifdef CAUSTICS_UNDERWATER_FLOOR
#endif
#ifdef VANILLA_CLOUD_CELLS
#endif
#ifdef SUN_SHAFTS
#endif
#ifdef CLOUDS_BLOCK_SUN
#endif
#ifdef SHADOW_COLORS
#endif
#ifdef ENTITY_SHADOW_FLAG
#endif
#ifdef LIGHT_DEBUG
#endif
#ifdef MOON_RAYS
#endif
#ifdef MOON_VEIL
#endif
#ifdef MOON_EDGE_RIM
#endif
#ifdef MOON_SHAFTS
#endif
#ifdef MOON_DEBUG
#endif
#ifdef BLOCK_DEBUG
#endif
#ifdef PREVIOUS_SUN_LIFT
#endif
// Update 2B: the micro-detail runs only when at least one block group is on.
#if !defined(GLITTER_BLOCKS) && !defined(SHEEN_BLOCKS) && !defined(GLOSS_BLOCKS) && !defined(FOLIAGE_SPARKLE)
#undef BLOCK_MICRO_DETAIL
#endif
// Patch 2.1, part B: the stray dark pixels in the daytime sky were the fake birds (final.fsh,
// GOLDEN_FAKE_BIRDS: 7-pixel cells at fixed screen heights that drift across the sky). The fix
// removes them; the option stays in the menu and works again with SKY_PIXEL_FIX off.
#ifdef SKY_PIXEL_FIX
#undef GOLDEN_FAKE_BIRDS
#endif
// Patch 2.1, part A: the adaptive eyes' sub-features need the main switch.
#ifndef ADAPTIVE_EYES
#undef ADAPT_SCENE_LUMA
#undef ADAPT_LOCAL_LIFT
#undef ADAPT_HIGHLIGHT_PROTECTION
#undef ADAPT_DEBUG
#endif
// Terrain programs read the entity flag only where entities are in the shadow map at all.
#if defined(SHADOW_COLORS) && defined(ENTITY_SHADOW_FLAG) && defined(ENTITY_SHADOWS)
#define SHADOW_ENTITY_FLAG_READ
#endif
// Update 3: every part needs its environment's main switch (and the debug views theirs).
#ifndef UNDERWATER_AMBIENCE
#undef UNDERWATER_SHAFTS
#undef UNDERWATER_SHAFTS_TIER2
#undef SURFACE_FROM_BELOW
#undef SNELL_WINDOW
#undef UNDERWATER_DEBUG
#endif
#ifndef UNDERWATER_SHAFTS
#undef UNDERWATER_SHAFTS_TIER2
#endif
#ifndef SURFACE_FROM_BELOW
#undef SNELL_WINDOW
#endif
#ifndef NETHER_AMBIENCE
#undef NETHER_WARM_LIGHT
#undef NETHER_FLICKER
#undef LAVA_SEA_HAZE
#undef NETHER_DEBUG
#endif
#ifndef NETHER_WARM_LIGHT
#undef NETHER_FLICKER
#endif
#ifndef END_AMBIENCE
#undef END_FLASHES
#undef END_DEBUG
#endif
#ifndef END_FLASHES
#undef FLASH_SHADOWS
#undef END_FLASH_SHAFTS
#undef FLASH_GLINTS
#undef FLASH_FOG_SHADOWS
#endif
// Update 4.1: the flash fog's lit share takes colortex5.a from the flash shafts (Vibrant Visuals draws no shafts;
// the shadowed fog makes its own through gaps).
#ifdef FLASH_FOG_SHADOWS
#undef END_FLASH_SHAFTS
#endif
#ifndef BLOCK_MICRO_DETAIL
#undef FLASH_GLINTS
#endif
// The shaft pass and its upsample (lib/sun_rays.glsl) also serve the underwater tier 2, the End
// flash shafts and the flash fog's shadows; their own code paths stay off without SUN_SHAFTS and MOON_SHAFTS.
#if defined(UNDERWATER_SHAFTS_TIER2) || defined(END_FLASH_SHAFTS) || defined(FLASH_FOG_SHADOWS)
#ifndef RAYS_SHAFTS
#define RAYS_SHAFTS
#endif
#endif
// Iris lists a Boolean option only if some shader source tests it with #ifdef; these are also used
// in shaders.properties.
#ifdef UNDERWATER_DEBUG
#endif
#ifdef NETHER_DEBUG
#endif
#ifdef END_DEBUG
#endif
#ifdef FLASH_PHOTOSENSITIVITY_LIMIT
#endif
// Update 5: the fake GI. The emitter light rides on the glow buffer (colortex3 and its mip chain, written and built
// for EMISSIVE_GLOW: without the glow the fake GI has no emitter light). The fog tint near lights needs the gather. Iris lists a Boolean option only if some source tests it with #ifdef.
#if defined(FAKE_GI) && defined(EMISSIVE_GLOW)
#define GI_EMITTERS
#endif
#ifndef FAKE_GI
#undef FOG_TINT_NEAR_EMITTER
#endif
// The gather runs in composite at quarter resolution (sharing that pass and its glow mip chain), in its own pass
// composite3 at half resolution.
#if defined(FAKE_GI) && GI_RESOLUTION == 1
#define GI_QUARTER
#endif
#if defined(FAKE_GI) && GI_RESOLUTION == 2
#define GI_HALF
#endif
#ifdef GI_MICRODETAIL_RESPONSE
#endif
#ifdef GI_DEBUG
#endif
