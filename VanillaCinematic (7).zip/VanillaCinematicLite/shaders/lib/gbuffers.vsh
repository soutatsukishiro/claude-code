#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
// Needed by lib/ambience.glsl (palettes are evaluated here, once per vertex).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#include "/lib/ambience.glsl"

#if defined(WATER_GBUFFER) || defined(TERRAIN_GBUFFER)
in vec2 mc_Entity;
// Update 2B: block IDs carry a micro-detail material next to the legacy class; the face light
// needs the shadow light (sun by day, moon at night).
uniform vec3 shadowLightPosition;
#define BLK_VERTEX
#include "/lib/block_lighting.glsl"
#endif
#ifdef TERRAIN_GBUFFER
#if defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL)
// x shade level, y direct amount, z direct light amount k (per frame), w plant up-blend (per block).
flat out vec4 vBlkFace;
#endif
#ifdef BLOCK_MICRO_DETAIL
// Micro-detail values of this block (BlkMaterial in lib/block_lighting.glsl).
flat out vec4 vBlkDetail;
flat out vec4 vBlkAmount;
flat out vec4 vBlkColor;
flat out vec3 vBlkShape;
#endif
#endif
#if defined(TERRAIN_GBUFFER) && defined(CHROMATIC_LIGHT)
// Update 5, the chromatic light's block-light colour ramp (layer 4) of this vertex's block light level, times the End's
// shorter reach (lib/fake_gi.glsl): evaluated here once per vertex and interpolated (the level itself is interpolated
// the same way), so the pixels pay only a multiply. The Nether keeps NETHER_WARM_LIGHT (no ramp there).
uniform float atmosEnd;
uniform float atmosNether;
#include "/lib/fake_gi.glsl"
out vec3 vGiRamp;
#endif
#if defined(WATER_GBUFFER) && (defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL))
// Ice and glass in the translucent program: the material only (its values are looked up per pixel
// there, which keeps this program's interpolators within the minimum every driver supports).
flat out int vBlkMaterial;
#endif

#if defined(WATER_GBUFFER) && defined(WAVE_LIGHTING)
// Iris attribute: centre of this quad's atlas sprite. With the vertex UV it gives the
// sprite half-extent, which keeps the wave pseudo-normal taps inside the sprite.
in vec4 mc_midTexCoord;
out vec2 vMidTexCoord;
out vec2 vSpriteHalf;
#endif

#ifdef AMBIENCE_COLORS
// Palette sunlight and sky light for the terrain light response (same for every vertex).
flat out vec3 vAmbSunLight;
flat out vec3 vAmbSkyLight;
#endif
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS)
// Ambient light for the shadow colours (terrain only): the palette sky light with the biome
// haze tint, or the vanilla sky colour without the Ambience colours.
flat out vec3 vAmbShadowLight;
#ifndef AMBIENCE_COLORS
uniform vec3 skyColor;
#endif
#endif
#if defined(ENTITY_GBUFFER) && defined(EMISSIVE_GLOW)
// Update 4: light-emitting mobs and items (gbuffers_textured_lit: entities, items, the hand). Iris and
// Vitrail hand the entity and item numbers of entity.properties / item.properties to the vertex stage
// (a lane of the entity mesh), so they are read here and handed on flat: 1 = glows (number 9, the
// emissive class of block.properties; a number of 1000 or more decodes its class as (n - 1000) % 10,
// as block.properties does).
uniform int entityId;
uniform int currentRenderedItemId;
flat out float vGlowKind;
#endif
#if defined(WATER_GBUFFER) && defined(WATER_REFLECTION_IMPROVEMENT)
// Palette sky for the improved Tier-1 water reflection.
flat out vec3 vAmbZenith;
flat out vec3 vAmbMid;
flat out vec3 vAmbHorizon;
flat out vec3 vAmbGlow;
flat out vec3 vAmbCloudTop;
flat out vec3 vAmbCloudUnder;
flat out float vAmbGolden;
#endif

#include "/lib/shadow_distortion.glsl"

out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vNormalView;
out vec3 vWorldPosition;
out vec3 vPlayerPosition;
out vec4 vShadowClip;
out vec3 vViewPosition;
out vec3 vWorldNormal;
out float vIsFluid;
out float vSunElevation;
out float vViewDistance;
out float vIsFoliage;
out float vIsThin;
out float vMaterialGroup;

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPosition = gbufferModelViewInverse * viewPosition;

    gl_Position = gl_ProjectionMatrix * viewPosition;
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;
    vec3 transformedNormal = gl_NormalMatrix * gl_Normal;
    vNormalView = transformedNormal * inversesqrt(max(dot(transformedNormal, transformedNormal), 0.000001));
    vWorldNormal = mat3(gbufferModelViewInverse) * vNormalView;
    vViewPosition = viewPosition.xyz;
    vViewDistance = length(viewPosition.xyz);
    vec3 worldSun = mat3(gbufferModelViewInverse) * sunPosition;
    vSunElevation = worldSun.y * inversesqrt(max(dot(worldSun, worldSun), 0.000001));
    vWorldPosition = cameraPosition + playerPosition.xyz;
    vPlayerPosition = playerPosition.xyz;
    vec4 shadowClip = shadowProjection * shadowModelView * playerPosition;
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    vShadowClip = shadowClip;
    vIsFluid = 0.0;
    vIsFoliage = 0.0;
    vIsThin = 0.0;
    vMaterialGroup = 0.0;
#ifdef WATER_GBUFFER
    // Iris sets mc_Entity.y = 1 on fluid-renderer geometry (-1 on blocks). Lava renders in
    // the solid layer, so in this translucent program any fluid quad is water: source,
    // flowing, waterlogged blocks and every visible face. block.1 (ID 1) is a fallback.
    vIsFluid = (mc_Entity.y > 0.5 || abs(mc_Entity.x - 1.0) < 0.5) ? 1.0 : 0.0;
    // The legacy class (equal to mc_Entity.x for IDs 1-9 and unmapped blocks, as before).
    int blkClass;
    int blkMaterialId;
    blkDecode(mc_Entity.x, blkClass, blkMaterialId);
    vMaterialGroup = float(blkClass);
    vIsThin = blkClass == 8 ? 1.0 : 0.0;
#if defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL)
    vBlkMaterial = blkMaterialId;
#endif
#ifdef WAVE_LIGHTING
    vMidTexCoord = (gl_TextureMatrix[0] * vec4(mc_midTexCoord.xy, 0.0, 1.0)).xy;
    vSpriteHalf = abs(vTexCoord - vMidTexCoord);
#endif
#endif
#ifdef TERRAIN_GBUFFER
    // The legacy class (equal to mc_Entity.x for IDs 1-9 and unmapped blocks, as before) and the
    // Update 2B micro-detail material.
    int blkClass;
    int blkMaterialId;
    blkDecode(mc_Entity.x, blkClass, blkMaterialId);
    vMaterialGroup = float(blkClass);
    vIsFoliage = blkClass == 2 ? 1.0 : 0.0;
    vIsThin = (blkClass == 3 || blkClass == 8) ? 1.0 : 0.0;
#if defined(DIRECTIONAL_LIGHTING) || defined(BLOCK_MICRO_DETAIL)
    // Cross-shaped plants (grass, ferns, flowers, crops) are lit through an
    // up-blended normal; vines (class 3 too) are flat on walls and keep their own normal.
    bool blkCrossPlant = blkClass == 3 && (blkMaterialId == 0 || (blkKindFlags(blkMaterialId) & 2) != 0);
    vBlkFace = vec4(blkFaceLightAmount(), blkCrossPlant ? PLANT_NORMAL_UP_BLEND : 0.0);
#endif
#ifdef BLOCK_MICRO_DETAIL
    BlkMaterial blkM = blkMaterial(blkMaterialId, vWorldNormal);
    vBlkDetail = blkM.detail;
    vBlkAmount = blkM.amount;
    vBlkColor = blkM.color;
    vBlkShape = blkM.shape;
#ifdef FOLIAGE_SPARKLE
    // Moss carpet, lily pads and mangrove roots get the thin-block back-light of the plants
    // (SUBSURFACE_TRANSMISSION) as their foliage back-light.
    if (blkClass == 0 && (blkKindFlags(blkMaterialId) & 16) != 0) vIsThin = 1.0;
#endif
#endif
#endif

#if defined(TERRAIN_GBUFFER) && defined(CHROMATIC_LIGHT)
    float giVertexLevel = clamp(vLightCoord.x * 16.0 - 0.5, 0.0, 15.0);
    vGiRamp = vec3(1.0);
    if (atmosEnd > 0.5) {
        vGiRamp = giRampHue(giVertexLevel, giHexColor(END_RAMP_NEAR_COLOR), giHexColor(END_RAMP_MID_COLOR), giHexColor(END_RAMP_FAR_COLOR)) *
                  giRampGainEnd(giVertexLevel);
    } else if (atmosNether < 0.5) {
        vGiRamp = giRampHue(giVertexLevel, giHexColor(RAMP_NEAR_COLOR), giHexColor(RAMP_MID_COLOR), giHexColor(RAMP_FAR_COLOR));
    }
#endif
#if defined(ENTITY_GBUFFER) && defined(EMISSIVE_GLOW)
    int glowItem = currentRenderedItemId;
    int glowItemClass = glowItem >= 1000 ? (glowItem - 1000) % 10 : glowItem;
    vGlowKind = (entityId == 9 || glowItemClass == 9) ? 1.0 : 0.0;
#endif
#if defined(WATER_GBUFFER) && defined(WATER_REFLECTION_IMPROVEMENT)
    // Biome ambience follows into the water reflection only with BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION.
    AmbPalette ambPal = ambiencePaletteBiome(ambSunDirection(), AMB_WATER_BIOME);
    vAmbZenith = ambPal.zenith;
    vAmbMid = ambPal.mid;
    vAmbHorizon = ambPal.horizon;
    vAmbGlow = ambPal.glow;
    vAmbCloudTop = ambPal.cloudTop;
    vAmbCloudUnder = ambPal.cloudUnder;
    vAmbGolden = ambPal.golden;
#ifdef AMBIENCE_COLORS
    vAmbSunLight = ambPal.sunLight;
    vAmbSkyLight = ambPal.skyLight;
#endif
#elif defined(AMBIENCE_COLORS)
    AmbTime ambT = ambTime(ambSunDirection());
    vAmbSunLight = ambColor(ambT, AMB_SUN_LIGHT);
    vAmbSkyLight = ambSkyLightColor(ambT);
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS)
    vAmbShadowLight = ambShadowAmbient(ambT);
#endif
#endif
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS) && !defined(AMBIENCE_COLORS)
    vAmbShadowLight = max(skyColor, vec3(0.02));
#endif
}
