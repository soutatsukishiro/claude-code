// Update 2B: directional face lighting (DIRECTIONAL_LIGHTING) and micro-detail lighting
// (BLOCK_MICRO_DETAIL) on blocks.
//
// Included by lib/gbuffers.vsh (with BLK_VERTEX: the per-frame light amount and the per-block
// material values, passed on as flat varyings) and by lib/gbuffers_forward.fsh (the per-pixel
// terms), only in the terrain program (blocks, block entities, cutout leaves and plants) and the
// translucent program (ice, glass, slime, honey; never on water). Entities, the hand and particles
// never include it.
//
// Why the faces looked alike before: Iris 1.11.7 replaces vanilla's per-face shade (top 1.0,
// north/south 0.8, east/west 0.6, bottom 0.5) by the top value for every face unless a pack sets
// oldLighting=true (Iris's MixinClientLevel on CardinalLighting.byFace; checked in the jars), so the
// vertex colour carries only the biome tint and the ambient occlusion. Lighting by face direction
// is done here instead, on the sky-lit part of the vanilla lightmap, so it is never applied twice.

#include "/lib/block_tables.glsl"

// The moon for the face light at night (neither including file declares these).
uniform int moonPhase;
#ifdef MOON_RAYS
uniform vec3 moonPosition;
#endif

// Faces turned straight down get this share of the sky light an upward face gets from the sky
// dome; side faces get halfway (0.85).
const float BLK_HEMI_GROUND = 0.70;
// In clear daylight a face turned away from the sun keeps 1 - BLK_SHADE_DROP of the flat light
// (0.66 at FACE_CONTRAST 1: exactly how deep the previous cast shadows were on a sun-facing face),
// and a face turned straight to the sun gets 1 + DIRECTIONAL_LIGHT_STRENGTH (the previous lift).
const float BLK_SHADE_DROP = 0.34 * FACE_CONTRAST;
const float BLK_DIRECT = DIRECTIONAL_LIGHT_STRENGTH + BLK_SHADE_DROP;
const vec3 BLK_MOON_COLOR = vec3(0.78, 0.85, 1.00);
const vec3 BLK_TORCH_COLOR = vec3(1.00, 0.72, 0.42);
// Update 5: the colour of the torch glints (the fixed torch colour, or the block light's own colour at this level
// with CHROMATIC_LIGHT and GI_MICRODETAIL_RESPONSE: lib/gbuffers_forward.fsh defines it before this file).
#ifndef BLK_TORCH_HUE
#define BLK_TORCH_HUE BLK_TORCH_COLOR
#endif
// Furrow tilt per texel column of the farmland top (both farmland textures), toward +x (u runs along
// world x on an upward face: FaceBakery.defaultFaceUV). From the column luminance profile of the
// 26.3 textures used as a height map: grooves at columns 3-4 and 11-12, ridges at 0, 7-8 and 14-15.
const float BLK_FURROW_TILT[16] = float[16](0.07, 0.59, 1.00, 0.37, -0.48, -0.73, -0.52, -0.26,
                                            0.10, 0.55, 0.93, 0.44, -0.59, -0.97, -0.50, 0.00);

// Splits a block ID (mc_Entity.x) into the legacy class (what every other system reads, exactly
// as before) and the micro-detail material (block.properties: ID = 1000 + 10 x material + class).
void blkDecode(float entityId, out int cls, out int material) {
    int id = int(floor(entityId + 0.5));
    cls = id;
    material = 0;
    if (id >= 1000) {
        int rel = id - 1000;
        cls = rel % 10;
        material = rel / 10;
        if (material >= BLK_MATERIAL_COUNT) material = 0;
    }
}

int blkKindFlags(int material) {
    return int(BLK_KIND_C[BLK_MATERIAL_KIND[material]].w + 0.5);
}

// Direct light of a face from its N.L: Lambert with a soft wrap that fades in over the first 0.1 of
// N.L, so the terminator is soft while faces turned away from the light and faces edge-on to it get no
// direct light at all (only the ambient). Edge-on faces never read the shadow map, so a wrap reaching
// below N.L = 0 would light them inside cast shadows.
float blkWrap(float NdotL) {
    return max(NdotL, 0.0) * (1.0 - DIRECTIONAL_WRAP) + DIRECTIONAL_WRAP * smoothstep(0.0, 0.10, NdotL);
}

// Moon light for the face light and the night glints: the moon light of Update 2A (night, dark
// sky, altitude, phase, rain, thunder, MOON_LIGHT_INTENSITY), or without MOON_RAYS the moon
// opposite the sun and the vanilla phase brightness.
float blkMoonLight(vec3 sunDir) {
#ifdef MOON_RAYS
    return ambMoonLight(ambCelestialDirection(moonPosition), sunDir, moonPhase);
#else
    float night = 1.0 - smoothstep(-0.139, 0.105, sunDir.y);
    float weather = (1.0 - clamp(rainStrength, 0.0, 1.0)) * (1.0 - 0.90 * clamp(thunderStrength, 0.0, 1.0));
    return night * smoothstep(0.0, 0.10, -sunDir.y) * ambMoonBrightness(moonPhase) * weather;
#endif
}

// The light of this frame for the face model, the same for every vertex:
//   x = shade level: the light an upward face gets without the direct sun (its sky ambient),
//   y = direct amount k x BLK_DIRECT, z = k, the direct light amount (1 = clear sun, 0 = none).
// One light at a time: shadowLightPosition is the sun while it is up and the moon after (Iris
// switches at the horizon), and k is 0 on both sides of that switch (the sun's k fades over its
// last 4 degrees, the moon's starts from 0 at the horizon), so the handover never pops. The shade
// level keeps an unshadowed upward face exactly as bright as the previous flat light plus the
// previous lift (1 + DIRECTIONAL_LIGHT_STRENGTH x sun height) at every sun height, so the landscape
// keeps its exposure; walls get the contrast. Weather: the same rain and thunder weights as the
// entity-shadow strength of the shadow colours.
vec3 blkFaceLightAmount() {
    vec3 sunDir = ambSunDirection();
    vec3 lightDir = mat3(gbufferModelViewInverse) * shadowLightPosition;
    lightDir *= inversesqrt(max(dot(lightDir, lightDir), 1.0e-6));
    float weather = (1.0 - 0.75 * ambRain()) * (1.0 - 0.40 * clamp(thunderStrength, 0.0, 1.0));
    float k = sunDir.y > 0.0 ? smoothstep(0.0, 0.07, sunDir.y) * weather : MOON_FACE_CONTRAST * blkMoonLight(sunDir);
    float wrapUp = blkWrap(lightDir.y);
    float shade = 1.0 + k * (DIRECTIONAL_LIGHT_STRENGTH * max(lightDir.y, 0.0) - BLK_DIRECT * wrapUp + AMBIENT_AMOUNT_BIAS);
    return vec3(shade, k * BLK_DIRECT, k);
}

// Light factor of a face on the sky-lit part of the lightmap: hemispherical sky ambient plus the
// direct sun (wrapped, times its visibility), never below SHADE_FLOOR.
float blkFaceFactor(vec3 amount, vec3 normal, float NdotL, float visibility) {
    float wrapL = blkWrap(NdotL);
    float hemi = mix(BLK_HEMI_GROUND, 1.0, normal.y * 0.5 + 0.5);
    return max(amount.x * hemi + amount.y * visibility * wrapL, SHADE_FLOOR);
}

// Per-block micro-detail values (computed once per vertex in the terrain program).
struct BlkMaterial {
    vec4 detail;  // x, y: detail mask thresholds (texture luminance); z: glint density; w: micro-normal tilt
    vec4 amount;  // x: glint strength; y: sheen strength; z: sheen lobe start (cos); w: sky reflection
    vec4 color;   // rgb: glint colour; a: share of the lightened albedo in it
    vec3 shape;   // x, y: glint lobe (cos where it starts, cos where it is full); z: flags + 32 x kind
};

BlkMaterial blkMaterial(int material, vec3 normalWorld) {
    BlkMaterial m;
    m.detail = vec4(2.0, 3.0, 0.0, 0.0);
    m.amount = vec4(0.0);
    m.color = vec4(0.0);
    m.shape = vec3(0.999, 1.0, 0.0);
    int kind = BLK_MATERIAL_KIND[material];
    vec4 a = BLK_KIND_A[kind];
    vec4 b = BLK_KIND_B[kind];
    vec4 c = BLK_KIND_C[kind];
    int type = int(a.x + 0.5);
    float scale = -1.0;
#ifdef GLITTER_BLOCKS
    if (type == 1) scale = GLITTER_STRENGTH;
#endif
#ifdef SHEEN_BLOCKS
    if (type == 2) scale = SHEEN_STRENGTH;
#endif
#ifdef GLOSS_BLOCKS
    if (type == 3) scale = GLOSS_BLOCK_STRENGTH;
#endif
#ifdef FOLIAGE_SPARKLE
    if (type == 4) scale = FOLIAGE_STRENGTH;
#endif
    if (kind == 0 || scale < 0.0) return m;
    vec4 stats = BLK_MATERIAL_STATS[material];
    bool endFace = abs(normalWorld.y) > 0.5;
    float mean = endFace ? stats.z : stats.x;
    float spread = endFace ? stats.w : stats.y;
    int flags = int(c.w + 0.5);
    float density = min(a.w * MAX_GLINT_COVERAGE * GLINT_DENSITY_SCALE, MAX_GLINT_COVERAGE);
#if MICRO_DETAIL_QUALITY == 1
    // LOW: glints (and so the per-texel hash) only where the kind allows it (sand, red sand).
    if ((flags & 8) == 0) density = 0.0;
#endif
    float lobe = max(radians(b.y) * BLOCK_GLINT_SIZE, 0.01);
    m.detail = vec4(mean + a.y * DETAIL_THRESHOLD * spread, mean + a.z * DETAIL_THRESHOLD * spread, density, b.x);
    m.amount = vec4(b.z * scale, c.x * scale, c.y, c.z * scale);
    m.color = vec4(BLK_KIND_COLOR[kind], b.w);
    m.shape = vec3(cos(min(1.4 * lobe, 1.5)), cos(0.6 * lobe), float(flags + 32 * kind));
    return m;
}

#ifndef BLK_VERTEX
// ---------------------------------------------------------------------------------------
// Fragment stage.

#ifdef BLOCK_DEBUG
// Intermediates for the debug views (BLOCK_DEBUG_MODE).
float gBlkDebugD = 0.0;
float gBlkDebugRaw = 0.0;
float gBlkDebugLevel = 0.0;
float gBlkDebugFoot = 1.0;
float gBlkDebugDist = 1.0;
float gBlkDebugSheen = 0.0;
vec3 gBlkDebugId = vec3(0.0);
#endif

uint blkHash(ivec3 p, uint seed) {
    uint h = uint(p.x) * 0x8DA6B343u ^ uint(p.y) * 0xD8163841u ^ uint(p.z) * 0xCB1AB31Fu ^ seed * 0x27D4EB2Fu;
    h ^= h >> 16u;
    h *= 0x7FEB352Du;
    h ^= h >> 15u;
    h *= 0x846CA68Bu;
    h ^= h >> 16u;
    return h;
}

vec3 blkLighten(vec3 albedo) {
    return mix(albedo / max(max(albedo.r, max(albedo.g, albedo.b)), 1.0e-3), vec3(1.0), 0.35);
}

struct BlkDetail {
    float sheen;  // multiplies the lit surface (1 + sheen)
    vec3 add;     // glints and sky reflection, added like a highlight
};

// Micro-detail of one pixel. Everything comes from the vanilla texture (luminance against the
// material's measured mean) and a static per-texel hash; there are no PBR maps.
//   rawTexel: texture only (no tint, no AO); albedo: texel x vertex colour; N: geometric world
//   normal; L: world light direction; NdotL: signed N.L of the face; visibility: shadow map x cloud
//   shadow (the value the face light uses); skyLight / skyExposure: sky-light weights; torchWeight:
//   where block light dominates; lightHue: sun or moon colour; zenith / horizon: sky colours for the
//   reflection; dpDx / dpDy: screen derivatives of the position (taken before any discard).
BlkDetail blkMicroDetail(BlkMaterial m, vec3 amount, vec4 rawTexel, vec3 albedo, vec3 N, vec3 L, float NdotL,
                         float visibility, float skyLight, float skyExposure, float torchWeight, vec3 lightHue,
                         vec3 zenith, vec3 horizon, vec3 dpDx, vec3 dpDy, float overworld) {
    BlkDetail r;
    r.sheen = 0.0;
    r.add = vec3(0.0);
    int kindFlags = int(m.shape.z + 0.5);
    int flags = kindFlags - (kindFlags / 32) * 32;

    // Detail mask D: only texels lighter than the texture's own mean (grains, speckles, lit leaf
    // texels, ridges) are eligible. At distance the mipmaps average them away, so D fades by itself.
    float luminance = dot(rawTexel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float D = smoothstep(m.detail.x, m.detail.y, luminance);

    // Texel frame. Axis-aligned faces: the 16-per-block world texel grid (the same grid as the
    // texture's texels on full blocks, slabs, stairs and snow layers), from the integer camera block
    // plus a camera-relative remainder, so it is exact at any distance from the origin; half a texel
    // into the block along the normal, so the face plane never sits on a rounding edge. Other faces
    // (cross-shaped models such as amethyst buds): the atlas texel plus the block position.
    vec3 Nabs = abs(N);
    bool axisFace = max(Nabs.x, max(Nabs.y, Nabs.z)) > 0.999;
    int axis = Nabs.y >= max(Nabs.x, Nabs.z) ? 1 : (Nabs.x >= Nabs.z ? 0 : 2);
    vec3 inside = cameraPositionFract + vPlayerPosition - N * (0.5 / 16.0);
    vec3 cell = floor(inside * 16.0);
    vec3 viewPoint = vPlayerPosition;
    ivec3 texelId = ivec3(cell) + cameraPositionInt * 16;
    uint seed = uint(axis * 2 + (N[axis] > 0.0 ? 1 : 0) + 1);
    if (axisFace) {
        // The view vector of the texel centre: one glint state per texel (a hard texel square).
        viewPoint = (cell + 0.5) * (1.0 / 16.0) - cameraPositionFract;
        viewPoint[axis] = vPlayerPosition[axis];
    } else {
        ivec2 atlasTexel = ivec2(floor(vTexCoord * vec2(textureSize(gtexture, 0))));
        texelId = ivec3(floor(cameraPositionFract + vPlayerPosition)) + cameraPositionInt;
        seed = blkHash(ivec3(atlasTexel, 7), seed);
    }
    vec3 V = -viewPoint * inversesqrt(max(dot(viewPoint, viewPoint), 1.0e-8));
    vec3 H = L + V;
    H *= inversesqrt(max(dot(H, H), 1.0e-8));

    float lightK = amount.z * overworld;
    float underwater = isEyeInWater == 1 ? 0.3 : 1.0;
    // Fades: a texel smaller than about a pixel (distance, grazing angles) cannot hold a glint
    // without moire or shimmer, and a second distance fade as a safety.
    float footprint = 16.0 * max(length(dpDx), length(dpDy));
    float footFade = 1.0 - smoothstep(0.9, 2.0, footprint);
    float distFade = 1.0 - smoothstep(float(GLINT_FADE_START), float(GLINT_FADE_END), vViewDistance);
#ifdef BLOCK_DEBUG
    gBlkDebugD = D;
    gBlkDebugFoot = footFade;
    gBlkDebugDist = distFade;
#if BLOCK_DEBUG_MODE == 8
    uint idColor = blkHash(texelId, seed);
    gBlkDebugId = vec3(float(idColor & 255u), float((idColor >> 8u) & 255u), float((idColor >> 16u) & 255u)) * (1.0 / 255.0);
#endif
#endif

    // Glints (glitter, gloss, the leaves' waxy texels): a static per-texel micro-normal; a texel
    // glints when it points along the half vector. The half vector is quantized to a coarse grid
    // (GLINT_ANGLE_STEPS), so a glint switches in discrete steps as the view moves and never
    // flickers with tiny motion, and the result has three levels: off, soft, bright.
    if (m.detail.z > 0.0 && D > 0.0 && footFade * distFade > 0.0) {
        uint h = blkHash(texelId, seed);
        if (float(h & 1023u) * (1.0 / 1024.0) < m.detail.z) {
            vec2 tilt = (vec2(float((h >> 10u) & 2047u), float((h >> 21u) & 2047u)) * (2.0 / 2047.0) - 1.0) * m.detail.w;
            vec3 T = cross(abs(N.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0), N);
            T *= inversesqrt(max(dot(T, T), 1.0e-8));
            vec3 micro = N + tilt.x * T + tilt.y * cross(N, T);
            micro *= inversesqrt(max(dot(micro, micro), 1.0e-8));
            vec3 Hq = floor(H * float(GLINT_ANGLE_STEPS) + 0.5);
            Hq *= inversesqrt(max(dot(Hq, Hq), 1.0e-8));
            float raw = smoothstep(m.shape.x, m.shape.y, dot(micro, Hq)) * D;
            float level = raw >= 0.70 ? 1.0 : (raw >= 0.30 ? 0.5 : 0.0);
            vec3 tint = mix(m.color.rgb, blkLighten(albedo), m.color.a);
            // Sun or moon glints: only on faces turned to the light, in its light (shadow map,
            // cloud shadow, weather through k), under the open sky.
            float sunGlint = level * m.amount.x * lightK * visibility * smoothstep(0.02, 0.15, NdotL) * skyLight;
            // Torch glints: block light has no direction, so the light is taken from the viewer.
            vec3 Vq = floor(V * float(GLINT_ANGLE_STEPS) + 0.5);
            Vq *= inversesqrt(max(dot(Vq, Vq), 1.0e-8));
            float rawTorch = smoothstep(m.shape.x, m.shape.y, dot(micro, Vq)) * D;
            float levelTorch = rawTorch >= 0.70 ? 1.0 : (rawTorch >= 0.30 ? 0.5 : 0.0);
            r.add = tint * (lightHue * sunGlint + BLK_TORCH_HUE * (levelTorch * TORCH_GLINT * torchWeight * m.amount.x));
            r.add *= footFade * distFade * underwater;
#ifdef BLOCK_DEBUG
            gBlkDebugRaw = raw;
            gBlkDebugLevel = level;
#endif
        }
    }

    // Sheen (sheen kinds, foliage, metals): the lighter texels catch a soft sun-facing highlight
    // that follows the face light. Farmland ridges get the furrow tilt of their texel column, so the
    // furrow sides turned to the sun light up (faded out where texels get smaller than a pixel).
    if (m.amount.y > 0.0 && D > 0.0) {
        vec3 Ns = N;
        if ((flags & 1) != 0 && N.y > 0.9) {
            Ns = N + vec3(BLK_FURROW_TILT[int(cell.x) & 15] * 0.6 * footFade, 0.0, 0.0);
            Ns *= inversesqrt(dot(Ns, Ns));
        }
        // Half of it follows the face light alone (the lit side's lighter texels always catch the sun),
        // half grows with a soft Blinn-Phong lobe toward the sun's reflection (sheenC sets its width).
        float lobe = clamp((dot(Ns, H) - m.amount.z) / max(1.0 - m.amount.z, 1.0e-3), 0.0, 1.0);
        float wrapS = blkWrap(dot(Ns, L));
        r.sheen = D * (0.5 + 0.5 * lobe) * m.amount.y * lightK * visibility * wrapS * skyLight * underwater;
#ifdef BLOCK_DEBUG
        gBlkDebugSheen = r.sheen;
#endif
    }

    // Faint analytic sky reflection (gloss kinds): Fresnel-weighted sky colour along the reflected
    // view; on ice and glass over the whole face, on obsidian, blackstone, basalt, quartz and
    // prismarine only on their detail texels (the speckles catch the sky).
    if (m.amount.w > 0.0) {
        float f1 = 1.0 - max(dot(N, V), 0.0);
        float f2 = f1 * f1;
        float fresnel = 0.04 + 0.96 * f2 * f2 * f1;
        vec3 R = reflect(-V, N);
        vec3 sky = mix(horizon, zenith, smoothstep(-0.05, 0.60, R.y));
        float mask = (flags & 4) != 0 ? D : 1.0;
        r.add += sky * (fresnel * m.amount.w * mask * skyExposure * underwater);
    }
    return r;
}
#endif
