#version 330 compatibility

// Update 4: glowing mob eyes (enderman, spider, cave spider, phantom, ender dragon). The game draws
// them as a light, blended additively over the skin at full light (Iris and Vitrail keep that blend
// for this program). The vertex is placed with exactly the arithmetic of lib/gbuffers.vsh (model-view,
// then projection), so the eyes land on the skin's depth to the last bit (no flicker, no z-fighting).

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = gl_ProjectionMatrix * viewPosition;
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
}
