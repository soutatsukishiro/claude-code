#version 330 compatibility

// Update 4: glowing mob eyes, as on your Vibrant Visuals reference (image 4): the enderman's eyes are a
// hot pinkish white (#F4B8FF) with a soft glow about 12 px around them at 1080p (the glow: colortex3,
// blurred in composite, added in final). The eye texture is brightened and given a pale pink core (Update
// 4.2); the additive blend adds it to the skin below. Lit by nothing (the eyes are a
// light), fogged in final like everything at their depth.

#include "/lib/settings.glsl"

uniform sampler2D gtexture;

in vec2 vTexCoord;
in vec4 vColor;

// Eye brightness and its pale core (the hot pinkish centre of the reference's eyes). Update 4.2: the eye is
// moved halfway toward a pale pink of its own brightness before the lift, so it reaches #FFB0FF-ish like the
// reference (#F4B8FF) instead of clipping to pure white (your image 8: 255 255 255).
const float EYE_BRIGHTNESS = 1.15;
const vec3 EYE_CORE_TINT = vec3(1.00, 0.75, 1.00);
// The eyes' glow source, a share of the eye's own colour: the calibration point of EMISSIVE_GLOW_STRENGTH
// (with composite's kernel it gives the reference's eye glow).
const float EYE_GLOW_GAIN = 0.60;

#ifdef EMISSIVE_GLOW
/* RENDERTARGETS: 0,3 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outGlow;
#else
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
#endif

void main() {
    vec4 texel = texture(gtexture, vTexCoord) * vColor;
    float eyePeak = max(texel.r, max(texel.g, texel.b));
    vec3 eye = mix(texel.rgb, EYE_CORE_TINT * eyePeak, 0.5) * EYE_BRIGHTNESS;
    outColor = vec4(eye, texel.a);
#ifdef EMISSIVE_GLOW
    outGlow = vec4(eye * EYE_GLOW_GAIN, texel.a);
#endif
}
