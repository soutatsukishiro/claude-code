#version 330 compatibility

// Update 5: the fake GI at half resolution (GI_RESOLUTION 2) needs only the full-screen quad.

void main() {
    gl_Position = ftransform();
}
