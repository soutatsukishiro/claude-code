#version 330 compatibility
// Update 4: the entity layer (entities, items, the hand, particles) reads the entity and item numbers
// for the emissive glow (lib/gbuffers.vsh).
#define ENTITY_GBUFFER
#include "/lib/gbuffers.vsh"
