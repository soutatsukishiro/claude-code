#version 330 compatibility

// Update 5: the fake GI's low-resolution blur at half resolution (GI_RESOLUTION 2), right after its gather (composite3):
// the 4 x 4 block around each texel by depth, which resolves the gather's 4 x 4 tile of patterns (lib/fake_gi.glsl,
// fakeGiBlur). At quarter resolution the same blur is a second output of composite1. Reads and writes only colortex4
// (Iris ping-pongs it). shaders.properties runs it only with GI_RESOLUTION 2; were it run anyway, it would write
// nothing.

#include "/lib/settings.glsl"

#ifdef GI_HALF
uniform sampler2D colortex4;
#define GI_BLUR
#include "/lib/fake_gi.glsl"
#endif

/* RENDERTARGETS: 4 */
layout(location = 0) out vec4 giOut;

void main() {
#ifdef GI_HALF
#if defined(GI_DEBUG) && GI_DEBUG_MODE == 5
    giOut = texelFetch(colortex4, ivec2(gl_FragCoord.xy), 0);
#else
    giOut = fakeGiBlur(ivec2(gl_FragCoord.xy));
#endif
#else
    discard;
#endif
}
