#version 330 compatibility

#define ENTITY_LAYER
#include "/lib/gbuffers_forward.fsh"

// Update 4: with EMISSIVE_GLOW the glow source goes to colortex3 (last output, written last, so the
// rank of every output equals its location under Vitrail as well).
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
#ifdef EMISSIVE_GLOW
/* RENDERTARGETS: 0,2,3 */
#else
/* RENDERTARGETS: 0,2 */
#endif
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outDebugMaterial;
#ifdef EMISSIVE_GLOW
layout(location = 2) out vec4 outGlow;
#endif
#else
#ifdef EMISSIVE_GLOW
/* RENDERTARGETS: 0,3 */
#else
/* RENDERTARGETS: 0 */
#endif
layout(location = 0) out vec4 outColor;
#ifdef EMISSIVE_GLOW
layout(location = 1) out vec4 outGlow;
#endif
#endif

void main() {
    vec3 causticsDebug;
    outColor = shadeFragment(causticsDebug);
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
    // This route has no terrain block ID; show it as unclassified in the diagnostic.
    outDebugMaterial = vec4(0.08, 0.08, 0.08, 1.0);
#endif
#ifdef EMISSIVE_GLOW
    // Blended like the colour (translucent mobs and particles cover the glow behind them by their alpha).
    outGlow = vec4(gGlowSource, outColor.a);
#endif
}
