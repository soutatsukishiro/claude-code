#version 330 compatibility

// Shadow pass for entities (Iris program shadow_entities; without it Iris uses shadow.vsh).
// Identical to shadow.vsh: same projection, same distortion, same shadow-map position.

#include "/lib/settings.glsl"
#include "/lib/shadow_distortion.glsl"

#ifdef FLASH_SHADOWS
// Update 3, the End only: as in shadow.vsh, nothing is rasterized there between flashes.
uniform float atmosEnd;
uniform float vclFlash;
#endif

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    gl_Position = ftransform();
    gl_Position.xyz = distortShadowClip(gl_Position.xyz);
#ifdef FLASH_SHADOWS
    if (atmosEnd > 0.5 && vclFlash <= 0.0005) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif
}
