# v6: biome-dependent ambience (2026-10-04)

**Scope.** This round changes only:
- the sky colour;
- the fog colour and fog character;
- the cloud tint;
- their settings, presets and debug views.

It does not change the shadow system, the water system, plastic gloss, materials, vegetation,
bloom, particles, entities or the sun algorithm. The few lines outside the scope are listed
in section 8.

**Backup.** Your zipped v5 ("VanillaCinematicLite (4).zip") is extracted into
`backup/2026-10-04_before_biome_ambience/`, together with the README. Every file this round did
not touch is byte-identical to that copy.

**Status:**
- **Measured:** WebGL2 compile and link of all programs in 74 option sets (592 programs, 0
  failures), and a WebGL2 render of the biome palettes.
- **Not tested:** nothing has run inside Minecraft.
- **Estimates:** all performance numbers are estimates.

## 1. Capability check

- I cannot capture the Minecraft window, so I captured nothing from the game.
- Your desert screenshot was sampled pixel by pixel (WebP decoded locally).
- The biome facts below come from reading your Iris 1.11.7 jar and the 26.3 client jar.

## 2. Current state (your desert/badlands screenshot, measured)

| Element | Your estimate | Measured |
|---|---|---|
| Sky top | #6593E8 | **#6794E1** |
| Horizon sky | #A8B8E8 | **#C2C8DC** (centre), **#B6BFCE** (right): grey-lavender |
| Clouds | lavender | **#8A9CD2 / #8FA1D3** (blue-lavender) |
| Sunlit sand | #E8D088 | **#DCC690** |
| Shaded sand | #CFC9A8 | **#A9A07E** |
| Far terracotta hills | – | #745143 / #7B6256 (cooled by the haze) |
| Far sand plateau | – | #9A957D (the haze turns it grey-beige) |

Your analysis is correct. What else I see:
- The cool haze pulls the warm sand and terracotta toward grey at a distance.
- The badlands hills at the horizon keep a visible edge, because they lie inside the render
  distance.

How the code produced the cool look:
- **One shared palette.** The midday horizon was #A4B8EC.
- **A weak old biome ratio.** It was one 9-family ratio relative to #B8C8E8, applied at
  BIOME_TINT_STRENGTH × 2.5 = 0.55. The desert only got about half its shift, so its horizon
  stayed grey-lavender: #A4B8EC × (1.13, 1.03, 0.89) ≈ #B8BDD1, which matches your #B6BFCE.
- **Unreliable categories.** The ratio's families came from `biome_category`, which is
  unreliable in 26.3 (see section 4). Savanna was never recognised.
- **No fog character.** Nothing changed the fog density or falloff per biome (only jungle ×1.3
  and desert ×0.85 in the density).
- **One function for sky and fog.** This was already the case since v5, so there was no
  horizon break; the problem was only the colour.

## 3. Iris biome uniforms: what is real in 1.11.7 / 26.3

Read from `BiomeUniforms`, `IrisDefines`, `BiomeCategories` and `PropertiesPreprocessor` in your
Iris jar.

| Uniform / constant | Source | Verdict |
|---|---|---|
| `biome` (int) + `BIOME_<NAME>` | a map filled when each vanilla biome is registered; NAME = id path in upper case (BIOME_DESERT, BIOME_DAPPLED_FOREST, …) | **used**: exact, per biome |
| `biome_category` + `CAT_*` | an Iris if-chain over biome tags: snowy-village → ICY, is_hill → EXTREME_HILLS, is_taiga, is_ocean, is_jungle, is_forest, is_badlands → MESA, is_nether, is_end, is_beach, desert-pyramid → DESERT, is_river, surface-slime → SWAMP, no-zombie-siege → MUSHROOM, is_mountain, else PLAINS | **not used for the ambience.** `CAT_SAVANNA` exists but is **never assigned**, so savanna counts as PLAINS. Ice spikes → PLAINS, frozen ocean → OCEAN, snowy taiga → TAIGA, peaks → MOUNTAIN, caves → PLAINS. |
| `biome_precipitation` + `PPT_NONE/RAIN/SNOW` | `getPrecipitationAt(player position, sea level)` | **used**: dry biomes, and snow vs rain (height-aware) |
| `temperature`, `rainfall` | base temperature, downfall | not needed |

- **Option values in shaders.properties:** the properties preprocessor receives option values
  as macros, so `#if BIOME_TRANSITION_TIME == 10` works. Property lines themselves are never
  macro-expanded.
- **What I could not verify without the game:**
  - the exact easing curve of `smooth()` (it is time-based in seconds);
  - that `sqrt` is accepted in custom-uniform expressions (OptiFine spec; Iris implements it).

  If any custom uniform fails to load, the shaders detect the all-zero values and keep the base
  look instead of turning black.

**Limits, plainly:**
1. **Camera biome only.** Looking from a forest into a desert, you see forest haze. There is no
   cheap trick worth doing: Iris cannot tell you which biome is in the distance.
2. **The change happens over time.** Crossing a border, the look drifts over
   BIOME_TRANSITION_TIME (default 10 s). Rapid crossings average out smoothly, with no flicker.
3. **After a portal back to the Overworld,** the family weights start from zero, so the
   Overworld fades from the base look to the biome over the transition time. Dimension switches
   themselves are instant.

## 4. Gap table (midday, clear)

| Family | Before v6 (horizon / fog density) | v6 target (horizon / density) | Responsible |
|---|---|---|---|
| all | #A4B8EC × weak ratio (from broken categories) / ×1.0 (jungle 1.3, desert 0.85) | per family below | properties (old amb* uniforms) → new biome uniforms; `ambiencePalette` (old `ambBiomeRatio`) → `ambiencePaletteBiome`; `ambienceFog` |
| desert | ≈#B8BDD1 (measured #B6BFCE) / 0.85 | #E6D2B0 / 0.70, dust optional | same |
| savanna | #A4B8EC (savanna never recognised) / 1.0 | #EDCF9C / 0.80 | same |
| badlands | ≈#BDBAC8 / 1.0 | #E4BEA4 / 0.75 | same |
| jungle | ≈#93BCC8 / 1.3 | #9CCFCB / 1.25, scatter 1.2 | same |
| snowy, ice spikes | ice spikes treated as plains | #CDDAF0 / 1.15, falloff 0.9 | same |
| Nether (5 biomes) | one fixed red tint (warped forest reddened too) | per biome tint on the vanilla fog | `evaluateAtmosphereColor`, `evaluateSkyGradient` |
| End | fixed #614A94 tint | #1A1030 | same |

## 5. Code review

| # | File / place | Problem | Severity | Fix |
|---|---|---|---|---|
| 1 | shaders.properties, amb* and atmos* uniforms | Built on `biome_category`: CAT_SAVANNA never assigned (savanna = plains), ice spikes = plains, frozen ocean = ocean, caves = plains | high | ambience families now use `biome` + `BIOME_*` (exact). The atmos* uniforms are kept for out-of-scope users (golden grade, pollen, legacy haze); **reported, not changed** |
| 2 | atmosNether / atmosEnd | Smoothed over 20/10 s while atmosOverworld switched instantly: for up to 20 s after a portal the Nether or End had only part of its tint | medium | instant (`if(in(biome_category, CAT_NETHER), 1.0, 0.0)`) |
| 3 | ambience.glsl `ambBiomeRatio` | One ratio at 0.55 strength, broken categories, global lavender, evaluated per terrain vertex (9 families) | high | replaced by the CPU-blended palette (custom uniforms); terrain vertices are now cheaper |
| 4 | Families | The old ones overlapped (plains + forest + savanna + caves in one) and weights could exceed 1 | medium | 16 families + base; the weights sum to 1 by construction (each biome belongs to exactly one family, snowy taiga is split 0.65/0.35); any leftover goes to base |
| 5 | Sky vs fog | Already the same function since v5: no break, vanilla fog overridden, fog applied once | ok | biome tint applied to the palette before that function, so they stay identical |
| 6 | Nether/End tints (final.fsh) | Hard-coded colours ignoring the biome | medium | per-biome tint via `ambNetherFogTint()` / `ambEndFogTint()` on top of the vanilla fog colour, same strengths as before |
| 7 | Rain | Vanilla rain level is global: deserts went rainy grey | medium | `BIOME_PRECIPITATION`: with precipitation NONE the palette, fog and sun see no rain (thunder unchanged). Snowfall is brighter and whiter than rain. |
| 8 | Other hard-coded colours | Golden-hour grade, haze and sky tints are time-of-day effects, not biome effects. The legacy haze only runs with the Ambience fog off. The terrain sky light used the old ratio. | low | Golden: unchanged; the warm-biome golden weight now comes from the new families. Terrain sky light: faint new biome tint (×0.12), about the old strength. |
| 9 | Underwater, caves | Underwater: final skips fog (unchanged). Caves: `ambienceCaveLight` density reduction (unchanged). | ok | – |
| 10 | Properties | composite condition unaffected; all presets define all 211 options; BIOME_TINT_STRENGTH is now legacy-only (relabelled) | ok | – |

## 6. Palettes and mapping

Of your suggestions I kept all the colours. The mapping choices and new biomes:
- **Lukewarm ocean:** family 2 only (your list had it in both 1 and 2).
- **Stony shore:** family 1 (it is coastal).
- **Old-growth birch forest:** family 5.
- **Pale garden:** dark forest (6). Vanilla gives it a grey #B9B9B9 sky and #817770 fog, and
  the moody family suits it.
- **Dappled forest:** forest (5). It is new in 26.x; vanilla fog is #CCD8E2.
- **Sulfur caves:** base. It is new in 26.x, and cave fog is unchanged.
- **Snowy taiga:** 0.65 snowy + 0.35 taiga, which gives about your #C6D4E8.

The fog character values are your multipliers. I added mild sun-scatter and saturation values
where you gave none.

Measured vanilla fog colours (26.3 data):
- nether wastes #330808;
- crimson #330303;
- warped #1A051A;
- soul sand valley #1B4745;
- basalt #685F70.

Your Nether colours are mixed in at 0.30 on top of those, which keeps the mood.

| # | Family | Group | Zenith | Mid | Horizon = fog | Clouds | Density | Falloff | Sun scatter | Saturation | Dust |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Base / default | other | #6593EE | #85A8EE | #A5B8EE | #A9B3EE | x1.00 | x1.00 | x1.00 | x1.00 | 0 |
| 1 | Ocean, river, beach | ocean | #5E9AEA | #84B2EC | #A9C6EC | #B4C2EE | x1.00 | x1.00 | x1.00 | x1.00 | 0 |
| 2 | Warm and lukewarm ocean | ocean | #55A8EE | #80C0EC | #A8D6EA | #BCCAEE | x0.90 | x1.00 | x1.05 | x1.05 | 0 |
| 3 | Frozen and snowy lowlands | cold | #7A9EE6 | #A4BCEC | #CDDAF0 | #DCE2F4 | x1.15 | x0.90 | x0.90 | x0.95 | 0 |
| 4 | Plains, meadow | other | #6A9BF0 | #8FB0EE | #B0C4EC | #B4BEEE | x0.90 | x1.00 | x1.00 | x1.00 | 0 |
| 5 | Forest, birch, flower | other | #6593E4 | #86A8DC | #A8C2D8 | #AEBCE0 | x1.05 | x1.00 | x1.00 | x1.00 | 0 |
| 6 | Dark forest, pale garden | other | #5A7FC8 | #7B98C0 | #90A4BC | #9CAAD0 | x1.35 | x0.80 | x0.85 | x0.90 | 0 |
| 7 | Taiga | cold | #5F8AD8 | #82A0D2 | #A8BCD6 | #B0BCE0 | x1.10 | x1.00 | x0.95 | x0.95 | 0 |
| 8 | Jungle | humid | #4E9ADC | #78B6D6 | #9CCFCB | #B0D0E0 | x1.25 | x1.00 | x1.20 | x1.10 | 0 |
| 9 | Swamp, mangrove | humid | #6F8FB8 | #8DA6B2 | #A3B39A | #B0B8C8 | x1.40 | x0.75 | x0.90 | x0.90 | 0 |
| 10 | Desert | warm | #5C97E8 | #9DB2DE | #E6D2B0 | #E4D8EA | x0.70 | x1.00 | x1.30 | x1.00 | 1 |
| 11 | Savanna | warm | #5C98E6 | #A4B6D8 | #EDCF9C | #EBDDE0 | x0.80 | x1.00 | x1.30 | x1.00 | 0.5 |
| 12 | Badlands | warm | #6A98E4 | #A9B4D8 | #E4BEA4 | #E6D2DC | x0.75 | x1.00 | x1.25 | x1.00 | 0.8 |
| 13 | Windswept hills, stony peaks | other | #6A8FD8 | #8EA6D2 | #B4C0D6 | #B8C0E0 | x0.85 | x1.00 | x1.00 | x0.95 | 0 |
| 14 | Snowy slopes and peaks, grove | cold | #6C9AEC | #9CBAEE | #D4E2F6 | #E0E6F6 | x1.00 | x1.10 | x0.95 | x0.95 | 0 |
| 15 | Cherry grove | other | #7EA0EA | #B0B4E8 | #E8CCE6 | #F0D8EC | x0.95 | x1.00 | x1.05 | x1.00 | 0 |
| 16 | Mushroom fields | other | #8A8CE8 | #B0A4E8 | #D4BCE8 | #E0CCF0 | x1.00 | x1.00 | x1.00 | x1.00 | 0 |

| Biome (26.3 id) | Family |
|---|---|
| ocean | 1 Ocean, river, beach |
| deep_ocean | 1 Ocean, river, beach |
| cold_ocean | 1 Ocean, river, beach |
| deep_cold_ocean | 1 Ocean, river, beach |
| river | 1 Ocean, river, beach |
| beach | 1 Ocean, river, beach |
| stony_shore | 1 Ocean, river, beach |
| warm_ocean | 2 Warm and lukewarm ocean |
| lukewarm_ocean | 2 Warm and lukewarm ocean |
| deep_lukewarm_ocean | 2 Warm and lukewarm ocean |
| frozen_ocean | 3 Frozen and snowy lowlands |
| deep_frozen_ocean | 3 Frozen and snowy lowlands |
| frozen_river | 3 Frozen and snowy lowlands |
| snowy_plains | 3 Frozen and snowy lowlands |
| ice_spikes | 3 Frozen and snowy lowlands |
| snowy_beach | 3 Frozen and snowy lowlands |
| snowy_taiga | 3 Frozen and snowy lowlands (weight 0.65) |
| plains | 4 Plains, meadow |
| sunflower_plains | 4 Plains, meadow |
| meadow | 4 Plains, meadow |
| forest | 5 Forest, birch, flower |
| birch_forest | 5 Forest, birch, flower |
| old_growth_birch_forest | 5 Forest, birch, flower |
| flower_forest | 5 Forest, birch, flower |
| dappled_forest | 5 Forest, birch, flower |
| dark_forest | 6 Dark forest, pale garden |
| pale_garden | 6 Dark forest, pale garden |
| taiga | 7 Taiga |
| old_growth_pine_taiga | 7 Taiga |
| old_growth_spruce_taiga | 7 Taiga |
| snowy_taiga | 7 Taiga (weight 0.35) |
| jungle | 8 Jungle |
| bamboo_jungle | 8 Jungle |
| sparse_jungle | 8 Jungle |
| swamp | 9 Swamp, mangrove |
| mangrove_swamp | 9 Swamp, mangrove |
| desert | 10 Desert |
| savanna | 11 Savanna |
| savanna_plateau | 11 Savanna |
| windswept_savanna | 11 Savanna |
| badlands | 12 Badlands |
| eroded_badlands | 12 Badlands |
| wooded_badlands | 12 Badlands |
| windswept_hills | 13 Windswept hills, stony peaks |
| windswept_forest | 13 Windswept hills, stony peaks |
| windswept_gravelly_hills | 13 Windswept hills, stony peaks |
| stony_peaks | 13 Windswept hills, stony peaks |
| snowy_slopes | 14 Snowy slopes and peaks, grove |
| frozen_peaks | 14 Snowy slopes and peaks, grove |
| jagged_peaks | 14 Snowy slopes and peaks, grove |
| grove | 14 Snowy slopes and peaks, grove |
| cherry_grove | 15 Cherry grove |
| mushroom_fields | 16 Mushroom fields |
| nether_wastes | Nether: fog tint #5A1A12 (vanilla fog #330808) |
| crimson_forest | Nether: fog tint #6A1020 (vanilla fog #330303) |
| warped_forest | Nether: fog tint #12505A (vanilla fog #1A051A) |
| soul_sand_valley | Nether: fog tint #2A5A6A (vanilla fog #1B4745) |
| basalt_deltas | Nether: fog tint #4A4A52 (vanilla fog #685F70) |
| the_end | End: fog tint #1A1030 |
| end_highlands | End: fog tint #1A1030 |
| end_midlands | End: fog tint #1A1030 |
| small_end_islands | End: fog tint #1A1030 |
| end_barrens | End: fog tint #1A1030 |
| lush_caves | 0 Base (no sky palette; cave fog unchanged) |
| dripstone_caves | 0 Base (no sky palette; cave fog unchanged) |
| deep_dark | 0 Base (no sky palette; cave fog unchanged) |
| sulfur_caves | 0 Base (no sky palette; cave fog unchanged) |
| the_void | 0 Base (no sky palette; cave fog unchanged) |

Every one of the 67 biomes in 26.3 is mapped. Unknown or modded biomes give their weight to the
base family (the v5 look).

## 7. How it is applied (and what it costs)

- **CPU, once per frame** (Iris custom uniforms):
  - 16 smoothed family weights;
  - the gamma-2 blend of zenith, mid, horizon and cloud colours (sqrt of weighted squares, so
    desert ↔ ocean does not pass through a muddy grey);
  - the density, falloff, scatter, saturation and dust multipliers;
  - group weights (warm, cold, humid, ocean);
  - rain visibility and snowfall;
  - the Nether tint.
- **GPU:**
  - vertex shaders that already build the palette apply the tint (`pow(target/base, k)`);
  - per pixel the fog reads three finished uniforms;
  - there are no per-pixel or per-vertex loops over biomes.
- **Delta approach.** The biome tint multiplies your time-of-day, golden-hour and weather
  palettes:
  - full at midday;
  - about a third at sunrise and sunset (desert sunsets a little redder, jungle a little
    greener);
  - 15 % at night;
  - weaker and greyed in rain.

  At midday the result is exactly the family's target.
- **One function.** The horizon colour is the fog colour, so the horizon tint uses
  BIOME_FOG_STRENGTH. The mid sky uses BIOME_SKY_STRENGTH, and the zenith uses
  BIOME_SKY_STRENGTH × BIOME_ZENITH_SHIFT (0.35), so the sky stays blue.
- **Clouds.** They derive from the same palette, with the biome cloud tint
  (BIOME_CLOUD_TINT_STRENGTH).
- **Clamps.** Tint ratios are limited to 0.5–1.8, density to ×0.5–1.6, falloff to ×0.6–1.4,
  scatter to ×0.5–1.5 and saturation to 0.7–1.3. The fog end still follows the render distance.
- **Sun system.** Its algorithm is unchanged. It is fed through its existing functions in two
  ways:
  - the wide halo lightens the local, now biome-tinted, sky, so it adapts automatically;
  - the glow, disc and moon visibility read `ambRain()` instead of `rainStrength`, so a desert
    in rain keeps its sun along with its clear sky. These are `ambSunGlowVisibility`, the moon
    term in `ambCelestialGlow`, and `ambSunDisc`.
- **Estimated cost:**
  - well under 0.01 ms on a GTX 1050 Ti;
  - about 60 custom-uniform expressions per frame on the CPU, which is negligible;
  - terrain vertex work drops slightly, because the old 9-family ratio is gone.

  Not measured.

## 8. Water, and files changed

**Water code that reads the sky or fog function:**
1. **gbuffers_water's Tier-1 reflection**, via `waterSkyReflectionImproved` → `ambienceSky` with
   the palette from `lib/gbuffers.vsh`. Changed line: `ambiencePalette(...)` →
   `ambiencePaletteBiome(ambSunDirection(), AMB_WATER_BIOME)`.
2. **final.fsh screen-space reflection**, `skyTier1`. Changed line: `finalPalette()` →
   `finalWaterPalette()`.
3. **final.fsh fog-aware reflection segment.** Changed lines: the segment colour reads
   `finalWaterPalette()`. `ambienceSegmentTransmittance` uses the biome fog character only with
   the toggle on.
4. **Far water** takes the fog colour through final's fog block (FOG_ON_WATER). That is
   expected, and it follows the biome.

`BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION` (default ON) controls 1–3. When it is off, final gets
a biome-free palette (`vWater*` varyings) so the screen reflection still matches the water's
own Tier 1. The water's base colour, opacity, tint, waves and caustics are untouched.

| File | Status |
|---|---|
| lib/settings.glsl | changed: 17 new options, debug forcing, internal switches, BIOME_TINT_STRENGTH relabelled |
| lib/ambience.glsl | changed: biome uniforms, `ambBiome`, `ambRain`, tint helpers, `ambiencePaletteBiome`, fog character, dust, Nether/End tints. Cloud-shadow code unchanged. |
| final.vsh | changed: biome-free water palette when the toggle is off |
| final.fsh | changed: Nether/End tints, `finalWaterPalette`, 2 water lines (above), BIOME_DEBUG views |
| lib/gbuffers.vsh | 1 line (water palette, above) |
| gbuffers_clouds.fsh | 1 line: the cloud sun-side light uses `ambRain()` |
| shaders.properties | biome uniforms, instant Nether/End weights, screen, sliders, presets; old amb* uniforms removed |
| lang/en_us.lang | labels |
| shadow.*, lib/shadow_distortion.glsl, gbuffers_water.*, lib/water_reflection.glsl, lib/gbuffers_forward.fsh, gbuffers_terrain.*, gbuffers_textured_lit.*, composite.*, gbuffers_skybasic.*, gbuffers_clouds.vsh, block.properties | **unchanged** (byte-identical to the backup) |

- **Removed:** the old `amb*` uniforms in shaders.properties (ambOcean, ambSnow, ambForest,
  ambTaiga, ambJungle, ambDesert, ambMesa, ambSavanna, ambMountain).
- **Renamed:** none.

## 9. Settings, presets, debug

- **Menu:** Ambience → **Biome Ambience**.
  - BIOME_AMBIENCE
  - BIOME_SKY_STRENGTH (0.85)
  - BIOME_FOG_STRENGTH (1.00)
  - BIOME_CLOUD_TINT_STRENGTH (0.80)
  - BIOME_ZENITH_SHIFT (0.35)
  - BIOME_DENSITY_MULTIPLIER_STRENGTH (1.00)
  - BIOME_TRANSITION_TIME (10 s)
  - BIOME_WARM / COLD / HUMID / OCEAN_STRENGTH (1.00)
  - BIOME_PRECIPITATION (on)
  - BIOME_DESERT_DUST (off)
  - BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION (on)
- **Debug menu:**
  - BIOME_DEBUG, with BIOME_DEBUG_MODE 1–6;
  - FORCE_BIOME_PREVIEW 0–16, which is compiled out at 0.
- **Presets:** every preset defines all 211 options.

| Preset | Biome colours | Density multipliers | Transition | Desert dust |
|---|---|---|---|---|
| ULTRA LOW | on | off (0.00) | 4 s | off |
| LOW | on | on | 10 s | off |
| MEDIUM | on | on | 10 s | off |
| HIGH | on | on | 10 s | on |
| CINEMATIC | on | on | 10 s | on |

**Debug views (expected look):**
1. **Weight bar** at the top: family colours as wide as their weights, no red at the right end
   (the sum is 1).
2. **Palette swatches:** zenith, mid, horizon = fog, cloud top, cloud underside, Nether tint.
3. **Horizon-fog difference ×8:** black in every biome.
4. **Fog density multiplier:** grey, 0.5 = ×1.0; dust in red.
5. **Transition:** grey = largest weight. It is 1 when settled and dips smoothly while crossing
   a border.
6. **Palette table:** 17 columns (horizon above, cloud in the middle band, zenith below); the
   current or forced family is framed.

## 10. Render test (shader math in WebGL2, not the game)

Midday, sun at 70° behind the camera, horizon view, flat sand at y 63, render distance 192, no
dither.

| Family | Horizon sky | Fogged ground at the edge | Sand at 60 blocks |
|---|---|---|---|
| 0 base | #A5B9F0 | #A5B9F0 | #CEC4A8 |
| 1 ocean | #A9C7EE | #A9C7EE | #CFC7A7 |
| 3 snowy | #CDDAF1 | #CCDAF1 | #D6CBAA |
| 6 dark forest | #92A4BB | #91A4BB | #C6BEA1 |
| 8 jungle | #98D1CE | #98D1CE | #C8C9A3 |
| 9 swamp | #A4B39E | #A4B39E | #CAC298 |
| 10 desert | **#E5D3B3** | #E5D3B3 | **#DBC997** |
| 11 savanna | #ECD19F | #ECD09F | #DDC894 |
| 12 badlands | #E3C0A7 | #E3BFA6 | #DBC696 |
| 14 snowy peaks | #D4E2F7 | #D3E2F7 | #D8CCA8 |

- **Horizon match:** the fogged ground at the edge equals the sky in every family (at most 1
  step apart), so there is no horizon line.
- **Base family:** identical to v5.
- **Rain, base:** horizon #A6AEC0 (rainy grey).
- **Rain, snowy:** horizon #DEE9FA (bright whitish).
- **Rain, desert:** unchanged (stays clear).

**Your desert, before and after (expected):**
- horizon #C2C8DC grey-lavender → #E5D3B3 warm peach-sand;
- zenith #6794E1 → about #6998E7, almost unchanged;
- the air about 30 % thinner (density ×0.7), so the far sand and terracotta keep their warm
  colours instead of greying.

## 11. Test plan

1. **Travel through the biomes.** Use `/locate biome minecraft:<id>` and `/tp`, or set
   FORCE_BIOME_PREVIEW (1–16) to jump without travelling. For each biome check midday, sunset
   (`/time set 12000`), night (`/time set 18000`) and rain (`/weather rain`).
   - The colours should match the table.
   - BIOME_DEBUG 3 should be black at the horizon.
   - Desert, savanna and badlands should stay clear in rain.
   - Snowy biomes should turn whitish in snow.
2. **Cross borders slowly and quickly** (walk, then elytra) with BIOME_DEBUG 5. The bar and grey
   should move smoothly, with no flicker and no black frames.
3. **Before and after.** Turn BIOME_AMBIENCE off and on. Water, shadows, rays and sun glow
   behave as before. Underwater and caves are unchanged.
4. **Modded or unknown biome:** BIOME_DEBUG 1 shows the base colour only.
5. **Nether** (5 biomes) and **End:** the vanilla mood with a small per-biome tint.
6. **Performance:** F3 FPS with the feature on and off. Expect no measurable difference
   (estimate).

**Screenshots I need** (F1, same spot, midday, clear, same FOV, render distance and
resolution):
- desert;
- badlands;
- savanna;
- jungle;
- swamp;
- snowy plains;
- ocean;
- dark forest;
- plus BIOME_DEBUG 1 and 3 in one of them.

## 12. Tuning

| Goal | Change |
|---|---|
| Less tint everywhere | BIOME_FOG_STRENGTH 0.50, BIOME_SKY_STRENGTH 0.50 |
| Keep my old lavender | BIOME_AMBIENCE off, or BIOME_FOG_STRENGTH 0 (the fog character still applies) |
| Warmer desert | BIOME_WARM_STRENGTH 1.25, or BIOME_DESERT_DUST on |
| Cooler desert | BIOME_WARM_STRENGTH 0.50 |
| Clearer jungle | BIOME_HUMID_STRENGTH 0.50 (less teal and thinner), or BIOME_DENSITY_MULTIPLIER_STRENGTH 0.50 (thinner everywhere) |
| Same fog thickness in every biome | BIOME_DENSITY_MULTIPLIER_STRENGTH 0.00 |
| White clouds everywhere | BIOME_CLOUD_TINT_STRENGTH 0.00 |
| Slower, dreamier transitions | BIOME_TRANSITION_TIME 16 |
| Water reflection like before | BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION off |
| Disable the feature | BIOME_AMBIENCE off (v5 look) |