# Vanilla Cinematic Lite — stylized golden-hour update

This is an Iris shaderpack update based on the latest pasted task brief. The attached jungle image remains an atmospheric reference; the new savanna image is the golden-hour target, with a vanilla square sun, coarse amber flare, layered haze, olive grass, and distant silhouettes. The attached text is the active implementation specification, while the screenshots provide visual evidence only. The pack keeps Minecraft textures, block geometry, and static vegetation.

## Current target: golden-hour savanna screenshot

The target shows a very bright, hard-edged square sun high-right of the horizon, surrounded by broad cream-to-amber glow. The glow includes obvious coarse square bands, a long horizontal streak, and a faint vertical cross flare. A smaller round amber orb appears lower and left of the main sun. The sky is cream/gold with soft cloud haze; acacia-like tree forms, grass, flowers, and terrain remain recognizably vanilla but become olive and bronze in the warm light. Far ridges and trees fade into bright layered silhouettes. Tiny bird shapes cross the open sky. The scene has lifted warm air, gentle bloom, and a restrained vignette.

Visible evidence versus interpretation:

| Feature | Observation | Certainty |
| --- | --- | --- |
| Square sun and coarse glow | Bright square core with pixel-stepped halo, horizontal band, and weak cross flare | Directly visible; exact rendering technique is unknown |
| Lower round orb | Smaller warm disc below-left of the square sun | Its presence is visible; calling it a second light source is interpretation, so it is implemented as a fake flare |
| Sky and clouds | Gold/cream sky, bright cloud edges, muted undersides and hazy horizon | Visible; cloud-edge lighting is only approximated because the pack has no cloud-specific gbuffer route |
| Terrain grading and depth | Foreground remains detailed; distant trees and hills fade warm and pale | Directly visible; the haze model behind the reference is unknown |
| Backlit leaves and grasses | Warm edges and glowing foliage near the sun | Visible; a simple normal/light-map/shadow response is an approximation |
| Birds | Small dark wing-like silhouettes | Visible; they are represented as optional screen-space marks, never Minecraft entities |

### Gap analysis

“Exact” means the visible shape can be kept or recreated in the current route; it does not claim renderer parity with the reference. “Approximate” means an Iris-compatible effect with different implementation or limited coverage.

| # | Target feature | Pack before this update → new implementation | Match | Limitation |
| --- | --- | --- | --- |
| 1 | Square white sun, large pixel glow, horizontal and cross bands | Before: `SUN_STYLE=1` softened/replaced the vanilla disc and drew a smooth halo. Now: the target match restores the vanilla square plus `GOLDEN_SUN_GLOW` adds snapped, posterized bands | Approximate | Analytic screen-space glow, not the unknown reference bloom kernel; core size and footprint vary by resolution |
| 2 | Lower round glow orb | Before: none. Now: `SECONDARY_GOLDEN_ORB` in `final.fsh` adds a low-sun flare offset from the sun UV | Approximate | Deliberately fake lens flare, not a second celestial body or reflection |
| 3 | Amber sky and backlit clouds | Before: analytic gradient and vanilla cloud route. Now: `GOLDEN_TARGET_SKY` tints analytic sky pixels; final haze/grade can affect cloud pixels included in the final scene-depth route | Approximate | Vanilla cloud geometry/texture remains; no independent cloud-edge lighting, and cloud depth behavior depends on the renderer path |
| 4 | Warm low-contrast scene, olive grass and bronze leaves | Before: restrained warm/cool grade. Now: `GOLDEN_TARGET_GRADE` in `final.fsh`; direct-light grade remains in `gbuffers_forward.fsh` | Approximate | Camera biome uniforms tint the whole scene; no per-pixel biome map or flower-texture classifier |
| 5 | Layered golden distance haze | Before: existing analytic haze. Now: `GOLDEN_TARGET_HAZE` reuses its fog factor in `final.fsh` and adds a screen-space sun-facing weight | Approximate | One exponential attenuation and screen-space phase cannot recreate volumetric scattering |
| 6 | Warm canopy/grass rim and translucency | Before: mapped foliage back-light. Now: `GOLDEN_TARGET_BACKLIGHT` adds low-sun warmth using the foliage flag, normals, skylight and existing shadow result | Approximate | Only foliage groups mapped by `block.properties`; no true leaf transmission |
| 7 | Soft rays and glow around objects | Before: quarter-resolution shafts. Now: `GOLDEN_TARGET_RAYS` changes tint/intensity in the same `composite.fsh` route | Approximate | Eight to twelve depth taps are a screen-space shaft approximation, not volumetric shafts |
| 8 | Small birds | Before: none. Now: `GOLDEN_FAKE_BIRDS` draws three snapped V marks only in sky pixels | Impossible as real entities; approximate as a fake | No AI, depth interaction, collision, or world-space path; off in ULTRA LOW/LOW |
| 9 | Pale blue water and glint | Before: analytic reflection, shallow-water rays and caustics already existed. Now: retained unchanged by this update | Approximate | No scene SSR, refraction, or physically based water |
| 10 | Vignette and subtle bloom, crisp blocks | Before: quarter bloom and final vignette. Now: `GOLDEN_BLOCKY_BLOOM` snaps bloom-source coordinates in existing `composite.fsh` | Approximate | Bloom remains a five-tap low-resolution filter; vanilla texture pixels are not blurred |

The latest task treats the attached documents as requested specifications, not as facts about how the Bedrock add-on was built. Its implementation here does not claim to reproduce that add-on's internals.

## Golden-hour code review

| Area reviewed | Result |
| --- | --- |
| GLSL version and stage interfaces | The additions use the pack's existing `#version 330 compatibility`, `vSunUV`, `vSunElevation`, depth reconstruction, and `colortex5` route. No varyings or draw-buffer layouts were changed. |
| Iris uniforms | `viewWidth`/`viewHeight` are declared only in variants that use the screen grid; biome and camera uniforms are included by the corresponding feature guards. Confirm against the target Iris build because custom biome uniforms are supplied by `shaders.properties`. |
| Toggle behavior | New golden effects have independent `#define` switches. `MATCH_STRENGTH=0` suppresses all new target contributions and restores the existing round-sun treatment when that pre-existing option is selected. |
| Pass order and formats | Glow, haze, grade, and vignette stay in `final.fsh`; warm rays and blocky bloom source sampling stay in the existing quarter-resolution composite. No attachment or format directive changed. |
| Sky/surface separation | Sun, orb, and fake birds run only for depth-sky pixels and outside-water views. Target haze and grade operate on scene pixels; no texture samples or geometry changes were added to draw clouds separately. |
| Numeric guards | Screen dimensions, fog distance, glow levels, and existing normalization denominators retain nonzero guards. Weather masks clamp before being used as visibility. |
| Known limit | No Iris game compile, GPU capture, or hardware benchmark was available. This is a source-level compatibility review, not a runtime certification. `glslangValidator` is not installed in the workspace. |

## Performance plan and estimates

The pack retains the same six shader program routes: shadow, terrain/textured-lit/water gbuffers, composite, and final. The existing `colortex5` target remains quarter width × quarter height (one sixteenth of full-resolution pixel count). There is no new full-resolution pass. The pixel sun glow and golden color math are in the existing final shader and are skipped on non-sky pixels; target haze reuses the existing fog reconstruction and fog factor when that feature is enabled.

| Route | Before this update | After this update |
| --- | --- | --- |
| Final sky | Existing analytic gradient, square/round sun option, smooth halo | Same route plus screen-quantized target sun glow, target sky tint, optional orb and birds; disabled target switches add no target math |
| Final haze / grade | Existing analytic fog, biome tint, color grade, vignette | Same reconstruction and attenuation plus one reused-factor golden blend and small grade arithmetic; no raymarch or extra depth fetch |
| Composite shafts | Existing 8/10/12 quarter-res depth samples | Same sample counts; target only tints and scales the existing ray amount |
| Composite bloom | Existing five-tap quarter-res threshold | Same five taps; one optional coordinate snap before sampling |
| Program count / buffers | Six routes, `colortex5` at ¼ × ¼ dimensions | Still six routes and same buffers; no added attachment or full-resolution pass |

Very rough GPU-time estimates at 1920×1080 on a GTX 1650 (not measured):

| Added feature | Resolution / route | Approx. cost in LOW | Approx. cost in MEDIUM | Notes |
| --- | --- | ---: | ---: | --- |
| Coarse square sun core, blocky glow, flare band | Existing final pass; sky pixels only | 0.02–0.10 ms | 0.02–0.10 ms | Screen math only, with two soft falloff exponentials; no texture taps |
| Secondary flare orb | Existing final pass; sky pixels only | 0.00–0.02 ms | 0.00–0.02 ms | A few scalar operations and one distance |
| Golden sky tint and whole-scene grade | Existing final pass | 0.01–0.05 ms | 0.01–0.05 ms | Arithmetic only; low-sun/biome masks |
| Added haze color / sun-facing phase | Existing final haze branch | 0.00–0.03 ms | 0.00–0.03 ms | Reuses reconstructed position and fog factor; no extra depth fetch |
| Extra mapped foliage back-light | Existing terrain fragment shader | 0.00–0.03 ms | 0.00–0.03 ms | Arithmetic on foliage fragments; no extra shadow read |
| Golden ray tint/boost | Existing quarter-res ray taps | 0.00–0.01 ms | 0.00–0.01 ms | No sample-count increase |
| Blocky bloom source snap | Existing quarter-res bloom | 0.00 ms (LOW bloom off) | 0.00–0.02 ms | Changes UV arithmetic, not tap count |
| Fake bird marks | Existing final sky pixels | 0.00 ms (LOW off) | 0.00–0.04 ms | Three tiny masks, gated by daylight and match strength |
| **Golden-hour additions total** | **Existing routes only** | **about 0.03–0.20 ms** | **about 0.04–0.28 ms** | Driver, sky coverage, resolution scaling and compiler affect the result |

The best-case expected GPU-bound change from a 120 FPS baseline is approximately 0.4–2.8 FPS for the LOW estimate, and approximately 0.4–3.8 FPS for the MEDIUM estimate. This arithmetic is not a benchmark. The pack’s pre-existing effects, terrain load, chunk distance, shadow fill rate, and CPU bottlenecks are outside that delta. The 120 FPS LOW and 90 FPS MEDIUM goals remain targets to measure in-game; the source cannot guarantee them.

## Golden-hour art plan and palette

Palette hexes below are display-space visual estimates read from the screenshot by eye; they are not pixel-sampled measurements and are not claimed to be the source add-on's internal colors. Shader constants are linear-ish working values, so exact on-screen output also depends on Minecraft's output transform and resource pack lighting.

| Screenshot element | Suggested swatch | Use |
| --- | --- | --- |
| Sun core | `#FFFDF2` | Keep a white-hot square center with a slight warm edge, preserving the vanilla square outline |
| Inner glow | `#FFF0C2` | Bright area immediately around the sun |
| Outer glow / band | `#F5C56F` / `#FFE0A0` | Coarse amber halo and long low-contrast horizontal streak |
| Sky zenith | `#8F8060` | Muted, warm-gray upper sky rather than deep blue |
| Sky mid | `#EBCB83` | Cream-gold middle sky |
| Horizon | `#FFD995` | Pale luminous horizon blend |
| Near haze | `#F5D17E` | Warm yellow air over nearby distant forms |
| Far haze | `#DCA85E` | Lower-contrast amber silhouette color |
| Grass | `#98914A` | Olive foreground with yellow light on top-facing surfaces |
| Leaves | `#A28A43` | Bronze/olive canopy highlights; retain dark green shade texels |
| Soil / trunks | `#4B392D` | Warm dark brown, preserving texture contrast |
| Flowers | `#F4D532` | Saturated yellow blooms without a global neon boost |
| Water | `#A8D7E6` | Pale blue reflected-sky hint and existing water glint |

| Time / weather / biome | Suggested direction |
| --- | --- |
| Sunrise | Peach horizon (`#EFAF91`), gold-white sunlight, cool muted upper sky (`#75829A`) |
| Golden hour / savanna / desert | Cream and amber sky (`#EBCB83` → `#FFD995`), bronze foliage, olive grass; strongest match preset response |
| Sunset | Deeper amber and peach (`#D98762`), rays/gold reduced smoothly as the sun drops |
| Midday | Keep the original blue sky and neutral vanilla lighting dominant; pixel glow and golden grade fall away with sun elevation |
| Night | Existing calm blue/night sky (`#263856`); target golden sun/orb/birds/rays are faded out |
| Rain / thunder | Desaturate the golden overlay, retain denser neutral haze, fade sun glow and shafts |
| Jungle / swamp | Keep the existing teal haze (`#398D85` / `#72CBB8`) in front of golden accents |
| Cold biomes / ocean | Preserve the existing blue/cyan atmosphere (`#6C91B8` / `#99C7D3`) |
| Nether / End | Keep the existing dimension palette and skip the target overworld sun treatment |

This palette works with square block forms and crisp textures: the glow is quantized in screen space and in brightness, while world textures remain untouched. A coarser cell makes the glow visibly more pixelated; lower blockiness moves it toward a smooth analytic halo.

## Honest match to Vibrant Visuals

Mojang describes Vibrant Visuals through visible results such as directional sunlight and moving shadows, reflective water, volumetric lighting/fog, and different lighting response for block textures. The exact caustic, fog, and lighting shader implementation is not published in the material linked below, so this pack recreates the visible style with Iris-compatible approximations rather than claiming source-level parity. Mojang's public status pages currently describe Vibrant Visuals as available for Bedrock and in development for Java; this pack is a Java shaderpack approximation, not a Mojang Java port. [Mojang's feature overview](https://www.minecraft.net/en-us/vibrant-visuals-update), [Mojang's Java roadmap](https://www.minecraft.net/en-us/article/the-road-to-vibrant-visuals-on-java).

For the caustics goal, the recognizable behavior is focused, moving light on underwater surfaces, strongest in shallow sunlit water and reduced by shade, depth, rain, and night. The method here is an educated approximation: opaque depth reconstruction under visible water plus a low-cost analytic interference net. It does not refract light through a simulated wave surface, ray trace, or add geometry.

The 16-cells-per-block default anchors caustic cells to Minecraft's block texel scale. The pattern is made from hard snapped coordinates and stepped brightness bands, so it reads as block-art lighting rather than a smooth photographic caustic. Eight or 32 cells per block are available as coarser/finer variants.

## What changed

- Pixel-aligned shadow receivers snap their world-space tangent coordinates to a configurable 8/16/32-cell grid and sample the nearest shadow texel. The LOW/MEDIUM default is one tap to keep edges crisp and reduce bandwidth; HIGH/CINEMATIC can select a small 4- or 8-tap filter.
- Terrain blocks receive simple material groups from `block.properties`: matte earth/wood, stone, finished masonry, metals, glass/ice/slime/honey, foliage/thin plants, water, and selected emissive blocks.
- `PLASTIC_GLOSS_MIX` blends the existing gloss/Fresnel layer from its current strength down to zero. A separate, restrained material response adds block-family highlights.
- A small directional sun/moon fill uses the existing shadow light direction and skylight. Existing vanilla block light is preserved.
- Water can reflect an analytic blend of sky and fog color with a Fresnel term. The existing texture, ripple normal, pixel caustics, shallow-water rays, and glints remain.
- Leaves and mapped thin blocks get a small back-light tint. Vegetation vertices and positions are untouched.
- Selected terrain emitters get a texture-luminance-gated boost. The scene and shared effect buffers use Iris `RGBA16F`, allowing the existing quarter-buffer bloom to receive values above one.
- `VV_DEBUG` adds the nine requested diagnostics. The extra terrain debug output is compiled only when that switch is enabled.
- The caustic analytic waves now repeat on a seamless 256-block tile; the previous 20-block world-coordinate wrap could create pattern repetition/seams.

No new geometry or full-resolution pass was added. Existing six custom routes remain: shadow; terrain, textured-lit, and water gbuffers; composite; final.

## Gap analysis

| Vibrant Visuals goal | Existing pack before this update | Updated approximation / remaining limit |
| --- | --- | --- |
| Directional light and moving shadows | Shadow map and warm/cool grade; direct diffuse response was subtle | Mild sun/moon directional skylight lift plus the existing moving shadow map. Not a full physically based lighting model. |
| Pixel-aligned shadows | Shadow map and configurable filter, with no block-grid receiver snap | Receiver tangent coordinates snap to the 16-cell world grid by default; optional small multi-tap filter can soften edges. This is not a native voxel shadow renderer. |
| Haze and air shafts | Analytic haze and quarter-resolution depth/shadow shafts | Preserved and retained in existing routes. Haze is one analytic exponential in final; shafts use 8/10/12 taps. No volumetric integration. |
| Shallow-water lighting and caustics | Pixel caustics, depth masks, shallow-water rays, surface glints | Preserved, with stable world projection, block-grid quantization, stepped animation/pattern, one receiver shadow compare, and a caustic debug path. |
| Reflective water | Ripple shading and shallow tint; no screen reflection | Added a cheap analytic sky/fog reflection and Fresnel mix. No scene reflection or refraction. Optional SSR was left out because this pack has no water-normal buffer and an 8-step full-resolution ray would add cost and artifacts. |
| Thin-surface transmission | Leaf back-light only | Existing leaf term plus a small tint for selected plants/glass/ice/honey/slime groups. This is not true light transmission or subsurface scattering. |
| Per-family materials | One shared plastic gloss response | `block.properties` groups tune a subtle additional specular tint/strength; plastic stays independently blendable. Only terrain/water routes receive block IDs. |
| Emissives and glow | Thresholded quarter-resolution bloom | Selected terrain block textures are luminance-masked and boosted before existing bloom. Block-entity models, held items, mob eyes, and many animated emissive texture regions are outside the current routes. |
| Sky, sun, stars, clouds | Analytic gradient/halo/stars; vanilla cloud geometry | Sky and celestial work remains in final. Vanilla clouds are unchanged; the pack has no cloud gbuffer route for relighting or explicit horizon fading. Stars may not be cloud-occluded on every Iris configuration. |
| Static vanilla style | Textures and geometry are vanilla; vegetation is static | Preserved. No wind, geometry edits, texture blur, or required resource pack. |

## Code review and compatibility notes

| Severity | Finding | Change / disposition |
| --- | --- | --- |
| High | Default `colortex` format is normalized RGBA8 on most systems; additive atmosphere/emissive values can clamp. | Set `colortex0` and quarter-size `colortex5` to `RGBA16F` with Iris block-comment format directives. This costs additional VRAM/bandwidth. |
| High | Iris `mc_Entity.x` only identifies blocks in supported terrain/water stages; it is not a universal material ID for items, mobs, and block entities. | Material and emitter group effects are scoped to block IDs available on those routes. No item/entity ID taxonomy was invented. |
| Medium | Soft shadow taps blur the pixel-aligned edge target and multiply depth reads. | Added stabilized block-grid snapping and nearest texel sampling; the default uses one tap. Higher filters remain available. |
| Medium | A short, repeating coordinate wrap can make a procedural caustic net visibly repeat or jump. | Caustic waves now tile on a 256-block period with integer frequencies. |
| Medium | Camera-water and underwater-caustic gates can leak across the surface if based only on `isEyeInWater`. | Existing camera-side/sign gates remain; underwater terrain caustics remain opt-in. |
| Low | Native cloud lighting, true glass/ice transmission, and complete emissive entity/item handling are not represented by the available custom routes. | Kept vanilla clouds and routes; documented the cheap alternatives and the limits. |

Source review covered GLSL 330 compatibility, include paths, varying pairs, conditional uniforms, buffer outputs/clears, format directives, depth reconstruction, zero-vector guards, and compile-time options. It was not compiled inside Minecraft/Iris and was not measured on the requested GPUs. Iris version and driver behavior still require an in-game pass.

## Art direction and palettes

The screenshots guide the art direction; the hex palettes below are suggestions, not claimed Mojang or Realismcraft internals. GLSL uses linear RGB approximations and Iris biome uniforms, not literal hex values. Biome tinting follows the camera biome and blends smoothly, so it is not per-pixel biome classification.

| Time / weather | Palette (zenith → horizon or key light) | Treatment |
| --- | --- | --- |
| Sunrise | `#5B719F` → `#F2A98F` | Cool upper sky with soft peach horizon. |
| Morning | `#5F9CCB` → `#B8D7E7` | Clear blue, pale haze. |
| Midday | `#3E78B7` → `#C5DCEB` | Clean blue, warm-white direct highlights. |
| Afternoon | `#608DAF` → `#D9BF97` | Slight amber near the horizon. |
| Golden hour | `#D88C45` → `#F1C08D` | Soft amber shafts, warm birch highlights. |
| Sunset | `#655D83` → `#E27F72` | Muted violet and coral transition. |
| Dusk | `#2C3B65` → `#857095` | Blue-violet, gradual night blend. |
| Night | `#101A35` → `#465B87` | Calm blue haze and very faint moon response. |
| Rain | `#536D82` → `#9EABB6` | Cooler, softer contrast and denser haze. |
| Thunderstorm | `#263342` → `#586676` | Dark slate, shafts nearly gone. |
| Underwater | `#0E5271` → `#75C7C1` | Turquoise shallows into deeper blue. |

| Biome family | Palette | Treatment |
| --- | --- | --- |
| Jungle / swamp | `#398D85` → `#72CBB8` | Teal haze; green vibrance remains clamped and modest. |
| Forest / birch | `#E8A46B` → `#F3B89A` | Warm peach/amber distance color, cool shade. |
| Plains | `#8BB8C9` → `#CDD2BF` | Neutral blue air and gentle warm distance. |
| Desert / savanna | `#B97D4B` → `#E1BB83` | Dry amber light without a full-screen orange cast. |
| Snow / cold | `#6C91B8` → `#C6DBEC` | Soft cool-blue haze, preserve snow detail. |
| Ocean | `#4F91AD` → `#99C7D3` | Muted blue-green atmosphere and deeper water. |
| Cave | `#223144` → `#596B78` | Neutral-cool darkness; vanilla block light remains warm. |
| Nether / End | `#7A3D31` / `#614A91` | Dimension-tinted restrained haze; native dimension sky retained. |

## Performance and pass plan

No new pass was added. `colortex5` remains 25% width × 25% height (one sixteenth the pixel count) and shares bloom, shallow-water lighting, shafts, and particles. Haze, sky, tone, vibrance, and vignette stay in final. Material, caustic, direct-light, and wet-ground terms stay in existing gbuffers.

These are rough 1080p GTX 1650 estimates, not benchmark results. They vary with water coverage, shadowed pixel count, driver, chunk distance, and shader option state. “Before” refers to the checked-in pack immediately before this change.

| Effect | Before → after | Approximate GPU cost after | Notes |
| --- | --- | ---: | --- |
| Atmosphere rays | Existing 8–12 depth taps at quarter width/height → unchanged route, 8 LOW / 10 MEDIUM / 12 HIGH-CINEMATIC | 0.08–0.22 ms | Includes one shadow compare on eligible surface pixels; no new full-resolution pass. |
| Haze, sky, grade | Existing final-stage analytic haze/sky → preserved, dimension-aware and tone-gated | 0.08–0.22 ms | One exponential for haze; full-resolution but no extra pass. |
| Bloom and pollen | Existing quarter target → preserved; bloom now samples HDR colortex0 | 0.03–0.14 ms | Existing 5-tap cross filter, not a separable blur. Bloom/pollen are off in LOW. |
| Pixel caustics | Existing water-fragment depth reconstruction and pattern → seamless tile, current single shadow compare, snapped net | 0.05–0.30 ms | Highly dependent on visible water coverage; only runs on eligible shallow-water pixels. |
| Pixel shadows | Existing interpolated shadow clip and 1/4/8 compares → world snap plus nearest texel; default 1 compare | −0.02 to +0.03 ms | Fewer taps can offset the coordinate math; exact gain is driver/coverage dependent. |
| Material response and direct light | One plastic term → added group selection and subtle light/material arithmetic | 0.01–0.08 ms | No extra texture reads. |
| Water analytic reflection | No water-surface sky reflection → reflection/Fresnel only on visible outside-water fragments | 0.005–0.05 ms | Not SSR; cost scales with water coverage. |
| Emissive lift and thin back-light | No group-masked block emissive lift → texture luminance tests on mapped terrain | 0.005–0.04 ms | No new texture reads; half-float colortex0 adds roughly 8.3 MiB at 1920×1080 versus RGBA8. |
| Estimated whole requested atmosphere | Existing profile-level estimate 0.19–0.50 ms LOW / 0.25–0.78 ms MEDIUM → same passes with HDR target and debug compiled out | about 0.20–0.55 ms LOW / 0.26–0.85 ms MEDIUM | Does not include terrain, water, or caustic cost. These are not measured totals. |

The entry-GPU 120 FPS LOW and RTX 3050 90 FPS MEDIUM targets cannot be guaranteed from source review; CPU chunk work, resolution scale, render distance, and actual water/shadow coverage materially affect frame time. `ULTRA_LOW` removes most shader additions. Use a GPU frame capture for measured claims.

### Changelog and estimated frame-rate effect

The FPS conversion below assumes a GPU-bound baseline and is only arithmetic from the estimated milliseconds (`1000 / (baseline frame ms + added ms)`). It is not a benchmark; CPU limits and the shadow-filter change make actual frame-rate deltas nonlinear.

| Addition / visible difference | Estimated cost or saving | Approximate effect at 120 GPU-bound FPS |
| --- | ---: | ---: |
| World-grid shadow receiver snap, nearest texel; default MEDIUM changes from four compares to one | About −0.02 to +0.03 ms net | roughly +0.3 to −0.4 FPS; LOW already used one compare, so expect a small cost from snap math |
| Block-family material response and directional sun/moon lift | +0.01–0.08 ms | about −0.1 to −1.1 FPS |
| Analytic sky reflection on visible water | +0.005–0.05 ms on water fragments | about 0 to −0.7 FPS, depending on water coverage |
| Texture-masked emissive lift and thin-material back-light | +0.005–0.04 ms | about 0 to −0.6 FPS |
| Full-resolution scene buffer changes from RGBA8 to RGBA16F | approximately +8.3 MiB at 1080p and +0.02–0.10 ms bandwidth | about −0.3 to −1.4 FPS if bandwidth-bound |
| Caustic coordinate tile correction | No meaningful ALU increase | visually removes a possible short-period seam; essentially 0 FPS |
| `VV_DEBUG` views and MRT output | 0 when disabled; debug-only overhead when enabled | 0 in all normal presets |
| Existing quarter-resolution haze/rays/bloom/pollen | No new pass; estimates in the table above | Retained, not a new cost from this change |

Combined new full-resolution additions (including HDR buffer bandwidth) are very roughly +0.02–0.25 ms on LOW, partly offset by fewer shadow compares on MEDIUM. This spread is intentionally wide; it cannot establish that a particular GPU meets 120/90 FPS.

## Presets and controls

| Preset | Main costs and effects | Hardware guidance |
| --- | --- | --- |
| ULTRA LOW | 768 shadow map; simple analytic haze and low-match warm sky/square glow only; no rays, bloom, caustics, or birds. | Integrated graphics; highest FPS priority. |
| LOW | 1024 shadow map, 64-block distance, 8 quarter-buffer ray taps, one-tap pixel shadows, 8-step/s caustic net; bloom and birds off; match 42. | GTX 1050 Ti / GTX 1650 / RX 6400 target profile. |
| MEDIUM | 1536 shadow map, 80-block distance, 10 ray taps, bloom, pollen and fake birds; match 65. | Default balance / RTX 3050 target profile. |
| HIGH | 2048 shadow map, 12 ray taps, 4-tap shadows, fine caustic grid; match 82. | Higher-end desktop GPUs. |
| CINEMATIC | 3072 shadow map, 96-block distance, 12 ray taps, 8-tap shadows, finer glow pixels, stronger haze/glow and finest caustic grid; match 100. | Screenshots/high-end only. |

Settings are under **Match Strength**, **Sky and Sun**, **Golden Haze**, **Color Grading**, **Light Shafts and Bloom**, **Water and Caustics**, **Materials**, **Glow and Emissive**, **Performance**, and **Debug**.

Key controls:

- **Plastic gloss blend** (`PLASTIC_GLOSS_MIX`): 1.0 preserves the existing plastic layer; 0.0 removes only that layer.
- **Material response strength**: the added block-family highlight, independent of plastic gloss.
- **Shadow texels per block** (`SHADOW_PIXEL_GRID`): 8/16/32 world cells per block. The default 16 follows the 16×16 texture scale.
- **Caustic pixel grid / pattern quality / levels / steps per second / depth range / tint / strength**: controls the world-space caustic net and water mask. Current defaults keep caustics full through 2 blocks below the water surface and fade smoothly to zero at 11 blocks. `CAUSTICS_FULL_DEPTH` and `CAUSTICS_FADE_DEPTH` tune those thresholds; `SHALLOW_DEPTH_RANGE` controls the separate shallow-water shafts.
- **Ray samples / length / softness / intensity** and optional snapped-ray grid.
- **Haze density / height falloff / biome tint**, **green vibrance**, **bloom threshold/intensity**, and **emissive texture threshold/strength**.
- **Match strength** (`MATCH_STRENGTH`): 0 reproduces the shaderpack's prior look; 100 applies the full golden-hour target. LOW/MEDIUM/CINEMATIC start at 42/65/100.
- **Sun glow** (`GOLDEN_GLOW_PIXEL_SIZE`, `GOLDEN_GLOW_BLOCKINESS`, `GOLDEN_GLOW_LEVELS`, `GOLDEN_GLOW_STRENGTH`): controls square screen-pixel cells, hard steps, and glow brightness. `GOLDEN_SUN_CORE_SIZE` changes the overexposed square footprint.
- **Secondary orb** (`SECONDARY_GOLDEN_ORB`, `SECONDARY_ORB_SIZE`, `SECONDARY_ORB_STRENGTH`): optional artistic flare below-left of the sun; it is not a second world light.
- **Golden sky/haze/grade** (`GOLDEN_TARGET_SKY`, `GOLDEN_SKY_TINT_STRENGTH`, `GOLDEN_TARGET_HAZE`, `GOLDEN_HAZE_STRENGTH`, `GOLDEN_HAZE_PHASE`, `GOLDEN_TARGET_GRADE`, `GOLDEN_GRADE_STRENGTH`, `GOLDEN_SHADOW_LIFT`): sunrise/sunset and savanna-weighted ambience.
- **Ray and foliage warmth** (`GOLDEN_TARGET_RAYS`, `GOLDEN_RAY_BOOST`, `GOLDEN_TARGET_BACKLIGHT`, `GOLDEN_BACKLIGHT_STRENGTH`): reuses the existing quarter-res rays and existing foliage classification/shadow result.
- **Optional birds** (`GOLDEN_FAKE_BIRDS`, `FAKE_BIRD_AMOUNT`, `FAKE_BIRD_SIZE`, `FAKE_BIRD_SPEED`): only sky marks, not entities. Disabled in ULTRA LOW/LOW.
- Every feature added here has a Boolean compile-time define; numeric controls are in `shaders/lib/settings.glsl` and exposed in `shaders.properties`.

### Tuning guide

- **More Vibrant Visuals:** raise `DIRECTIONAL_LIGHT_STRENGTH` slightly, keep `MATERIAL_RESPONSE` on, and raise biome tint or haze only a little. Leave the plastic mix at 0.5–1.0 if you want the pack's original highlights.
- **More vanilla:** lower `PLASTIC_GLOSS_MIX`, `MATERIAL_RESPONSE_STRENGTH`, `DIRECTIONAL_LIGHT_STRENGTH`, bloom, and `SKY_GRADIENT_STRENGTH`; disable optional vignette/stars.
- **Less haze:** lower `HAZE_DENSITY`; lower `HAZE_HEIGHT_FALLOFF` if the ground-level buildup is too strong.
- **Softer shafts:** increase `ATMOS_RAY_SOFTNESS` and reduce `ATMOS_RAY_INTENSITY`; decrease `ATMOS_RAY_LENGTH` for shorter beams.
- **Less glossy:** reduce `PLASTIC_GLOSS_MIX` to remove the existing plastic response; reduce `MATERIAL_RESPONSE_STRENGTH` separately for quieter stone/metal/glass highlights.
- **Finer caustics:** set `CAUSTIC_GRID_SIZE` to 32 and/or raise `CAUSTIC_QUALITY`. The pattern remains cell-stepped by design.
- **Less emissive glow:** raise `EMISSIVE_THRESHOLD`, lower `EMISSIVE_STRENGTH`, or disable `EMISSIVE_BLOCKS`/`BLOOM`.
- **More vanilla water:** lower `WATER_REFLECTION_STRENGTH` or disable `WATER_SKY_REFLECTION`.
- **More like the golden-hour target:** raise `MATCH_STRENGTH`, then raise `GOLDEN_GLOW_STRENGTH` or `GOLDEN_HAZE_STRENGTH` in small increments.
- **Make the glow softer:** lower `GOLDEN_GLOW_BLOCKINESS`, increase `GOLDEN_GLOW_LEVELS`, and reduce `GOLDEN_BAND_STRENGTH` if the horizontal flare is too hard.
- **Make the glow more pixelated:** raise `GOLDEN_GLOW_BLOCKINESS` and `GOLDEN_GLOW_PIXEL_SIZE`; lower `GOLDEN_GLOW_LEVELS` for fewer, more obvious brightness bands.
- **Make the haze less strong:** lower `GOLDEN_HAZE_STRENGTH` first, then lower the general `HAZE_DENSITY` if the existing pack haze is also too heavy.
- **Make the image less yellow:** lower `MATCH_STRENGTH` or `GOLDEN_GRADE_STRENGTH`; set `GOLDEN_SKY_TINT_STRENGTH` lower to keep sky colors cooler.
- **Hide the fake birds:** turn off `GOLDEN_FAKE_BIRDS` or set `FAKE_BIRD_AMOUNT` to 0.
- **Move the flare orb:** the current implementation offsets it from the sun by a fixed screen-space amount; use `SECONDARY_ORB_SIZE`/strength or disable the toggle. Its screen offset is intentionally not exposed as a slider.
- **Tune canopy rays:** use `ATMOS_RAY_SOFTNESS`, `ATMOS_RAY_LENGTH`, and `ATMOS_RAY_INTENSITY`; `GOLDEN_RAY_BOOST` only adds target warmth/weight.

### Golden-hour screenshot comparison checklist

| Compare | If too weak | If too strong |
| --- | --- | --- |
| Square sun and glow footprint | Raise `MATCH_STRENGTH` or `GOLDEN_GLOW_STRENGTH`; raise `GOLDEN_SUN_CORE_SIZE` for a larger square | Lower `GOLDEN_GLOW_STRENGTH` or `GOLDEN_SUN_CORE_SIZE` |
| Glow blockiness / bands | Raise `GOLDEN_GLOW_BLOCKINESS`, pixel size, or band strength; reduce levels for chunkier steps | Lower pixel size/blockiness; increase levels |
| Secondary orb | Raise `SECONDARY_ORB_STRENGTH` or size | Lower its strength/size or disable `SECONDARY_GOLDEN_ORB` |
| Sky warmth | Raise `GOLDEN_SKY_TINT_STRENGTH` or match strength | Lower either control; keep `SKY_GRADIENT_STRENGTH` for the base pack look |
| Clouds | General haze/grade affect distant cloud pixels | Cloud geometry and direct cloud-edge light are vanilla; no slider can independently relight cloud undersides |
| Haze layers and horizon silhouettes | Raise `GOLDEN_HAZE_STRENGTH` gently | Lower target haze, then `HAZE_DENSITY` |
| Whole-scene golden grade | Raise `GOLDEN_GRADE_STRENGTH` | Lower grade strength or `MATCH_STRENGTH` |
| Backlit canopy and grass | Raise `GOLDEN_BACKLIGHT_STRENGTH`; check foliage IDs/shadow light | Lower strength or disable `GOLDEN_TARGET_BACKLIGHT` |
| Rays | Raise `ATMOS_RAY_INTENSITY` or `GOLDEN_RAY_BOOST` | Lower ray intensity/boost or disable either ray switch |
| Yellow flowers | Increase `VIBRANCE_STRENGTH` cautiously; the shader does not identify flower texels separately | Lower vibrance; there is no per-flower color slider |
| Water highlight | Raise `WATER_REFLECTION_STRENGTH` or existing sparkle amount | Lower them; no screen-space reflection is present |
| Vignette | Raise `GOLDEN_VIGNETTE_STRENGTH` | Lower it or disable `GOLDEN_SOFT_VIGNETTE` |

### Golden-hour test checklist

| Scene / state | Expected result |
| --- | --- |
| Sunrise and sunset, looking toward the sun | Square core with warm pixel bands, subtle horizon orb, golden haze and shafts fade in smoothly |
| Look away from the sun | Warm grade and haze remain subtle; flare and rays largely disappear from the sun cone |
| Noon | Sky returns toward the base palette; target glow/orb and warm ray boost fall off |
| Night | No golden sun or secondary orb; calm blue base sky, no strong rays or birds |
| Rain and thunderstorm | Sun glow/rays and golden grade soften; existing haze gets denser/desaturated |
| Savanna/desert | Warmest amber haze and bronze/olive grade |
| Forest/birch | Warm highlights but keep green shade texels readable |
| Jungle/swamp | Existing teal biome haze remains legible; golden overlay stays restrained |
| Snow/ocean | Existing cool palette remains dominant |
| Open sky with birds enabled | Three sparse snapped silhouettes drift slowly; disabled in LOW/ULTRA LOW |
| Under trees, indoors, under a roof | Atmospheric rays reduce with sky light/shadows; square sun effects remain sky-only |
| Water and crossing the surface | Existing water reflection/caustics gates behave as before; no new caustics are drawn on the visible surface |
| Nether/End | Golden overworld sun treatment stays gated out; native dimension mood remains |
| `MATCH_STRENGTH` 0 vs 100 | 0 matches the previous pack; 100 shows the strongest screenshot-inspired golden-hour additions |
| LOW at 1080p / 12 chunks | Birds and bloom off, 8 ray taps; measure GTX 1050 Ti/1650/RX 6400 rather than assuming the FPS target |
| MEDIUM at 1080p | 10 ray taps plus bloom and birds; measure on the RTX 3050 and compare against your own baseline |

### Golden-hour changelog and estimated frame cost

| Addition | Visible difference | Estimated added GPU time (GTX 1650, 1080p) |
| --- | --- | ---: |
| `MATCH_STRENGTH` and presets | Single 0–100 blend for target additions; profiles select 25/42/65/82/100 and their quality/toggle sets | No meaningful cost |
| Pixel sun core/glow/bands | White square-overlaid core and quantized amber square-grid halo/cross/horizontal streak | 0.02–0.10 ms, sky pixels only |
| Lower orb | Soft round screen flare below-left of the sun | 0.00–0.02 ms, sky pixels only |
| Golden sky and distant haze/phase | Cream/amber sky and warmer distant silhouettes around the sun | 0.01–0.08 ms; reuses existing scene and fog reconstruction |
| Warm scene grade and backlight | Golden low-sun tint/lift; mapped foliage and grass edges receive a small extra tint | 0.01–0.08 ms; no additional shadow sample |
| Ray tint/boost and blocky bloom source | Warmer existing shafts and pixel-grid bloom selection | 0.00–0.03 ms; existing tap counts unchanged |
| Optional fake birds | Three tiny sky-only screen marks | 0.00–0.04 ms; off in LOW/ULTRA LOW |

## Debug views

Turn on `VV_DEBUG` and select `VV_DEBUG_MODE`. These diagnostics are compiled out when `VV_DEBUG` is off.

For the new target-only checks, enable `TARGET_DEBUG` and select `TARGET_DEBUG_MODE`. This code is compiled out when the switch is off. Modes 6 and 7 read the existing quarter-resolution effect buffer; no diagnostic render pass is added.

| Target mode | View |
| --- | --- |
| 1 | Raw golden sun glow before tint contribution |
| 2 | Posterized glow contribution |
| 3 | Target warm sky palette |
| 4 | Warm haze mask/fog factor |
| 5 | Screen-space sun-facing haze phase |
| 6 | Quarter-resolution raw sun shafts |
| 7 | Quarter-resolution bloom buffer (the target is shared with other composite effects) |
| 8 | Left half before golden grade, right half after golden grade |

| Mode | Expected result |
| --- | --- |
| 1 — Sun-lit mask | Black in night/indoors, white in open sky and lit sun-facing receivers. |
| 2 — Raw shafts | Grayscale quarter-resolution ray intensity; brightest around alternating canopy gaps. |
| 3 — Fog factor | Black nearby and brighter with distance; sky pixels stay black. |
| 4 — Biome tint | Flat active palette color; transitions gradually as the camera biome changes. |
| 5 — Shadow factor | White for visible/unshadowed receivers, dark for shadowed/out-of-map receivers; quarter-resolution. |
| 6 — Emissive mask | Grayscale threshold result on supported, tagged terrain blocks only. |
| 7 — Material group | Matte brown, stone gray, polished purple, metal gold, transmission cyan, foliage green, water blue, emitter red. Unmapped/entity routes are dark gray. |
| 8 — Water mask | White on mapped water surfaces; black elsewhere. |
| 9 — Bloom buffer | Isolated low-resolution thresholded glow contribution. |

The older `ATMOS_DEBUG` and `CAUSTICS_DEBUG` controls remain available for their existing focused diagnostics.

## In-game test checklist

The source-level work is complete; use this checklist in Minecraft/Iris to verify visuals and performance.

| Scenario | Expected result |
| --- | --- |
| Sunrise / sunset | Smooth peach/coral sky band, warm directional tint, no abrupt transition. |
| Morning / noon | Clear blue sky, restrained warm direct light, no excessive orange cast. |
| Golden hour in birch forest | Amber/peach haze and faint shafts between trunks, like reference 2. |
| Jungle canopy | Soft diagonal shafts, teal/cyan distance haze, restrained pollen and green vibrance, like reference 1. |
| Night | Calm blue haze, no strong sun rays or caustics, subtle stars/moon response. |
| Rain / thunderstorm | Shafts and caustics fade; haze becomes cooler/denser and grading softens. |
| Plains / desert / savanna | Smooth neutral or amber palette blend; no hard biome boundary. |
| Snowy biome | Cool air; white surfaces retain visible texture detail. |
| Ocean / shallow water from shore | Depth tint, visible block-pixel caustics on submerged opaque surfaces, mild water reflection. |
| Deep water | Caustics stay full through 2 blocks, fade smoothly to zero at 11 blocks, and are absent below that. |
| Crossing water surface | Outside-camera caustics fade out as the eye enters water; never show the outside-water caustic overlay from below. |
| Underwater floor toggle | When `CAUSTICS_UNDERWATER_FLOOR` is enabled, faint terrain caustics use the conservative eye-light proxy. |
| Cave / indoors / under roof | No air shafts in sealed shade; caves remain dark, warm block light remains vanilla-like. |
| Window / canopy gaps | Shafts pass through visible openings; fully occluded regions stay subdued. |
| Look toward/away from sun; look straight up/down | Shafts fade with the sun-screen cone; sky effects do not spill over opaque terrain or singularly flicker. |
| Nether / End | Native dimension mood is retained with restrained dimension haze. |
| Far from spawn | Caustic grid remains anchored and repeats only at its seamless 256-block tile. Check for visible tile recognition. |
| Emissive blocks / leaves / glass | Supported blocks gain a subtle local glow/back-light; no actual transmitted light is expected. |
| Performance on targets | Measure LOW at 1080p/12 chunks on GTX 1050 Ti, GTX 1650, RX 6400; MEDIUM on RTX 3050. Source estimates are not benchmark data. |

## Troubleshooting Iris errors

1. Check the first `Shader compilation failed` or GLSL `ERROR` in `.minecraft/logs/latest.log`; the first program and line number are the useful part, not the final stack trace.
2. If a varying is undeclared, compare vertex `out` and fragment `in` names/types. `vMaterialGroup` and related values are shared by `/lib/gbuffers.vsh` and `/lib/gbuffers_forward.fsh`.
3. If the error mentions `colortex0Format` or `colortex5Format`, leave each Iris buffer format directive on its own line inside a block comment. `RGBA16F` is an Iris directive, not a GLSL identifier.
4. If a `RENDERTARGETS`/attachment error appears, try with `VV_DEBUG` off first; its material/emissive views add a `colortex2` MRT output only for the selected debug modes. The normal water mask remains in `colortex1`.
5. If an option seems unchanged, reselect the profile or reload shaders; profiles can override GUI defines. Confirm its Boolean switch and its slider are both enabled/raised.
6. If a block group does not tint, confirm the block has an ID in `shaders/block.properties` and is rendered in terrain/water. Block entities, items, and entities do not automatically inherit `mc_Entity.x`.
7. For a reproducible report, include Minecraft version, Iris version, GPU/driver, the first compile diagnostic, the selected profile, and the relevant setting values.

## Changed and unchanged files

All changed shader/config files below contain their complete contents in the pack folder and ZIP; no diffs or placeholders are required to use the pack.

Changed:

- `README.md`
- `shaders/block.properties`
- `shaders/composite.fsh`
- `shaders/final.fsh`
- `shaders/gbuffers_terrain.fsh`
- `shaders/gbuffers_textured_lit.fsh`
- `shaders/gbuffers_water.fsh`
- `shaders/lang/en_us.lang`
- `shaders/lib/gbuffers_forward.fsh`
- `shaders/lib/gbuffers.vsh`
- `shaders/lib/settings.glsl`
- `shaders/shaders.properties`

Unchanged:

- `shaders/composite.vsh`
- `shaders/final.vsh`
- `shaders/gbuffers_terrain.vsh`
- `shaders/gbuffers_textured_lit.vsh`
- `shaders/gbuffers_water.vsh`
- `shaders/shadow.fsh`
- `shaders/shadow.vsh`
- `shaders/lib/shadow_distortion.glsl`

## Caustics depth and shadow fix

The report describes a pattern visible only through very thin water. The source inspection found the strongest matching cause in `shaders/lib/gbuffers_forward.fsh`, `singleReceiverShadow()`: the caustic receiver test sampled `shadowtex0`. Iris defines `shadowtex0` as including all geometry, while `shadowtex1` excludes transparent geometry. When translucent water is included in the shadow pass, it can therefore occlude its own receiver. The caustic test now uses one `shadowtex1` sample, keeps its normal/depth bias, and treats positions outside the shadow map range as unshadowed instead of suppressing the effect. Whether water was actually present in the active runtime map depends on Iris shadow settings; no game log was attached to verify that runtime state.

Other findings:

- The caustic receiver depth was already measured vertically in the current pack, using the visible water fragment position and the perspective-divided `depthtex1` floor position. It was not the original view-ray metric described in the report. The defaults now match the requested 2-to-11-block fade.
- The quarter-resolution shallow-water shafts and tint in `shaders/composite.fsh` did use linear view-depth subtraction, which changes with camera angle. They now use the vertical difference between reconstructed `depthtex0` water and `depthtex1` floor positions.
- `block.properties` maps `minecraft:water` to ID 1. Iris reports `mc_Entity.y == 1` for fluids, so the current `mc_Entity.y > 0.5 && mc_Entity.x == 1.0` test covers still and flowing water states. The source water mesh position also handles partial flowing heights; it does not infer depth from block-boundary `fract()`.
- The caustic color is added in the translucent water fragment and adjusted by its alpha so blending transmits the increment onto the opaque floor. The mask is not stored in an 8-bit buffer before application; the scene target uses `RGBA16F`. I added a separate gentle exponential absorption and a blue-green depth tint.
- The view-angle fade on the visible water surface has been reduced to a front/back sign test. The outside-camera and surface-crossing fade remain, so default caustics remain hidden when the camera is underwater.

**Certain from source/API:** the old caustic helper read `shadowtex0`; `shadowtex1` is Iris's opaque-only sampler; the floor depth reconstruction perspective-divides by `w`; and the water ID/render-type test matches Iris's documented `mc_Entity` meaning. **Approximate:** the screenshot's precise runtime cause, the quality of opaque shadow coverage for every GPU/driver, and all timing estimates; the screenshot and Iris log were not available in the workspace.

The caustic controls, debug views and test pool of this earlier fix are superseded by **Voronoi caustics v3 (floor and walls)** below.

### Change log and performance estimate

- Replaced the caustic shadow lookup from `shadowtex0` to `shadowtex1`; this is the primary fix for translucent-water self-occlusion. It is the same single shadow fetch, with no additional pass.
- Set caustic fade defaults to 2/11 blocks and added shallow-boost and absorption controls. The pixel grid, posterized bands, stepped animation, and intensity controls remain.
- Changed the water shaft/tint thickness to vertical world-space depth and its receiver visibility to the opaque-only shadow map.
- Replaced the grazing-angle surface fade with a front/back test while retaining the camera crossing gate.
- Expanded debug views to eight choices; these compile only when `CAUSTICS_DEBUG` is on.

Estimated incremental cost on a GTX 1650 at 1080p: about **0.01–0.04 ms** for the caustic path (one exponential and a few arithmetic operations; the shadow lookup is replaced, not added), plus roughly **0.01–0.05 ms** for quarter-resolution water shaft depth reconstruction when that effect is enabled. These are source-based estimates, not measured results. Total caustic cost depends on visible water coverage and may approach or exceed 0.25 ms in a water-heavy scene; the 120 FPS LOW target still needs an in-game benchmark.


## Voronoi caustics v3 (floor and walls)

This replaces the orthogonal-maze generator, its sliders and its "visible-space" blend. The reference is a Bedrock Vibrant Visuals pool floor seen straight down; Bedrock's renderer is not public, so everything below is either measured from the attached image or an approximation, as marked.

### Measured from the reference (decoded pixels, sRGB, no colour management)

| Property | Brief estimate | Measured | Certainty |
| --- | --- | --- | --- |
| Texel grid | 16 / block | ≈ 9.5 px per texel on both the floor and the brown block, i.e. 16 / block | Measured |
| Cell shape | Rounded 5–6-sided polygons | Confirmed: closed, rounded polygons with staircase edges | Visual |
| Cell size | 10–14 texels | Mean scanline chord ≈ 5–6 texels, which means a point spacing of about 7–9 texels. Floor-texture speckle makes this noisy. | Measured, ± 2 texels |
| Line width | 1–2 texels | Median line run ≈ 1 texel (8–9 px) | Measured |
| Line coverage | 12–20 % | ≈ 10 % (bright stretches) to 20 % (all line pixels) | Measured |
| Base floor | `#8DB4D0` | `#7A97A7` (median); light patches `#7F9DB0` | Measured |
| Mosaic (dark patches) | `#6F9BBE` | `#6988A0`, ≈ −10 % against the base; light patches ≈ +4 % | Measured |
| Line mid / light | `#B7D2D2` / `#D5E3D6` | `#A3B7BA` / `#B7CAC3` | Measured |
| Peak | `#EDE6BE` | `#C4CBBB` / `#C3D3C6` (top 0.5 %), warm R ≈ G > B | Measured |
| Wall | Light cyan-grey, faint lines | `#688099`–`#7187A0`, only ≈ 2–3 % bright pixels | Measured |
| Animation | – | Not visible in a still; all motion values are guesses exposed as sliders | Unknown |

The measured colours are darker and greyer than the eye estimates. That may be partly display gamma; the shader is calibrated to the measured values. Part of the mosaic in the reference is probably the sand texture itself.

### Why the previous version looked wrong (current Java screenshot: base `#42597F`, lines `#6F85A3`–`#8A9FB5`)

| Symptom | Cause | Fix |
| --- | --- | --- |
| Orthogonal maze, 4–8 texel cells | `causticLayer` / `causticCellHash` (value-noise outline against the texel to the right/below) in `lib/gbuffers_forward.fsh` | Removed with `CAUSTIC_LAYERS`, `NOISE_CELL_SIZE_A/B`, `LINE_THICKNESS`, `LINE_DENSITY`, `CAUSTIC_MORPH` and `MORPH_SECONDS`; replaced by the Voronoi F2 − F1 generator |
| Lines look painted on the water, with the water texture showing through them | Not a depthtex0 error: the receiver always came from depthtex1. The v2 blend added the light at full strength regardless of water opacity ("visible-space" compensation in `gbuffers_water.fsh`), so it read as a surface overlay. | Light is now added to the floor and multiplied by the water transmission (1 − a) |
| Navy, nearly opaque water; no floor visible | Vanilla texture alpha and biome blue, plus the pack's shading; no depth-dependent opacity | `WATER_DEPTH_TINT`: light teal and 25 % opacity in the shallows, deep blue and ≥ 80 % opacity with depth |
| Uniform grey lines, no peaks, no mosaic | Fixed four-level palette on a maze | Per-edge twinkle, junction boost, cream peaks, one-sided halo, three-tone mosaic |

### Generator (`causticPattern`)

1. Integer texel coordinate on the face plane (wrap period 210 blocks, divisible by every cell and mosaic size), plus a slow whole-texel global drift.
2. One jittered feature point per cell, at integer texel positions, so distances are exact integers. Each point orbits its cell on an octagon in whole-texel steps at its own rate (`CELL_ORBIT`), so the net deforms like a caustic.
3. 3×3 search (MEDIUM and up) or the 2×2 cells nearest the texel (LOW). Tracks F1, F2, F3 and the two nearest cell ids.
4. A line pixel is `F2 − F1 < LINE_WIDTH` texels, evaluated at texel centres, which gives hard staircases.
5. Brightness: 70 % per-edge hash (the unordered cell pair, re-rolled `EDGE_TWINKLE` times a second at a per-edge phase) plus 30 % per-3-texel stretch hash, plus a boost where borders meet (F3 − F1 small). The result picks mid or light; the brightest stretches become a cream peak (`PEAK_AMOUNT`). `EDGE_DROPOUT` turns some stretches into gaps.
6. Halo: one dim texel next to lines on the side of the lower cell id (`EDGE_HALO`).
7. Isolated texels: rare light pixels within 3 texels of a line.
8. Mosaic: nearest-neighbour value noise at `MOSAIC_CELL_SIZE`, three tones (−10 % / −3 % / +4 % × `MOSAIC_STRENGTH`) applied as a floor scale, never additive grey.

The level colours are additive floor light solved so that a floor under 25 %-opacity light-teal water reproduces the measured swatches. A WebGL2 render of the generator gave floor avg `#7995A3` (reference `#7A97A7`), line avg `#AABDB9` (reference `#A3B7BA`–`#B7CAC3`) and 19.8 % line coverage (17.7 % with the LOW 2×2 search).

### Blend and water

`gbuffers_water` writes premultiplied colour (`blend.gbuffers_water = ONE ONE_MINUS_SRC_ALPHA …`):

`result = water·a + (1 − a) · (floor · (1 − k) + L)`

Here L is the caustic light and k is a half-strength screen term minus the mosaic tone. The caustics land on the floor before the water tint is added and are seen through the water. Without caustics this is exactly the standard alpha blend. With `CAUSTICS_SCREEN_BLEND` off the shader falls back to additive `(1 − a)·L` with no mosaic.

`WATER_DEPTH_TINT` uses the same depthtex1 receiver: `deepMix = 1 − exp(−max(column − 1, 0) · ABSORPTION_STRENGTH)` blends `SHALLOW_TINT` → `DEEP_TINT` and `SHALLOW_OPACITY` → max(vanilla alpha, 0.8). With the defaults that is about 22 % deep at 2 blocks, 83 % at 8 and 94 % at 12. The vanilla water texture survives only as a ±15 % brightness ripple. It is not applied when the camera is underwater.

### Sliders (Water and Caustics → Pixel Caustics; water tint options on the Water screen)

| Option | Default | Notes |
| --- | --- | --- |
| `PIXEL_CAUSTICS`, `CAUSTICS_WALLS`, `CAUSTICS_SCREEN_BLEND`, `WATER_DEPTH_TINT` | on | Compile-time |
| `CAUSTICS_UNDERWATER_FLOOR` | off | Opt-in camera-underwater route (same generator, exact normals) |
| `CAUSTICS_STRENGTH` | 1.00 | 1.0 reproduces the measured swatches |
| `VORONOI_QUALITY` | 2 | 1 = 2×2 search: slightly more regular cells and the occasional straight cut where F2 is missed |
| `TEXELS_PER_BLOCK` | 16 | 8 / 16 / 32 |
| `CELL_SIZE_TEXELS` | 8 | Measured. 10–12 matches the brief's estimate; at 12, use `LINE_WIDTH` 1.0 for similar coverage |
| `CELL_JITTER` | 0.85 | LOW 0.60 to suit the 2×2 search |
| `LINE_WIDTH` | 0.75 texels | 1.0–1.25 for thicker lines |
| `EDGE_HALO` | 0.45 | 0 = off |
| `EDGE_DROPOUT` | 0.05 | Gaps per 3-texel stretch |
| `EDGE_TWINKLE` | 1.0 /s | 0 = static brightness |
| `ISOLATED_PIXELS` | 0.010 | |
| `PEAK_AMOUNT` | 0.30 | |
| `WARMTH` | 1.00 | Peak: cool white → measured cream |
| `CONTRAST` | 1.00 | Below 1 adds a faint fill between lines |
| `MOSAIC_STRENGTH` / `MOSAIC_CELL_SIZE` | 1.00 / 3 | |
| `STEPS_PER_SECOND` | 8 | |
| `CELL_ORBIT` | 2 texels | LOW 1; 0 = no deformation |
| `DRIFT_SPEED` / `DRIFT_DIRECTION` | 0.5 texels/s / 45° | Not verifiable from a still |
| `CAUSTIC_FULL_DEPTH` / `CAUSTIC_FADE_DEPTH` | 2 / 11 blocks | The mosaic fades 1.5× slower; the shallow-water shafts share the range |
| `WALL_STRENGTH` / `WALL_DEPTH_FADE` / `WALL_SUN_FACTOR` | 0.45 / 6 / 0.65 | Minimum wall sun response = 1 − factor |
| `SHALLOW_TINT` / `DEEP_TINT` | 1 / 1 | Light teal / deep blue (0 = vanilla biome colour) |
| `SHALLOW_OPACITY` / `ABSORPTION_STRENGTH` | 0.25 / 0.25 | Absorption also tints deep caustics bluer |

Presets define every caustic and water option.
- ULTRA LOW: caustics off; depth tint on, which is one depth fetch per water pixel.
- LOW: floor only, 2×2 search, 8 steps/s, orbit 1, no halo.
- MEDIUM: floor and walls, 3×3 search.
- HIGH: as MEDIUM plus water sparkles.
- CINEMATIC: 10 steps/s, more isolated pixels, stronger and deeper walls.

### Debug views (`CAUSTICS_DEBUG`, `CAUSTICS_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Face axis: floors green, X walls red, Z walls blue, stable at edges |
| 2 | 16-per-block texel checker aligned with the block texture; blocks alternate red/blue tint |
| 3 | Random flat colours per Voronoi cell: rounded 5–7-sided polygons about 8–10 texels across |
| 4 | F1: dark at each feature point, brighter towards the cell borders |
| 5 | Edge value F2 − F1: black thin network along the borders, bright cell centres |
| 6 / 7 | Line mask before / after dropout: white 1-texel staircases; mode 7 has small gaps |
| 8 | Per-edge brightness on the lines: whole edges in different greys that change about once a second |
| 9 | Mosaic alone: 3-texel grey patches in three tones |
| 10 | Levels: dark floor, navy halo, blue mid, green light, cream peak (rare, on bright stretches) |
| 11 | Vertical water column 0–12 blocks, independent of camera pitch |
| 12 | Submerged mask: white below the water line only |
| 13 | Opaque-only shadow: dark only behind opaque occluders |
| 14 | Final caustic light added to the floor |
| 15 | Water flag on every water face |

### Screenshot comparison

This session has no screen-capture or computer-use tool, so no game window was captured. Only the two attached images were measured. To iterate against Bedrock, provide these, taken under identical conditions:
- Conditions: noon (`/time set 6000`), `/weather clear`, the same coordinates, pitch −90 (straight down) and yaw 0, the same FOV, render distance, GUI scale and resolution, HUD hidden (F1), no entities or particles.
- Shots, from each game:
  1. The floor from straight above.
  2. The floor at 45°.
  3. A side wall.
  4. A flowing-water edge.
  5. About 12 consecutive frames (2 s) of the floor, or a short screen recording. These set the drift, orbit and twinkle defaults.
- Java extras: debug modes 3, 7 and 10 from the same camera.

### Test pool (identical in Java and Bedrock)

1. Flat area at y = 63. Dig a 9 × 15 pit stepped in five 3-wide bands with floors at 1, 2, 4, 8 and 12 blocks below the rim.
2. Floor material: sand in the left half, stone in the right half. Walls: smooth stone, straight.
3. In the 4-deep band, a 1 × 1 pillar up to the surface. In the 8-deep band, a 1-block-wide wall across the band.
4. A dirt block on the rim, one above the water line, as the shore block.
5. Fill with water source blocks to y = 63. At one short end, remove the rim and let water flow down a 3-block slope for the sloped edge.
6. Roof: a 3 × 3 stone slab platform 4 blocks above the 2-deep band. Plant an oak tree beside the 1-deep band.

| Situation | Correct result |
| --- | --- |
| Noon, straight down | Clear light-teal water; the sand or stone texture is readable. Polygon net about 8–10 texels per cell, light teal-white lines with some cream stretches and soft mosaic patches. Full strength to 2 blocks, fading by 11; the mosaic lingers to about 16. Walls carry a fainter net down to about 6 blocks. Hard shadows under the roof and tree. The dirt block and the water surface stay clean. |
| Sunrise / sunset | Floors fade with sun height; sun-facing walls hold longer; walls whose water is in the rim's shadow lose caustics (expected) |
| Night / rain | No caustics; the water tint remains |
| Grazing angle | The same depth classes (the column is vertical); the net is foreshortened but not stretched on walls |
| Crossing the surface | The effect fades as the eye nears the surface; underwater it is off unless `CAUSTICS_UNDERWATER_FLOOR` is on |
| 12-deep band | Deep blue and mostly opaque; no lines; a faint mosaic only near 11–16 blocks |

### Comparison checklist

| Difference | Slider |
| --- | --- |
| Cells too big / small | `CELL_SIZE_TEXELS` |
| Cells too regular / chaotic | `CELL_JITTER` (and `VORONOI_QUALITY` 2) |
| Lines too thin / thick | `LINE_WIDTH`, `EDGE_HALO` |
| Too many / few gaps | `EDGE_DROPOUT` |
| Twinkle too busy / static | `EDGE_TWINKLE`, `STEPS_PER_SECOND` |
| Mosaic too strong / invisible | `MOSAIC_STRENGTH`, `MOSAIC_CELL_SIZE` |
| Too few / many cream peaks | `PEAK_AMOUNT`, `WARMTH` |
| Lone bright pixels | `ISOLATED_PIXELS` |
| Floor not visible enough | `SHALLOW_OPACITY` ↓, `ABSORPTION_STRENGTH` ↓, `SHALLOW_TINT` |
| Overall brightness | `CAUSTICS_STRENGTH` |
| Wall response | `WALL_STRENGTH`, `WALL_SUN_FACTOR`, `WALL_DEPTH_FADE` |
| Depth fade | `CAUSTIC_FULL_DEPTH`, `CAUSTIC_FADE_DEPTH` |
| Anything above the water line | None. That is a bug: check debug modes 12 and 15. |

### Changelog and cost

- Removed the orthogonal maze generator and its options; added the Voronoi F2 − F1 generator, per-edge twinkle, junction boost, halo, dropout, isolated texels and the mosaic.
- The caustic light is now transmitted by (1 − a), so it sits on the floor seen through the water.
- Added `WATER_DEPTH_TINT`: shallow clear teal → deep blue, with depth-based opacity.
- Removed `CAUSTICS_SHALLOW_BOOST` and `CAUSTICS_ABSORPTION`; `ABSORPTION_STRENGTH` drives both the water and the caustic absorption.
- Wrap period changed from 240 to 210 blocks so every new cell size tiles.
- Debug selector extended to 15 views.
- Estimated cost (GTX 1650, 1080p, not measured), per water pixel within 48 blocks:
  - MEDIUM (3×3): about 9 + 5 integer hashes, ~400 ALU ops, one depth and one shadow fetch.
  - LOW (2×2): ~250 ops.
  - Water covering 30–40 % of the screen: about 0.10–0.25 ms MEDIUM and 0.06–0.15 ms LOW.
  - A screen filled with near water (looking down into a lake) can reach ~0.5 ms on MEDIUM, above the 0.35 ms budget; LOW stays near 0.35 ms. Use `VORONOI_QUALITY` 1 to lower it.
  - The depth tint alone (ULTRA LOW) is one fetch plus ~40 ops per water pixel.
- No new pass or buffer.
- Verified by compiling the generator in WebGL2 (GLSL ES 3.00) in both search modes; not compiled inside Iris.
- Backup of all pre-v3 files: `backup/2026-10-04_before_voronoi_v3/`.

## v3.1: smoother caustic curves and sun-lit vanilla wave pixels

### Caustic smoothing (patterns otherwise unchanged)

- **Curved edges** (`CELL_CURVE`, default 2.5 texels): a smooth, seamless domain warp (periods of about 3–4 cells) bends the straight Voronoi edges into arcs. Each texel is still evaluated once at its centre, so the output is still hard pixels.
- **Constant-width lines**: the line test now uses the exact distance to the bisector of the two nearest points instead of F2 − F1. This removes the thick clumps where borders meet. `LINE_WIDTH` 0.90 gives ≈ 20 % coverage, like before.
- **Softer brightness**: per-edge weight 0.8 / stretch weight 0.2, junction boost 0.18, `EDGE_HALO` 0.35.

The WebGL2 check rendered rounder cells at the same scale and colours, with 20.6 % line coverage.

### Sun-lit vanilla wave pixels (`WAVE_LIGHTING`)

**Source.** The vanilla animated `water_still` / `water_flow` texture stays the only wave source; frames, shapes and texel grid are untouched. Measured from the 1.21.1 jar, `water_still` is grayscale with alpha 0.706, mean luminance 0.694 and only four tones: 0.647 (50 %), 0.682 (35 %), 0.761 (10 %) and 0.827 (5 %). `water_flow` has mean 0.662. With a mean of 0.68 and the threshold `smoothstep(0.03, 0.13, L − 0.68)` quantized to `CREST_LEVELS` (default 3), the 0.761 tone becomes "soft" and the 0.827 tone "bright". The darker texels are never lit.

**Pseudo-normal.**
- Two one-texel taps (`textureGrad` with the centre's derivatives). On the sprite's last row/column, the tap steps back instead of forward; the sprite bounds come from `mc_midTexCoord`.
- A cotangent frame from screen derivatives of position and UV, taken before the alpha discard. It follows any face orientation and the rotated UVs of flowing water.
- Tilt: `WAVE_NORMAL_STRENGTH` × gradient / 0.08, where 0.08 is the measured typical crest-edge step.

**Lighting.**
- Wrap diffuse `dot(N, L)·0.5 + 0.5` × `DIFFUSE_AMOUNT`.
- Blinn-Phong glint (roughness `GLINT_SIZE`) × view Fresnel × `GLINT_AMOUNT`. This gives a pixel glint path toward a low sun and stays weak looking down at noon.
- Sun height: ×1.5 at low and mid sun, warm tint near the horizon, faint cool moon at night.
- Masks: sky light, rain (−85 %), 24–56 block distance fade, grazing fade, one opaque-only `shadowtex1` lookup.
- Stepped sparkle: `SPARKLE_AMOUNT` of the bright crests twinkle at `STEPS_PER_SECOND`, driven by the glint.

**Blend.** The light is added on the surface (not transmitted), screened over the water colour. On base texels it is exactly zero, so the base water is unchanged.

**Anti-shimmer.** Uses the texture's own mip chain (`textureGrad` with the real derivatives flattens crest contrast and gradients with distance) plus explicit distance and grazing fades. There is no LOD-bias slider, because the vanilla atlas mips already do the work and a bias would sharpen the crawl it is meant to hide.

**What it replaces.** With `WAVE_LIGHTING` on, the procedural triangle-wave ripple, the plastic water gloss and `PIXEL_WATER_SPARKLES` are bypassed on water. `WAVE_LIGHT_STRENGTH` 0 therefore leaves the plain base water, with nothing left over. With `WAVE_LIGHTING` off, the previous water shading returns.

**Presets.** ULTRA LOW off; LOW–CINEMATIC on, with the same defaults: strength 0.60, diffuse 0.25, glint 0.35, size 0.20, contrast 1.0, levels 3, tilt 0.12.

**Cost.** About two texture taps, one shadow lookup (only on lit crests) and ~120 ALU ops per visible water pixel: roughly 0.02–0.06 ms at 1080p on a GTX 1650 (not measured).

### Wave debug views (`WAVE_DEBUG`, `WAVE_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Texture luminance: the vanilla wave pattern in grey, animating as in vanilla |
| 2 | Wave = L − mean: mid grey base, brighter crest rows |
| 3 / 4 | Crest mask before / after quantization: mode 4 shows only black, grey and white texels |
| 5 | Pseudo-normal (tangent x / y in red / green): flat ≈ (0.5, 0.5); crest edges tinted |
| 6 | Wrap diffuse: brighter when the sun is high or on crests facing it |
| 7 | Glint: a band of bright texels toward a low sun; almost black with the sun behind you |
| 8 | Red = opaque shadow, green = sky light, blue = combined mask: red drops under roofs/trees, green in caves |
| 9 | Crest light alone (×2) |
| 10 | Split screen: left half with crest light, right half without (normal grading) |

### Acceptance test

1. Clear weather, `/time set 23500` (sunrise), facing the sun over a lake. The crest pixels warm up and a glint path of texels forms toward the sun. Turn 180°: only a soft lift on the crests remains.
2. `/time set 6000` (noon), looking down. The wave rows are slightly lighter than in vanilla, the glint is weak, and the shapes and animation match vanilla. Check with debug mode 10.
3. Set `WAVE_LIGHT_STRENGTH` to 0: the water equals the base water and the crests are not lit.
4. Under a roof, in a cave, in heavy rain, at night: no light (rain −85 %; night only a faint cool moon response).
5. Walk and turn over far water: no crawling; the effect fades with distance and at grazing angles.
