#version 330 compatibility

// colortex1 is white by default in Iris; the water mask needs an empty zero baseline.
const bool colortex1Clear = true;
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);

#define WATER_LAYER
#include "/lib/gbuffers_forward.fsh"

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWaterInfo;
layout(location = 2) out vec4 outDebugMaterial;
#else
/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWaterInfo;
#endif

#if defined(WAVE_DEBUG) && WAVE_DEBUG_MODE == 10
uniform float viewWidth;
#endif

void main() {
    vec3 causticsDebug;
    vec4 shaded = shadeFragment(causticsDebug);
    float transmission = 1.0 - shaded.a;
    vec3 waveLight = gWaveLight;
#if defined(WAVE_DEBUG) && WAVE_DEBUG_MODE == 10
    // Split screen: left half with the crest light, right half without.
    if (gl_FragCoord.x > 0.5 * viewWidth) waveLight = vec3(0.0);
#endif
#ifdef CAUSTICS_SCREEN_BLEND
    // Premultiplied output; shaders.properties sets blend ONE ONE_MINUS_SRC_ALPHA here.
    // result = water * a + (1 - a) * (floor * (1 - k) + L): the caustic light L and the
    // mosaic/screen factor k act on the floor BEFORE the water blend, and the sum is seen
    // through the water's transmission. Without caustics (L = 0, k = 0) this is exactly the
    // standard alpha blend.
    outColor = vec4(shaded.rgb * shaded.a + transmission * gCausticLight.rgb,
                    1.0 - transmission * (1.0 - gCausticLight.a));
    // Wave crest light sits on the surface itself: not transmitted, screened over the water.
    outColor.rgb += waveLight * clamp(1.0 - outColor.rgb, 0.0, 1.0);
#else
    // Standard alpha blend: the transmitted increment equals (1 - a) * L. The mosaic tone
    // needs the floor colour and is skipped on this path. Dividing by alpha keeps the
    // visible crest light equal to waveLight.
    outColor = vec4(shaded.rgb + (transmission * gCausticLight.rgb + waveLight) / max(shaded.a, 0.05), shaded.a);
#endif
    float fluid = vIsFluid > 0.5 ? 1.0 : 0.0;
#if defined(VV_DEBUG) && VV_DEBUG_MODE == 8
    outWaterInfo = vec4(vec3(fluid), 1.0);
#elif defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10
    outWaterInfo = vec4(gWaveDebug, 1.0);
#elif defined(CAUSTICS_DEBUG)
    outWaterInfo = vec4(causticsDebug, 1.0);
#else
    // R=fluid marker, G=surface sky light, B=water blend alpha, A=fluid marker.
    outWaterInfo = vec4(fluid, clamp(vLightCoord.y, 0.0, 1.0), clamp(shaded.a, 0.0, 1.0), fluid);
#endif

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
    vec4 debugTexel = texture(gtexture, vTexCoord) * vColor;
    float debugLuma = dot(debugTexel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float debugEmissive = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup)) *
                          smoothstep(EMISSIVE_THRESHOLD, 1.0, debugLuma);
#if VV_DEBUG_MODE == 6
    outDebugMaterial = vec4(vec3(debugEmissive), 1.0);
#else
    vec3 materialColor = vec3(0.08);
    if (vMaterialGroup == 1.0) materialColor = vec3(0.10, 0.38, 0.68);
    else if (vMaterialGroup == 2.0) materialColor = vec3(0.18, 0.48, 0.16);
    else if (vMaterialGroup == 3.0) materialColor = vec3(0.52, 0.72, 0.22);
    else if (vMaterialGroup == 4.0) materialColor = vec3(0.48, 0.29, 0.15);
    else if (vMaterialGroup == 5.0) materialColor = vec3(0.42, 0.44, 0.48);
    else if (vMaterialGroup == 6.0) materialColor = vec3(0.62, 0.40, 0.72);
    else if (vMaterialGroup == 7.0) materialColor = vec3(0.86, 0.62, 0.19);
    else if (vMaterialGroup == 8.0) materialColor = vec3(0.18, 0.68, 0.82);
    else if (vMaterialGroup == 9.0) materialColor = vec3(0.95, 0.22, 0.08);
    outDebugMaterial = vec4(materialColor, 1.0);
#endif
#endif
}
