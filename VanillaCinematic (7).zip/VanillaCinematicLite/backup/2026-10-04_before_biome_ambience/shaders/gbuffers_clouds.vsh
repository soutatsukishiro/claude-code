#version 330 compatibility

// Vanilla cloud geometry, unchanged (Iris feeds the cloud mesh: position, colour, normal).
// Only the lighting changes, in gbuffers_clouds.fsh.

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#include "/lib/ambience.glsl"

out vec4 vColor;
out vec3 vPlayerPosition;
flat out vec3 vSunWorld;
flat out vec3 vCloudTop;
flat out vec3 vCloudEdge;
flat out vec3 vCloudUnder;
flat out vec3 vZenith;
flat out vec3 vMid;
flat out vec3 vHorizon;
flat out vec3 vGlow;
flat out float vGolden;

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = gl_ProjectionMatrix * viewPosition;
    vPlayerPosition = (gbufferModelViewInverse * viewPosition).xyz;
    vColor = gl_Color;

    vSunWorld = ambSunDirection();
    AmbPalette pal = ambiencePalette(vSunWorld);
    vCloudTop = pal.cloudTop;
    vCloudEdge = pal.cloudEdge;
    vCloudUnder = pal.cloudUnder;
    vZenith = pal.zenith;
    vMid = pal.mid;
    vHorizon = pal.horizon;
    vGlow = pal.glow;
    vGolden = pal.golden;
}
