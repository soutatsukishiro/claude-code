// Shared Tier-1 water reflection. gbuffers_water and final evaluate exactly the same
// functions, so final can replace the Tier-1 colour with the screen-space reflection
// (Tier 2) without a seam, and use the same sky colour for the horizon blend.
// The includer must declare: fogColor, skyColor, sunPosition, gbufferModelViewInverse,
// rainStrength, frameTimeCounter, cameraPosition (and include lib/ambience.glsl first when
// WATER_REFLECTION_IMPROVEMENT is on).

// Core of final's evaluateSkyGradient without the camera-biome terms.
vec3 reflectionSkyGradientCore(vec3 dir, float sunElevation) {
    float day = smoothstep(-0.10, 0.20, sunElevation);
    float twilight = 1.0 - smoothstep(0.015, 0.28, abs(sunElevation));
    vec3 zenith = mix(vec3(0.035, 0.060, 0.145), vec3(0.16, 0.40, 0.68), day);
    vec3 horizon = mix(vec3(0.12, 0.17, 0.29), vec3(0.58, 0.77, 0.89), day);
    horizon = mix(horizon, vec3(0.96, 0.63, 0.46), twilight * 0.86);
    float horizonBlend = 1.0 - smoothstep(0.02, 0.90, max(dir.y, 0.0));
    vec3 gradient = mix(zenith, horizon, horizonBlend);
    float luma = dot(gradient, vec3(0.2126, 0.7152, 0.0722));
    return mix(gradient, mix(vec3(luma), vec3(0.43, 0.53, 0.64), 0.50), clamp(rainStrength, 0.0, 1.0) * 0.72);
}

// The sky seen along dir, without sun disc or clouds: the vanilla dome (fog colour at the
// horizon, sky colour above) plus the pack's sky grade and golden-hour tint.
vec3 reflectionSkyBase(vec3 dir, float sunElevation) {
    vec3 sky = mix(fogColor, skyColor, smoothstep(0.0, 0.35, dir.y));
#ifdef SKY_GRADE
    sky += (reflectionSkyGradientCore(dir, sunElevation) - skyColor) * SKY_GRADIENT_STRENGTH;
#endif
#ifdef GOLDEN_TARGET_SKY
    float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(sunElevation));
    float daySide = smoothstep(-0.16, -0.005, sunElevation);
    float warm = twilightSky * daySide * clamp(1.0 - rainStrength * 0.58, 0.0, 1.0);
    vec3 goldenSky = mix(vec3(0.46, 0.37, 0.27), vec3(1.00, 0.72, 0.39), 1.0 - smoothstep(0.015, 0.90, max(dir.y, 0.0)));
    sky = mix(sky, goldenSky, float(MATCH_STRENGTH) * 0.01 * warm * GOLDEN_SKY_TINT_STRENGTH);
#endif
    return max(sky, vec3(0.0));
}

float reflectionHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

// Tier 1: analytic sky along the reflected direction, a soft sun glow and faint,
// pixel-edged procedural clouds. No texture fetch.
vec3 waterSkyReflection(vec3 dir, float sunElevation, float cloudAmount) {
    dir.y = max(dir.y, 0.0);
    vec3 sky = reflectionSkyBase(dir, sunElevation);

    vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    float s1 = max(dot(dir, sunDir), 0.0);
    float s2 = s1 * s1;
    float s4 = s2 * s2;
    float s8 = s4 * s4;
    float s16 = s8 * s8;
    float s64 = s16 * s16 * s16 * s16;
    float twilight = 1.0 - smoothstep(0.05, 0.35, sunElevation);
    vec3 glowTint = mix(vec3(1.00, 0.93, 0.80), vec3(1.00, 0.68, 0.42), twilight);
    float sunVisible = smoothstep(-0.04, 0.10, sunElevation) * (1.0 - clamp(rainStrength, 0.0, 1.0) * 0.8);
    sky += glowTint * (s16 * 0.22 + s64 * 0.45) * sunVisible;

    // Clouds: one ray-plane intersection with the vanilla cloud height and two hashes on the
    // vanilla 12-block cloud grid (coarse clusters + fine cells). The shapes are not the real
    // vanilla clouds; real clouds that are on screen come from the Tier-2 reflection instead.
    if (cloudAmount > 0.0 && dir.y > 0.02) {
        float t = (192.0 - cameraPosition.y) / dir.y;
        if (t > 0.0) {
            vec2 cloudPos = mod(cameraPosition.xz, 3072.0) + dir.xz * t + vec2(frameTimeCounter * 0.6, 0.0);
            vec2 cell = floor(cloudPos / 12.0);
            float cover = reflectionHash(floor(cell / 4.0)) * 0.65 + reflectionHash(cell) * 0.35;
            float cloud = step(0.58, cover) * smoothstep(0.02, 0.20, dir.y);
            float day = smoothstep(-0.10, 0.20, sunElevation);
            vec3 cloudColor = mix(sky, vec3(1.0), 0.55) * mix(0.25, 1.0, day);
            sky = mix(sky, cloudColor, cloud * cloudAmount);
        }
    }
    return sky;
}

#ifdef WATER_REFLECTION_IMPROVEMENT
// Improved Tier 1 (A/B with WATER_REFLECTION_IMPROVEMENT; needs lib/ambience.glsl first):
// - the palette sky, i.e. the same function as the visible sky and the far fog (the previous
//   vanilla-based sky when the Ambience colours are off);
// - the same sharp sun glow as before;
// - clouds read from the vanilla cloud cells where the reflected ray meets the cloud layer,
//   so the reflected clouds match the real ones (one texel fetch);
// - a cooler, weaker reflection at night.
// surfaceWorld is the wrapped world position of the water surface (ambWrappedWorld).
vec3 waterSkyReflectionImproved(vec3 dir, vec3 sunDir, vec3 surfaceWorld, AmbPalette pal, float cloudAmount) {
    dir.y = max(dir.y, 0.0);
    float sunElevation = sunDir.y;
#ifdef AMBIENCE_COLORS
    vec3 sky = ambienceSky(dir, sunDir, pal.zenith, pal.mid, pal.horizon, pal.glow, pal.golden);
#else
    vec3 sky = reflectionSkyBase(dir, sunElevation);
#endif
    float s1 = max(dot(dir, sunDir), 0.0);
    float s2 = s1 * s1;
    float s4 = s2 * s2;
    float s8 = s4 * s4;
    float s16 = s8 * s8;
    float s64 = s16 * s16 * s16 * s16;
    float twilight = 1.0 - smoothstep(0.05, 0.35, sunElevation);
    vec3 glowTint = mix(vec3(1.00, 0.93, 0.80), vec3(1.00, 0.68, 0.42), twilight);
    float sunVisible = smoothstep(-0.04, 0.10, sunElevation) * (1.0 - clamp(rainStrength, 0.0, 1.0) * 0.8);
    sky += glowTint * (s16 * 0.22 + s64 * 0.45) * sunVisible;

    if (cloudAmount > 0.0 && dir.y > 0.02) {
        float t;
        vec2 cloudPos = ambCloudSpace(surfaceWorld, dir, t);
        if (t > 0.0) {
            float cloud = ambCloudCell(floor(cloudPos / AMB_CLOUD_CELL)) * smoothstep(0.02, 0.20, dir.y);
#ifdef AMBIENCE_COLORS
            // Seen from below, a cloud shows mostly its underside.
            vec3 cloudColor = mix(pal.cloudUnder, pal.cloudTop, 0.35);
#else
            vec3 cloudColor = mix(sky, vec3(1.0), 0.55) * mix(0.25, 1.0, smoothstep(-0.10, 0.20, sunElevation));
#endif
            sky = mix(sky, cloudColor, cloud * cloudAmount);
        }
    }
    float night = 1.0 - smoothstep(-0.20, 0.05, sunElevation);
    return sky * mix(vec3(1.0), vec3(0.80, 0.88, 1.05), night);
}
#endif
