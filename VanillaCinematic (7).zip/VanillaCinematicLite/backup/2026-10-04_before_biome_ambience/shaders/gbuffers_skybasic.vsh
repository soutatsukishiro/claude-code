#version 330 compatibility

// Vanilla sky geometry (sky disc, stars, sunrise fan, dark void disc), unchanged. The palette
// is evaluated per vertex (identical for every vertex) and handed on as flat values.

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#include "/lib/ambience.glsl"

out vec4 vColor;
flat out vec3 vSunWorld;
flat out vec3 vZenith;
flat out vec3 vMid;
flat out vec3 vHorizon;
flat out vec3 vGlow;
flat out float vGolden;

void main() {
    gl_Position = ftransform();
    vColor = gl_Color;
    vSunWorld = ambSunDirection();
    AmbPalette pal = ambiencePalette(vSunWorld);
    vZenith = pal.zenith;
    vMid = pal.mid;
    vHorizon = pal.horizon;
    vGlow = pal.glow;
    vGolden = pal.golden;
}
