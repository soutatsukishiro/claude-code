#version 330 compatibility

// Cloud lighting only; the vanilla blocky shapes, height, cell size and scroll are untouched.
// Colours come from the same sky as everything else (ambiencePalette derives them from the
// horizon colour and the sunlight): a translucent sky-tinted lavender body, lighter and
// denser side faces (seen edge-on they read as the thin light outlines of the reference),
// cooler deeper undersides, a mild brightening toward the sun, golden at sunrise and sunset,
// grey-lavender in rain and dim blue at night. Far clouds melt into the sky behind them
// (ambienceSkyGlow, the same function as the sky). The clouds blend over the sky that
// gbuffers_skybasic wrote, so the sky (and the sun's glow) shows through them. final skips
// its fog and tone curve on these pixels (marker in colortex1).

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
uniform float far;
uniform int moonPhase;
uniform vec3 skyColor;
uniform vec3 fogColor;

#include "/lib/ambience.glsl"

in vec4 vColor;
in vec3 vPlayerPosition;
flat in vec3 vSunWorld;
flat in vec3 vCloudTop;
flat in vec3 vCloudEdge;
flat in vec3 vCloudUnder;
flat in vec3 vZenith;
flat in vec3 vMid;
flat in vec3 vHorizon;
flat in vec3 vGlow;
flat in float vGolden;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outInfo;

void main() {
    // Face normal from screen derivatives: exact for the flat cloud faces and independent of
    // the vertex normals; flipped to face the camera.
    vec3 faceNormal = cross(dFdx(vPlayerPosition), dFdy(vPlayerPosition));
    faceNormal *= inversesqrt(max(dot(faceNormal, faceNormal), 1.0e-12));
    vec3 viewDir = vPlayerPosition * inversesqrt(max(dot(vPlayerPosition, vPlayerPosition), 1.0e-6));
    if (dot(faceNormal, viewDir) > 0.0) faceNormal = -faceNormal;
#ifdef HIDE_VANILLA_CLOUDS
    discard;
#endif
    if (vColor.a < 0.01) discard;

    float top = smoothstep(0.5, 0.9, faceNormal.y);
    float bottom = smoothstep(0.5, 0.9, -faceNormal.y);
    float side = clamp(1.0 - top - bottom, 0.0, 1.0);
    float horizontalDistance = length(vPlayerPosition.xz);

#ifdef AMBIENCE_CLOUDS
    float rain = clamp(rainStrength, 0.0, 1.0);
    float sunVisible = smoothstep(-0.05, 0.10, vSunWorld.y) * (1.0 - 0.8 * rain);

    // Side faces: light edge colour, a little deeper toward the base of the 4-block slab.
    float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
    float slab = clamp((cameraY + vPlayerPosition.y - cloudHeight) / AMB_CLOUD_THICKNESS, 0.0, 1.0);
    vec3 sideColor = mix(mix(vCloudUnder, vCloudEdge, 0.25), vCloudEdge, slab);
    // Undersides seen from straight below are a little lighter than at a grazing angle.
    vec3 underColor = mix(vCloudUnder, vCloudTop, 0.30 * smoothstep(0.35, 0.95, viewDir.y));
    vec3 body = vCloudTop * top + underColor * bottom + sideColor * side;

    // Very mild brightening of the faces turned to the sun (wrapped, no hard terminator).
    float wrap = clamp((dot(faceNormal, vSunWorld) + 0.3) / 1.3, 0.0, 1.0);
    body = mix(body, min(vCloudEdge * 1.12 + vec3(0.02), vec3(1.0)), CLOUD_SUN_LIGHT * wrap * sunVisible);
    vec3 color = mix(vColor.rgb, body, CLOUD_TINT);

    // Distance haze toward the sky behind the cloud: farther and lower clouds melt into it.
    float haze = smoothstep(far * 0.25, far * 2.6, horizontalDistance) * 0.9;
    haze = max(haze, (1.0 - smoothstep(0.02, 0.25, viewDir.y)) * smoothstep(-0.02, 0.02, viewDir.y) * 0.7);
#ifdef AMBIENCE_COLORS
    AmbPalette pal;
    pal.zenith = vZenith;
    pal.mid = vMid;
    pal.horizon = vHorizon;
    pal.fogNear = vHorizon;
    pal.cloudTop = vCloudTop;
    pal.cloudEdge = vCloudEdge;
    pal.cloudUnder = vCloudUnder;
    pal.sunLight = vec3(1.0);
    pal.skyLight = vec3(0.0);
    pal.glow = vGlow;
    pal.golden = vGolden;
    vec3 skyBehind = ambienceSkyGlow(viewDir, vSunWorld, pal, ambMoonBrightness(moonPhase));
#else
    vec3 skyBehind = mix(fogColor, skyColor, smoothstep(0.0, 0.35, viewDir.y));
#endif
    color = mix(color, skyBehind, haze);

    // Translucent body (the sky shows through); side faces are denser, like the outlines.
    float alpha = min(CLOUD_OPACITY * (1.0 + 0.30 * CLOUD_EDGE_HIGHLIGHT * side), 0.95);
#else
    // Vanilla colours (AMBIENCE_CLOUDS off), still blended over the palette sky.
    vec3 color = vColor.rgb;
    float alpha = vColor.a;
#endif
    // The far edge of the cloud mesh fades out instead of cutting off.
    alpha *= 1.0 - smoothstep(far * 3.0, far * 4.0, horizontalDistance);

#if defined(SUN_DEBUG) && SUN_DEBUG_MODE == 11
    // Cloud lighting terms: red = top faces, green = side faces, blue = undersides.
    color = vec3(top, side, bottom);
    alpha = 1.0;
#endif
    outColor = vec4(color, alpha);
    // Cloud marker for final: R = 0 keeps it apart from the water marker, G = this face's
    // opacity (sun visibility through clouds), A = 1 overwrites.
    outInfo = vec4(0.0, alpha, 0.0, 1.0);
}
