#version 330 compatibility

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
// Needed by lib/ambience.glsl (the palette is evaluated here, once per frame in practice).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#include "/lib/ambience.glsl"

out vec2 vTexCoord;
out float vSunElevation;
out float vMoonElevation;
out vec2 vSunUV;
out float vSunInFront;
out vec2 vMoonUV;
out float vMoonInFront;

// Ambience palette for this frame (sky, fog, clouds, light) and the world sun direction.
flat out vec3 vSunWorld;
flat out vec3 vPalZenith;
flat out vec3 vPalMid;
flat out vec3 vPalHorizon;
flat out vec3 vPalFogNear;
flat out vec3 vPalCloudTop;
flat out vec3 vPalCloudUnder;
flat out vec3 vPalSkyLight;
flat out vec3 vPalGlow;
flat out float vPalGolden;

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec3 sunWorld = mat3(gbufferModelViewInverse) * sunPosition;
    float sunLength2 = dot(sunWorld, sunWorld);
    sunWorld = sunLength2 > 0.000001 ? sunWorld * inversesqrt(sunLength2) : vec3(0.0, 1.0, 0.0);
    vSunElevation = sunWorld.y;

    vec3 moonWorld = mat3(gbufferModelViewInverse) * moonPosition;
    float moonLength2 = dot(moonWorld, moonWorld);
    moonWorld = moonLength2 > 0.000001 ? moonWorld * inversesqrt(moonLength2) : vec3(0.0, -1.0, 0.0);
    vMoonElevation = moonWorld.y;

    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    vMoonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = vMoonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);

    vSunWorld = sunWorld;
    AmbPalette pal = ambiencePalette(sunWorld);
    vPalZenith = pal.zenith;
    vPalMid = pal.mid;
    vPalHorizon = pal.horizon;
    vPalFogNear = pal.fogNear;
    vPalCloudTop = pal.cloudTop;
    vPalCloudUnder = pal.cloudUnder;
    vPalSkyLight = pal.skyLight;
    vPalGlow = pal.glow;
    vPalGolden = pal.golden;
}
