#version 330 compatibility

#include "/lib/settings.glsl"

// The shared sky functions (Ambience palette sky and fog, water reflection, horizon blend) are
// used by the sky treatment, the fog and the screen-space water reflection: always available.
#define FINAL_WATER_SKY

// colortex1 carries the water marker (R), its sky light (G), packed reflection data (B) and,
// on cloud pixels written by gbuffers_clouds, the cloud marker (A = 1 with R = 0).
#if defined(AMBIENCE_CLOUDS) || defined(AMBIENCE_DEBUG) || (defined(AMBIENCE_FOG) && !defined(FOG_ON_WATER))
#define AMB_FINAL_INFO
#endif

uniform sampler2D colortex0;
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES) || defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
uniform sampler2D colortex5;
#endif
#if defined(VV_DEBUG) || defined(WATER_SSR) || defined(AMB_FINAL_INFO) || ((defined(CAUSTICS_DEBUG) || defined(REFLECTION_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10)) && !defined(ATMOS_DEBUG))
uniform sampler2D colortex1;
#endif
#ifdef WATER_SSR
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelView;
#endif
uniform vec3 sunPosition;
uniform float far;
// Needed by lib/ambience.glsl.
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform ivec2 eyeBrightnessSmooth;
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
uniform sampler2D colortex2;
#endif
#if defined(SKY_GRADE) || defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(ATMOS_DEBUG) || defined(PROCEDURAL_STARS) || defined(CELESTIAL_GLOW) || defined(GOLDEN_SUN_GLOW) || defined(GOLDEN_TARGET_SKY) || defined(SECONDARY_GOLDEN_ORB) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(FINAL_WATER_SKY)
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform int isEyeInWater;
#endif
#if defined(SKY_GRADE) || defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(GOLDEN_TARGET_GRADE) || defined(ATMOS_DEBUG) || defined(PROCEDURAL_STARS) || defined(CELESTIAL_GLOW) || defined(GOLDEN_SUN_GLOW) || defined(GOLDEN_TARGET_SKY) || defined(SECONDARY_GOLDEN_ORB) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(FINAL_WATER_SKY)
uniform float temperature;
uniform float rainfall;
uniform float fogDensity;
uniform float atmosHumidBiome;
uniform float atmosCoolBiome;
uniform float atmosWoodlandBiome;
uniform float atmosSavannaBiome;
uniform float atmosPlainsBiome;
uniform float atmosDesertBiome;
uniform float atmosNether;
uniform float atmosEnd;
#endif
#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(FINAL_WATER_SKY)
uniform vec3 cameraPosition;
#endif
#if defined(SKY_GRADE) || defined(CELESTIAL_GLOW) || defined(PROCEDURAL_STARS) || defined(GOLDEN_SUN_GLOW) || defined(SECONDARY_GOLDEN_ORB) || defined(GOLDEN_FAKE_BIRDS) || defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(FINAL_WATER_SKY)
uniform int moonPhase;
uniform float frameTimeCounter;
#endif
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float thunderStrength;
uniform float aspectRatio;
uniform float atmosOverworld;
uniform bool hasSkylight;
uniform bool hasCeiling;

in vec2 vTexCoord;
in float vSunElevation;
in float vMoonElevation;
in vec2 vSunUV;
in float vSunInFront;
in vec2 vMoonUV;
in float vMoonInFront;

// Ambience palette of this frame (final.vsh).
flat in vec3 vSunWorld;
flat in vec3 vPalZenith;
flat in vec3 vPalMid;
flat in vec3 vPalHorizon;
flat in vec3 vPalFogNear;
flat in vec3 vPalCloudTop;
flat in vec3 vPalCloudUnder;
flat in vec3 vPalSkyLight;
flat in vec3 vPalGlow;
flat in float vPalGolden;

#if defined(SKY_GRADE) || defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(GOLDEN_TARGET_GRADE) || defined(ATMOS_DEBUG) || defined(PROCEDURAL_STARS) || defined(CELESTIAL_GLOW) || defined(GOLDEN_SUN_GLOW) || defined(GOLDEN_TARGET_SKY) || defined(SECONDARY_GOLDEN_ORB) || defined(GOLDEN_FAKE_BIRDS) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(FINAL_WATER_SKY)
vec3 safeNormalize(vec3 value) {
    return value * inversesqrt(max(dot(value, value), 0.000001));
}

#ifdef GOLDEN_FAKE_BIRDS
float targetBirdMask(vec2 screenUV, vec2 centerUV) {
    float cell = max(float(FAKE_BIRD_SIZE), 1.0);
    vec2 screen = vec2(viewWidth, viewHeight);
    vec2 p = (screenUV - centerUV) * screen / cell;
    float wingLine = abs(p.y - (0.30 - 0.46 * abs(p.x)));
    return step(abs(p.x), 1.05) * (1.0 - step(0.12, wingLine));
}
#endif

float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

vec3 worldViewRay(vec2 uv) {
    vec4 rayH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 0.5, 1.0);
    vec3 viewRay = safeNormalize(rayH.xyz);
    return safeNormalize(mat3(gbufferModelViewInverse) * viewRay);
}

vec3 evaluateAtmosphereColor(float viewUp, float twilight, float night) {
    vec3 haze = mix(fogColor, skyColor, smoothstep(-0.15, 0.70, viewUp) * 0.22);
    float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.15, rainfall) * 0.25), 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome * (0.65 + 0.35 * (1.0 - smoothstep(0.10, 0.75, temperature))), 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    float desertWeight = clamp(atmosDesertBiome * 0.75, 0.0, 1.0);
    float plainsWeight = clamp(atmosPlainsBiome * 0.30, 0.0, 1.0);

    haze = mix(haze, vec3(0.91, 0.64, 0.42), autumnWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.45, 0.80, 0.73), humidWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.58, 0.72, 0.87), coldWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.83, 0.65, 0.44), desertWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.65, 0.77, 0.80), plainsWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.95, 0.70, 0.50), twilight * 0.10);
    haze = mix(haze, vec3(0.40, 0.52, 0.70), night * 0.32);
    haze = mix(haze, vec3(0.48, 0.24, 0.19), clamp(atmosNether, 0.0, 1.0) * 0.30);
    haze = mix(haze, vec3(0.38, 0.29, 0.58), clamp(atmosEnd, 0.0, 1.0) * 0.28);
    return haze;
}

vec3 evaluateSkyGradient(vec3 worldDirection) {
    float day = smoothstep(-0.10, 0.20, vSunElevation);
    float twilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);

    vec3 dayZenith = vec3(0.16, 0.40, 0.68);
    vec3 dayHorizon = vec3(0.58, 0.77, 0.89);
    vec3 twilightHorizon = vec3(0.96, 0.63, 0.46);
    vec3 nightZenith = vec3(0.035, 0.060, 0.145);
    vec3 nightHorizon = vec3(0.12, 0.17, 0.29);
    vec3 zenith = mix(nightZenith, dayZenith, day);
    vec3 horizon = mix(nightHorizon, dayHorizon, day);
    horizon = mix(horizon, twilightHorizon, twilight * 0.86);

    float horizonBlend = 1.0 - smoothstep(0.02, 0.90, max(worldDirection.y, 0.0));
    vec3 gradient = mix(zenith, horizon, horizonBlend);
    vec3 fogMatchedHorizon = evaluateAtmosphereColor(0.0, twilight, night);
    gradient = mix(gradient, fogMatchedHorizon, horizonBlend * 0.22);

    float humidWeight = clamp(atmosHumidBiome, 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome, 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    gradient = mix(gradient, vec3(0.48, 0.74, 0.76), humidWeight * BIOME_TINT_STRENGTH * 0.38);
    gradient = mix(gradient, vec3(0.63, 0.75, 0.88), coldWeight * BIOME_TINT_STRENGTH * 0.32);
    gradient = mix(gradient, vec3(0.90, 0.65, 0.44), autumnWeight * BIOME_TINT_STRENGTH * 0.36);

    float luma = dot(gradient, vec3(0.2126, 0.7152, 0.0722));
    vec3 rainySky = mix(vec3(luma), vec3(0.43, 0.53, 0.64), 0.50);
    gradient = mix(gradient, rainySky, clamp(rainStrength, 0.0, 1.0) * 0.72);
    gradient = mix(gradient, vec3(0.22, 0.28, 0.37), clamp(thunderStrength, 0.0, 1.0) * 0.48);
    gradient = mix(gradient, vec3(0.48, 0.24, 0.19), clamp(atmosNether, 0.0, 1.0) * 0.22);
    gradient = mix(gradient, vec3(0.38, 0.29, 0.58), clamp(atmosEnd, 0.0, 1.0) * 0.24);
    return max(gradient, vec3(0.0));
}
#endif

#ifdef FINAL_WATER_SKY
#include "/lib/ambience.glsl"
#include "/lib/water_reflection.glsl"
#endif

AmbPalette finalPalette() {
    AmbPalette p;
    p.zenith = vPalZenith;
    p.mid = vPalMid;
    p.horizon = vPalHorizon;
    p.fogNear = vPalFogNear;
    p.cloudTop = vPalCloudTop;
    p.cloudEdge = vPalCloudTop;
    p.cloudUnder = vPalCloudUnder;
    p.sunLight = vec3(1.0);
    p.skyLight = vPalSkyLight;
    p.glow = vPalGlow;
    p.golden = vPalGolden;
    return p;
}

// Camera sky exposure (0 deep in a cave, 1 under open sky): caves get a thinner, darker haze.
float ambienceCaveLight() {
    return smoothstep(0.05, 0.60, float(eyeBrightnessSmooth.y) / 240.0);
}

#ifdef AMBIENCE_DEBUG
// Values stashed for the Ambience debug views.
float gDebugFogAmount = 0.0;
vec3 gDebugFogColor = vec3(0.0);
float gDebugBank = 0.0;
float gDebugScatter = 0.0;
float gDebugDesaturation = 0.0;
float gDebugCloudMask = 0.0;
float gDebugCloudShadow = 1.0;
vec2 gDebugCloudUV = vec2(0.0);
vec3 gDebugReflectionColor = vec3(0.0);
float gDebugReflectionValid = 0.0;
float gDebugReflectionFog = 0.0;
#endif

#ifdef WATER_SSR
bool waterProjectToScreen(vec3 playerPosition, out vec2 uv) {
    vec4 clip = gbufferProjection * (gbufferModelView * vec4(playerPosition, 1.0));
    uv = clip.xy / max(clip.w, 0.0001) * 0.5 + 0.5;
    return clip.w > 0.0001;
}

vec3 waterPlayerFromDepth(vec2 uv, float depth) {
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
}

// Tier 2: screen-space planar reflection. The water top is a horizontal plane at this
// pixel's surface height, so no ray march is needed: the reflected ray is projected at the
// render distance, then refined with the depth seen there (WATER_SSR_REFINE steps).
// colortex0 holds the scene the gbuffers produced; final only reads it, so there is no
// read/write hazard. The objects reflected stand above the water line, so their pixels are
// not covered by water. Returns the change to add: weight * (environment - Tier 1).
vec3 waterScreenReflection(vec2 uv, out vec4 debugInfo) {
    debugInfo = vec4(0.0);
    vec4 info = texture(colortex1, uv);
    if (info.r < 0.5 || isEyeInWater != 0) return vec3(0.0);
    float packedValue = floor(info.b * 255.0 + 0.5);
    float weight = floor(packedValue / 8.0) / 31.0;
    float wobble = mod(packedValue, 8.0) / 7.0 * 2.0 - 1.0;

    vec3 surface = waterPlayerFromDepth(uv, texture(depthtex0, uv).r);
    vec3 viewDir = safeNormalize(surface);
    vec3 reflectDir = vec3(viewDir.x, abs(viewDir.y), viewDir.z);
    float weather = clamp(rainStrength, 0.0, 1.0);
    // Exactly the Tier-1 colour the water program blended in (same function, flat normal).
#ifdef WATER_REFLECTION_IMPROVEMENT
    vec3 skyTier1 = waterSkyReflectionImproved(reflectDir, vSunWorld, ambWrappedWorld(surface), finalPalette(),
                                               CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#else
    vec3 skyTier1 = waterSkyReflection(reflectDir, vSunElevation, CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#endif

    vec2 reflectUV;
    bool onScreen = waterProjectToScreen(surface + reflectDir * far, reflectUV);
    for (int i = 0; i < WATER_SSR_REFINE; ++i) {
        float refineDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
        if (refineDepth > 0.99999 || !onScreen) break;
        vec3 seen = waterPlayerFromDepth(reflectUV, refineDepth);
        onScreen = waterProjectToScreen(surface + reflectDir * distance(seen, surface), reflectUV);
    }

    // Wobble with the vanilla wave texels, rougher in rain, snapped to a 2-pixel grid.
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    float roughness = 1.0 + weather * 1.5;
    reflectUV.y += wobble * REFLECTION_WOBBLE * roughness * 3.0 * pixel.y;
    reflectUV = (floor(reflectUV / (2.0 * pixel)) + 0.5) * 2.0 * pixel;

    float hitDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
    vec3 hit = waterPlayerFromDepth(reflectUV, hitDepth);
    float edgeFade = smoothstep(0.0, 0.05, reflectUV.x) * smoothstep(0.0, 0.05, 1.0 - reflectUV.x) *
                     smoothstep(0.0, 0.05, reflectUV.y) * smoothstep(0.0, 0.05, 1.0 - reflectUV.y);
    // Valid: on screen, an object above the water plane (not water, floor or sky), and not the
    // hand or other camera-near geometry. Sky samples keep Tier 1, which already matches the sky.
    bool aboveWater = hitDepth < 0.99999 && hit.y > surface.y + 0.05 && dot(hit, hit) > 1.0;
    float valid = (onScreen && aboveWater) ? edgeFade : 0.0;

    // Soft, vertically stretched, low contrast: vertical taps around the reflected point.
    vec3 environment = vec3(0.0);
    for (int k = 0; k < REFLECTION_BLUR; ++k) {
        float offset = (float(k) - float(REFLECTION_BLUR - 1) * 0.5) * float(REFLECTION_STRETCH) * roughness;
        environment += texture(colortex0, clamp(reflectUV + vec2(0.0, offset * pixel.y), vec2(0.0), vec2(1.0))).rgb;
    }
    environment /= float(REFLECTION_BLUR);
#ifdef WATER_REFLECTION_IMPROVEMENT
    float reflectionFog = 0.0;
#ifdef AMBIENCE_FOG
    // Fog-aware: the reflected light first crosses the haze between the reflected object and
    // the water; final's fog then adds the camera-to-water part, so far reflected mountains
    // ghost out like the real ones (exact for uniform fog, close for the height profile).
    // Reflected clouds carry their own haze from gbuffers_clouds and are left alone.
    bool hitIsCloud = false;
#ifdef AMBIENCE_CLOUDS
    vec4 hitInfo = texture(colortex1, clamp(reflectUV, vec2(0.0), vec2(1.0)));
    hitIsCloud = hitInfo.a > 0.5 && hitInfo.r < 0.5;
#endif
    if (valid > 0.0 && !hitIsCloud && atmosOverworld > 0.5) {
        float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
        float segmentT = ambienceSegmentTransmittance(distance(hit, surface), cameraY + surface.y, cameraY + hit.y);
        vec3 segmentColor = ambienceFogNear(reflectDir, vSunWorld, vPalFogNear, vPalGlow) * mix(0.25, 1.0, ambienceCaveLight());
        environment = mix(segmentColor, environment, segmentT);
        reflectionFog = 1.0 - segmentT;
    }
#endif
    // Rain roughens the reflection (lower contrast); at night it is cooler like Tier 1.
    environment = mix(environment, vec3(ambLuma(environment)), 0.25 * weather);
    environment *= mix(vec3(1.0), vec3(0.80, 0.88, 1.05), 1.0 - smoothstep(-0.20, 0.05, vSunWorld.y));
#ifdef AMBIENCE_DEBUG
    gDebugReflectionFog = reflectionFog;
    gDebugReflectionValid = valid;
#endif
#endif
    environment = mix(environment, skyTier1, 0.20 + 0.35 * weather);
#ifdef AMBIENCE_DEBUG
    gDebugReflectionColor = mix(skyTier1, environment, valid);
#endif

#ifdef REFLECTION_DEBUG
#if REFLECTION_DEBUG_MODE == 5
    debugInfo = vec4(clamp(reflectUV, vec2(0.0), vec2(1.0)), 0.0, valid);
#else
    debugInfo = vec4(environment * valid, valid);
#endif
#endif
    return weight * valid * (environment - skyTier1);
}
#endif

#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(ATMOS_DEBUG)
float evaluateFogFactor(float viewDistance, float worldY) {
    float heightAboveSea = max(worldY - 63.0, 0.0);
    float heightFactor = 1.0 / (1.0 + heightAboveSea * HAZE_HEIGHT_FALLOFF);
    float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
    float weatherDensity = 1.0 + rainStrength * 0.22 + thunderStrength * 0.38 + twilight * 0.20 + night * 0.10;
    float biomeFogScale = mix(0.80, 1.20, clamp(fogDensity, 0.0, 1.0));
    float dimensionFogScale = mix(1.0, 0.55, clamp(atmosNether, 0.0, 1.0));
    dimensionFogScale = mix(dimensionFogScale, 0.30, clamp(atmosEnd, 0.0, 1.0));
    return 1.0 - exp(-viewDistance * HAZE_DENSITY * heightFactor * weatherDensity * biomeFogScale * dimensionFogScale);
}
#endif

#ifdef PROCEDURAL_STARS
float evaluateProceduralStars(vec3 worldDirection) {
    float nightFade = 1.0 - smoothstep(-0.22, 0.06, vSunElevation);
    float weatherFade = (1.0 - clamp(rainStrength, 0.0, 1.0)) *
                        (1.0 - clamp(thunderStrength, 0.0, 1.0) * 0.95);
    float moonBrightness = abs(4.0 - float(moonPhase)) * 0.25;
    float moonFade = 1.0 - moonBrightness * 0.28;
    float upperSky = smoothstep(-0.04, 0.10, worldDirection.y);
    float starGridScale;
#if SKY_QUALITY == 1
    starGridScale = 58.0;
#else
    starGridScale = 104.0;
#endif
    vec2 projected = worldDirection.xz / max(abs(worldDirection.y), 0.08) * starGridScale;
    vec2 cell = floor(projected);
    vec2 localPoint = fract(projected) - 0.5;
    float cellHash = cheapHash(cell);
    float star = step(1.0 - STAR_AMOUNT * 0.045, cellHash);
    float pixel = 1.0 - smoothstep(0.025, 0.11, length(localPoint));
    float twinkle = 0.68 + 0.32 * cheapHash(cell + vec2(floor(frameTimeCounter * 1.3), 29.0));
    return star * pixel * twinkle * nightFade * weatherFade * moonFade * upperSky * atmosOverworld;
}
#endif

void main() {
#ifdef TARGET_DEBUG
    float targetDebugSun = 0.0;
    float targetDebugQuantizedGlow = 0.0;
    vec3 targetDebugSky = vec3(0.0);
    float targetDebugFog = 0.0;
    float targetDebugPhase = 0.0;
    vec3 targetDebugBeforeGrade = vec3(0.0);
    vec3 targetDebugAfterGrade = vec3(0.0);
#endif
#ifdef VV_DEBUG
#if VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 2 || VV_DEBUG_MODE == 5 || VV_DEBUG_MODE == 9
    vec3 quarterDebug = texture(colortex5, vTexCoord).rgb;
#if VV_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(quarterDebug.r), 1.0);
#else
    gl_FragColor = vec4(quarterDebug, 1.0);
#endif
#elif VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex2, vTexCoord).rgb, 1.0);
#elif VV_DEBUG_MODE == 8
    gl_FragColor = vec4(vec3(texture(colortex1, vTexCoord).r), 1.0);
#elif VV_DEBUG_MODE == 3
    float debugDepth = texture(depthtex0, vTexCoord).r;
    if (debugDepth < 0.99999) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, debugDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
#elif VV_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), 1.0);
#else
    gl_FragColor = vec4(1.0, 0.0, 1.0, 1.0);
#endif
    return;
#endif

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 1 || ATMOS_DEBUG_MODE == 2 || ATMOS_DEBUG_MODE == 6
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
    return;
#endif
#elif defined(CAUSTICS_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10) || (defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE != 3 && REFLECTION_DEBUG_MODE != 4 && REFLECTION_DEBUG_MODE != 5 && REFLECTION_DEBUG_MODE != 12)
    // Raw diagnostic written by the water/terrain programs, shown without grading.
    gl_FragColor = vec4(texture(colortex1, vTexCoord).rgb, 1.0);
    return;
#endif

    vec4 scene = texture(colortex0, vTexCoord);
    vec3 color = scene.rgb;

#ifdef WATER_SSR
    // Swap the Tier-1 sky colour baked into the water for the reflected environment, before
    // haze and grading so the reflection is fogged by the water's own distance.
    vec4 reflectionDebug;
    vec3 screenReflection = waterScreenReflection(vTexCoord, reflectionDebug);
#if defined(AMBIENCE_DEBUG) && AMBIENCE_DEBUG_MODE == 14
    // Split view: left half without the screen-space reflection, right half with it.
    if (vTexCoord.x < 0.5) screenReflection = vec3(0.0);
#endif
    color += screenReflection;
#if defined(REFLECTION_DEBUG) && (REFLECTION_DEBUG_MODE == 3 || REFLECTION_DEBUG_MODE == 4 || REFLECTION_DEBUG_MODE == 5)
#if REFLECTION_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(reflectionDebug.a), 1.0);
#else
    gl_FragColor = vec4(reflectionDebug.rgb, 1.0);
#endif
    return;
#endif
#endif

    float sceneDepth = texture(depthtex0, vTexCoord).r;

    // Sun-ray mask written by composite into colortex5.a (0 without rays): it brightens the
    // haze slightly inside light shafts, with no extra sample.
    float rayMask = 0.0;
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES)
    vec4 auxiliary = texture(colortex5, vTexCoord);
    color += auxiliary.rgb;
#ifdef ATMOSPHERIC_RAYS
    rayMask = clamp(auxiliary.a, 0.0, 1.0);
#endif
#endif

#ifdef ATMOS_TONE_MAP
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;
    float day = smoothstep(-0.12, 0.15, vSunElevation);
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float shadowTone = 1.0 - smoothstep(0.08, 0.72, luminance);
    float highlightTone = smoothstep(0.22, 0.90, luminance);

    // Gentle existing cinematic shoulder and highlight warmth.
    color *= mix(vec3(1.0), vec3(0.94, 0.98, 1.035), shadowTone * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    color *= mix(vec3(1.0), vec3(1.025, 1.008, 0.975), highlightTone * day * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    vec3 softClip = color / (1.0 + max(color, vec3(0.0)) * 0.12);
    color = mix(color, softClip, 0.58 * TONE_SHOULDER_STRENGTH * overworld);
#else
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;
#endif

#if defined(SKY_GRADE) || defined(CELESTIAL_GLOW) || defined(PROCEDURAL_STARS) || defined(GOLDEN_SUN_GLOW) || defined(GOLDEN_TARGET_SKY) || defined(SECONDARY_GOLDEN_ORB) || defined(GOLDEN_FAKE_BIRDS) || defined(TARGET_DEBUG) || defined(AMBIENCE_COLORS)
    if (sceneDepth > 0.99999 && isEyeInWater == 0) {
        vec3 worldDirection = worldViewRay(vTexCoord);
        vec3 skyGradient = skyColor;
#ifdef AMBIENCE_COLORS
        if (overworld > 0.5) {
            // Palette sky. Vanilla draws a dome that fades from the sky colour to the fog colour
            // (sky disc 16 blocks up, linear fog to the render distance); that dome is replaced
            // by the palette sky, and what vanilla draws on top of it (sun, moon, stars, sunrise
            // fan) survives as the residual. Near the horizon the replacement is complete, so
            // the sky equals the far fog colour there: no line between terrain and sky.
            vec3 vanillaDome = mix(skyColor, fogColor, clamp(16.0 / (max(worldDirection.y, 0.0) * far + 1.0e-3), 0.0, 1.0));
#ifdef ATMOS_TONE_MAP
            vanillaDome = mix(vanillaDome, vanillaDome / (1.0 + vanillaDome * 0.12), 0.58 * TONE_SHOULDER_STRENGTH);
#endif
            skyGradient = ambienceSky(worldDirection, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            float paletteWeight = mix(ENV_SKY_PALETTE, 1.0, 1.0 - smoothstep(0.0, 0.25, worldDirection.y));
            color = max(color + (skyGradient - vanillaDome) * paletteWeight, vec3(0.0));
#ifdef TARGET_DEBUG
            targetDebugSky = skyGradient;
#endif
        } else
#endif
        {
        // Previous sky treatment (Ambience colours off, or the Nether and the End).
#if defined(SKY_GRADE) || defined(CELESTIAL_GLOW) || defined(GOLDEN_TARGET_SKY)
        skyGradient = evaluateSkyGradient(worldDirection);
#endif

#ifdef SKY_GRADE
        float dimensionWeight = clamp(atmosOverworld + atmosNether + atmosEnd, 0.0, 1.0);
        color += (skyGradient - skyColor) * SKY_GRADIENT_STRENGTH * dimensionWeight;
        float dither = (cheapHash(floor(gl_FragCoord.xy)) - 0.5) * (0.75 / 255.0);
        color += vec3(dither * SKY_GRADIENT_STRENGTH);
#endif

#ifdef GOLDEN_TARGET_SKY
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(vSunElevation));
        float daySide = smoothstep(-0.16, -0.005, vSunElevation);
        float targetSkyWeather = clamp(1.0 - rainStrength * 0.58 - thunderStrength * 0.32, 0.0, 1.0);
        float warmBiomeSky = clamp(max(atmosSavannaBiome * 0.55, atmosWoodlandBiome * 0.24), 0.0, 1.0);
        float warmSkyMask = max(twilightSky * daySide, warmBiomeSky * (1.0 - smoothstep(-0.10, 0.18, vSunElevation)));
        warmSkyMask *= targetSkyWeather * atmosOverworld;
        float skyHorizonMix = 1.0 - smoothstep(0.015, 0.90, max(worldDirection.y, 0.0));
        vec3 goldenZenith = vec3(0.46, 0.37, 0.27);
        vec3 goldenHorizon = vec3(1.00, 0.72, 0.39);
        vec3 goldenSky = mix(goldenZenith, goldenHorizon, skyHorizonMix);
        color = mix(color, goldenSky, targetMatch * warmSkyMask * GOLDEN_SKY_TINT_STRENGTH);
#ifdef TARGET_DEBUG
        targetDebugSky = goldenSky;
#endif
#endif
        }

#if defined(CELESTIAL_GLOW) || defined(GOLDEN_SUN_GLOW) || defined(SECONDARY_GOLDEN_ORB)
        if (atmosOverworld > 0.5) {
        vec2 aspectScale = vec2(aspectRatio, 1.0);
        float sunVisible = vSunInFront * smoothstep(-0.12, 0.12, vSunElevation) * clamp(1.0 - rainStrength * 0.78 - thunderStrength * 0.22, 0.0, 1.0);
        vec2 sunDelta = (vTexCoord - vSunUV) * aspectScale;
        float sunDistance = length(sunDelta);
#ifdef CELESTIAL_GLOW
        float sunRadius = max(CELESTIAL_GLOW_RADIUS, 0.001);
        float sunHalo = 1.0 / (1.0 + 7.0 * sunDistance * sunDistance / (sunRadius * sunRadius));
        float twilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
        vec3 sunTint = mix(vec3(1.00, 0.91, 0.72), vec3(1.00, 0.68, 0.43), twilight * 0.75);
        float targetMatchForHalo = 0.0;
#ifdef GOLDEN_SUN_GLOW
        targetMatchForHalo = float(MATCH_STRENGTH) * 0.01;
#endif
        color += sunTint * sunHalo * sunVisible * CELESTIAL_GLOW_STRENGTH * (1.0 - targetMatchForHalo);

#if SUN_STYLE == 1
        float squareDistance = max(abs(sunDelta.x), abs(sunDelta.y));
        float vanillaDiscCover = 1.0 - smoothstep(SUN_DISC_SIZE, SUN_DISC_SIZE + 0.002, squareDistance);
        float roundDisc = 1.0 - smoothstep(SUN_DISC_SIZE * 0.67, SUN_DISC_SIZE, sunDistance);
        color = mix(color, skyGradient, vanillaDiscCover * sunVisible * (1.0 - targetMatchForHalo));
        color += vec3(1.18, 0.86, 0.58) * roundDisc * sunVisible * (1.0 - targetMatchForHalo);
#endif
#endif

#ifdef GOLDEN_SUN_GLOW
        float targetSunMatch = float(MATCH_STRENGTH) * 0.01;
        float targetTwilight = 1.0 - smoothstep(0.035, 0.36, abs(vSunElevation));
        float lowSunFade = 1.0 - smoothstep(0.12, 0.56, max(vSunElevation, 0.0));
        float targetSunTime = max(targetTwilight, lowSunFade * 0.24);
        float targetSunVisible = vSunInFront * smoothstep(-0.10, 0.10, vSunElevation) *
                                 clamp(1.0 - rainStrength * 0.78 - thunderStrength * 0.22, 0.0, 1.0);
        vec2 fullResolution = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
        vec2 glowUV = vTexCoord;
        float glowCell = float(GOLDEN_GLOW_PIXEL_SIZE);
        vec2 snappedGlowUV = (floor(glowUV * fullResolution / glowCell) + 0.5) * glowCell / fullResolution;
        glowUV = mix(glowUV, snappedGlowUV, GOLDEN_GLOW_BLOCKINESS);
        vec2 targetDelta = (glowUV - vSunUV) * fullResolution / max(viewHeight, 1.0);
        float targetRadialDistance = length(targetDelta);
        float targetSquareDistance = max(abs(targetDelta.x), abs(targetDelta.y));
        float radialGlow = 0.64 / (1.0 + 8.0 * targetRadialDistance + 26.0 * targetRadialDistance * targetRadialDistance);
        float horizontalBand = exp(-abs(targetDelta.y) * 15.0) * exp(-abs(targetDelta.x) * 1.15);
        float verticalCross = exp(-abs(targetDelta.x) * 17.0) * exp(-abs(targetDelta.y) * 0.95);
        float glowEnergy = clamp(radialGlow + horizontalBand * GOLDEN_BAND_STRENGTH +
                                 verticalCross * GOLDEN_CROSS_STRENGTH, 0.0, 1.0);
        float glowLevels = max(float(GOLDEN_GLOW_LEVELS), 2.0);
        float steppedGlow = floor(glowEnergy * glowLevels + 0.5) / glowLevels;
        float glowTime = targetSunTime * targetSunVisible * targetSunMatch;
        vec3 goldenGlowTint = mix(vec3(1.00, 0.83, 0.59), vec3(1.00, 0.63, 0.31), targetTwilight);
        color += goldenGlowTint * steppedGlow * GOLDEN_GLOW_STRENGTH * glowTime;

        float coreAA = 1.0 / max(viewHeight, 1.0);
        float squareSunCore = 1.0 - smoothstep(GOLDEN_SUN_CORE_SIZE, GOLDEN_SUN_CORE_SIZE + coreAA, targetSquareDistance);
        color = mix(color, vec3(1.42, 1.30, 1.08), squareSunCore * glowTime);
#ifdef TARGET_DEBUG
        targetDebugSun = clamp(glowEnergy * glowTime, 0.0, 1.0);
        targetDebugQuantizedGlow = clamp(steppedGlow * glowTime, 0.0, 1.0);
#endif
#endif

#ifdef SECONDARY_GOLDEN_ORB
        float targetOrbMatch = float(MATCH_STRENGTH) * 0.01;
        float orbTime = (1.0 - smoothstep(0.07, 0.48, max(vSunElevation, 0.0))) *
                        smoothstep(-0.12, 0.08, vSunElevation);
        orbTime *= vSunInFront * clamp(1.0 - rainStrength * 0.75 - thunderStrength * 0.25, 0.0, 1.0);
        vec2 orbUV = vSunUV + vec2(-0.035, -0.20);
        vec2 orbDelta = (vTexCoord - orbUV) * vec2(aspectRatio, 1.0);
        float orbDistance = length(orbDelta);
        float orbSize = max(SECONDARY_ORB_SIZE, 0.001);
        float orbHalo = 1.0 / (1.0 + 14.0 * orbDistance * orbDistance / (orbSize * orbSize));
        float orbCore = 1.0 - smoothstep(orbSize * 0.18, orbSize * 0.34, orbDistance);
        color += vec3(1.00, 0.75, 0.47) * (orbHalo * 0.52 + orbCore * 0.30) *
                 SECONDARY_ORB_STRENGTH * orbTime * targetOrbMatch;
#endif

#ifdef CELESTIAL_GLOW
        vec2 moonDelta = (vTexCoord - vMoonUV) * aspectScale;
        float moonDistance = length(moonDelta);
        float moonRadius = max(CELESTIAL_GLOW_RADIUS * 0.75, 0.001);
        float moonHalo = 1.0 / (1.0 + 7.0 * moonDistance * moonDistance / (moonRadius * moonRadius));
        float moonVisible = vMoonInFront * smoothstep(0.015, 0.20, vMoonElevation) *
                            (1.0 - rainStrength * 0.72 - thunderStrength * 0.24);
        float moonBrightness = abs(4.0 - float(moonPhase)) * 0.25;
        color += vec3(0.56, 0.70, 0.94) * moonHalo * moonVisible * moonBrightness * CELESTIAL_GLOW_STRENGTH * 0.70;
#endif
        }
#endif

#ifdef PROCEDURAL_STARS
        float stars = evaluateProceduralStars(worldDirection);
        color += vec3(0.72, 0.84, 1.0) * stars * 0.22;
#endif

#ifdef GOLDEN_FAKE_BIRDS
        float birdMatch = float(MATCH_STRENGTH) * 0.01;
        float birdTime = frameTimeCounter * FAKE_BIRD_SPEED;
        float birdDay = smoothstep(-0.10, 0.12, vSunElevation) *
                        clamp(1.0 - rainStrength * 0.90 - thunderStrength * 0.40, 0.0, 1.0);
        if (birdDay * birdMatch * FAKE_BIRD_AMOUNT > 0.001) {
            vec2 birdScreen = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
            float birdCell = max(float(FAKE_BIRD_SIZE), 1.0);
            vec2 birdPixelUV = (floor(vTexCoord * birdScreen / birdCell) + 0.5) * birdCell / birdScreen;
            float birds = targetBirdMask(birdPixelUV, vec2(fract(0.16 + birdTime), 0.84));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.49 + birdTime * 0.78), 0.78));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.76 + birdTime * 1.12), 0.88));
            color = mix(color, vec3(0.13, 0.10, 0.075), clamp(birds * FAKE_BIRD_AMOUNT * birdDay * birdMatch, 0.0, 0.82));
        }
#endif
    }
#endif

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 3
    if (sceneDepth < 0.99999 && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
    return;
#elif ATMOS_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(max(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), vec3(0.0)), 1.0);
    return;
#elif ATMOS_DEBUG_MODE == 5
    vec3 debugSkyDirection = worldViewRay(vTexCoord);
    gl_FragColor = vec4(evaluateSkyGradient(debugSkyDirection), 1.0);
    return;
#endif
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    vec3 colorBeforeFog = color;
#endif
#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(AMBIENCE_FOG)
    if (sceneDepth < 0.99999 && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec4 viewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        vec3 viewPosition = viewH.xyz / max(viewH.w, 0.0001);
        vec3 playerPosition = (gbufferModelViewInverse * vec4(viewPosition, 1.0)).xyz;
        vec3 worldPosition = cameraPosition + playerPosition;
        float viewDistance = length(viewPosition);
        float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
        float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
        float viewUp = viewPosition.y / max(viewDistance, 0.0001);
        vec3 hazeColor = evaluateAtmosphereColor(viewUp, twilight, night);
        float targetFogFactor = 0.0;

        // Which surface is this? Clouds (gbuffers_clouds marker) carry their own haze toward the
        // same sky colour, so they are never fogged twice. Water uses the Ambience fog unless
        // FOG_ON_WATER is off, in which case it keeps the previous haze.
        bool cloudPixel = false;
        bool waterPixel = false;
#ifdef AMB_FINAL_INFO
        vec4 ambienceInfo = texture(colortex1, vTexCoord);
        waterPixel = ambienceInfo.r > 0.5;
#ifdef AMBIENCE_CLOUDS
        cloudPixel = ambienceInfo.a > 0.5 && !waterPixel;
#endif
#endif
        bool ambienceFogHere = false;
#ifdef AMBIENCE_FOG
        ambienceFogHere = overworld > 0.5;
#ifndef FOG_ON_WATER
        if (waterPixel) ambienceFogHere = false;
#endif
#endif

        if (cloudPixel) {
            // Nothing: see gbuffers_clouds.fsh.
        } else if (ambienceFogHere) {
#ifdef AMBIENCE_FOG
            // The cloud shadow on this surface darkens and cools the haze in front of it. Final
            // cannot see the gbuffers' value (no free buffer channel), so it re-reads the same
            // cells: one fetch (quality 1) or four (quality 2), cached 256x256 texture.
            float cloudShadowHere = 1.0;
#ifdef CLOUD_SHADOW_ENABLE
            float cloudMask;
            vec2 cloudUV;
            cloudShadowHere = ambienceCloudShadow(playerPosition + vec3(0.0, 0.1, 0.0), vSunWorld, cloudMask, cloudUV);
#ifdef AMBIENCE_DEBUG
            gDebugCloudMask = cloudMask;
            gDebugCloudShadow = cloudShadowHere;
            gDebugCloudUV = cloudUV;
#endif
#endif
            AmbFog fog = ambienceFog(playerPosition, vSunWorld, finalPalette(), far, cloudShadowHere, rayMask, ambienceCaveLight());
#ifdef FOG_BANDED_LOOK
            // Pixel-art option: a few fog steps, ordered-dithered so the steps do not band.
            float fogLevels = float(FOG_LEVELS);
            fog.amount = min(floor(fog.amount * fogLevels + ambBayer4(gl_FragCoord.xy)) / fogLevels, 1.0);
#endif
            color = ambienceApplyFog(color, fog);
            targetFogFactor = fog.amount;
            hazeColor = fog.color;
#ifdef AMBIENCE_DEBUG
            gDebugFogAmount = fog.amount;
            gDebugFogColor = fog.color;
            gDebugBank = fog.bank;
            gDebugScatter = fog.scatter;
            gDebugDesaturation = fog.desaturation;
#endif
#endif
        } else {
#ifdef ATMOSPHERIC_HAZE
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
        float distanceBlend = smoothstep(24.0, 112.0, viewDistance);
        color *= mix(vec3(1.0), vec3(0.95, 0.98, 1.035), distanceBlend * targetFogFactor * 0.45);
        float rainLumaForHaze = dot(color, vec3(0.2126, 0.7152, 0.0722));
        color = mix(color, vec3(rainLumaForHaze) * vec3(0.96, 1.0, 1.05), targetFogFactor * rainStrength * 0.10);
        color = mix(color, hazeColor, targetFogFactor);
#elif defined(GOLDEN_TARGET_HAZE)
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
#endif
        // Horizon blend: near the render distance, terrain and water fade into the colour of the
        // sky behind them (like vanilla's border fog), so the water edge meets the sky without
        // the hard pale band. Same sky function as the water's Tier-1 reflection.
        float borderFog = smoothstep(far * 0.55, far * 0.95, length(playerPosition.xz)) * HORIZON_BLEND;
        color = mix(color, reflectionSkyBase(safeNormalize(playerPosition), vSunElevation), borderFog);
        }

#ifdef GOLDEN_TARGET_HAZE
        if (!cloudPixel) {
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float targetWarmTime = smoothstep(-0.16, 0.07, vSunElevation) *
                               (1.0 - smoothstep(0.14, 0.54, max(vSunElevation, 0.0)));
        float savannaHaze = clamp(max(atmosSavannaBiome, atmosDesertBiome * 0.42), 0.0, 1.0);
        float warmHazeMask = max(1.0 - smoothstep(0.035, 0.34, abs(vSunElevation)), savannaHaze * targetWarmTime);
        float targetWeather = clamp(1.0 - rainStrength * 0.70 - thunderStrength * 0.35, 0.0, 1.0);
        vec2 hazeScreenDelta = (vTexCoord - vSunUV) * vec2(aspectRatio, 1.0);
        float hazePhase = 1.0 - smoothstep(0.035, 0.62, length(hazeScreenDelta));
        hazePhase *= hazePhase * vSunInFront * smoothstep(-0.10, 0.14, vSunElevation);
        vec3 goldenHazeColor = mix(hazeColor, vec3(0.99, 0.70, 0.43), warmHazeMask);
        float extraGoldenFog = targetFogFactor * GOLDEN_HAZE_STRENGTH * targetMatch * warmHazeMask * targetWeather;
        extraGoldenFog *= clamp(0.58 + hazePhase * GOLDEN_HAZE_PHASE, 0.0, 1.0);
        color = mix(color, goldenHazeColor, clamp(extraGoldenFog, 0.0, 0.72));
#ifdef TARGET_DEBUG
        targetDebugFog = clamp(targetFogFactor * warmHazeMask, 0.0, 1.0);
        targetDebugPhase = clamp(hazePhase, 0.0, 1.0);
#endif
        }
#endif
    }
#endif

#ifdef AMBIENCE_DEBUG
    vec3 colorAfterFog = color;
#endif
#ifdef TARGET_DEBUG
    targetDebugBeforeGrade = color;
#endif

#ifdef GOLDEN_TARGET_GRADE
    float targetMatch = float(MATCH_STRENGTH) * 0.01;
    float goldenHour = (1.0 - smoothstep(0.035, 0.34, abs(vSunElevation))) *
                       smoothstep(-0.16, 0.045, vSunElevation);
    float warmRegion = clamp(max(atmosSavannaBiome * 0.52, atmosDesertBiome * 0.20), 0.0, 1.0);
    float goldenGradeMask = max(goldenHour, warmRegion * (1.0 - smoothstep(0.18, 0.52, max(vSunElevation, 0.0))));
    goldenGradeMask *= overworld * clamp(1.0 - rainStrength * 0.42 - thunderStrength * 0.30, 0.0, 1.0);
    vec3 gradeLumaColor = vec3(dot(color, vec3(0.2126, 0.7152, 0.0722)));
    vec3 goldenTint = vec3(1.00, 0.91, 0.77);
    color *= mix(vec3(1.0), goldenTint, goldenGradeMask * GOLDEN_GRADE_STRENGTH * targetMatch);
    float darkSurface = 1.0 - smoothstep(0.06, 0.44, dot(color, vec3(0.2126, 0.7152, 0.0722)));
    color += vec3(1.0, 0.57, 0.28) * darkSurface * goldenGradeMask * GOLDEN_SHADOW_LIFT * targetMatch;
    color = mix(color, max(gradeLumaColor, vec3(0.0)), rainStrength * targetMatch * 0.025 * overworld);
#endif

#ifdef TARGET_DEBUG
    targetDebugAfterGrade = color;
#endif

#ifdef ATMOSPHERIC_GRADE
    // Restrained green vibrance with a 0..1 saturation safety clamp.
    float greenChroma = color.g - max(color.r, color.b);
    float greenMask = smoothstep(0.015, 0.18, greenChroma) * overworld * (1.0 - rainStrength * 0.35);
    vec3 safeColor = clamp(color, vec3(0.0), vec3(1.0));
    float safeLuma = dot(safeColor, vec3(0.2126, 0.7152, 0.0722));
    vec3 vibrantColor = clamp(mix(vec3(safeLuma), safeColor, 1.0 + VIBRANCE_STRENGTH), vec3(0.0), vec3(1.0));
    color = mix(color, vibrantColor, greenMask);
#endif

#ifdef ATMOSPHERIC_GRADE
    float rainLuma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float stormDesaturation = rainStrength * 0.11 + thunderStrength * 0.08;
    color = mix(color, vec3(rainLuma) * vec3(0.96, 1.00, 1.05), stormDesaturation * overworld);
#endif

#if defined(ATMOS_VIGNETTE) || defined(GOLDEN_SOFT_VIGNETTE)
    vec2 vignettePos = (vTexCoord - vec2(0.5)) * vec2(aspectRatio, 1.0);
    float vignette = smoothstep(0.12, 0.72, dot(vignettePos, vignettePos));
    float vignetteStrength = 0.0;
#ifdef ATMOS_VIGNETTE
    vignetteStrength += VIGNETTE_STRENGTH;
#endif
#ifdef GOLDEN_SOFT_VIGNETTE
    vignetteStrength += GOLDEN_VIGNETTE_STRENGTH * float(MATCH_STRENGTH) * 0.01;
#endif
    color *= 1.0 - vignette * vignetteStrength * overworld;
#endif

#ifdef TARGET_DEBUG
#if TARGET_DEBUG_MODE == 1
    gl_FragColor = vec4(vec3(targetDebugSun), 1.0);
#elif TARGET_DEBUG_MODE == 2
    gl_FragColor = vec4(vec3(targetDebugQuantizedGlow), 1.0);
#elif TARGET_DEBUG_MODE == 3
    gl_FragColor = vec4(max(targetDebugSky, vec3(0.0)), 1.0);
#elif TARGET_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(targetDebugFog), 1.0);
#elif TARGET_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(targetDebugPhase), 1.0);
#elif TARGET_DEBUG_MODE == 6
    gl_FragColor = vec4(vec3(texture(colortex5, vTexCoord).r), 1.0);
#elif TARGET_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
#else
    gl_FragColor = vec4(vTexCoord.x < 0.5 ? targetDebugBeforeGrade : targetDebugAfterGrade, 1.0);
#endif
    return;
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    // Left half: before haze, horizon blend and grading; right half: the normal result.
    if (vTexCoord.x < 0.5) color = colorBeforeFog;
#endif

#ifdef AMBIENCE_DEBUG
    {
        // Ambience diagnostics; the expected look of each view is listed in the README.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
#if AMBIENCE_DEBUG_MODE == 1
        debugOut = vec3(gDebugFogAmount);
#elif AMBIENCE_DEBUG_MODE == 2
        debugOut = gDebugFogColor;
#elif AMBIENCE_DEBUG_MODE == 3
        debugOut = vec3(clamp(gDebugBank * 0.5, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 4
        debugOut = vec3(clamp(ambSunPhase(dot(debugDir, vSunWorld)) * FOG_SUN_SCATTER, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 5
        debugOut = vec3(gDebugDesaturation);
#elif AMBIENCE_DEBUG_MODE == 6
        debugOut = vec3(gDebugCloudMask);
#elif AMBIENCE_DEBUG_MODE == 7
        debugOut = vec3(gDebugCloudShadow);
#elif AMBIENCE_DEBUG_MODE == 8
        debugOut = vec3(gDebugCloudUV, 0.0);
#elif AMBIENCE_DEBUG_MODE == 9
        debugOut = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
#elif AMBIENCE_DEBUG_MODE == 10
        // Terrain that should have dissolved into the sky (last 15 % before the fog end) minus
        // the sky colour behind it, x8. Expected: black everywhere.
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && isEyeInWater == 0) {
            vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
            vec3 debugPlayer = (gbufferModelViewInverse * vec4(debugViewH.xyz / max(debugViewH.w, 0.0001), 1.0)).xyz;
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(debugPlayer.xz));
            vec3 skyBehind = ambienceSky(vec3(debugDir.x, max(debugDir.y, 0.0), debugDir.z), vSunWorld,
                                         vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif AMBIENCE_DEBUG_MODE == 11
        debugOut = gDebugReflectionColor;
#elif AMBIENCE_DEBUG_MODE == 12
        debugOut = vec3(gDebugReflectionValid);
#elif AMBIENCE_DEBUG_MODE == 13
        debugOut = vec3(gDebugReflectionFog);
#elif AMBIENCE_DEBUG_MODE == 14 || AMBIENCE_DEBUG_MODE == 15
        // Split views (left without, right with); the line marks the split.
        if (abs(vTexCoord.x - 0.5) < 0.75 / viewWidth) debugOut = vec3(1.0);
#elif AMBIENCE_DEBUG_MODE == 16
        // Cloud alignment: on cloud pixels, green if the vanilla cell at that point is filled
        // (shadows and reflections use the same cells), red if it is empty. Expected: all green.
        debugOut = color * 0.35;
#if defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT)
        vec4 debugInfo = texture(colortex1, vTexCoord);
        if (sceneDepth < 0.99999 && debugInfo.a > 0.5 && debugInfo.r < 0.5) {
            vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
            vec3 debugPlayer = (gbufferModelViewInverse * vec4(debugViewH.xyz / max(debugViewH.w, 0.0001), 1.0)).xyz;
            vec3 debugWorld = ambWrappedWorld(debugPlayer - debugDir * 0.05);
            vec2 debugCell = floor(vec2(debugWorld.x + mod(cloudTime, ambCloudPeriod()), debugWorld.z + AMB_CLOUD_Z_OFFSET) / AMB_CLOUD_CELL);
            debugOut = ambCloudCell(debugCell) > 0.5 ? vec3(0.1, 0.9, 0.2) : vec3(0.95, 0.1, 0.1);
        }
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef AMBIENCE_COLORS
    // Ordered dither before the 8-bit output: no banding in the smooth sky and fog gradients.
    color += (ambBayer4(gl_FragCoord.xy) - 0.5) / 255.0;
#endif
    gl_FragColor = vec4(color, scene.a);
}
