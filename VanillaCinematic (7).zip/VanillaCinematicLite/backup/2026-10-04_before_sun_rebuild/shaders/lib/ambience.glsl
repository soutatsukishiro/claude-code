// Ambience: time-of-day and biome palettes, the shared sky/fog colour, the closed-form
// layered height fog with banks, vanilla-aligned cloud shadows and the terrain light
// response. Palettes are evaluated in vertex shaders and handed on as flat varyings; the
// per-pixel parts are ALU plus at most four texel fetches of the small cloud texture.
// The includer declares: gbufferModelViewInverse, sunPosition, rainStrength,
// thunderStrength, cameraPositionInt, cameraPositionFract, frameTimeCounter.
// No function here reads gl_FragCoord, so vertex shaders can include this file too.

// Iris uniforms that reproduce the vanilla cloud layer (checked in the 26.3 client and
// Iris 1.11 jars): cloudTime = ((game time mod width x 400) + partial tick) x 0.03, the
// cloud scroll in blocks; cloudHeight = the cloud-height environment attribute (base of the
// layer, fallback 192).
uniform float cloudTime;
uniform float cloudHeight;

// Camera-biome weights, smoothed over time in shaders.properties (Iris has no per-pixel biome).
uniform float ambOcean;
uniform float ambSnow;
uniform float ambForest;
uniform float ambTaiga;
uniform float ambJungle;
uniform float ambDesert;
uniform float ambMesa;
uniform float ambSavanna;
uniform float ambMountain;

#ifdef AMB_CLOUD_TEXTURE
// customTexture.vclClouds = textures/clouds.png (a copy of the vanilla clouds.png inside the
// pack): the image the vanilla CloudRenderer turns into cells (one texel = one 12 x 12 block
// cell, alpha < 10 = empty).
uniform sampler2D vclClouds;
#endif

const float AMB_CLOUD_CELL = 12.0;       // vanilla cell size in blocks
const float AMB_CLOUD_Z_OFFSET = 3.96;   // vanilla: cloud z = camera z + 3.96
const float AMB_CLOUD_THICKNESS = 4.0;   // vanilla fancy cloud height in blocks
// World x/z are wrapped by this many blocks using the camera's integer position, so there is
// no float precision loss far from spawn. 24576 is a multiple of 12 x 256 (the cloud texture
// period), of every fog bank period and of every shadow grid step. The offset (24576 x 1221)
// lies beyond the world border, so % only ever sees non-negative values.
const int AMB_WRAP = 24576;
const int AMB_WRAP_OFFSET = 30007296;

float ambLuma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float ambHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

// 4x4 ordered dither in (0, 1); fragment shaders pass gl_FragCoord.xy.
float ambBayer4(vec2 fragCoord) {
    const float B[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    ivec2 p = ivec2(fragCoord) & 3;
    return (B[p.x + p.y * 4] + 0.5) / 16.0;
}

vec3 ambSunDirection() {
    vec3 s = mat3(gbufferModelViewInverse) * sunPosition;
    return s * inversesqrt(max(dot(s, s), 1.0e-6));
}

// World position of a camera-relative point: x/z wrapped by AMB_WRAP, y exact.
vec3 ambWrappedWorld(vec3 playerPos) {
    ivec3 wrapped = (cameraPositionInt + ivec3(AMB_WRAP_OFFSET)) % ivec3(AMB_WRAP);
    return vec3(float(wrapped.x), float(cameraPositionInt.y), float(wrapped.z)) + cameraPositionFract + playerPos;
}

// ---------------------------------------------------------------------------------------
// Palettes. Rows: 0 night, 1 dusk, 2 sunset, 3 golden hour (pm), 4 afternoon, 5 midday,
// 6 dawn, 7 sunrise, 8 golden hour (am), 9 morning, 10 rain (day), 11 thunder (day).
// Columns: zenith, mid sky, horizon (= far fog), near fog, cloud top, cloud edge, cloud
// underside, sunlight, sky light. Midday matches the coastal reference; see the README.
const vec3 AMB_PAL[108] = vec3[108](
    vec3(0.027, 0.047, 0.118), vec3(0.055, 0.086, 0.188), vec3(0.102, 0.141, 0.251), vec3(0.094, 0.133, 0.235), vec3(0.133, 0.165, 0.267), vec3(0.173, 0.212, 0.329), vec3(0.078, 0.102, 0.180), vec3(0.353, 0.416, 0.604), vec3(0.157, 0.196, 0.306),
    vec3(0.118, 0.157, 0.314), vec3(0.235, 0.267, 0.455), vec3(0.424, 0.392, 0.533), vec3(0.353, 0.353, 0.502), vec3(0.361, 0.361, 0.502), vec3(0.541, 0.439, 0.565), vec3(0.204, 0.220, 0.353), vec3(0.376, 0.439, 0.627), vec3(0.290, 0.329, 0.502),
    vec3(0.290, 0.369, 0.612), vec3(0.604, 0.518, 0.690), vec3(0.957, 0.604, 0.424), vec3(0.847, 0.604, 0.549), vec3(0.941, 0.659, 0.565), vec3(1.000, 0.690, 0.439), vec3(0.431, 0.408, 0.565), vec3(1.000, 0.604, 0.361), vec3(0.549, 0.565, 0.753),
    vec3(0.416, 0.518, 0.769), vec3(0.690, 0.643, 0.800), vec3(0.973, 0.769, 0.612), vec3(0.941, 0.737, 0.612), vec3(0.973, 0.824, 0.722), vec3(1.000, 0.816, 0.549), vec3(0.643, 0.596, 0.722), vec3(1.000, 0.784, 0.533), vec3(0.706, 0.722, 0.863),
    vec3(0.486, 0.612, 0.855), vec3(0.627, 0.698, 0.878), vec3(0.776, 0.792, 0.910), vec3(0.800, 0.769, 0.878), vec3(0.902, 0.871, 0.925), vec3(1.000, 0.949, 0.902), vec3(0.776, 0.769, 0.863), vec3(1.000, 0.902, 0.769), vec3(0.776, 0.800, 0.918),
    vec3(0.498, 0.624, 0.863), vec3(0.616, 0.698, 0.894), vec3(0.761, 0.804, 0.925), vec3(0.784, 0.769, 0.902), vec3(0.894, 0.886, 0.957), vec3(0.965, 0.961, 0.988), vec3(0.816, 0.824, 0.925), vec3(1.000, 0.945, 0.863), vec3(0.784, 0.831, 0.941),
    vec3(0.125, 0.173, 0.345), vec3(0.251, 0.290, 0.486), vec3(0.439, 0.408, 0.557), vec3(0.369, 0.369, 0.525), vec3(0.376, 0.376, 0.494), vec3(0.565, 0.471, 0.596), vec3(0.212, 0.235, 0.376), vec3(0.408, 0.471, 0.659), vec3(0.306, 0.345, 0.533),
    vec3(0.306, 0.392, 0.643), vec3(0.627, 0.549, 0.722), vec3(0.957, 0.659, 0.549), vec3(0.863, 0.643, 0.627), vec3(0.949, 0.706, 0.643), vec3(1.000, 0.753, 0.627), vec3(0.447, 0.439, 0.596), vec3(1.000, 0.659, 0.471), vec3(0.565, 0.596, 0.784),
    vec3(0.431, 0.533, 0.784), vec3(0.659, 0.659, 0.831), vec3(0.941, 0.784, 0.722), vec3(0.910, 0.753, 0.722), vec3(0.957, 0.839, 0.800), vec3(1.000, 0.878, 0.722), vec3(0.643, 0.627, 0.769), vec3(1.000, 0.824, 0.627), vec3(0.722, 0.753, 0.894),
    vec3(0.478, 0.604, 0.847), vec3(0.604, 0.690, 0.886), vec3(0.769, 0.792, 0.918), vec3(0.792, 0.761, 0.886), vec3(0.894, 0.863, 0.941), vec3(1.000, 0.949, 0.949), vec3(0.769, 0.776, 0.878), vec3(1.000, 0.918, 0.816), vec3(0.769, 0.808, 0.933),
    vec3(0.541, 0.573, 0.620), vec3(0.604, 0.635, 0.675), vec3(0.659, 0.682, 0.714), vec3(0.643, 0.667, 0.698), vec3(0.651, 0.671, 0.706), vec3(0.706, 0.722, 0.753), vec3(0.494, 0.518, 0.557), vec3(0.784, 0.800, 0.816), vec3(0.643, 0.675, 0.722),
    vec3(0.290, 0.314, 0.361), vec3(0.337, 0.361, 0.408), vec3(0.392, 0.416, 0.455), vec3(0.369, 0.392, 0.431), vec3(0.361, 0.384, 0.424), vec3(0.416, 0.439, 0.478), vec3(0.235, 0.259, 0.298), vec3(0.541, 0.565, 0.596), vec3(0.361, 0.392, 0.439)
);
// Sun elevation (sin of the altitude) of rows 0-5; rows 1-4 have morning twins (rows 6-9).
const float AMB_KEY_E[6] = float[6](-0.30, -0.10, 0.00, 0.12, 0.35, 0.70);

const int AMB_ZENITH = 0;
const int AMB_MID = 1;
const int AMB_HORIZON = 2;
const int AMB_FOG_NEAR = 3;
const int AMB_CLOUD_TOP = 4;
const int AMB_CLOUD_EDGE = 5;
const int AMB_CLOUD_UNDER = 6;
const int AMB_SUN_LIGHT = 7;
const int AMB_SKY_LIGHT = 8;

struct AmbTime {
    int key;            // lower palette row
    float blend;        // smoothstep weight toward key + 1 (no pops)
    float morning;      // 1 = the sun is in the east (rising), 0 = west (setting)
    float rain;
    float thunder;
    float weatherLight; // overcast palettes darken with the time of day
    vec3 biome;         // biome haze ratio relative to the coastal reference haze
};

vec3 ambKey(int key, int column, float morning) {
    int morningKey = (key >= 1 && key <= 4) ? key + 5 : key;
    return mix(AMB_PAL[key * 9 + column], AMB_PAL[morningKey * 9 + column], morning);
}

// Biome haze ratio relative to the ocean/coast reference haze (#B8C8E8): lavender stays at
// the coast, snow and mountains; jungle goes teal, badlands peach, desert sand, savanna gold.
vec3 ambBiomeRatio() {
    float total = ambOcean + ambSnow + ambForest + ambTaiga + ambJungle + ambDesert + ambMesa + ambSavanna + ambMountain;
    float neutral = max(1.0 - total, 0.0);
    vec3 sum = vec3(neutral + ambOcean + 1.0e-3);
    sum += ambSnow * vec3(1.087, 1.060, 1.034);      // #C8D4F0 snowy and icy
    sum += ambForest * vec3(0.957, 1.000, 0.966);    // #B0C8E0 plains and forest
    sum += ambTaiga * vec3(0.913, 0.950, 0.862);     // #A8BEC8 taiga
    sum += ambJungle * vec3(0.826, 1.020, 0.845);    // #98CCC4 jungle and swamp
    sum += ambDesert * vec3(1.228, 1.050, 0.793);    // #E2D2B8 desert
    sum += ambMesa * vec3(1.272, 0.960, 0.724);      // #EAC0A8 badlands
    sum += ambSavanna * vec3(1.196, 1.020, 0.707);   // #DCCCA4 savanna
    sum += ambMountain * vec3(1.000, 0.940, 0.983);  // #B8BCE4 mountains
    return sum / (neutral + total + 1.0e-3);
}

AmbTime ambTime(vec3 sunDir) {
    AmbTime t;
    float e = sunDir.y;
    t.key = e < AMB_KEY_E[1] ? 0 : (e < AMB_KEY_E[2] ? 1 : (e < AMB_KEY_E[3] ? 2 : (e < AMB_KEY_E[4] ? 3 : 4)));
    t.blend = smoothstep(AMB_KEY_E[t.key], AMB_KEY_E[t.key + 1], e);
    t.morning = smoothstep(-0.25, 0.25, sunDir.x);
    t.rain = clamp(rainStrength, 0.0, 1.0);
    t.thunder = clamp(thunderStrength, 0.0, 1.0);
    t.weatherLight = mix(0.14, 1.0, smoothstep(-0.25, 0.10, e));
    float biomeStrength = clamp(BIOME_TINT_STRENGTH * 2.5, 0.0, 1.0) * smoothstep(-0.20, 0.10, e) * (1.0 - 0.7 * t.rain);
    t.biome = mix(vec3(1.0), ambBiomeRatio(), biomeStrength);
    return t;
}

// One palette column at the current time and weather (biome not applied).
vec3 ambColor(AmbTime t, int column) {
    vec3 clear = mix(ambKey(t.key, column, t.morning), ambKey(t.key + 1, column, t.morning), t.blend);
    clear = mix(clear, AMB_PAL[90 + column] * t.weatherLight, t.rain * 0.85);
    return mix(clear, AMB_PAL[99 + column] * t.weatherLight, t.thunder * 0.90);
}

// Lavender control: 0 = neutral blue haze, 1 = palette, 1.5 = more lavender.
vec3 ambLavender() {
    return mix(vec3(1.0), vec3(1.05, 0.96, 1.03), ENV_LAVENDER - 1.0);
}

vec3 ambSkyLightColor(AmbTime t) {
    return ambColor(t, AMB_SKY_LIGHT) * mix(vec3(1.0), t.biome, 0.3);
}

struct AmbPalette {
    vec3 zenith;
    vec3 mid;
    vec3 horizon;      // also the far fog colour
    vec3 fogNear;
    vec3 cloudTop;
    vec3 cloudEdge;
    vec3 cloudUnder;
    vec3 sunLight;
    vec3 skyLight;
    vec3 glow;         // sun scattering colour, already scaled by sun visibility and weather
    float golden;      // weight of the golden-hour sky tint (GOLDEN_TARGET_SKY)
};

AmbPalette ambiencePalette(vec3 sunDir) {
    AmbTime t = ambTime(sunDir);
    vec3 lavender = ambLavender();
    AmbPalette p;
    p.zenith = ambColor(t, AMB_ZENITH) * mix(vec3(1.0), t.biome, 0.25);
    p.mid = ambColor(t, AMB_MID) * mix(vec3(1.0), t.biome * lavender, 0.5);
    p.horizon = ambColor(t, AMB_HORIZON) * t.biome * lavender;
    p.fogNear = ambColor(t, AMB_FOG_NEAR) * t.biome * lavender;
    p.cloudTop = ambColor(t, AMB_CLOUD_TOP);
    p.cloudEdge = ambColor(t, AMB_CLOUD_EDGE);
    p.cloudUnder = ambColor(t, AMB_CLOUD_UNDER) * mix(vec3(1.0), t.biome, 0.3);
    p.sunLight = ambColor(t, AMB_SUN_LIGHT);
    p.skyLight = ambSkyLightColor(t);
    float sunVisible = smoothstep(-0.06, 0.06, sunDir.y) * (1.0 - 0.85 * t.rain) * (1.0 - 0.9 * t.thunder);
    p.glow = p.sunLight * (0.35 * sunVisible);
    p.golden = 0.0;
#ifdef GOLDEN_TARGET_SKY
    // Same weights as the golden-hour sky tint in final, so sky, fog and reflections agree.
    float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(sunDir.y));
    float daySide = smoothstep(-0.16, -0.005, sunDir.y);
    float weather = clamp(1.0 - t.rain * 0.58 - t.thunder * 0.32, 0.0, 1.0);
    float warmBiome = clamp(max(ambSavanna * 0.55, ambForest * 0.24), 0.0, 1.0) * (1.0 - smoothstep(-0.10, 0.18, sunDir.y));
    p.golden = max(twilightSky * daySide, warmBiome) * weather * float(MATCH_STRENGTH) * 0.01 * GOLDEN_SKY_TINT_STRENGTH;
#endif
    return p;
}

// ---------------------------------------------------------------------------------------
// Sky and fog colour.

// Forward scattering: a broad halo plus a tighter lobe around the sun (Henyey-Greenstein-like
// shape from powers of the cosine, no pow()).
float ambSunPhase(float mu) {
    float f = max(mu, 0.0);
    float f2 = f * f;
    float f4 = f2 * f2;
    float f8 = f4 * f4;
    return f4 * 0.30 + f8 * f8 * 0.70;
}

// The sky seen along dir. The far fog uses exactly this colour, so terrain at the render
// distance dissolves into the sky behind it without a line.
vec3 ambienceSky(vec3 dir, vec3 sunDir, vec3 zenith, vec3 mid, vec3 horizon, vec3 glow, float golden) {
    float up = max(dir.y, 0.0);
    vec3 sky = mix(horizon, mid, smoothstep(0.0, 0.30, up));
    sky = mix(sky, zenith, smoothstep(0.20, 0.95, up));
    sky = mix(sky, horizon * 0.82, smoothstep(0.0, 0.45, -dir.y));
#ifdef FOG_SCATTERING
    sky += glow * (ambSunPhase(dot(dir, sunDir)) * FOG_SUN_SCATTER * (1.0 - smoothstep(0.05, 0.75, up)));
#endif
#ifdef GOLDEN_TARGET_SKY
    vec3 goldenSky = mix(vec3(0.46, 0.37, 0.27), vec3(1.00, 0.72, 0.39), 1.0 - smoothstep(0.015, 0.90, up));
    sky = mix(sky, goldenSky, golden);
#endif
    return max(sky, vec3(0.0));
}

// Haze colour close to the camera: palette near fog, brighter and warmer toward the sun,
// a little cooler and more lavender opposite it.
vec3 ambienceFogNear(vec3 dir, vec3 sunDir, vec3 fogNear, vec3 glow) {
    vec3 c = fogNear;
#ifdef FOG_SCATTERING
    float mu = dot(dir, sunDir);
    c += glow * (ambSunPhase(mu) * FOG_SUN_SCATTER);
    c *= mix(vec3(1.0), vec3(0.94, 0.95, 1.05), max(-mu, 0.0) * 0.6 * min(FOG_SUN_SCATTER, 1.0));
#endif
    return c;
}

// Optical depth per unit density of rho(h) = exp(-k h) along a straight path between two
// heights (h relative to FOG_BASE_HEIGHT), in closed form. Heights below -8 are clamped, so
// deep valleys and caves do not blow up; both exponentials stay bounded by exp(8 k).
float ambFogOpticalDepth(float pathLength, float hStart, float hEnd, float k) {
    float a = max(hStart, -8.0);
    float b = max(hEnd, -8.0);
    float ea = exp(-k * a);
    float dh = b - a;
    return pathLength * (abs(k * dh) > 1.0e-3 ? (ea - exp(-k * b)) / (k * dh) : ea);
}

#if FOG_BANK_QUALITY > 0
// Fog bank thickness noise (0..1) on large block-aligned cells with a slow drift.
float ambFogBank(vec2 worldXZ) {
    const float period = float(AMB_WRAP / FOG_BANK_SCALE);
    vec2 p = (worldXZ + vec2(1.0, 0.6) * (FOG_DRIFT_SPEED * frameTimeCounter)) / float(FOG_BANK_SCALE);
    vec2 cell = floor(p);
#if FOG_BANK_QUALITY == 1
    return ambHash(mod(cell, period));
#else
    vec2 f = p - cell;
    float a = ambHash(mod(cell, period));
    float b = ambHash(mod(cell + vec2(1.0, 0.0), period));
    float c = ambHash(mod(cell + vec2(0.0, 1.0), period));
    float d = ambHash(mod(cell + vec2(1.0, 1.0), period));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
#endif
}
#endif

struct AmbFog {
    vec3 color;
    float amount;
    float desaturation;
    float bank;      // bank density multiplier (debug)
    float scatter;   // sun scattering term (debug)
};

// Layered height fog from the camera to a surface: closed-form optical depth (no ray march),
// a clear zone around the camera, bank noise sampled inside the fogged segment, and a ramp to
// full opacity at the render distance in the colour of the sky behind the surface.
AmbFog ambienceFog(vec3 playerPos, vec3 sunDir, AmbPalette pal, float renderDistance,
                   float cloudShadow, float rayMask, float caveLight) {
    AmbFog fog;
    float pathLength = length(playerPos);
    vec3 dir = playerPos / max(pathLength, 1.0e-4);
    float horizontalDistance = length(playerPos.xz);
    float rain = clamp(rainStrength, 0.0, 1.0);
    float thunder = clamp(thunderStrength, 0.0, 1.0);
    float night = 1.0 - smoothstep(-0.30, -0.05, sunDir.y);

    float t0 = min(float(FOG_START), pathLength);
    float segment = pathLength - t0;
    float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
    float hStart = cameraY + dir.y * t0 - float(FOG_BASE_HEIGHT);
    float hEnd = cameraY + playerPos.y - float(FOG_BASE_HEIGHT);
    // Rain: denser, grayer (palette) and lower (faster falloff). Night: a calmer haze.
    float k = FOG_HEIGHT_FALLOFF * (1.0 + 0.6 * rain);
    float density = FOG_DENSITY * (1.0 + 1.5 * rain + 1.0 * thunder) * mix(1.0, 0.85, night) *
                    (1.0 + 0.30 * ambJungle - 0.15 * ambDesert) * mix(0.30, 1.0, caveLight);

    fog.bank = 1.0;
#if FOG_BANK_QUALITY > 0
    if (horizontalDistance < renderDistance) {
        vec2 cameraXZ = ambWrappedWorld(vec3(0.0)).xz;
#if FOG_BANK_QUALITY == 1
        float noise = ambFogBank(cameraXZ + dir.xz * (t0 + segment * 0.5));
#else
        float noise = 0.5 * (ambFogBank(cameraXZ + dir.xz * (t0 + segment * 0.33)) +
                             ambFogBank(cameraXZ + dir.xz * (t0 + segment * 0.67)));
#endif
        fog.bank = 1.0 + FOG_BANK_STRENGTH * (2.0 * noise - 1.0);
    }
#endif
    float tau = density * fog.bank * ambFogOpticalDepth(segment, hStart, hEnd, k);

    float farRamp = smoothstep(renderDistance * FOG_END * 0.65, renderDistance * FOG_END, horizontalDistance);
    fog.amount = 1.0 - exp(-tau) * (1.0 - farRamp);
    fog.desaturation = ENV_DISTANCE_DESATURATION * max(1.0 - exp(-1.6 * tau), farRamp);

    vec3 nearColor = ambienceFogNear(dir, sunDir, pal.fogNear, pal.glow);
    // Under cloud shadows the haze is darker and cooler; light shafts brighten it slightly.
    nearColor *= mix(vec3(1.0), vec3(0.84, 0.87, 0.95), 1.0 - cloudShadow);
    nearColor *= 1.0 + rayMask * 0.35 * min(FOG_SUN_SCATTER, 1.0);
    nearColor *= mix(0.25, 1.0, caveLight);
    vec3 farColor = ambienceSky(vec3(dir.x, max(dir.y, 0.0), dir.z), sunDir, pal.zenith, pal.mid, pal.horizon, pal.glow, pal.golden);
    float colorMix = max(smoothstep(renderDistance * 0.20, renderDistance * 0.90, horizontalDistance), farRamp);
    fog.color = mix(nearColor, farColor, colorMix);
    fog.scatter = 0.0;
#ifdef FOG_SCATTERING
    fog.scatter = ambSunPhase(dot(dir, sunDir)) * FOG_SUN_SCATTER;
#endif
    return fog;
}

// Atmospheric perspective and fog: far surfaces lose saturation toward the fog hue, get
// lighter and blend into the fog colour, keeping their silhouettes.
vec3 ambienceApplyFog(vec3 color, AmbFog fog) {
    float luma = ambLuma(color);
    vec3 fogHue = fog.color / max(ambLuma(fog.color), 1.0e-3);
    color = mix(color, vec3(luma) * mix(vec3(1.0), fogHue, 0.25), fog.desaturation * 0.6);
    return mix(color, fog.color, fog.amount);
}

// Transmittance of the height fog along a segment between two world heights (reflected light).
float ambienceSegmentTransmittance(float pathLength, float worldYStart, float worldYEnd) {
    float rain = clamp(rainStrength, 0.0, 1.0);
    float k = FOG_HEIGHT_FALLOFF * (1.0 + 0.6 * rain);
    float density = FOG_DENSITY * (1.0 + 1.5 * rain + 1.0 * clamp(thunderStrength, 0.0, 1.0));
    return exp(-density * ambFogOpticalDepth(pathLength, worldYStart - float(FOG_BASE_HEIGHT),
                                             worldYEnd - float(FOG_BASE_HEIGHT), k));
}

// ---------------------------------------------------------------------------------------
// Vanilla cloud cells (shadows and the improved cloud reflection).
#if defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT)
float ambCloudPeriod() {
#ifdef AMB_CLOUD_TEXTURE
    return AMB_CLOUD_CELL * float(textureSize(vclClouds, 0).x);
#else
    return AMB_CLOUD_CELL * 256.0;
#endif
}

// Occupancy of one cloud cell: 1 = cloud, 0 = clear. cell = floor(cloud-space position / 12).
float ambCloudCell(vec2 cell) {
#ifdef AMB_CLOUD_TEXTURE
    vec2 size = vec2(textureSize(vclClouds, 0));
    return step(0.04, texelFetch(vclClouds, ivec2(mod(cell, size)), 0).a);
#else
    // Procedural cells (VANILLA_CLOUD_CELLS off): clusters plus single cells; not the vanilla shapes.
    vec2 c = mod(cell, 256.0);
    return step(0.58, ambHash(floor(c * 0.25)) * 0.65 + ambHash(c) * 0.35);
#endif
}

// Cloud-space position where the ray from a (wrapped) world point along dir meets the middle
// of the cloud layer: x carries the vanilla scroll, z the vanilla 3.96 offset. dir.y > 0.
vec2 ambCloudSpace(vec3 world, vec3 dir, out float t) {
    t = (cloudHeight + 0.5 * AMB_CLOUD_THICKNESS - world.y) / dir.y;
    vec2 q = world.xz + dir.xz * t;
    return vec2(q.x + mod(cloudTime, ambCloudPeriod()), q.y + AMB_CLOUD_Z_OFFSET);
}
#endif

#ifdef CLOUD_SHADOW_ENABLE
// Strongest at midday, weaker with a low sun, gone at night, in rain and in thunder.
float ambCloudShadowFade(vec3 sunDir) {
    return smoothstep(0.04, 0.50, sunDir.y) * (1.0 - clamp(rainStrength, 0.0, 1.0)) *
           (1.0 - clamp(thunderStrength, 0.0, 1.0));
}

// Soft blocky cloud shadow for a camera-relative receiver: 1 = lit, 1 - CLOUD_SHADOW_STRENGTH
// = under a cloud. The receiver is moved along the sun direction to the cloud layer and the
// vanilla cell there is read: one fetch (quality 1) or four (quality 2).
float ambienceCloudShadow(vec3 playerPos, vec3 sunDir, out float rawMask, out vec2 cellUV) {
    rawMask = 0.0;
    cellUV = vec2(0.0);
    vec3 world = ambWrappedWorld(playerPos);
    // Only below the layer: receivers inside or above the clouds get no cloud shadow.
    float fade = ambCloudShadowFade(sunDir) * (1.0 - smoothstep(cloudHeight - 6.0, cloudHeight + 1.0, world.y));
    if (fade <= 0.0) return 1.0;
#if CLOUD_SHADOW_GRID > 0
    // The receiver steps on a coarse world block grid, so the shadow edges come out blocky.
    world.xz = (floor(world.xz / float(CLOUD_SHADOW_GRID)) + 0.5) * float(CLOUD_SHADOW_GRID);
#endif
    float t;
    vec2 cells = ambCloudSpace(world, vec3(sunDir.x, max(sunDir.y, 0.05), sunDir.z), t) / AMB_CLOUD_CELL;
#if CLOUD_SHADOW_QUALITY == 1
    float mask = ambCloudCell(floor(cells));
#else
    // Bilinear coverage of the four nearest cell centres, then a soft threshold: the penumbra
    // is CLOUD_SHADOW_SOFTNESS x 12 blocks wide, wider with a low sun.
    vec2 lattice = cells - 0.5;
    vec2 base = floor(lattice);
    vec2 f = lattice - base;
    float coverage = mix(mix(ambCloudCell(base), ambCloudCell(base + vec2(1.0, 0.0)), f.x),
                         mix(ambCloudCell(base + vec2(0.0, 1.0)), ambCloudCell(base + vec2(1.0, 1.0)), f.x), f.y);
    float halfWidth = clamp(0.5 * CLOUD_SHADOW_SOFTNESS * mix(1.6, 1.0, smoothstep(0.15, 0.70, sunDir.y)), 0.02, 0.5);
    float mask = smoothstep(0.5 - halfWidth, 0.5 + halfWidth, coverage);
#endif
    rawMask = mask;
    cellUV = fract(cells * (AMB_CLOUD_CELL / ambCloudPeriod()));
    return 1.0 - CLOUD_SHADOW_STRENGTH * mask * fade;
}

float ambienceCloudShadow(vec3 playerPos, vec3 sunDir) {
    float rawMask;
    vec2 cellUV;
    return ambienceCloudShadow(playerPos, sunDir, rawMask, cellUV);
}
#endif

// ---------------------------------------------------------------------------------------
// Terrain light response (opaque surfaces and glass; never water).
#ifdef AMBIENCE_COLORS
// Warm sunlit faces, cool soft shade (warm albedos such as sand and rock resist it), gentle
// vibrance on dull colours with a neon clamp, and a slight blue on snow and ice with a
// highlight shoulder so they never burn out to flat white.
vec3 ambienceTerrainResponse(vec3 lit, vec3 albedo, float sunMask, float shadeMask, vec3 sunLight, vec3 skyLight) {
    vec3 sunTint = sunLight / max(ambLuma(sunLight), 1.0e-3);
    vec3 skyTint = skyLight / max(ambLuma(skyLight), 1.0e-3);
    float warmAlbedo = smoothstep(0.03, 0.22, albedo.r - albedo.b);
    lit *= mix(vec3(1.0), sunTint, clamp(sunMask * ENV_WARMTH, 0.0, 1.0));
    lit *= mix(vec3(1.0), skyTint, clamp(shadeMask * ENV_SHADOW_COOLNESS, 0.0, 1.0) * (1.0 - 0.5 * warmAlbedo));

    float luma = ambLuma(lit);
    float maxC = max(lit.r, max(lit.g, lit.b));
    float sat = (maxC - min(lit.r, min(lit.g, lit.b))) / max(maxC, 1.0e-3);
    vec3 vivid = mix(vec3(luma), lit, 1.0 + ENV_VIBRANCE * (1.0 - sat));
    float vividMax = max(vivid.r, max(vivid.g, vivid.b));
    float vividSat = (vividMax - min(vivid.r, min(vivid.g, vivid.b))) / max(vividMax, 1.0e-3);
    // Neon clamp: the boost never pushes a colour past 80 % saturation.
    lit = max(mix(lit, vivid, clamp((0.80 - sat) / max(vividSat - sat, 1.0e-3), 0.0, 1.0)), vec3(0.0));

    float albedoMax = max(albedo.r, max(albedo.g, albedo.b));
    float albedoSat = (albedoMax - min(albedo.r, min(albedo.g, albedo.b))) / max(albedoMax, 1.0e-3);
    float snow = smoothstep(0.70, 0.86, ambLuma(albedo)) * (1.0 - smoothstep(0.06, 0.18, albedoSat)) * ENV_SNOW_TINT;
    lit *= mix(vec3(1.0), vec3(0.93, 0.97, 1.05), snow);
    lit -= max(lit - vec3(0.80), vec3(0.0)) * (0.45 * snow);
    return lit;
}
#endif
