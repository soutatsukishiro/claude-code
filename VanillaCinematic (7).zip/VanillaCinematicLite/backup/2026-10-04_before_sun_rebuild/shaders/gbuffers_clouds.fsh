#version 330 compatibility

// Cloud lighting only; the vanilla blocky shapes, height, cell size and scroll are untouched.
// Soft translucent white-lavender body, lighter warmer edges toward the sun, cooler darker
// undersides, golden rims at sunrise/sunset and grey-blue in rain (all from the palette), and
// a distance haze toward the same sky colour the sky and the fog use, so the clouds melt
// into the horizon without a band. final skips its fog on these pixels (marker in colortex1).

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
uniform float far;
uniform vec3 skyColor;
uniform vec3 fogColor;

#include "/lib/ambience.glsl"

in vec4 vColor;
in vec3 vPlayerPosition;
flat in vec3 vSunWorld;
flat in vec3 vCloudTop;
flat in vec3 vCloudEdge;
flat in vec3 vCloudUnder;
flat in vec3 vZenith;
flat in vec3 vMid;
flat in vec3 vHorizon;
flat in vec3 vGlow;
flat in float vGolden;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outInfo;

void main() {
    // Face normal from screen derivatives: exact for the flat cloud faces and independent of
    // the vertex normals; flipped to face the camera.
    vec3 faceNormal = cross(dFdx(vPlayerPosition), dFdy(vPlayerPosition));
    faceNormal *= inversesqrt(max(dot(faceNormal, faceNormal), 1.0e-12));
    vec3 viewDir = vPlayerPosition * inversesqrt(max(dot(vPlayerPosition, vPlayerPosition), 1.0e-6));
    if (dot(faceNormal, viewDir) > 0.0) faceNormal = -faceNormal;
#ifdef HIDE_VANILLA_CLOUDS
    discard;
#endif
    if (vColor.a < 0.01) discard;

    float top = smoothstep(0.5, 0.9, faceNormal.y);
    float bottom = smoothstep(0.5, 0.9, -faceNormal.y);
    float side = clamp(1.0 - top - bottom, 0.0, 1.0);
    vec3 body = mix(vCloudTop, vCloudUnder, bottom);
    body = mix(body, mix(vCloudTop, vCloudUnder, 0.45), side);

    // Lighter, warmer faces toward the sun, and bright rims where faces are seen edge-on
    // (the cloud outlines); the edge colour turns golden at sunrise and sunset.
    float rain = clamp(rainStrength, 0.0, 1.0);
    float sunVisible = smoothstep(-0.05, 0.10, vSunWorld.y) * (1.0 - 0.8 * rain);
    float towardSun = max(dot(faceNormal, vSunWorld), 0.0);
    float grazing = 1.0 - abs(dot(faceNormal, viewDir));
    vec3 lit = body + vCloudEdge * ((0.18 * towardSun + 0.30 * grazing * grazing) * sunVisible);
    vec3 color = mix(vColor.rgb, lit, CLOUD_TINT);

    // Distance haze toward the sky behind the cloud: farther and lower clouds melt into it.
    float horizontalDistance = length(vPlayerPosition.xz);
    float haze = smoothstep(far * 0.25, far * 2.6, horizontalDistance) * 0.9;
    haze = max(haze, (1.0 - smoothstep(0.02, 0.25, viewDir.y)) * step(0.0, viewDir.y) * 0.7);
#ifdef AMBIENCE_COLORS
    vec3 skyBehind = ambienceSky(viewDir, vSunWorld, vZenith, vMid, vHorizon, vGlow, vGolden);
#else
    vec3 skyBehind = mix(fogColor, skyColor, smoothstep(0.0, 0.35, viewDir.y));
#endif
    color = mix(color, skyBehind, haze);

    // Translucent body; the far edge of the cloud mesh fades out instead of cutting off.
    float alpha = CLOUD_OPACITY * (1.0 - smoothstep(far * 3.0, far * 4.0, horizontalDistance));
    outColor = vec4(color, alpha);
    // Cloud marker for final (R = 0 keeps it apart from the water marker, A = 1 overwrites).
    outInfo = vec4(0.0, 0.0, 0.0, 1.0);
}
