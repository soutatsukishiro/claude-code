#version 330 compatibility

// Patch 2.1: the one-pixel adaptive-eyes pass (composite2.fsh) needs only the full-screen quad.

void main() {
    gl_Position = ftransform();
}
