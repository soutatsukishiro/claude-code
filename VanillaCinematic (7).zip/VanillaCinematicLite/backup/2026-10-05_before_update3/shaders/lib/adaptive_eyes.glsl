// Patch 2.1, part A: adaptive eyes (auto exposure), shared by final.vsh (the per-frame numbers),
// composite2 (the scene measurement and the debug graph) and final.fsh (the exposure stage).
//
// Units. The pack works in display values (textures and the screen are both sRGB-like; there is
// no linear-light stage), so a gain of g in linear light is a factor g^(1/2.2) on the values
// here. The sliders give linear-light gains (ADAPT_MAX_BRIGHTEN 2.2 = 2.2 x the light, 1.43 x
// the screen value); everything below works in stops of linear light ("X").
//
// Tier 1 (all presets) runs on the CPU (shaders.properties, custom uniforms): the light at the
// camera (eyeBrightness), the night and the weather give a darkness in stops; it is turned into
// a "fraction of full dark adaptation" a = 1 - 2^(-darkness / 1.733) (0 = daylight, 1 = pitch
// black, slider-free) and smoothed with Iris' frame-rate independent smooth(): slowly while it
// rises (dark adaptation), fast while it falls (light adaptation). Here a becomes a gain:
// X = Xmax (1 - (1 - a)^k), k = 1.25 ADAPT_DARK_STRENGTH / Xmax, which is exactly the target
// curve Xmax (1 - exp(-0.5 ADAPT_DARK_STRENGTH d / Xmax)) in the darkness d and keeps the visible
// change close to the smoothing time. Tier 2 (ADAPT_SCENE_LUMA) moves X by the measured scene
// brightness, limited to ADAPT_SCENE_REFINE_LIMIT stops x ADAPT_SCENE_LUMA_WEIGHT.

// ---- tier 1, from shaders.properties (custom uniforms) ----
uniform float vclAdaptEye;        // smoothed fraction of dark adaptation (the eyes)
uniform float vclAdaptGoal;       // the same target, smoothed over ~0.25 s (the lag = over-bright moment)
uniform float vclAdaptNight;      // night under open sky (the night limit applies), smoothed
uniform float vclAdaptBright;     // above the reference light in very bright places (0..1), smoothed
uniform float vclAdaptBrightGoal; // its target over ~0.25 s (the brief dazzle when it rises)
uniform float vclAdaptDark;       // darkness at the eye now, in stops (tier 2's expected scene level)
uniform float vclAdaptSnap;       // > 0.1 for about a second after a camera jump (join, respawn, teleport)

// Typical daylight scene (log-average linear luminance of grass, stone, leaves and dirt in sun in
// this pack); the scene measurement is relative to it.
const float ADAPT_Y_REF = 0.15;
// The pack's darkest lighting relative to daylight (2^-6), fitted to the user's cave screenshot:
// its taps average -5.6 stops below ADAPT_Y_REF at a camera sky light of about 3.
const float ADAPT_FLOOR = 0.015625;
// The over-bright moment adds this much bloom per stop of over-brightness.
const float ADAPT_FLASH_BLOOM = 0.6;
// The upward dazzle (stepping into a very bright place) in stops at full BRIGHT_FLASH.
const float ADAPT_DAZZLE = 0.35;

float adaptLuma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Gain in stops for a fraction of dark adaptation a, with the cap xMax (stops).
float adaptGainStops(float a, float xMax) {
    float k = 1.25 * ADAPT_DARK_STRENGTH / max(xMax, 0.01);
    return xMax * (1.0 - pow(max(1.0 - clamp(a, 0.0, 1.0), 0.0), k));
}

// ---- tier 2 taps (composite2 measures, the debug view draws them) ----
#if ADAPT_SCENE_TAPS == 16
const int ADAPT_TAP_COUNT = 16;
#elif ADAPT_SCENE_TAPS == 25
const int ADAPT_TAP_COUNT = 25;
#else
const int ADAPT_TAP_COUNT = 9;
#endif

// Fixed tap pattern in screen UV (no jitter, the same every frame). xy = position, z = 1 for the
// centre group (weighted by ADAPT_CENTER_WEIGHT), 0 for the ring.
vec3 adaptTap(int i) {
#if ADAPT_SCENE_TAPS == 16
    // 2 x 2 centre group, then a ring of 12.
    if (i < 4) return vec3(0.5 + 0.06 * (float(i & 1) * 2.0 - 1.0), 0.5 + 0.08 * (float(i >> 1) * 2.0 - 1.0), 1.0);
    float a = 6.2831853 * float(i - 4) / 12.0 + 0.2618;
    return vec3(0.5 + 0.30 * cos(a), 0.5 + 0.34 * sin(a), 0.0);
#elif ADAPT_SCENE_TAPS == 25
    // 5 x 5 grid over the middle 80 % of the screen; the middle 3 x 3 is the centre group.
    int gx = i - (i / 5) * 5;
    int gy = i / 5;
    bool centre = gx >= 1 && gx <= 3 && gy >= 1 && gy <= 3;
    return vec3(0.1 + 0.2 * float(gx), 0.1 + 0.2 * float(gy), centre ? 1.0 : 0.0);
#else
    // Centre tap, then a ring of 8.
    if (i == 0) return vec3(0.5, 0.5, 1.0);
    float a = 6.2831853 * float(i - 1) / 8.0;
    return vec3(0.5 + 0.30 * cos(a), 0.5 + 0.32 * sin(a), 0.0);
#endif
}

// ---- the per-frame numbers (final.vsh; the debug graph in composite2) ----
struct AdaptState {
    float gainStops;   // final gain in stops (linear light), 0 = untouched
    float goalStops;   // the gain the light asks for (tier 1, ~0.25 s smoothing)
    float eyeStops;    // the eyes' tier-1 gain (before the over-bright moment and tier 2)
    float flashStops;  // over-brightness: the eyes' lag shown by BRIGHT_FLASH, plus the dazzle
    float sceneStops;  // tier 2's change (stops), after the weight, the limit and the gate
    float darkAmount;  // 0..1, how dark-adapted (Purkinje, shadow lift, local lift)
    float punch;       // 0..1 x BRIGHT_PUNCH
};

// history = colortex6 texel 0: x = tier-2 refinement (stops, smoothed and limited), y = bright
// scene amount (0..1), z = measured scene level (stops, debug), w = 1 once written.
AdaptState adaptState(vec4 history, float overworld, float nether, float end, float blindnessNow, float darknessNow, float nightVisionNow) {
    AdaptState s;
    float xCave = log2(max(float(ADAPT_MAX_BRIGHTEN), 1.0));
    float xNight = log2(max(float(ADAPT_NIGHT_LIMIT), 1.0));
    float xMax = mix(xCave, min(xNight, xCave), clamp(vclAdaptNight, 0.0, 1.0));
    s.eyeStops = adaptGainStops(vclAdaptEye, xMax);
    s.goalStops = adaptGainStops(vclAdaptGoal, xMax);
    // The over-bright moment: while the eyes are still adapted to a darker place than the light
    // asks for, BRIGHT_FLASH of that lag shows (0 = none: the gain drops with the light at once).
    float applied = min(s.eyeStops, s.goalStops + BRIGHT_FLASH * (s.eyeStops - s.goalStops));
    s.flashStops = max(applied - s.goalStops, 0.0);
    // Tier 2: the measured scene moves the gain, at most ADAPT_SCENE_REFINE_LIMIT x weight. More
    // gain raises the goal (within the cap) and is shown in step with the eyes' own progress toward
    // it: 0 in normal daylight (the reference stays exact), never faster than ADAPT_TO_DARK_TIME.
    s.sceneStops = 0.0;
#ifdef ADAPT_SCENE_LUMA
    if (history.w > 0.5) {
        float delta = -ADAPT_SCENE_LUMA_WEIGHT * clamp(history.x, -float(ADAPT_SCENE_REFINE_LIMIT), float(ADAPT_SCENE_REFINE_LIMIT));
        if (delta > 0.0) {
            // Only where the light at the camera itself says dark (goal above 0.25 stop): never
            // in daylight, and never while stepping out into it.
            float headroom = max(min(s.goalStops + delta, xMax) - s.goalStops, 0.0);
            delta = headroom * clamp(applied / max(s.goalStops, 0.05), 0.0, 1.0) * smoothstep(0.0, 0.25, s.goalStops);
        }
        s.sceneStops = delta;
    }
#endif
    // Never below 1 x (the eyes do not darken bright places; the punch handles those) and never
    // above the cap (ADAPT_MAX_BRIGHTEN, ADAPT_NIGHT_LIMIT outdoors at night).
    float x = clamp(applied + s.sceneStops, 0.0, max(xMax, applied));
    // Dimensions, the eye in lava or powder snow (already 0 from the CPU), Blindness and
    // Darkness (never brightened, so the effects keep their darkness), Night Vision (the game
    // already brightens everything).
    x *= mix(1.0, ADAPT_NETHER_STRENGTH, clamp(nether, 0.0, 1.0));
    x *= mix(1.0, ADAPT_END_STRENGTH, clamp(end, 0.0, 1.0));
    float effects = clamp(max(blindnessNow, darknessNow), 0.0, 1.0);
    x *= (1.0 - effects) * (1.0 - clamp(nightVisionNow, 0.0, 1.0));
    // The dazzle when stepping into a very bright place (snow, desert at midday): brief.
    float dazzle = BRIGHT_FLASH * ADAPT_DAZZLE * max(vclAdaptBrightGoal - vclAdaptBright, 0.0) * overworld * (1.0 - effects);
    s.flashStops += dazzle;
    x += dazzle;
    // A settled reference is exact: below 0.0005 stops (0.03 %) nothing is applied.
    s.gainStops = x < 0.0005 ? 0.0 : x;
    s.darkAmount = clamp(s.gainStops / max(xCave, 0.01), 0.0, 1.0);
    // Punch: very bright places (tier 1 biomes, tier 2 measured), only at daylight levels.
    float bright = clamp(vclAdaptBright, 0.0, 1.0);
#ifdef ADAPT_SCENE_LUMA
    if (history.w > 0.5) bright = max(bright, clamp(history.y, 0.0, 1.0) * (1.0 - smoothstep(0.0, 0.25, applied)));
#endif
    // (It fades out as soon as the eyes start to dark-adapt: punch and brightening never mix.)
    float p = BRIGHT_PUNCH * clamp(bright + BRIGHT_PUNCH_REFERENCE_SHIFT, 0.0, 1.0) * overworld * (1.0 - effects) *
              (1.0 - smoothstep(0.0, 0.3, applied));
    s.punch = p < 0.002 ? 0.0 : p;
    return s;
}

#ifdef ADAPT_STAGE
// ---- the exposure stage (final.fsh) ----
// params A: x = display gain, y = local lift amount, z = dark amount, w = punch
// params B: x = bloom boost (1 = none), y = highlight protection weight, z = dither scale, w = unused
// Kept short on purpose (about 20 operations per pixel in ULTRA LOW, 40 in MEDIUM, only while
// the view is brightened; nothing at the reference): the roll-off is one scalar per pixel.
vec3 adaptApply(vec3 color, vec3 auxiliary, vec4 A, vec4 B) {
    // Sanitized input: no negative light, NaN (dropped by max on current GPUs) or huge value
    // enters the gain.
    color = clamp(color, vec3(0.0), vec3(64.0));
    // The over-bright moment: a little more of the bloom (pre-exposure threshold, so the gain
    // itself never makes more things bloom).
    if (B.x != 1.0) color += max(auxiliary, vec3(0.0)) * (B.x - 1.0);
    // One gain for everything the eye sees (scene, sky, fog, bloom, rays): hues and torch colours
    // are kept.
    float gain = A.x;
#ifdef ADAPT_HIGHLIGHT_PROTECTION
    // Highlight roll-off on the largest channel (hue kept): a soft rational shoulder above the
    // knee that never reaches 1, and never below the pixel's own value without the stage (a sky
    // that is already near white stays as it was). Blended in as the gain rises (B.y).
    float m = max(color.r, max(color.g, color.b));
    float mg = m * gain;
    float over = max(mg - ADAPT_HIGHLIGHT_KNEE, 0.0);
    float rolled = max(mg - over + over / (1.0 + over / (1.0 - ADAPT_HIGHLIGHT_KNEE)), min(m, 1.0));
    gain = mix(gain, rolled / max(m, 1.0e-4), B.y);
#endif
    color *= gain;
    float luma = adaptLuma(color);
#ifdef ADAPT_LOCAL_LIFT
    // Soft toe: the darkest pixels get up to (1 + y) x, a pixel at 0.06 a quarter of that, bright
    // ones almost nothing; L (1 + y L0^2 / (L + L0)^2) never reverses the order of brightness.
    const float L0 = 0.06;
    float lift = A.y * (L0 * L0) / ((luma + L0) * (luma + L0));
    color *= 1.0 + lift;
    luma *= 1.0 + lift;
#endif
    // Deep darks of a dark-adapted view (one weight for both, never on bright pixels): a tiny cool
    // lift of the black level, and the night-vision feel (a little colour lost toward cool grey).
    float dark = A.z * (1.0 - smoothstep(0.015, 0.20, luma));
    color += ADAPT_SHADOW_LIFT * dark * vec3(0.80, 0.92, 1.18);
    color = mix(color, vec3(luma) * vec3(0.84, 0.95, 1.18), 0.5 * PURKINJE_STRENGTH * dark);
    // Punch in very bright places: +6 % contrast at mid grey (an S-curve that keeps 0 and 1, so
    // whites never clip) and +8 % vibrance on the duller colours (neon clamp).
    if (A.w > 0.0) {
        float l = clamp(adaptLuma(color), 0.0, 1.0);
        float curved = l + 0.06 * A.w * 4.0 * l * (1.0 - l) * (l - 0.5);
        color *= l > 1.0e-4 ? curved / l : 1.0;
        float maxC = max(color.r, max(color.g, color.b));
        float sat = (maxC - min(color.r, min(color.g, color.b))) / max(maxC, 1.0e-3);
        vec3 vivid = mix(vec3(adaptLuma(color)), color, 1.0 + 0.08 * A.w * (1.0 - sat));
        color = clamp(vivid, vec3(0.0), max(color, vec3(1.0)));
    }
    return color;
}
#endif
