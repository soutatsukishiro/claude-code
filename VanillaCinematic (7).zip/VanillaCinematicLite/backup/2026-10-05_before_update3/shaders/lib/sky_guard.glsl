// Patch 2.1, part B safety net (SKY_PIXEL_FIX). A sky colour is valid when every channel is a
// finite number in [-0.01, 64): comparisons with NaN are false, so NaN fails the test, and so do
// infinities and garbage. Only an invalid value is replaced (by a simpler analytic colour for
// the same pixel, or black), so valid values pass through bit for bit and the test costs a few
// comparisons. No blur, no neighbours, no change to the sky's look. (The legacy sky path adds a
// signed dither that can dip a hair below zero; -0.01 leaves that alone.)

bool skyColorValid(vec3 c) {
    return all(greaterThanEqual(c, vec3(-0.01))) && all(lessThan(c, vec3(64.0)));
}

// Fallback for an invalid sky value: the analytic colour passed in if that one is valid, else black.
vec3 skyGuardFallback(vec3 analytic) {
    return skyColorValid(analytic) ? clamp(analytic, vec3(0.0), vec3(64.0)) : vec3(0.0);
}
