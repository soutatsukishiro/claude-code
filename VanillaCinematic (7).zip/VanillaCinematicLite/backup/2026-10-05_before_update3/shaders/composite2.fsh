#version 330 compatibility

// Patch 2.1, part A: one-pixel pass for the adaptive eyes (only when ADAPT_SCENE_LUMA or
// ADAPT_DEBUG is on). colortex6 is 1 x 1 (128 x 1 with ADAPT_DEBUG), RGBA16F, never cleared,
// and only this pass writes it; Iris ping-pongs it (this pass reads last frame's value and
// writes this frame's), final.vsh reads texel 0 once per vertex. It never touches colortex5, so
// the bloom, shallow-water shafts, pollen and sun/moon shafts are unaffected.
//
// Texel 0, tier 2 (ADAPT_SCENE_LUMA): ADAPT_SCENE_TAPS fixed taps of the scene (colortex0: before
// fog, grading and exposure, so the measurement never feeds back on itself), sky and cloud taps
// left out (looking at the sky or the sun never darkens the world), each tap clamped to at most
// +2 stops (lava, a sun reflection), a log-average with the centre group weighted by
// ADAPT_CENTER_WEIGHT, but less when the centre is a bright window (> 1 stop above the ring).
// The measured level is low-passed (2 s), then compared with what the light at the camera
// predicts (vclAdaptDark): the refinement R = measured - expected, limited to
// ADAPT_SCENE_REFINE_LIMIT stops, a 0.75-stop dead band, smoothed with ADAPT_TO_DARK_TIME in both
// directions (the fast light adaptation comes from the light at the camera, tier 1) and
// rate-limited to 0.6 stop per second. Quick head turns between a wall and a window, a lightning
// flash or an explosion cannot pump it. It snaps on a camera jump.
// x = R, y = bright-scene amount (0..1, for the punch), z = low-passed measured level (stops), w = 1.
//
// Texels 1-127 (ADAPT_DEBUG): the exposure graph, 10 samples per second over 12.7 seconds:
// x = final gain, y = the light's gain (goal), z = tier 2's change, w = over-brightness (stops).

#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// Cloud marker (gbuffers_clouds): A = 1, R = 0.
uniform sampler2D colortex1;
#endif
uniform float frameTime;
uniform float frameTimeCounter;
#ifdef ADAPT_DEBUG
uniform float blindness;
uniform float darknessFactor;
uniform float nightVision;
uniform float atmosNether;
uniform float atmosEnd;
uniform float atmosOverworld;
#endif

#include "/lib/adaptive_eyes.glsl"

/* RENDERTARGETS: 6 */
/*
const int colortex6Format = RGBA16F;
const bool colortex6Clear = false;
*/
layout(location = 0) out vec4 outAdapt;

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec4 previous = texelFetch(colortex6, ivec2(0, 0), 0);
    // A new or garbage buffer (NaN fails the comparisons) counts as empty.
    bool valid = previous.w > 0.5 && previous.w < 1.5 &&
                 all(greaterThanEqual(previous.xyz, vec3(-64.0))) && all(lessThan(previous.xyz, vec3(64.0)));
    vec4 state = valid ? previous : vec4(0.0);

    if (px.x == 0) {
#ifdef ADAPT_SCENE_LUMA
        vec2 size = vec2(textureSize(colortex0, 0));
        float ringW = 0.0, ringL = 0.0, centreW = 0.0, centreL = 0.0;
        for (int i = 0; i < ADAPT_TAP_COUNT; ++i) {
            vec3 tap = adaptTap(i);
            ivec2 texel = clamp(ivec2(tap.xy * size), ivec2(1), ivec2(size) - 1);
            if (texelFetch(depthtex0, texel, 0).r > 0.99999) continue;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
            vec4 info = texelFetch(colortex1, texel, 0);
            if (info.a > 0.5 && info.r < 0.5) continue;
#endif
            // One bilinear read at a texel corner = the average of 2 x 2 texels (calmer than one).
            vec3 c = texture(colortex0, vec2(texel) / size).rgb;
            float y = pow(clamp(adaptLuma(c), 0.0, 64.0), 2.2);
            float stops = clamp(log2(max(y, 1.0e-6) / ADAPT_Y_REF), -10.0, 2.0);
            if (tap.z > 0.5) {
                centreW += 1.0;
                centreL += stops;
            } else {
                ringW += 1.0;
                ringL += stops;
            }
        }
        if (ringW + centreW > 0.0) {
            float ringAvg = ringW > 0.0 ? ringL / ringW : centreL / centreW;
            float centreAvg = centreW > 0.0 ? centreL / centreW : ringAvg;
            // Centre weight per tap (1 = like the ring), reduced to 1 when the centre is a bright
            // window (1 to 3 stops above the ring), so a window in the middle never dominates.
            float cw = mix(1.0, 4.0, ADAPT_CENTER_WEIGHT);
            cw = mix(cw, 1.0, smoothstep(1.0, 3.0, centreAvg - ringAvg));
            float measured = (ringL + cw * centreL) / (ringW + cw * centreW);
            float expected = log2(exp2(-max(vclAdaptDark, 0.0)) + ADAPT_FLOOR);
            float limit = float(ADAPT_SCENE_REFINE_LIMIT);
            if (!valid || vclAdaptSnap > 0.1) {
                state = vec4(clamp(measured - expected, -limit, limit), smoothstep(1.0, 2.0, measured), measured, 1.0);
            } else {
                float dt = clamp(frameTime, 0.0, 0.25);
                // The measured level itself is low-passed first (2 s): turning the head back and
                // forth between a dark wall and a bright window averages out (a 2-stop swing at
                // 1 Hz leaves a ripple of about 0.17 stop), a view you keep still gets through.
                float measuredSlow = state.z + (measured - state.z) * (1.0 - exp(-dt / 2.0));
                float target = clamp(measuredSlow - expected, -limit, limit);
                float brightTarget = smoothstep(1.0, 2.0, measuredSlow);
                // R moves with the dark adaptation time in both directions: the fast light
                // adaptation belongs to the light at the camera (tier 1), not to where you look.
                // The bright amount rises in ADAPT_TO_BRIGHT_TIME.
                float tauDark = float(ADAPT_TO_DARK_TIME) / 2.3026;
                float tauBright = float(ADAPT_TO_BRIGHT_TIME) * 0.001 / 2.3026;
                // Dead band: R only moves once the scene is more than 0.75 stop away from it.
                float wanted = clamp(state.x, target - 0.75, target + 0.75);
                float follow = 1.0 - exp(-dt / tauDark);
                state.x += clamp((wanted - state.x) * follow, -0.6 * dt, 0.6 * dt);
                float followB = 1.0 - exp(-dt / (brightTarget > state.y ? tauBright : tauDark));
                state.y += clamp((brightTarget - state.y) * followB, -0.5 * dt, 0.5 * dt);
                state.z = measuredSlow;
                state.w = 1.0;
            }
        } else if (valid) {
            // Nothing but sky in the taps: the refinement eases back to zero (over about 2 s).
            float dt = clamp(frameTime, 0.0, 0.25);
            state.x -= clamp(state.x * (1.0 - exp(-dt / 0.87)), -0.6 * dt, 0.6 * dt);
            state.y -= clamp(state.y * (1.0 - exp(-dt / 0.87)), -0.5 * dt, 0.5 * dt);
        }
#endif
        outAdapt = state;
        return;
    }

#ifdef ADAPT_DEBUG
    int slot = 1 + int(mod(floor(frameTimeCounter * 10.0), 127.0));
    if (px.x == slot) {
        AdaptState s = adaptState(state, atmosOverworld, atmosNether, atmosEnd, blindness, darknessFactor, nightVision);
        outAdapt = vec4(s.gainStops, s.goalStops, s.sceneStops, s.flashStops);
    } else {
        outAdapt = texelFetch(colortex6, px, 0);
    }
#else
    outAdapt = vec4(0.0);
#endif
}
