#version 330 compatibility

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;

#ifdef MOON_SHAFTS
// Needed by lib/ambience.glsl (the moon's light decides which source owns the shafts).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
uniform int moonPhase;
#include "/lib/ambience.glsl"
#endif

out vec2 vTexCoord;
out vec2 vSunUV;
out float vSunElevation;
out float vSunInFront;
out vec2 vMoonUV;
out float vMoonElevation;
out float vMoonInFront;
#ifdef MOON_SHAFTS
// > 0 while the moon owns the shaft buffer this frame (lib/ambience.glsl, ambMoonShaftOwner).
flat out float vMoonShaftOwner;
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    vec3 sunWorldRaw = mat3(gbufferModelViewInverse) * sunPosition;
    float sunLength2 = dot(sunWorldRaw, sunWorldRaw);
    vec3 sunWorld = sunLength2 > 0.000001 ? sunWorldRaw * inversesqrt(sunLength2) : vec3(0.0, 1.0, 0.0);
    vSunElevation = sunWorld.y;
    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);

    vec3 moonWorldRaw = mat3(gbufferModelViewInverse) * moonPosition;
    float moonLength2 = dot(moonWorldRaw, moonWorldRaw);
    vec3 moonWorld = moonLength2 > 0.000001 ? moonWorldRaw * inversesqrt(moonLength2) : vec3(0.0, -1.0, 0.0);
    vMoonElevation = moonWorld.y;
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    vMoonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = vMoonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);
#ifdef MOON_SHAFTS
    vec3 moonDir = ambCelestialDirection(moonPosition);
    vMoonShaftOwner = ambMoonShaftOwner(vMoonInFront, ambMoonLight(moonDir, ambCelestialDirection(sunPosition), moonPhase),
                                        moonDir, vSunInFront, ambCelestialDirection(sunPosition).y);
#endif
}

