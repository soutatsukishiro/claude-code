#version 330 compatibility

// The sky behind everything: the palette sky with the sun's glow and the analytic sun
// (ambienceSkyFull), written into colortex0 at full float precision. Translucent clouds blend
// over exactly this sky, and the screen-space water reflection samples it. final rebuilds the
// same value on the visible sky pixels and keeps only what vanilla adds on top (moon, stars).
// Vanilla stars are kept (only at night); the sunrise fan and the dark void disc are dropped
// (the palette already has the golden-hour colours, and the sky below the horizon is the
// horizon colour). The vanilla sun is disabled in shaders.properties (sun=false).
// MOON_RAYS: the moon's glow and halo replace the previous moon glow (ambienceSkyFullMoon), and
// the vanilla stars fade softly near the moon. The vanilla moon itself is drawn by vanilla on
// top of this sky, unchanged (its phase sprite, its square shape).

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform int renderStage;
uniform int moonPhase;

#include "/lib/ambience.glsl"

in vec4 vColor;
flat in vec3 vSunWorld;
flat in vec3 vZenith;
flat in vec3 vMid;
flat in vec3 vHorizon;
flat in vec3 vGlow;
flat in float vGolden;
#ifdef MOON_RAYS
flat in vec4 vMoonWorldLight;
flat in vec3 vMoonTint;
flat in vec2 vMoonSide;
#endif

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// View direction from the pixel (the same construction as final's worldViewRay).
vec3 skyViewDirection() {
    vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec4 rayH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 0.5, 1.0);
    vec3 viewRay = rayH.xyz * inversesqrt(max(dot(rayH.xyz, rayH.xyz), 1.0e-6));
    vec3 dir = mat3(gbufferModelViewInverse) * viewRay;
    return dir * inversesqrt(max(dot(dir, dir), 1.0e-6));
}

#ifdef MOON_RAYS
AmbMoon skyMoon() {
    AmbMoon m;
    m.dir = vMoonWorldLight.xyz;
    m.light = vMoonWorldLight.w;
    m.tint = vMoonTint;
    m.side = vMoonSide;
    return m;
}
#endif

void main() {
#ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) {
        // Vanilla stars; faded by our own night factor as well, in case the star brightness
        // is not carried in the vertex colour.
        float night = 1.0 - smoothstep(-0.25, 0.05, vSunWorld.y);
#ifdef MOON_RAYS
        // Stars inside the moon's glow fade softly (only near the moon).
        night *= ambMoonStarDimming(skyViewDirection(), skyMoon());
#endif
        outColor = vec4(vColor.rgb * night * (1.0 - clamp(rainStrength, 0.0, 1.0)), vColor.a);
        return;
    }
#endif
#ifdef MC_RENDER_STAGE_SUNSET
    if (renderStage == MC_RENDER_STAGE_SUNSET) discard;
#endif
#ifdef MC_RENDER_STAGE_VOID
    if (renderStage == MC_RENDER_STAGE_VOID) discard;
#endif

    vec3 dir = skyViewDirection();

    AmbPalette pal;
    pal.zenith = vZenith;
    pal.mid = vMid;
    pal.horizon = vHorizon;
    pal.fogNear = vHorizon;
    pal.cloudTop = vec3(0.0);
    pal.cloudEdge = vec3(0.0);
    pal.cloudUnder = vec3(0.0);
    pal.sunLight = vec3(1.0);
    pal.skyLight = vec3(0.0);
    pal.glow = vGlow;
    pal.golden = vGolden;
    float pixelAngle = 2.0 / max(gbufferProjection[1][1] * viewHeight, 1.0);
#ifdef MOON_RAYS
    outColor = vec4(ambienceSkyFullMoon(dir, vSunWorld, pal, skyMoon(), pixelAngle), 1.0);
#else
    outColor = vec4(ambienceSkyFull(dir, vSunWorld, pal, ambMoonBrightness(moonPhase), pixelAngle), 1.0);
#endif
}
