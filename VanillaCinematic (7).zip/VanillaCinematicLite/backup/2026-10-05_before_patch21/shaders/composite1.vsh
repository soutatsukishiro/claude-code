#version 330 compatibility

// Full-screen quad of the quarter-resolution shaft pass, with the sun's screen position (and the
// moon's, with the source that owns the shafts this frame, when MOON_SHAFTS is on).

#include "/lib/settings.glsl"

uniform mat4 gbufferProjection;
uniform vec3 sunPosition;

#ifdef MOON_SHAFTS
uniform vec3 moonPosition;
uniform int moonPhase;
// Needed by lib/ambience.glsl.
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
#include "/lib/ambience.glsl"
#endif

out vec2 vTexCoord;
out vec2 vSunUV;
out float vSunInFront;
#ifdef MOON_SHAFTS
out vec2 vMoonUV;
// > 0 while the moon owns the shaft buffer (the same decision as composite and final).
flat out float vMoonShaftOwner;
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
#ifdef MOON_SHAFTS
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    float moonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = moonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec3 moonDir = ambCelestialDirection(moonPosition);
    vMoonShaftOwner = ambMoonShaftOwner(moonInFront, ambMoonLight(moonDir, ambCelestialDirection(sunPosition), moonPhase),
                                        moonDir, vSunInFront, ambCelestialDirection(sunPosition).y);
#endif
}
