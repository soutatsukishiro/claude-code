#version 330 compatibility

// Shadow pass for entities (Iris program shadow_entities; without it Iris uses shadow.fsh).
// Same depth and alpha test as shadow.fsh, so the shadow map itself is unchanged. The only
// difference: with ENTITY_SHADOW_FLAG, R = 1 marks the caster as an entity in shadowcolor0
// (shadow.fsh writes R = 0), which lets the terrain programs give player and mob shadows their
// own strength and colour. Without ENTITY_SHADOW_FLAG the output equals shadow.fsh exactly.

#include "/lib/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

in vec2 vTexCoord;
in vec4 vColor;

void main() {
    vec4 texel = texture(gtexture, vTexCoord) * vColor;
    if (texel.a < alphaTestRef) discard;
#ifdef ENTITY_SHADOW_FLAG
    gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
#else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
#endif
}
