#version 330 compatibility

// Vanilla cloud geometry, unchanged (Iris feeds the cloud mesh: position, colour, normal).
// Only the lighting changes, in gbuffers_clouds.fsh.

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;
#ifdef MOON_RAYS
uniform vec3 moonPosition;
uniform int moonPhase;
#endif

#include "/lib/ambience.glsl"

out vec4 vColor;
out vec3 vPlayerPosition;
flat out vec3 vSunWorld;
flat out vec3 vCloudTop;
flat out vec3 vCloudEdge;
flat out vec3 vCloudUnder;
flat out vec3 vZenith;
flat out vec3 vMid;
flat out vec3 vHorizon;
flat out vec3 vGlow;
flat out float vGolden;
#ifdef MOON_RAYS
// The moon for this frame: direction (xyz) and light (w), colour tint, lit side.
flat out vec4 vMoonWorldLight;
flat out vec3 vMoonTint;
flat out vec2 vMoonSide;
#endif

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = gl_ProjectionMatrix * viewPosition;
    vPlayerPosition = (gbufferModelViewInverse * viewPosition).xyz;
    vColor = gl_Color;

    vSunWorld = ambSunDirection();
    AmbPalette pal = ambiencePalette(vSunWorld);
    vCloudTop = pal.cloudTop;
    vCloudEdge = pal.cloudEdge;
    vCloudUnder = pal.cloudUnder;
    vZenith = pal.zenith;
    vMid = pal.mid;
    vHorizon = pal.horizon;
    vGlow = pal.glow;
    vGolden = pal.golden;
#ifdef MOON_RAYS
    AmbMoon moon = ambMoon(ambCelestialDirection(moonPosition), vSunWorld, moonPhase);
    vMoonWorldLight = vec4(moon.dir, moon.light);
    vMoonTint = moon.tint;
    vMoonSide = moon.side;
#endif
}
