#version 330 compatibility

#include "/lib/settings.glsl"

// The shared sky functions (Ambience palette sky and fog, water reflection, horizon blend) are
// used by the sky treatment, the fog and the screen-space water reflection: always available.
#define FINAL_WATER_SKY

// colortex1 carries the water marker (R), its sky light (G), packed reflection data (B) and,
// on cloud pixels written by gbuffers_clouds, the cloud marker (A = 1 with R = 0, G = the
// face's opacity). gbuffers_clouds runs whenever the Ambience colours or clouds are on.
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
#define AMB_CLOUD_MARKER
#endif
#if defined(AMB_CLOUD_MARKER) || defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG) || (defined(AMBIENCE_FOG) && !defined(FOG_ON_WATER))
#define AMB_FINAL_INFO
#endif

uniform sampler2D colortex0;
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(RAYS_SHAFTS)
uniform sampler2D colortex5;
#endif
#if defined(VV_DEBUG) || defined(WATER_SSR) || defined(AMB_FINAL_INFO) || ((defined(CAUSTICS_DEBUG) || defined(REFLECTION_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10)) && !defined(ATMOS_DEBUG))
uniform sampler2D colortex1;
#endif
uniform mat4 gbufferProjection;
#ifdef WATER_SSR
uniform mat4 gbufferModelView;
#endif
uniform vec3 sunPosition;
uniform float far;
// Needed by lib/ambience.glsl.
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform ivec2 eyeBrightnessSmooth;
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
uniform sampler2D colortex2;
#endif
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform float temperature;
uniform float rainfall;
uniform float fogDensity;
uniform float atmosHumidBiome;
uniform float atmosCoolBiome;
uniform float atmosWoodlandBiome;
uniform float atmosSavannaBiome;
uniform float atmosPlainsBiome;
uniform float atmosDesertBiome;
uniform float atmosNether;
uniform float atmosEnd;
uniform vec3 cameraPosition;
uniform int moonPhase;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float thunderStrength;
uniform float aspectRatio;
uniform float atmosOverworld;
uniform bool hasSkylight;
uniform bool hasCeiling;

in vec2 vTexCoord;
in float vSunElevation;
in float vMoonElevation;
in vec2 vSunUV;
in float vSunInFront;
in vec2 vMoonUV;
in float vMoonInFront;

// Ambience palette of this frame (final.vsh).
flat in vec3 vSunWorld;
flat in vec3 vPalZenith;
flat in vec3 vPalMid;
flat in vec3 vPalHorizon;
flat in vec3 vPalFogNear;
flat in vec3 vPalCloudTop;
flat in vec3 vPalCloudUnder;
flat in vec3 vPalSkyLight;
flat in vec3 vPalGlow;
flat in float vPalGolden;
// Sun visibility from the fixed taps in final.vsh, the share of the sun behind clouds, and the
// on-screen fade of the veil, rim and shafts.
flat in float vSunVisibility;
flat in float vSunCloudCover;
flat in float vSunScreenFade;
#ifdef MOON_RAYS
// The moon for this frame (final.vsh): direction and light; tint and night weight; lit side;
// visibility, cloud cover, on-screen fade and shaft gate.
flat in vec4 vMoonWorldLight;
flat in vec4 vMoonTintNight;
flat in vec2 vMoonSide;
flat in vec4 vMoonRays;
#ifdef MOON_SHAFTS
flat in float vSunShaftGate;
#endif
#endif
#if defined(LIGHT_DEBUG) && defined(CAUSTICS_UNDERWATER_FLOOR)
// Estimated water surface above an underwater camera (custom uniform, shaders.properties).
uniform float vclWaterSurfaceY;
#endif
#ifdef AMB_WATER_OWN_PALETTE
flat in vec3 vWaterZenith;
flat in vec3 vWaterMid;
flat in vec3 vWaterHorizon;
flat in vec3 vWaterCloudTop;
flat in vec3 vWaterCloudUnder;
flat in vec3 vWaterGlow;
flat in float vWaterGolden;
#endif
// lib/ambience.glsl comes early: the previous haze functions below use its Nether/End tints.
#include "/lib/ambience.glsl"
// Rim gather, depth normal, shaft upsample and the CelestialLight veil/rim/shaft composition
// (deterministic, no noise, no shadow map).
#define RAYS_FINAL
#include "/lib/sun_rays.glsl"

vec3 safeNormalize(vec3 value) {
    return value * inversesqrt(max(dot(value, value), 0.000001));
}

#ifdef GOLDEN_FAKE_BIRDS
float targetBirdMask(vec2 screenUV, vec2 centerUV) {
    float cell = max(float(FAKE_BIRD_SIZE), 1.0);
    vec2 screen = vec2(viewWidth, viewHeight);
    vec2 p = (screenUV - centerUV) * screen / cell;
    float wingLine = abs(p.y - (0.30 - 0.46 * abs(p.x)));
    return step(abs(p.x), 1.05) * (1.0 - step(0.12, wingLine));
}
#endif

float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

vec3 worldViewRay(vec2 uv) {
    vec4 rayH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 0.5, 1.0);
    vec3 viewRay = safeNormalize(rayH.xyz);
    return safeNormalize(mat3(gbufferModelViewInverse) * viewRay);
}

vec3 evaluateAtmosphereColor(float viewUp, float twilight, float night) {
    vec3 haze = mix(fogColor, skyColor, smoothstep(-0.15, 0.70, viewUp) * 0.22);
    float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.15, rainfall) * 0.25), 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome * (0.65 + 0.35 * (1.0 - smoothstep(0.10, 0.75, temperature))), 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    float desertWeight = clamp(atmosDesertBiome * 0.75, 0.0, 1.0);
    float plainsWeight = clamp(atmosPlainsBiome * 0.30, 0.0, 1.0);

    haze = mix(haze, vec3(0.91, 0.64, 0.42), autumnWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.45, 0.80, 0.73), humidWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.58, 0.72, 0.87), coldWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.83, 0.65, 0.44), desertWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.65, 0.77, 0.80), plainsWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.95, 0.70, 0.50), twilight * 0.10);
    haze = mix(haze, vec3(0.40, 0.52, 0.70), night * 0.32);
    // Nether and End: a small tint on top of the vanilla fog colour (per Nether biome with
    // BIOME_AMBIENCE; the previous fixed tints without it).
    haze = mix(haze, ambNetherFogTint(), clamp(atmosNether, 0.0, 1.0) * 0.30);
    haze = mix(haze, ambEndFogTint(), clamp(atmosEnd, 0.0, 1.0) * 0.28);
    return haze;
}

vec3 evaluateSkyGradient(vec3 worldDirection) {
    float day = smoothstep(-0.10, 0.20, vSunElevation);
    float twilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);

    vec3 dayZenith = vec3(0.16, 0.40, 0.68);
    vec3 dayHorizon = vec3(0.58, 0.77, 0.89);
    vec3 twilightHorizon = vec3(0.96, 0.63, 0.46);
    vec3 nightZenith = vec3(0.035, 0.060, 0.145);
    vec3 nightHorizon = vec3(0.12, 0.17, 0.29);
    vec3 zenith = mix(nightZenith, dayZenith, day);
    vec3 horizon = mix(nightHorizon, dayHorizon, day);
    horizon = mix(horizon, twilightHorizon, twilight * 0.86);

    float horizonBlend = 1.0 - smoothstep(0.02, 0.90, max(worldDirection.y, 0.0));
    vec3 gradient = mix(zenith, horizon, horizonBlend);
    vec3 fogMatchedHorizon = evaluateAtmosphereColor(0.0, twilight, night);
    gradient = mix(gradient, fogMatchedHorizon, horizonBlend * 0.22);

    float humidWeight = clamp(atmosHumidBiome, 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome, 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    gradient = mix(gradient, vec3(0.48, 0.74, 0.76), humidWeight * BIOME_TINT_STRENGTH * 0.38);
    gradient = mix(gradient, vec3(0.63, 0.75, 0.88), coldWeight * BIOME_TINT_STRENGTH * 0.32);
    gradient = mix(gradient, vec3(0.90, 0.65, 0.44), autumnWeight * BIOME_TINT_STRENGTH * 0.36);

    float luma = dot(gradient, vec3(0.2126, 0.7152, 0.0722));
    vec3 rainySky = mix(vec3(luma), vec3(0.43, 0.53, 0.64), 0.50);
    gradient = mix(gradient, rainySky, clamp(rainStrength, 0.0, 1.0) * 0.72);
    gradient = mix(gradient, vec3(0.22, 0.28, 0.37), clamp(thunderStrength, 0.0, 1.0) * 0.48);
    gradient = mix(gradient, ambNetherFogTint(), clamp(atmosNether, 0.0, 1.0) * 0.22);
    gradient = mix(gradient, ambEndFogTint(), clamp(atmosEnd, 0.0, 1.0) * 0.24);
    return max(gradient, vec3(0.0));
}

#include "/lib/water_reflection.glsl"

AmbPalette finalPalette() {
    AmbPalette p;
    p.zenith = vPalZenith;
    p.mid = vPalMid;
    p.horizon = vPalHorizon;
    p.fogNear = vPalFogNear;
    p.cloudTop = vPalCloudTop;
    p.cloudEdge = vPalCloudTop;
    p.cloudUnder = vPalCloudUnder;
    p.sunLight = vec3(1.0);
    p.skyLight = vPalSkyLight;
    p.glow = vPalGlow;
    p.golden = vPalGolden;
    return p;
}

// The palette the water reflection reads: the frame palette, or the biome-free one when
// BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off (it must match the water's own Tier 1).
AmbPalette finalWaterPalette() {
    AmbPalette p = finalPalette();
#ifdef AMB_WATER_OWN_PALETTE
    p.zenith = vWaterZenith;
    p.mid = vWaterMid;
    p.horizon = vWaterHorizon;
    p.fogNear = vWaterHorizon;
    p.cloudTop = vWaterCloudTop;
    p.cloudEdge = vWaterCloudTop;
    p.cloudUnder = vWaterCloudUnder;
    p.glow = vWaterGlow;
    p.golden = vWaterGolden;
#endif
    return p;
}

// Camera sky exposure (0 deep in a cave, 1 under open sky): caves get a thinner haze.
float ambienceCaveLight() {
    return smoothstep(0.05, 0.60, float(eyeBrightnessSmooth.y) / 240.0);
}

// The sun as a celestial light for the veil, rim and shafts: its approved constants, exactly
// the values the previous sun code used (eyeSky = the camera's sky exposure term).
CelestialLight finalSunLight(float eyeSky) {
    CelestialLight L;
    L.direction = vSunWorld;
    L.screenUV = vSunUV;
    L.inFront = vSunInFront;
    L.screenFade = vSunScreenFade;
    L.halfSize = AMB_SUN_HALF;
    L.haloSize = SUN_HALO_SIZE;
    L.light = ambSunGlowVisibility(vSunWorld) * eyeSky;
    L.visibility = vSunVisibility;
    L.cloudCover = vSunCloudCover;
    vec3 glowColor = ambSunGlowColor(vSunWorld);
    L.veilStrength = VEIL_STRENGTH;
    L.veilColor = glowColor;
    L.rimStrength = RIM_STRENGTH;
    L.rimColor = ambRimColor(vSunWorld);
    L.rimReach = RIM_REACH;
    L.shaftStrength = SHAFT_STRENGTH;
#ifdef MOON_SHAFTS
    // 0 while the moon owns the shaft buffer (never while the sun can show shafts).
    L.shaftStrength *= vSunShaftGate;
#endif
    L.shaftColor = glowColor;
    L.shaftSpread = 1.0;
    return L;
}

#ifdef MOON_RAYS
AmbMoon finalMoon() {
    AmbMoon m;
    m.dir = vMoonWorldLight.xyz;
    m.light = vMoonWorldLight.w;
    m.tint = vMoonTintNight.rgb;
    m.side = vMoonSide;
    return m;
}

// The moon as a celestial light: smaller (AMB_MOON_HALF), much fainter, cool colours tinted by
// the biome; its rim reaches 0.75 x as far (thinner), its shaft cone is narrower (spread 0.75).
CelestialLight finalMoonLight(float eyeSky) {
    CelestialLight L;
    vec3 tint = vMoonTintNight.rgb;
    L.direction = vMoonWorldLight.xyz;
    L.screenUV = vMoonUV;
    L.inFront = vMoonInFront;
    L.screenFade = vMoonRays.z;
    L.halfSize = AMB_MOON_HALF;
    L.haloSize = MOON_HALO_SIZE;
    L.light = vMoonWorldLight.w * eyeSky;
    L.visibility = vMoonRays.x;
    L.cloudCover = vMoonRays.y;
    L.veilStrength = MOON_VEIL_STRENGTH;
    L.veilColor = min(AMB_MOON_VEIL * tint, vec3(1.0));
    L.rimStrength = MOON_RIM_STRENGTH;
    L.rimColor = min(AMB_MOON_RIM * tint, vec3(1.0));
    L.rimReach = 0.75 * RIM_REACH;
    L.shaftStrength = MOON_SHAFT_STRENGTH * vMoonRays.w;
    L.shaftColor = min(AMB_MOON_SHAFT * tint, vec3(1.0));
    L.shaftSpread = 0.75;
    return L;
}
#endif

// Night boost of the static output dither (MOON_RAYS): dark regions at night get up to
// (1 + NIGHT_SKY_DITHER) x SKY_DITHER, where 8-bit steps band most easily. It is added as a
// separate term that only runs at night, so the daytime dither stays the previous expression
// exactly (bit for bit).
float finalNightDitherBoost(vec3 color) {
#ifdef MOON_RAYS
    return NIGHT_SKY_DITHER * vMoonTintNight.a * (1.0 - smoothstep(0.0, 0.20, ambLuma(color)));
#else
    return 0.0;
#endif
}

#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
// The sun's veil, rim and shafts exactly as final wrote them before Update 2A (inline constants
// and falloffs), for the identity check view: the CelestialLight path must give the same colour.
vec3 finalSunRaysPrevious(vec3 color, vec3 viewDirection, vec3 playerPosition, float sceneDepth, bool cloudPixel) {
    float theta = ambAngle(viewDirection, vSunWorld);
    float sunLight = ambSunGlowVisibility(vSunWorld) * smoothstep(0.10, 0.45, float(eyeBrightnessSmooth.y) / 240.0);
#ifdef SUN_VEIL
    float visibility = vSunVisibility * vSunScreenFade;
    float depthFactor = 1.0 - exp(-length(playerPosition) / 6.0);
    float veilFalloff = 0.65 * exp(-max(theta - AMB_SUN_HALF, 0.0) / (1.2 * AMB_SUN_HALF)) + 0.35 * exp(-theta / SUN_HALO_SIZE);
    float veil = VEIL_STRENGTH * visibility * veilFalloff * depthFactor * sunLight;
    color = mix(color, ambSunGlowColor(vSunWorld), clamp(veil, 0.0, 0.6));
#endif
#ifdef SUN_EDGE_RIM
    float rimVisibility = (vSunVisibility + 0.55 * max(1.0 - vSunVisibility - vSunCloudCover, 0.0)) * vSunScreenFade;
    float rimFalloff = exp(-max(theta - AMB_SUN_HALF, 0.0) / (0.6 * AMB_SUN_HALF)) * sunLight * rimVisibility * smoothstep(0.6, 2.0, length(playerPosition));
    if (rimFalloff > 0.004 && vSunInFront > 0.5 && !cloudPixel) {
        vec2 screen = vec2(viewWidth, viewHeight);
        float gather = raysRimGather(vTexCoord, vSunUV, screen, AMB_SUN_HALF * gbufferProjection[1][1] * 0.5 * viewHeight, RIM_REACH);
        if (gather > 0.002) {
            vec3 normal = raysNormal(ivec2(gl_FragCoord.xy), sceneDepth, playerPosition, screen);
            float facing = mix(0.65, 1.0, smoothstep(-0.10, 0.30, dot(normal, vSunWorld)));
            float rim = RIM_STRENGTH * gather * rimFalloff * facing;
            color = mix(color, ambRimColor(vSunWorld), clamp(rim, 0.0, 0.75));
        }
    }
#endif
#ifdef SUN_SHAFTS
    float shaftLight = SHAFT_STRENGTH * (exp(-max(theta - 0.075, 0.0) / 0.22) * (1.0 - smoothstep(0.45, 0.80, theta))) * sunLight * vSunScreenFade * vSunInFront;
    if (shaftLight > 0.0005 && texture(colortex5, vTexCoord).a > 0.002) {
        float shafts = raysShaftUpsample(vTexCoord, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight));
        color += ambSunGlowColor(vSunWorld) * (shaftLight * shafts) * max(vec3(1.0) - color, vec3(0.0));
    }
#endif
    return color;
}
#endif

// Angular size of one pixel (anti-aliasing width of the analytic sun's edges).
float finalPixelAngle() {
    return 2.0 / max(gbufferProjection[1][1] * viewHeight, 1.0);
}

// Existing cinematic tone shoulder and highlight warmth (unchanged).
vec3 finalToneMap(vec3 color, float overworld) {
    float day = smoothstep(-0.12, 0.15, vSunElevation);
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float shadowTone = 1.0 - smoothstep(0.08, 0.72, luminance);
    float highlightTone = smoothstep(0.22, 0.90, luminance);
    color *= mix(vec3(1.0), vec3(0.94, 0.98, 1.035), shadowTone * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    color *= mix(vec3(1.0), vec3(1.025, 1.008, 0.975), highlightTone * day * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    vec3 softClip = color / (1.0 + max(color, vec3(0.0)) * 0.12);
    return mix(color, softClip, 0.58 * TONE_SHOULDER_STRENGTH * overworld);
}

#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG)
// Values stashed for the debug views.
float gDebugFogAmount = 0.0;
vec3 gDebugFogColor = vec3(0.0);
float gDebugBank = 1.0;
float gDebugScatter = 0.0;
float gDebugDesaturation = 0.0;
float gDebugCloudMask = 0.0;
float gDebugCloudShadow = 1.0;
vec2 gDebugCloudUV = vec2(0.0);
vec3 gDebugReflectionColor = vec3(0.0);
float gDebugReflectionValid = 0.0;
float gDebugReflectionFog = 0.0;
float gDebugVeil = 0.0;
float gDebugRim = 0.0;
#endif
#ifdef LIGHT_DEBUG
float gLightDebugRim = 0.0;
float gLightDebugShaft = 0.0;
#endif
#ifdef MOON_DEBUG
float gMoonDebugVeil = 0.0;
float gMoonDebugRim = 0.0;
float gMoonDebugShaft = 0.0;
vec3 gMoonDebugRaysBefore = vec3(0.0);
vec3 gMoonDebugRaysAfter = vec3(0.0);
vec3 gMoonDebugSunBefore = vec3(0.0);
vec3 gMoonDebugSunAfter = vec3(0.0);
float gMoonDebugTerrain = 0.0;
#endif

#ifdef WATER_SSR
bool waterProjectToScreen(vec3 playerPosition, out vec2 uv) {
    vec4 clip = gbufferProjection * (gbufferModelView * vec4(playerPosition, 1.0));
    uv = clip.xy / max(clip.w, 0.0001) * 0.5 + 0.5;
    return clip.w > 0.0001;
}

vec3 waterPlayerFromDepth(vec2 uv, float depth) {
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
}

// Tier 2: screen-space planar reflection. The water top is a horizontal plane at this
// pixel's surface height, so no ray march is needed: the reflected ray is projected at the
// render distance, then refined with the depth seen there (WATER_SSR_REFINE steps).
// colortex0 holds the scene the gbuffers produced; final only reads it, so there is no
// read/write hazard. The objects reflected stand above the water line, so their pixels are
// not covered by water. Returns the change to add: weight * (environment - Tier 1).
vec3 waterScreenReflection(vec2 uv, out vec4 debugInfo) {
    debugInfo = vec4(0.0);
    vec4 info = texture(colortex1, uv);
    if (info.r < 0.5 || isEyeInWater != 0) return vec3(0.0);
    float packedValue = floor(info.b * 255.0 + 0.5);
    float weight = floor(packedValue / 8.0) / 31.0;
    float wobble = mod(packedValue, 8.0) / 7.0 * 2.0 - 1.0;

    vec3 surface = waterPlayerFromDepth(uv, texture(depthtex0, uv).r);
    vec3 viewDir = safeNormalize(surface);
    vec3 reflectDir = vec3(viewDir.x, abs(viewDir.y), viewDir.z);
    float weather = clamp(rainStrength, 0.0, 1.0);
    // Exactly the Tier-1 colour the water program blended in (same function, flat normal).
#ifdef WATER_REFLECTION_IMPROVEMENT
    vec3 skyTier1 = waterSkyReflectionImproved(reflectDir, vSunWorld, ambWrappedWorld(surface), finalWaterPalette(),
                                               CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#else
    vec3 skyTier1 = waterSkyReflection(reflectDir, vSunElevation, CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#endif

    vec2 reflectUV;
    bool onScreen = waterProjectToScreen(surface + reflectDir * far, reflectUV);
    for (int i = 0; i < WATER_SSR_REFINE; ++i) {
        float refineDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
        if (refineDepth > 0.99999 || !onScreen) break;
        vec3 seen = waterPlayerFromDepth(reflectUV, refineDepth);
        onScreen = waterProjectToScreen(surface + reflectDir * distance(seen, surface), reflectUV);
    }

    // Wobble with the vanilla wave texels, rougher in rain, snapped to a 2-pixel grid.
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    float roughness = 1.0 + weather * 1.5;
    reflectUV.y += wobble * REFLECTION_WOBBLE * roughness * 3.0 * pixel.y;
    reflectUV = (floor(reflectUV / (2.0 * pixel)) + 0.5) * 2.0 * pixel;

    float hitDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
    vec3 hit = waterPlayerFromDepth(reflectUV, hitDepth);
    float edgeFade = smoothstep(0.0, 0.05, reflectUV.x) * smoothstep(0.0, 0.05, 1.0 - reflectUV.x) *
                     smoothstep(0.0, 0.05, reflectUV.y) * smoothstep(0.0, 0.05, 1.0 - reflectUV.y);
    // Valid: on screen, an object above the water plane (not water, floor or sky), and not the
    // hand or other camera-near geometry. Sky samples keep Tier 1, which already matches the sky.
    bool aboveWater = hitDepth < 0.99999 && hit.y > surface.y + 0.05 && dot(hit, hit) > 1.0;
    float valid = (onScreen && aboveWater) ? edgeFade : 0.0;

    // Soft, vertically stretched, low contrast: vertical taps around the reflected point.
    vec3 environment = vec3(0.0);
    for (int k = 0; k < REFLECTION_BLUR; ++k) {
        float offset = (float(k) - float(REFLECTION_BLUR - 1) * 0.5) * float(REFLECTION_STRETCH) * roughness;
        environment += texture(colortex0, clamp(reflectUV + vec2(0.0, offset * pixel.y), vec2(0.0), vec2(1.0))).rgb;
    }
    environment /= float(REFLECTION_BLUR);
#ifdef WATER_REFLECTION_IMPROVEMENT
    float reflectionFog = 0.0;
#ifdef AMBIENCE_FOG
    // Fog-aware: the reflected light first crosses the haze between the reflected object and
    // the water; final's fog then adds the camera-to-water part, so far reflected mountains
    // ghost out like the real ones (exact for uniform fog, close for the height profile).
    // Reflected clouds carry their own haze from gbuffers_clouds and are left alone.
    bool hitIsCloud = false;
#ifdef AMBIENCE_CLOUDS
    vec4 hitInfo = texture(colortex1, clamp(reflectUV, vec2(0.0), vec2(1.0)));
    hitIsCloud = hitInfo.a > 0.5 && hitInfo.r < 0.5;
#endif
    if (valid > 0.0 && !hitIsCloud && atmosOverworld > 0.5) {
        float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
        float segmentT = ambienceSegmentTransmittance(distance(hit, surface), cameraY + surface.y, cameraY + hit.y);
        AmbPalette waterPalette = finalWaterPalette();
        vec3 segmentColor = ambienceFogNear(reflectDir, vSunWorld, waterPalette.fogNear, waterPalette.glow) * mix(0.25, 1.0, ambienceCaveLight());
        environment = mix(segmentColor, environment, segmentT);
        reflectionFog = 1.0 - segmentT;
    }
#endif
    // Rain roughens the reflection (lower contrast); at night it is cooler like Tier 1.
    environment = mix(environment, vec3(ambLuma(environment)), 0.25 * weather);
    environment *= mix(vec3(1.0), vec3(0.80, 0.88, 1.05), 1.0 - smoothstep(-0.20, 0.05, vSunWorld.y));
#ifdef AMBIENCE_DEBUG
    gDebugReflectionFog = reflectionFog;
    gDebugReflectionValid = valid;
#endif
#endif
    environment = mix(environment, skyTier1, 0.20 + 0.35 * weather);
#ifdef AMBIENCE_DEBUG
    gDebugReflectionColor = mix(skyTier1, environment, valid);
#endif

#ifdef REFLECTION_DEBUG
#if REFLECTION_DEBUG_MODE == 5
    debugInfo = vec4(clamp(reflectUV, vec2(0.0), vec2(1.0)), 0.0, valid);
#else
    debugInfo = vec4(environment * valid, valid);
#endif
#endif
    return weight * valid * (environment - skyTier1);
}
#endif

#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(ATMOS_DEBUG)
float evaluateFogFactor(float viewDistance, float worldY) {
    float heightAboveSea = max(worldY - 63.0, 0.0);
    float heightFactor = 1.0 / (1.0 + heightAboveSea * HAZE_HEIGHT_FALLOFF);
    float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
    float weatherDensity = 1.0 + rainStrength * 0.22 + thunderStrength * 0.38 + twilight * 0.20 + night * 0.10;
    float biomeFogScale = mix(0.80, 1.20, clamp(fogDensity, 0.0, 1.0));
    float dimensionFogScale = mix(1.0, 0.55, clamp(atmosNether, 0.0, 1.0));
    dimensionFogScale = mix(dimensionFogScale, 0.30, clamp(atmosEnd, 0.0, 1.0));
    return 1.0 - exp(-viewDistance * HAZE_DENSITY * heightFactor * weatherDensity * biomeFogScale * dimensionFogScale);
}
#endif

#ifdef PROCEDURAL_STARS
float evaluateProceduralStars(vec3 worldDirection) {
    float nightFade = 1.0 - smoothstep(-0.22, 0.06, vSunElevation);
    float weatherFade = (1.0 - clamp(rainStrength, 0.0, 1.0)) *
                        (1.0 - clamp(thunderStrength, 0.0, 1.0) * 0.95);
    float moonBrightness = abs(4.0 - float(moonPhase)) * 0.25;
    float moonFade = 1.0 - moonBrightness * 0.28;
    float upperSky = smoothstep(-0.04, 0.10, worldDirection.y);
    float starGridScale;
#if SKY_QUALITY == 1
    starGridScale = 58.0;
#else
    starGridScale = 104.0;
#endif
    vec2 projected = worldDirection.xz / max(abs(worldDirection.y), 0.08) * starGridScale;
    vec2 cell = floor(projected);
    vec2 localPoint = fract(projected) - 0.5;
    float cellHash = cheapHash(cell);
    float star = step(1.0 - STAR_AMOUNT * 0.045, cellHash);
    float pixel = 1.0 - smoothstep(0.025, 0.11, length(localPoint));
    float twinkle = 0.68 + 0.32 * cheapHash(cell + vec2(floor(frameTimeCounter * 1.3), 29.0));
    return star * pixel * twinkle * nightFade * weatherFade * moonFade * upperSky * atmosOverworld;
}
#endif

void main() {
#if defined(LIGHT_DEBUG) && (LIGHT_DEBUG_MODE == 7 || LIGHT_DEBUG_MODE == 9 || LIGHT_DEBUG_MODE == 10 || LIGHT_DEBUG_MODE == 13 || LIGHT_DEBUG_MODE == 15 || LIGHT_DEBUG_MODE == 16 || LIGHT_DEBUG_MODE == 17)
    // Values written by the terrain program into its colour, shown without fog or grading.
    gl_FragColor = vec4(texture(colortex0, vTexCoord).rgb, 1.0);
    return;
#endif
#ifdef TARGET_DEBUG
    float targetDebugSun = 0.0;
    vec3 targetDebugSky = vec3(0.0);
    float targetDebugFog = 0.0;
    float targetDebugPhase = 0.0;
    vec3 targetDebugBeforeGrade = vec3(0.0);
    vec3 targetDebugAfterGrade = vec3(0.0);
#endif
#ifdef VV_DEBUG
#if VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 2 || VV_DEBUG_MODE == 5 || VV_DEBUG_MODE == 9
    vec3 quarterDebug = texture(colortex5, vTexCoord).rgb;
#if VV_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(quarterDebug.r), 1.0);
#else
    gl_FragColor = vec4(quarterDebug, 1.0);
#endif
#elif VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex2, vTexCoord).rgb, 1.0);
#elif VV_DEBUG_MODE == 8
    gl_FragColor = vec4(vec3(texture(colortex1, vTexCoord).r), 1.0);
#elif VV_DEBUG_MODE == 3
    float debugDepth = texture(depthtex0, vTexCoord).r;
    if (debugDepth < 0.99999) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, debugDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
#elif VV_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), 1.0);
#else
    gl_FragColor = vec4(1.0, 0.0, 1.0, 1.0);
#endif
    return;
#endif

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 1 || ATMOS_DEBUG_MODE == 2 || ATMOS_DEBUG_MODE == 6
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
    return;
#endif
#elif defined(CAUSTICS_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10) || (defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE != 3 && REFLECTION_DEBUG_MODE != 4 && REFLECTION_DEBUG_MODE != 5 && REFLECTION_DEBUG_MODE != 12)
    // Raw diagnostic written by the water/terrain programs, shown without grading.
    gl_FragColor = vec4(texture(colortex1, vTexCoord).rgb, 1.0);
    return;
#endif

    vec4 scene = texture(colortex0, vTexCoord);
    vec3 color = scene.rgb;

#ifdef WATER_SSR
    // Swap the Tier-1 sky colour baked into the water for the reflected environment, before
    // haze and grading so the reflection is fogged by the water's own distance.
    vec4 reflectionDebug;
    vec3 screenReflection = waterScreenReflection(vTexCoord, reflectionDebug);
#if defined(AMBIENCE_DEBUG) && AMBIENCE_DEBUG_MODE == 14
    // Split view: left half without the screen-space reflection, right half with it.
    if (vTexCoord.x < 0.5) screenReflection = vec3(0.0);
#endif
    color += screenReflection;
#if defined(REFLECTION_DEBUG) && (REFLECTION_DEBUG_MODE == 3 || REFLECTION_DEBUG_MODE == 4 || REFLECTION_DEBUG_MODE == 5)
#if REFLECTION_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(reflectionDebug.a), 1.0);
#else
    gl_FragColor = vec4(reflectionDebug.rgb, 1.0);
#endif
    return;
#endif
#endif

    float sceneDepth = texture(depthtex0, vTexCoord).r;

    // What is this pixel? Clouds carry their own haze and are composed over the palette sky
    // in display colours, so they get neither the fog nor the tone curve here; water uses the
    // Ambience fog unless FOG_ON_WATER is off.
    bool cloudPixel = false;
    bool waterPixel = false;
#ifdef AMB_FINAL_INFO
    vec4 ambienceInfo = texture(colortex1, vTexCoord);
    waterPixel = ambienceInfo.r > 0.5;
#ifdef AMB_CLOUD_MARKER
    cloudPixel = ambienceInfo.a > 0.5 && !waterPixel;
#endif
#endif
    bool skyPixel = sceneDepth > 0.99999 && !cloudPixel;
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;
    float moonBrightness = ambMoonBrightness(moonPhase);

    // Bloom, shallow-water shafts and pollen from the quarter-resolution pass.
    vec3 auxiliary = vec3(0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES)
    auxiliary = texture(colortex5, vTexCoord).rgb;
    color += auxiliary;
#endif

#ifdef ATMOS_TONE_MAP
    bool displayReferred = false;
#ifdef AMBIENCE_COLORS
    displayReferred = overworld > 0.5 && isEyeInWater == 0 && (skyPixel || cloudPixel);
#endif
    if (!displayReferred) color = finalToneMap(color, overworld);
#endif

    if (skyPixel && isEyeInWater == 0) {
        vec3 worldDirection = worldViewRay(vTexCoord);
#ifdef AMBIENCE_COLORS
        if (overworld > 0.5) {
            // The sky is rebuilt from the same function gbuffers_skybasic used, so the sun, its
            // glow and the gradient are exact and smooth. What vanilla drew on top of that sky
            // (moon and stars; the vanilla sun is disabled) is the positive difference; below
            // the sky disc's rim (about 2 degrees) colortex0 holds the vanilla clear colour, so
            // that band takes nothing from it.
#ifdef MOON_RAYS
            vec3 skyNow = ambienceSkyFullMoon(worldDirection, vSunWorld, finalPalette(), finalMoon(), finalPixelAngle());
#else
            vec3 skyNow = ambienceSkyFull(worldDirection, vSunWorld, finalPalette(), moonBrightness, finalPixelAngle());
#endif
            vec3 celestial = max(scene.rgb - skyNow - vec3(0.004), vec3(0.0)) * smoothstep(0.035, 0.07, worldDirection.y);
            color = skyNow + celestial + auxiliary;
#ifdef TARGET_DEBUG
            targetDebugSky = skyNow;
#endif
        } else
#endif
        {
        // Previous sky treatment (Ambience colours off, or the Nether and the End).
        vec3 skyGradient = skyColor;
#ifdef SKY_GRADE
        skyGradient = evaluateSkyGradient(worldDirection);
        float dimensionWeight = clamp(atmosOverworld + atmosNether + atmosEnd, 0.0, 1.0);
        color += (skyGradient - skyColor) * SKY_GRADIENT_STRENGTH * dimensionWeight;
        float dither = (cheapHash(floor(gl_FragCoord.xy)) - 0.5) * (0.75 / 255.0);
        color += vec3(dither * SKY_GRADIENT_STRENGTH);
#endif

#ifdef GOLDEN_TARGET_SKY
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(vSunElevation));
        float daySide = smoothstep(-0.16, -0.005, vSunElevation);
        float targetSkyWeather = clamp(1.0 - rainStrength * 0.58 - thunderStrength * 0.32, 0.0, 1.0);
        float warmBiomeSky = clamp(max(atmosSavannaBiome * 0.55, atmosWoodlandBiome * 0.24), 0.0, 1.0);
        float warmSkyMask = max(twilightSky * daySide, warmBiomeSky * (1.0 - smoothstep(-0.10, 0.18, vSunElevation)));
        warmSkyMask *= targetSkyWeather * atmosOverworld;
        float skyHorizonMix = 1.0 - smoothstep(0.015, 0.90, max(worldDirection.y, 0.0));
        vec3 goldenZenith = vec3(0.46, 0.37, 0.27);
        vec3 goldenHorizon = vec3(1.00, 0.72, 0.39);
        vec3 goldenSky = mix(goldenZenith, goldenHorizon, skyHorizonMix);
        color = mix(color, goldenSky, targetMatch * warmSkyMask * GOLDEN_SKY_TINT_STRENGTH);
#ifdef TARGET_DEBUG
        targetDebugSky = goldenSky;
#endif
#endif

#ifdef SUN_GLOW
        // The new analytic glow around the vanilla sun (drawn by vanilla on this path), kept
        // off the square itself so its centre is never overwritten.
        if (overworld > 0.5) {
            AmbGlow legacyGlow = ambCelestialGlow(worldDirection, vSunWorld, moonBrightness);
            float outside = 1.0 - ambSunDisc(worldDirection, vSunWorld, finalPixelAngle()).a;
            color = mix(color, ambSunGlowColor(vSunWorld), clamp(legacyGlow.core + legacyGlow.mid, 0.0, 0.92) * outside);
#ifndef MOON_RAYS
            color = mix(color, vec3(0.78, 0.86, 1.00), clamp(legacyGlow.moon, 0.0, 0.60));
#endif
        }
#endif
#ifdef MOON_RAYS
        // The moon's glow and halo around the vanilla moon (never on its disc).
        if (overworld > 0.5) color = ambMoonGlowApply(color, worldDirection, finalMoon(), finalPixelAngle());
#endif
        }

#if defined(TARGET_DEBUG) && defined(SUN_GLOW)
        AmbGlow targetGlow = ambCelestialGlow(worldDirection, vSunWorld, moonBrightness);
        targetDebugSun = clamp(targetGlow.core + targetGlow.mid, 0.0, 1.0);
#endif

#ifdef PROCEDURAL_STARS
        float stars = evaluateProceduralStars(worldDirection);
#ifdef MOON_RAYS
        // Stars inside the moon's glow fade softly (the vanilla stars do the same in the sky pass).
        stars *= ambMoonStarDimming(worldDirection, finalMoon());
#endif
        color += vec3(0.72, 0.84, 1.0) * stars * 0.22;
#endif

#ifdef GOLDEN_FAKE_BIRDS
        float birdMatch = float(MATCH_STRENGTH) * 0.01;
        float birdTime = frameTimeCounter * FAKE_BIRD_SPEED;
        float birdDay = smoothstep(-0.10, 0.12, vSunElevation) *
                        clamp(1.0 - rainStrength * 0.90 - thunderStrength * 0.40, 0.0, 1.0);
        if (birdDay * birdMatch * FAKE_BIRD_AMOUNT > 0.001) {
            vec2 birdScreen = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
            float birdCell = max(float(FAKE_BIRD_SIZE), 1.0);
            vec2 birdPixelUV = (floor(vTexCoord * birdScreen / birdCell) + 0.5) * birdCell / birdScreen;
            float birds = targetBirdMask(birdPixelUV, vec2(fract(0.16 + birdTime), 0.84));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.49 + birdTime * 0.78), 0.78));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.76 + birdTime * 1.12), 0.88));
            color = mix(color, vec3(0.13, 0.10, 0.075), clamp(birds * FAKE_BIRD_AMOUNT * birdDay * birdMatch, 0.0, 0.82));
        }
#endif
    }

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 3
    if (sceneDepth < 0.99999 && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
    return;
#elif ATMOS_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(max(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), vec3(0.0)), 1.0);
    return;
#elif ATMOS_DEBUG_MODE == 5
    vec3 debugSkyDirection = worldViewRay(vTexCoord);
    gl_FragColor = vec4(evaluateSkyGradient(debugSkyDirection), 1.0);
    return;
#endif
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    vec3 colorBeforeFog = color;
#endif
    // Camera-relative position of the surface (fog, veil); zero on sky pixels.
    vec3 playerPosition = vec3(0.0);
    if (!skyPixel) {
        vec4 viewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        playerPosition = (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
    }
#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(AMBIENCE_FOG)
    if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec3 worldPosition = cameraPosition + playerPosition;
        float viewDistance = length(playerPosition);
        float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
        float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
        float viewUp = playerPosition.y / max(viewDistance, 0.0001);
        vec3 hazeColor = evaluateAtmosphereColor(viewUp, twilight, night);
        float targetFogFactor = 0.0;

        bool ambienceFogHere = false;
#ifdef AMBIENCE_FOG
        ambienceFogHere = overworld > 0.5;
#ifndef FOG_ON_WATER
        if (waterPixel) ambienceFogHere = false;
#endif
#endif

        if (ambienceFogHere) {
#ifdef AMBIENCE_FOG
            // The cloud shadow on this surface darkens and cools the near haze in front of it.
            // Final cannot see the gbuffers' value (no free buffer channel), so it re-reads the
            // same cells: one fetch (quality 1) or four (quality 2), cached 256x256 texture.
            float cloudShadowHere = 1.0;
#ifdef CLOUD_SHADOW_ENABLE
            float cloudMask;
            vec2 cloudUV;
            cloudShadowHere = ambienceCloudShadow(playerPosition + vec3(0.0, 0.1, 0.0), vSunWorld, cloudMask, cloudUV);
#ifdef AMBIENCE_DEBUG
            gDebugCloudMask = cloudMask;
            gDebugCloudShadow = cloudShadowHere;
            gDebugCloudUV = cloudUV;
#endif
#endif
            AmbFog fog = ambienceFog(playerPosition, vSunWorld, finalPalette(), far, cloudShadowHere, ambienceCaveLight());
#ifdef FOG_BANDED_LOOK
            // Pixel-art option: a few fog steps, ordered-dithered so the steps do not band.
            float fogLevels = float(FOG_LEVELS);
            fog.amount = min(floor(fog.amount * fogLevels + ambBayer4(gl_FragCoord.xy)) / fogLevels, 1.0);
#endif
            color = ambienceApplyFog(color, fog);
            targetFogFactor = fog.amount;
            hazeColor = fog.color;
#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG)
            gDebugFogAmount = fog.amount;
            gDebugFogColor = fog.color;
            gDebugBank = fog.bank;
            gDebugScatter = fog.scatter;
            gDebugDesaturation = fog.desaturation;
#endif
#endif
        } else {
#ifdef ATMOSPHERIC_HAZE
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
        float distanceBlend = smoothstep(24.0, 112.0, viewDistance);
        color *= mix(vec3(1.0), vec3(0.95, 0.98, 1.035), distanceBlend * targetFogFactor * 0.45);
        float rainLumaForHaze = dot(color, vec3(0.2126, 0.7152, 0.0722));
        color = mix(color, vec3(rainLumaForHaze) * vec3(0.96, 1.0, 1.05), targetFogFactor * rainStrength * 0.10);
        color = mix(color, hazeColor, targetFogFactor);
#elif defined(GOLDEN_TARGET_HAZE)
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
#endif
        // Horizon blend: near the render distance, terrain and water fade into the colour of the
        // sky behind them (like vanilla's border fog). Overworld: the same sky function as the
        // water's Tier-1 reflection; the Nether and the End keep their vanilla-like fog colour.
        float borderFog = smoothstep(far * 0.55, far * 0.95, length(playerPosition.xz)) * HORIZON_BLEND;
        vec3 borderColor = overworld > 0.5 ? reflectionSkyBase(safeNormalize(playerPosition), vSunElevation) : hazeColor;
        color = mix(color, borderColor, borderFog);

#ifdef GOLDEN_TARGET_HAZE
        // Extra amber haze, only where the Ambience fog is off (it would break the horizon
        // match, since the sky does not get it).
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float targetWarmTime = smoothstep(-0.16, 0.07, vSunElevation) *
                               (1.0 - smoothstep(0.14, 0.54, max(vSunElevation, 0.0)));
        float savannaHaze = clamp(max(atmosSavannaBiome, atmosDesertBiome * 0.42), 0.0, 1.0);
        float warmHazeMask = max(1.0 - smoothstep(0.035, 0.34, abs(vSunElevation)), savannaHaze * targetWarmTime);
        float targetWeather = clamp(1.0 - rainStrength * 0.70 - thunderStrength * 0.35, 0.0, 1.0);
        vec2 hazeScreenDelta = (vTexCoord - vSunUV) * vec2(aspectRatio, 1.0);
        float hazePhase = 1.0 - smoothstep(0.035, 0.62, length(hazeScreenDelta));
        hazePhase *= hazePhase * vSunInFront * smoothstep(-0.10, 0.14, vSunElevation);
        vec3 goldenHazeColor = mix(hazeColor, vec3(0.99, 0.70, 0.43), warmHazeMask);
        float extraGoldenFog = targetFogFactor * GOLDEN_HAZE_STRENGTH * targetMatch * warmHazeMask * targetWeather;
        extraGoldenFog *= clamp(0.58 + hazePhase * GOLDEN_HAZE_PHASE, 0.0, 1.0);
        color = mix(color, goldenHazeColor, clamp(extraGoldenFog, 0.0, 0.72));
#ifdef TARGET_DEBUG
        targetDebugFog = clamp(targetFogFactor * warmHazeMask, 0.0, 1.0);
        targetDebugPhase = clamp(hazePhase, 0.0, 1.0);
#endif
#endif
        }
    }
#endif

#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG) || defined(BIOME_DEBUG)
    vec3 colorAfterFog = color;
#endif

#if defined(AMB_SUN_VISIBILITY) || defined(SUN_SHAFTS) || defined(AMB_MOON_VISIBILITY) || defined(MOON_SHAFTS)
    // Veil, edge rim and shafts: a light's glow over what stands in front of it (terrain and
    // clouds; never on sky pixels, which carry the analytic glow), for the sun and then the moon,
    // through the same CelestialLight functions (lib/sun_rays.glsl). The veil is analytic (angle
    // to the light) times its visibility V; the rim adds light-directed depth taps right around
    // it on faces turned to it; the shafts come from the quarter-resolution march (composite1)
    // through a depth-aware upsample. No noise, no jitter, no shadow map. The two lights are
    // opposite, so at most one is on screen: the per-pixel work never doubles; the shafts have
    // one buffer and belong to one source per frame.
    if (!skyPixel && overworld > 0.5 && isEyeInWater == 0) {
        vec3 viewDirection = worldViewRay(vTexCoord);
        float eyeSky = smoothstep(0.10, 0.45, float(eyeBrightnessSmooth.y) / 240.0);
        float depthFactor = 1.0 - exp(-length(playerPosition) / 6.0);
#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
        gMoonDebugSunBefore = color;
        gMoonDebugTerrain = 1.0;
#endif
#if defined(AMB_SUN_VISIBILITY) || defined(SUN_SHAFTS)
        {
            // The sun: faint shafts and the rim are low by default, strongest near the sun, gone
            // off screen, behind the camera, below the horizon, in rain, indoors and underwater.
            CelestialLight sun = finalSunLight(eyeSky);
            float theta = ambAngle(viewDirection, sun.direction);
#ifdef SUN_VEIL
            float veil;
            color = celestialVeil(color, sun, theta, depthFactor, veil);
#ifdef SUN_DEBUG
            gDebugVeil = veil;
#endif
#endif
#ifdef SUN_EDGE_RIM
            // Which edges face the sun is decided by the taps (open sky toward the sun on screen:
            // no rim on edges turned away); the normal weights the rim (65 % on backlit faces,
            // which carry the reference's rim when the camera looks up at the sun).
            float rim;
            color = celestialRim(color, sun, theta, playerPosition, sceneDepth, cloudPixel, vTexCoord, rim);
            if (rim > 0.0) {
#ifdef SUN_DEBUG
                gDebugRim = rim;
#endif
#ifdef LIGHT_DEBUG
                gLightDebugRim = rim;
#endif
            }
#endif
#ifdef SUN_SHAFTS
            float shaft;
            color = celestialShafts(color, sun, theta, sceneDepth, vTexCoord, shaft);
#ifdef LIGHT_DEBUG
            if (shaft > 0.0) gLightDebugShaft = shaft;
#endif
#endif
        }
#endif
#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
        gMoonDebugSunAfter = color;
#endif
#ifdef MOON_RAYS
        // The moon, only while it has light (night, above the horizon, not rained out).
        if (vMoonWorldLight.w > 0.0) {
#ifdef MOON_DEBUG
            gMoonDebugRaysBefore = color;
#endif
            CelestialLight moon = finalMoonLight(eyeSky);
            float moonTheta = ambAngle(viewDirection, moon.direction);
#ifdef MOON_VEIL
            float moonVeil;
            color = celestialVeil(color, moon, moonTheta, depthFactor, moonVeil);
#ifdef MOON_DEBUG
            gMoonDebugVeil = moonVeil;
#endif
#endif
#ifdef MOON_EDGE_RIM
            float moonRim;
            color = celestialRim(color, moon, moonTheta, playerPosition, sceneDepth, cloudPixel, vTexCoord, moonRim);
#ifdef MOON_DEBUG
            gMoonDebugRim = moonRim;
#endif
#endif
#ifdef MOON_SHAFTS
            float moonShaft;
            color = celestialShafts(color, moon, moonTheta, sceneDepth, vTexCoord, moonShaft);
#ifdef MOON_DEBUG
            gMoonDebugShaft = moonShaft;
#endif
#endif
#ifdef MOON_DEBUG
            gMoonDebugRaysAfter = color;
#endif
        }
#endif
    }
#endif

#ifdef TARGET_DEBUG
    targetDebugBeforeGrade = color;
#endif

#ifdef GOLDEN_TARGET_GRADE
    float targetMatch = float(MATCH_STRENGTH) * 0.01;
    float goldenHour = (1.0 - smoothstep(0.035, 0.34, abs(vSunElevation))) *
                       smoothstep(-0.16, 0.045, vSunElevation);
    float warmRegion = clamp(max(atmosSavannaBiome * 0.52, atmosDesertBiome * 0.20), 0.0, 1.0);
    float goldenGradeMask = max(goldenHour, warmRegion * (1.0 - smoothstep(0.18, 0.52, max(vSunElevation, 0.0))));
    goldenGradeMask *= overworld * clamp(1.0 - rainStrength * 0.42 - thunderStrength * 0.30, 0.0, 1.0);
    vec3 gradeLumaColor = vec3(dot(color, vec3(0.2126, 0.7152, 0.0722)));
    vec3 goldenTint = vec3(1.00, 0.91, 0.77);
    color *= mix(vec3(1.0), goldenTint, goldenGradeMask * GOLDEN_GRADE_STRENGTH * targetMatch);
    float darkSurface = 1.0 - smoothstep(0.06, 0.44, dot(color, vec3(0.2126, 0.7152, 0.0722)));
    color += vec3(1.0, 0.57, 0.28) * darkSurface * goldenGradeMask * GOLDEN_SHADOW_LIFT * targetMatch;
    color = mix(color, max(gradeLumaColor, vec3(0.0)), rainStrength * targetMatch * 0.025 * overworld);
#endif

#ifdef TARGET_DEBUG
    targetDebugAfterGrade = color;
#endif

#ifdef ATMOSPHERIC_GRADE
    // Restrained green vibrance with a 0..1 saturation safety clamp.
    float greenChroma = color.g - max(color.r, color.b);
    float greenMask = smoothstep(0.015, 0.18, greenChroma) * overworld * (1.0 - rainStrength * 0.35);
    vec3 safeColor = clamp(color, vec3(0.0), vec3(1.0));
    float safeLuma = dot(safeColor, vec3(0.2126, 0.7152, 0.0722));
    vec3 vibrantColor = clamp(mix(vec3(safeLuma), safeColor, 1.0 + VIBRANCE_STRENGTH), vec3(0.0), vec3(1.0));
    color = mix(color, vibrantColor, greenMask);
#endif

#ifdef ATMOSPHERIC_GRADE
    float rainLuma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float stormDesaturation = rainStrength * 0.11 + thunderStrength * 0.08;
    color = mix(color, vec3(rainLuma) * vec3(0.96, 1.00, 1.05), stormDesaturation * overworld);
#endif

#if defined(ATMOS_VIGNETTE) || defined(GOLDEN_SOFT_VIGNETTE)
    vec2 vignettePos = (vTexCoord - vec2(0.5)) * vec2(aspectRatio, 1.0);
    float vignette = smoothstep(0.12, 0.72, dot(vignettePos, vignettePos));
    float vignetteStrength = 0.0;
#ifdef ATMOS_VIGNETTE
    vignetteStrength += VIGNETTE_STRENGTH;
#endif
#ifdef GOLDEN_SOFT_VIGNETTE
    vignetteStrength += GOLDEN_VIGNETTE_STRENGTH * float(MATCH_STRENGTH) * 0.01;
#endif
    color *= 1.0 - vignette * vignetteStrength * overworld;
#endif

#ifdef TARGET_DEBUG
#if TARGET_DEBUG_MODE == 1
    gl_FragColor = vec4(vec3(targetDebugSun), 1.0);
#elif TARGET_DEBUG_MODE == 2
    // The pixelated golden glow was removed.
    gl_FragColor = vec4(vec3(0.0), 1.0);
#elif TARGET_DEBUG_MODE == 3
    gl_FragColor = vec4(max(targetDebugSky, vec3(0.0)), 1.0);
#elif TARGET_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(targetDebugFog), 1.0);
#elif TARGET_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(targetDebugPhase), 1.0);
#elif TARGET_DEBUG_MODE == 6
    gl_FragColor = vec4(vec3(texture(colortex5, vTexCoord).r), 1.0);
#elif TARGET_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
#else
    gl_FragColor = vec4(vTexCoord.x < 0.5 ? targetDebugBeforeGrade : targetDebugAfterGrade, 1.0);
#endif
    return;
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    // Left half: before haze, horizon blend and grading; right half: the normal result.
    if (vTexCoord.x < 0.5) color = colorBeforeFog;
#endif

#ifdef AMBIENCE_DEBUG
    {
        // Ambience diagnostics; the expected look of each view is listed in the README.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
#if AMBIENCE_DEBUG_MODE == 1
        debugOut = vec3(gDebugFogAmount);
#elif AMBIENCE_DEBUG_MODE == 2
        debugOut = gDebugFogColor;
#elif AMBIENCE_DEBUG_MODE == 3
        debugOut = vec3(clamp(gDebugBank * 0.5, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 4
        float debugHalo;
        float debugScatter;
        ambienceSkyTerms(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden, debugHalo, debugScatter);
        debugOut = vec3(clamp(debugScatter, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 5
        debugOut = vec3(gDebugDesaturation);
#elif AMBIENCE_DEBUG_MODE == 6
        debugOut = vec3(gDebugCloudMask);
#elif AMBIENCE_DEBUG_MODE == 7
        debugOut = vec3(gDebugCloudShadow);
#elif AMBIENCE_DEBUG_MODE == 8
        debugOut = vec3(gDebugCloudUV, 0.0);
#elif AMBIENCE_DEBUG_MODE == 9
        debugOut = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
#elif AMBIENCE_DEBUG_MODE == 10
        // Terrain that should have dissolved into the sky (last 15 % before the fog end) minus
        // the sky colour behind it, x8. Expected: black everywhere.
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif AMBIENCE_DEBUG_MODE == 11
        debugOut = gDebugReflectionColor;
#elif AMBIENCE_DEBUG_MODE == 12
        debugOut = vec3(gDebugReflectionValid);
#elif AMBIENCE_DEBUG_MODE == 13
        debugOut = vec3(gDebugReflectionFog);
#elif AMBIENCE_DEBUG_MODE == 14 || AMBIENCE_DEBUG_MODE == 15
        // Split views (left without, right with); the line marks the split.
        if (abs(vTexCoord.x - 0.5) < 0.75 / viewWidth) debugOut = vec3(1.0);
#elif AMBIENCE_DEBUG_MODE == 16
        // Cloud alignment: on cloud pixels, green if the vanilla cell at that point is filled
        // (shadows and reflections use the same cells), red if it is empty. Expected: all green.
        debugOut = color * 0.35;
#if defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT)
        vec4 debugInfo = texture(colortex1, vTexCoord);
        if (sceneDepth < 0.99999 && debugInfo.a > 0.5 && debugInfo.r < 0.5) {
            vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
            vec3 debugPlayer = (gbufferModelViewInverse * vec4(debugViewH.xyz / max(debugViewH.w, 0.0001), 1.0)).xyz;
            vec3 debugWorld = ambWrappedWorld(debugPlayer - debugDir * 0.05);
            vec2 debugCell = floor(vec2(debugWorld.x + mod(cloudTime, ambCloudPeriod()), debugWorld.z + AMB_CLOUD_Z_OFFSET) / AMB_CLOUD_CELL);
            debugOut = ambCloudCell(debugCell) > 0.5 ? vec3(0.1, 0.9, 0.2) : vec3(0.95, 0.1, 0.1);
        }
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef SUN_DEBUG
    {
        // Sun, sky and fog diagnostics; the expected look of each view is in the README (v5).
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        AmbGlow debugGlow = ambCelestialGlow(debugDir, vSunWorld, moonBrightness);
        float debugHalo;
        float debugScatter;
        ambienceSkyTerms(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden, debugHalo, debugScatter);
#if SUN_DEBUG_MODE == 1
        // Angle to the sun: a smooth radial gradient, black at the sun.
        debugOut = vec3(ambAngle(debugDir, vSunWorld) / 3.14159265);
#elif SUN_DEBUG_MODE == 2
        debugOut = vec3(debugGlow.core);
#elif SUN_DEBUG_MODE == 3
        debugOut = vec3(debugGlow.mid);
#elif SUN_DEBUG_MODE == 4
        debugOut = vec3(debugHalo / max(SUN_HALO_STRENGTH, 0.001));
#elif SUN_DEBUG_MODE == 5
        // Ray lobes: mid grey = no modulation; soft light and dark wedges around the sun.
        debugOut = vec3(0.5 + 0.5 * (debugGlow.rays - 1.0) / max(RAY_VARIATION, 0.001));
#elif SUN_DEBUG_MODE == 6
        // Sun visibility V as a full-screen tint: it changes smoothly as a block covers the sun.
        debugOut = mix(color * 0.25, vec3(1.0, 0.85, 0.3), vSunVisibility * vSunScreenFade * 0.75);
#elif SUN_DEBUG_MODE == 7
        debugOut = vec3(gDebugVeil);
#elif SUN_DEBUG_MODE == 8
        debugOut = vec3(gDebugRim);
#elif SUN_DEBUG_MODE == 9
        debugOut = ambSkyGradient(debugDir, vPalZenith, vPalMid, vPalHorizon);
#elif SUN_DEBUG_MODE == 10
        // Terrain in the last 15 % before the fog end minus the sky behind it, x8: black.
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif SUN_DEBUG_MODE == 11
        // Cloud terms are written by gbuffers_clouds (red top, green side, blue underside).
        debugOut = cloudPixel ? scene.rgb : color * 0.3;
#elif SUN_DEBUG_MODE == 12
        debugOut = vec3(gDebugFogAmount);
#elif SUN_DEBUG_MODE == 13
        debugOut = vec3(clamp(debugScatter, 0.0, 1.0));
#elif SUN_DEBUG_MODE == 14
        // Fog banks: mid grey = average density, smooth large patches, no grain.
        debugOut = vec3(clamp(0.5 + (gDebugBank - 1.0) / max(2.0 * FOG_BANK_STRENGTH, 0.001), 0.0, 1.0));
#elif SUN_DEBUG_MODE == 15
        // The dither, amplified x16: a fine, even, static grain.
        debugOut = vec3(0.5 + ambDither(gl_FragCoord.xy) * SKY_DITHER / 255.0 * 16.0);
#elif SUN_DEBUG_MODE == 16
        // Banding test: each 8-bit step of the final colour becomes a visible stripe. Wide
        // clean stripes = banding; with the dither the stripes dissolve into a fine grain.
        vec3 codes = floor(clamp(color + ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0), 0.0, 1.0) * 255.0 + 0.5);
        debugOut = mod(codes, 4.0) / 3.0;
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef BIOME_DEBUG
    {
        // Biome ambience diagnostics; the expected look of each view is in the README (v6).
        vec3 debugOut = color * 0.6;
        vec2 uv = vTexCoord;
        // Normalised family weights (0 = base), from the CPU blend or the forced family.
        float w[17];
#if FORCE_BIOME_PREVIEW > 0
        for (int i = 0; i < 17; ++i) w[i] = (i == FORCE_BIOME_PREVIEW) ? 1.0 : 0.0;
#else
        w[0] = bfBase;
        w[1] = bfOcean * bfScale;
        w[2] = bfWarmOcean * bfScale;
        w[3] = bfSnowy * bfScale;
        w[4] = bfPlains * bfScale;
        w[5] = bfForest * bfScale;
        w[6] = bfDarkForest * bfScale;
        w[7] = bfTaiga * bfScale;
        w[8] = bfJungle * bfScale;
        w[9] = bfSwamp * bfScale;
        w[10] = bfDesert * bfScale;
        w[11] = bfSavanna * bfScale;
        w[12] = bfBadlands * bfScale;
        w[13] = bfWindswept * bfScale;
        w[14] = bfPeaks * bfScale;
        w[15] = bfCherry * bfScale;
        w[16] = bfMushroom * bfScale;
#endif
        float pixel = 1.0 / viewWidth;
        // Stacked weight bar along the top of the screen (used by views 1 and 5): each family's
        // horizon colour, as wide as its weight, black separators; red at the right end would
        // mean the weights do not add up to 1.
        vec3 bar = vec3(1.0, 0.0, 0.0);
        float acc = 0.0;
        for (int i = 0; i < 17; ++i) {
            if (uv.x >= acc && uv.x < acc + w[i]) bar = AMB_BIOME_HORIZON[i];
            if (w[i] > 0.002 && abs(uv.x - acc) < pixel) bar = vec3(0.0);
            acc += w[i];
        }
        float maxWeight = 0.0;
        for (int i = 0; i < 17; ++i) maxWeight = max(maxWeight, w[i]);
        AmbBiome biomeNow = ambBiome();
#if BIOME_DEBUG_MODE == 1
        if (uv.y > 0.92) debugOut = bar;
#elif BIOME_DEBUG_MODE == 2
        // Swatches of this frame's palette: zenith, mid, horizon = fog, cloud top, cloud
        // underside, Nether tint.
        if (uv.y > 0.80) {
            int slot = int(uv.x * 6.0);
            debugOut = slot == 0 ? vPalZenith : slot == 1 ? vPalMid : slot == 2 ? vPalHorizon :
                       slot == 3 ? vPalCloudTop : slot == 4 ? vPalCloudUnder : ambNetherFogTint();
        }
#elif BIOME_DEBUG_MODE == 3
        // Terrain in the last 15 % before the fog end minus the sky behind it, x8: black in
        // every biome (the fog colour is the sky function).
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(worldViewRay(uv), vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif BIOME_DEBUG_MODE == 4
        // Effective fog density multiplier as grey (0.5 = x1.0), the dust layer in red.
        float character = BIOME_DENSITY_MULTIPLIER_STRENGTH * biomeNow.strength;
        float densityNow = mix(1.0, clamp(biomeNow.density, 0.5, 1.6), character);
        debugOut = vec3(0.5 * densityNow);
#ifdef BIOME_DESERT_DUST
        debugOut.r += 0.5 * biomeNow.dust * character;
#endif
#elif BIOME_DEBUG_MODE == 5
        // Transition: grey = the largest family weight (1 = settled); it moves smoothly while
        // the camera crosses a border. The weight bar is on top.
        debugOut = vec3(maxWeight);
        if (uv.y > 0.92) debugOut = bar;
#elif BIOME_DEBUG_MODE == 6
        // Palette table: 17 columns (family 0-16), horizon colour above, zenith below, cloud
        // tint in the middle band; the current or forced family gets a white frame.
        int column = clamp(int(uv.x * 17.0), 0, 16);
        debugOut = uv.y > 0.55 ? AMB_BIOME_HORIZON[column] : (uv.y > 0.45 ? AMB_BIOME_CLOUD[column] : AMB_BIOME_ZENITH[column]);
        float cell = fract(uv.x * 17.0);
        if (w[column] >= maxWeight - 1.0e-4 && (cell < 0.04 || cell > 0.96)) debugOut = vec3(1.0);
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef LIGHT_DEBUG
    {
        // Update-1 diagnostics (sun rays, cloud occlusion, underwater caustics); the expected
        // look of each view is in the README. Views 7, 9, 10, 13, 15-17 are written by the
        // terrain program and returned at the top of main; view 8 is a split of the normal image.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        float debugCameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
#if LIGHT_DEBUG_MODE == 1
        // Sun visibility V (yellow) and the share of the sun behind clouds (blue), full screen:
        // both change smoothly while an edge crosses the sun.
        debugOut = color * 0.25 + vec3(1.0, 0.85, 0.3) * (vSunVisibility * vSunScreenFade * 0.75) +
                   vec3(0.2, 0.4, 1.0) * (vSunCloudCover * 0.75);
#elif LIGHT_DEBUG_MODE == 2
        // Open-sky mask of the shafts (quarter resolution, linear filtering): soft edges, no grain.
        debugOut = vec3(texture(colortex5, vTexCoord).a);
#elif LIGHT_DEBUG_MODE == 3
        // Rim alone: thin light only on silhouette edges turned to the sun, right around it.
        debugOut = vec3(gLightDebugRim);
#elif LIGHT_DEBUG_MODE == 4
        // Shafts alone (x4): faint streaks from gaps, fading with the angle to the sun.
        debugOut = vec3(gLightDebugShaft * 4.0);
#elif LIGHT_DEBUG_MODE == 5
        // Clouds: red = marker opacity (1 = hides the sun), green = linear depth / (4 x render
        // distance), black elsewhere.
        debugOut = vec3(0.0);
#ifdef AMB_CLOUD_MARKER
        if (cloudPixel) debugOut = vec3(ambienceInfo.g, clamp(raysLinearDepth(sceneDepth) / (4.0 * far), 0.0, 1.0), 0.0);
#endif
#elif LIGHT_DEBUG_MODE == 6
        // Hidden by clouds: cloud pixels in front of the sun square red, in front of the moon
        // blue, at night cyan (stars behind them hidden); other clouds grey; the sky dimmed.
        debugOut = color * 0.25;
        if (cloudPixel) {
            debugOut = vec3(0.30);
            vec4 sunBehind = ambSunDisc(debugDir, vSunWorld, finalPixelAngle());
            vec3 moonPlane = ambCelestialPlane(debugDir, -vSunWorld);
            bool moonBehind = moonPlane.z > 0.0 && max(abs(moonPlane.x), abs(moonPlane.y)) < AMB_MOON_HALF;
            if (vSunElevation < -0.10) debugOut = vec3(0.0, 0.55, 0.60);
            if (moonBehind) debugOut = vec3(0.15, 0.35, 1.0);
            if (sunBehind.a > 0.0) debugOut = vec3(1.0, 0.15, 0.10);
        }
#elif LIGHT_DEBUG_MODE == 11
        // Camera in water: blue full screen (black above water); the bar on top is the surface
        // fade (it ramps up over the first 0.4 blocks below the surface).
        debugOut = isEyeInWater == 1 ? vec3(0.0, 0.45, 0.85) : vec3(0.0);
#ifdef CAUSTICS_UNDERWATER_FLOOR
        if (vTexCoord.y > 0.95) debugOut = vec3(smoothstep(0.05, 0.40, vclWaterSurfaceY - debugCameraY) * float(isEyeInWater == 1));
#endif
#elif LIGHT_DEBUG_MODE == 12
        // Estimated camera depth below the surface: grey = depth / 16 blocks; red above water.
        debugOut = vec3(1.0, 0.0, 0.0);
#ifdef CAUSTICS_UNDERWATER_FLOOR
        if (isEyeInWater == 1) debugOut = vec3(clamp((vclWaterSurfaceY - debugCameraY) / 16.0, 0.0, 1.0));
#endif
#elif LIGHT_DEBUG_MODE == 14
        // Water surface in front of the pixel (seen from below with the camera underwater):
        // white = surface, where underwater caustics must never appear.
        debugOut = color * 0.2;
#ifdef AMB_FINAL_INFO
        if (waterPixel) debugOut = isEyeInWater == 1 ? vec3(1.0) : vec3(0.35, 0.35, 0.5);
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef MOON_DEBUG
    {
        // Update-2A diagnostics (moon light, sun/moon handover, sun identity); the expected look
        // of each view is in the README.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        AmbMoon dMoon = finalMoon();
        float dPixelAngle = finalPixelAngle();
        vec3 dPlane = ambCelestialPlane(debugDir, dMoon.dir);
        float dSquare = dPlane.z > 0.0 ? max(abs(dPlane.x), abs(dPlane.y)) : 10.0;
#if MOON_DEBUG_MODE == 1
        // Ray weights over a whole day: x = sun altitude from -90 (left) to +90 degrees (right),
        // y = weight 0 (10 % from the bottom) to 1 (10 % from the top); yellow = the sun's
        // (veil, rim, shafts), blue = the moon's (this phase and weather, moon opposite the sun),
        // white line = now. Both curves are smooth; they overlap only a little, near 0 degrees.
        float sunAltitude = (vTexCoord.x * 2.0 - 1.0) * 1.5707963;
        vec3 sunD = vec3(cos(sunAltitude), sin(sunAltitude), 0.0);
        float y = (vTexCoord.y - 0.1) / 0.8;
        float sunCurve = y - ambSunGlowVisibility(sunD);
        float moonCurve = y - clamp(ambMoonLight(-sunD, sunD, moonPhase), 0.0, 1.0);
        debugOut = color * 0.25;
        if (abs(y) * 0.8 * viewHeight < 1.0 || abs(y - 1.0) * 0.8 * viewHeight < 1.0) debugOut = vec3(0.35);
        if (abs(sunCurve) / max(length(vec2(dFdx(sunCurve), dFdy(sunCurve))), 1.0e-6) < 1.5) debugOut = vec3(1.0, 0.85, 0.2);
        if (abs(moonCurve) / max(length(vec2(dFdx(moonCurve), dFdy(moonCurve))), 1.0e-6) < 1.5) debugOut = vec3(0.35, 0.55, 1.0);
        float nowX = (asin(clamp(vSunElevation, -1.0, 1.0)) / 1.5707963 + 1.0) * 0.5;
        if (abs(vTexCoord.x - nowX) * viewWidth < 1.0) debugOut = vec3(1.0);
#elif MOON_DEBUG_MODE == 2
        // Moon position: its disc square (light blue) and sprite quad (dark blue) outlined on the
        // sky, crosshairs at the screen positions (blue moon, yellow sun; only when in front),
        // altitude bars at the left edge (moon, then sun; -90 at the bottom, +90 at the top).
        debugOut = color * 0.3;
        if (abs(dSquare - AMB_MOON_HALF) < dPixelAngle) debugOut = vec3(0.45, 0.65, 1.0);
        if (abs(dSquare - 4.0 * AMB_MOON_HALF) < dPixelAngle) debugOut = vec3(0.20, 0.30, 0.60);
        if (vMoonInFront > 0.5 && (abs(vTexCoord.x - vMoonUV.x) * viewWidth < 1.0 || abs(vTexCoord.y - vMoonUV.y) * viewHeight < 1.0)) debugOut = mix(debugOut, vec3(0.3, 0.5, 1.0), 0.6);
        if (vSunInFront > 0.5 && (abs(vTexCoord.x - vSunUV.x) * viewWidth < 1.0 || abs(vTexCoord.y - vSunUV.y) * viewHeight < 1.0)) debugOut = mix(debugOut, vec3(1.0, 0.85, 0.2), 0.6);
        if (vTexCoord.x < 0.015) debugOut = vTexCoord.y < 0.5 + 0.5 * dMoon.dir.y ? vec3(0.3, 0.5, 1.0) : vec3(0.0);
        else if (vTexCoord.x < 0.03) debugOut = vTexCoord.y < 0.5 + 0.5 * vSunElevation ? vec3(1.0, 0.85, 0.2) : vec3(0.0);
#elif MOON_DEBUG_MODE == 3 || MOON_DEBUG_MODE == 4 || MOON_DEBUG_MODE == 5
        // One glow term alone (x4, halo x2): smooth, round (or leaning to the lit side with
        // MOON_GLOW_QUALITY 2), black on the disc itself, no steps or rings.
        AmbMoonGlow dGlow = ambMoonGlowTerms(debugDir, dMoon, dPixelAngle);
#if MOON_DEBUG_MODE == 3
        debugOut = vec3(dGlow.bloom * 4.0);
#elif MOON_DEBUG_MODE == 4
        debugOut = vec3(dGlow.mid * 4.0);
#else
        debugOut = vec3(dGlow.halo * 2.0);
#endif
#elif MOON_DEBUG_MODE == 6
        // Moon visibility V (blue) and the share of the moon behind clouds (cyan), full screen:
        // both change smoothly while an edge or a cloud crosses the moon.
        debugOut = color * 0.25 + vec3(0.3, 0.5, 1.0) * (vMoonRays.x * vMoonRays.z * 0.75) + vec3(0.0, 0.8, 0.8) * (vMoonRays.y * 0.75);
#elif MOON_DEBUG_MODE == 7
        // Moon veil alone (x8): a faint smooth glow over terrain near the moon, none on the sky.
        debugOut = vec3(gMoonDebugVeil * 8.0);
#elif MOON_DEBUG_MODE == 8
        // Moon rim alone (x4): thin light only on silhouette edges turned to the moon.
        debugOut = vec3(gMoonDebugRim * 4.0);
#elif MOON_DEBUG_MODE == 9
        // Moon shafts alone (x32): faint streaks from gaps toward the moon, narrower than the sun's.
        debugOut = vec3(gMoonDebugShaft * 32.0);
#elif MOON_DEBUG_MODE == 10
        // Clouds over the moon: cloud pixels in front of the disc blue, other clouds grey, plus
        // the silver patch weight in green; the bar on top: moon V (blue), cloud cover (cyan).
        debugOut = color * 0.25;
        if (cloudPixel) {
            debugOut = dSquare < AMB_MOON_HALF ? vec3(0.15, 0.35, 1.0) : vec3(0.30);
            debugOut.g += 1.5 * clamp(CLOUD_MOON_GLOW_THROUGH * ambCloudMoonGlow(debugDir, dMoon), 0.0, 0.60);
        }
        if (vTexCoord.y > 0.97) {
            debugOut = vTexCoord.x < vMoonRays.x ? vec3(0.3, 0.5, 1.0) : (vTexCoord.x < vMoonRays.x + vMoonRays.y ? vec3(0.0, 0.8, 0.8) : vec3(0.0));
        }
#elif MOON_DEBUG_MODE == 11
        // Everything the moon adds (x4): on the sky its glow and halo, on terrain and clouds its
        // veil, rim and shafts. Clamped; dark everywhere except around the moon.
        if (skyPixel) {
            debugOut = abs(ambienceSkyFullMoon(debugDir, vSunWorld, finalPalette(), dMoon, dPixelAngle) -
                           ambienceSkyFull(debugDir, vSunWorld, finalPalette(), 0.0, dPixelAngle)) * 4.0;
        } else {
            debugOut = abs(gMoonDebugRaysAfter - gMoonDebugRaysBefore) * 4.0;
        }
        debugOut = clamp(debugOut, 0.0, 1.0);
#elif MOON_DEBUG_MODE == 12
        // Dark banding test: each 8-bit step of the output becomes a stripe (mod 4). Left half
        // without the dither: wide clean rings = banding; right half with the final dither (night
        // boost included): the stripes dissolve into a fine, static grain.
        float dDither = vTexCoord.x < 0.5 ? 0.0 : ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * (1.0 + finalNightDitherBoost(color));
        vec3 codes = floor(clamp(color + dDither, 0.0, 1.0) * 255.0 + 0.5);
        debugOut = mod(codes, 4.0) / 3.0;
        if (abs(vTexCoord.x - 0.5) * viewWidth < 0.75) debugOut = vec3(1.0, 0.0, 0.0);
#elif MOON_DEBUG_MODE == 13
        // Sun identity check: red = the sky's sun part now minus before (x4096), green = the
        // sun's veil, rim and shafts through the new CelestialLight path minus the previous code
        // (x4096). Expected: black everywhere, at any time (blue tint = the moon has light now).
        debugOut = vec3(0.0, 0.0, dMoon.light > 0.0 ? 0.15 : 0.0);
        if (skyPixel) {
            AmbMoon dark = dMoon;
            dark.light = 0.0;
            vec3 skyBefore = ambienceSkyFull(debugDir, vSunWorld, finalPalette(), 0.0, dPixelAngle);
            vec3 skyNowSun = ambienceSkyFullMoon(debugDir, vSunWorld, finalPalette(), dark, dPixelAngle);
            debugOut.r = clamp(4096.0 * length(skyNowSun - skyBefore), 0.0, 1.0);
        } else if (gMoonDebugTerrain > 0.5) {
            vec3 previous = finalSunRaysPrevious(gMoonDebugSunBefore, debugDir, playerPosition, sceneDepth, cloudPixel);
            debugOut.g = clamp(4096.0 * length(gMoonDebugSunAfter - previous), 0.0, 1.0);
        }
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

    // Static triangular dither (SKY_DITHER x 1/255) before the 8-bit output: no banding in
    // the smooth sky, glow and fog gradients, no visible grain, no crawl (no frame input). At
    // night the dark regions get a little more (finalNightDitherBoost, 0 by day).
    float nightDitherBoost = finalNightDitherBoost(color);
    color += ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0);
    if (nightDitherBoost > 0.0) color += ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * nightDitherBoost;
    gl_FragColor = vec4(color, scene.a);
}
