// Celestial rays: the edge rim (with its soft bleed), the faint shafts through gaps and, in
// final, the veil, for ONE light source at a time (the sun, or the moon since Update 2A).
// Everything here is deterministic and noise-free: fixed tap offsets, smooth weights, no
// jitter, no frame input, and never the shadow map (only the camera depth buffer and the
// cloud marker). The functions take the light's screen position and size; the sun passes its
// approved constants, the moon its own.
// Used by composite (the quarter-resolution open-sky mask), composite1 (the shaft march) and
// final (the rim, the depth-derived normal, the shaft upsample and the CelestialLight
// composition, RAYS_FINAL).
// The includer declares: depthtex0, far, gbufferProjectionInverse, gbufferModelViewInverse, and
// colortex1 when the cloud marker exists (AMBIENCE_COLORS or AMBIENCE_CLOUDS); final also
// colortex5, gbufferProjection, viewWidth and viewHeight, and includes lib/ambience.glsl first.

#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// gbuffers_clouds writes the cloud marker into colortex1: A = 1, R = 0, G = the face's opacity.
#define RAYS_CLOUD_MARKER
#endif

// View-space distance (blocks) of a depth-buffer value.
float raysLinearDepth(float depth) {
    vec4 v = gbufferProjectionInverse * vec4(0.0, 0.0, depth * 2.0 - 1.0, 1.0);
    return -v.z / max(v.w, 1.0e-6);
}

// Camera-relative position of a screen point.
vec3 raysPlayerPosition(vec2 uv, float depth) {
    vec4 v = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(v.xyz / max(v.w, 1.0e-6), 1.0)).xyz;
}

// Open sky at one full-resolution texel: sky = 1, a cloud = its transparency (an opaque cloud is
// an occluder), terrain = 0, softened toward 1 near the render distance where the fog turns
// terrain into the sky colour (a wide smoothstep on the linear depth, never a hard step).
float raysOpenSkyTexel(ivec2 texel) {
#ifdef RAYS_CLOUD_MARKER
    vec4 info = texelFetch(colortex1, texel, 0);
    if (info.a > 0.5 && info.r < 0.5) return 1.0 - info.g;
#endif
    float depth = texelFetch(depthtex0, texel, 0).r;
    if (depth > 0.99999) return 1.0;
    return smoothstep(0.75 * far, 1.05 * far, raysLinearDepth(depth));
}

#ifdef RAYS_EDGE_RIM
// Edge gather for the rim and its soft bleed: taps from this pixel straight toward the light's
// screen position at fixed offsets (pixels at 1080p, scaled with the resolution and reach =
// RIM_REACH for the sun), with smooth decreasing weights. 1 right at an edge with open sky
// toward the light, a soft ramp inside the silhouette, 0 deeper in (a tap past the light's
// centre only finds more disc). Inside the light's own screen square (lightRadius = its half
// size in pixels) an edge can have its open side away from the centre (the centre just sank
// behind it while the rest of the disc still shows, or the lower edge of a bar across the
// disc): the same taps away from the centre take over there, fading out between 0.9 and 1.4
// half sizes, so the rim never switches off at once.
float raysRimGather(vec2 uv, vec2 lightUV, vec2 screen, float lightRadius, float reach) {
    vec2 toLight = (lightUV - uv) * screen;
    float distanceToLight = length(toLight);
    // Right at the light's centre the direction is undefined: look up and down instead.
    vec2 direction = distanceToLight > 0.5 ? toLight / distanceToLight : vec2(0.0, 1.0);
    float scale = (screen.y / 1080.0) * reach;
    float inside = 1.0 - smoothstep(0.9 * lightRadius, 1.4 * lightRadius, distanceToLight);
    // Weights fitted to the reference: a bright edge over the first taps, then a soft bleed.
#if RIM_TAPS == 3
    const int TAPS = 3;
    const float OFFSET[3] = float[3](2.0, 5.0, 10.0);
    const float WEIGHT[3] = float[3](0.50, 0.30, 0.20);
#elif RIM_TAPS == 6
    const int TAPS = 6;
    const float OFFSET[6] = float[6](1.5, 3.0, 5.0, 8.0, 11.0, 14.0);
    const float WEIGHT[6] = float[6](0.26, 0.20, 0.17, 0.14, 0.12, 0.11);
#else
    const int TAPS = 4;
    const float OFFSET[4] = float[4](2.0, 4.0, 8.0, 14.0);
    const float WEIGHT[4] = float[4](0.40, 0.27, 0.19, 0.14);
#endif
    ivec2 maxTexel = ivec2(screen) - 1;
    float gather = 0.0;
    float away = 0.0;
    for (int i = 0; i < TAPS; ++i) {
        float tapReach = OFFSET[i] * scale;
        vec2 position = uv * screen + direction * tapReach;
        gather += WEIGHT[i] * raysOpenSkyTexel(clamp(ivec2(position), ivec2(0), maxTexel));
        if (inside > 0.0) {
            vec2 opposite = uv * screen - direction * tapReach;
            away += WEIGHT[i] * raysOpenSkyTexel(clamp(ivec2(opposite), ivec2(0), maxTexel));
        }
    }
    return max(gather, away * inside);
}

// Surface normal from the depth buffer: per screen axis the neighbour closer in depth (it stays
// on the same face at block edges and silhouettes), a cross product, turned toward the camera.
// Exact on the flat faces of blocks.
vec3 raysNormal(ivec2 texel, float depth, vec3 position, vec2 screen) {
    ivec2 maxTexel = ivec2(screen) - 1;
    ivec2 left = clamp(texel - ivec2(1, 0), ivec2(0), maxTexel);
    ivec2 right = clamp(texel + ivec2(1, 0), ivec2(0), maxTexel);
    ivec2 down = clamp(texel - ivec2(0, 1), ivec2(0), maxTexel);
    ivec2 up = clamp(texel + ivec2(0, 1), ivec2(0), maxTexel);
    float depthLeft = texelFetch(depthtex0, left, 0).r;
    float depthRight = texelFetch(depthtex0, right, 0).r;
    float depthDown = texelFetch(depthtex0, down, 0).r;
    float depthUp = texelFetch(depthtex0, up, 0).r;
    bool useLeft = abs(depthLeft - depth) < abs(depthRight - depth);
    bool useDown = abs(depthDown - depth) < abs(depthUp - depth);
    ivec2 horizontal = useLeft ? left : right;
    ivec2 vertical = useDown ? down : up;
    vec3 a = raysPlayerPosition((vec2(horizontal) + 0.5) / screen, useLeft ? depthLeft : depthRight) - position;
    vec3 b = raysPlayerPosition((vec2(vertical) + 0.5) / screen, useDown ? depthDown : depthUp) - position;
    vec3 n = cross(a, b);
    float n2 = dot(n, n);
    if (n2 < 1.0e-14) return -position * inversesqrt(max(dot(position, position), 1.0e-6));
    n *= inversesqrt(n2);
    return dot(n, position) > 0.0 ? -n : n;
}
#endif

#ifdef RAYS_SHAFTS
// Pre-filtered open-sky mask of one quarter-resolution pixel: four full-resolution taps spread
// over its 4 x 4 block (a box filter), so the march reads a soft mask whose samples overlap.
// It does not depend on the light: composite writes it for whichever source owns the shafts.
float raysQuarterMask(vec2 uv, vec2 fullSize) {
    vec2 centre = uv * fullSize;
    ivec2 maxTexel = ivec2(fullSize) - 1;
    float mask = raysOpenSkyTexel(clamp(ivec2(centre + vec2(-1.0, -1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(1.0, -1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(-1.0, 1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(1.0, 1.0)), ivec2(0), maxTexel));
    return 0.25 * mask;
}

// Deterministic radial march from this quarter-resolution pixel toward the light over the mask
// (bilinear, alpha of maskTex): SHAFT_SAMPLES fixed offsets along a short ray (shaftLength of
// the distance to the light, capped at half of shaftLength in screen heights, so the samples
// stay close enough to overlap; the sun passes SHAFT_LENGTH), Gaussian-like weights. Result:
// the share of open sky seen toward the light, 0 deep inside occluders, partial next to gaps.
float raysShaftMarch(sampler2D maskTex, vec2 uv, vec2 lightUV, float aspect, float shaftLength) {
    vec2 delta = (lightUV - uv) * vec2(aspect, 1.0);
    float distanceToLight = length(delta);
    if (distanceToLight < 1.0e-4) return texture(maskTex, uv).a;
    float span = min(distanceToLight * shaftLength, 0.5 * shaftLength);
    vec2 march = delta / distanceToLight * span / vec2(aspect, 1.0);
    float sum = 0.0;
    float weightSum = 0.0;
    for (int i = 0; i < SHAFT_SAMPLES; ++i) {
        float t = (float(i) + 0.5) / float(SHAFT_SAMPLES);
        float weight = exp(-0.5 * t * t / (SHAFT_SOFTNESS * SHAFT_SOFTNESS));
        sum += weight * texture(maskTex, uv + march * t).a;
        weightSum += weight;
    }
    return sum / weightSum;
}

// Where shafts show: strongest next to the light (half size halfSize), gone about 45 degrees
// away for the sun (spread 1); a smaller spread narrows the smooth cone.
float raysShaftFalloff(float theta, float halfSize, float spread) {
    return exp(-max(theta - halfSize, 0.0) / (0.22 * spread)) * (1.0 - smoothstep(0.45 * spread, 0.80 * spread, theta));
}
#endif

#if defined(RAYS_SHAFTS) && defined(RAYS_FINAL)
// Depth-aware upsample of the quarter-resolution shafts (colortex5.a): the four nearest
// quarter-resolution texels with their bilinear weights, each weighted by how close its depth
// (the full-resolution depth at its centre) is to this pixel's, so shafts on a distant hill
// never bleed onto a fence post in front of it.
float raysShaftUpsample(vec2 uv, float pixelDistance, vec2 fullSize) {
    vec2 quarterSize = vec2(textureSize(colortex5, 0));
    vec2 position = uv * quarterSize - 0.5;
    ivec2 base = ivec2(floor(position));
    vec2 f = position - floor(position);
    ivec2 maxQuarter = ivec2(quarterSize) - 1;
    ivec2 maxTexel = ivec2(fullSize) - 1;
    float sum = 0.0;
    float weightSum = 0.0;
    for (int j = 0; j < 2; ++j) {
        for (int i = 0; i < 2; ++i) {
            ivec2 q = clamp(base + ivec2(i, j), ivec2(0), maxQuarter);
            float bilinear = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
            ivec2 centre = clamp(ivec2((vec2(q) + 0.5) * fullSize / quarterSize), ivec2(0), maxTexel);
            float texelDistance = raysLinearDepth(texelFetch(depthtex0, centre, 0).r);
            float relative = abs(texelDistance - pixelDistance) / max(pixelDistance, 0.5);
            float weight = bilinear * (exp(-12.0 * relative) + 1.0e-4);
            sum += weight * texelFetch(colortex5, q, 0).a;
            weightSum += weight;
        }
    }
    return sum / max(weightSum, 1.0e-6);
}
#endif

#ifdef RAYS_FINAL
// One celestial light source as the ray system sees it. final fills it once per pixel from the
// vertex shader's flat values: the sun with its approved constants (VEIL_STRENGTH, RIM_STRENGTH,
// RIM_REACH, SHAFT_STRENGTH, its glow and rim colours, spread 1), the moon with its own
// (smaller, cooler, much fainter). The functions below are the sun's previous code with these
// fields in place of the constants, in the same order of operations.
struct CelestialLight {
    vec3 direction;      // world direction
    vec2 screenUV;       // screen position (valid when inFront > 0.5)
    float inFront;       // 1 = in front of the camera
    float screenFade;    // 1 on screen, 0 from 1.35 x the screen half size out
    float halfSize;      // half size of its visible square (AMB_SUN_HALF, AMB_MOON_HALF)
    float haloSize;      // wide part of the veil (SUN_HALO_SIZE, MOON_HALO_SIZE)
    float light;         // brightness: time of day, weather, phase (moon), eye sky exposure
    float visibility;    // V: visible share (fixed depth taps in final.vsh)
    float cloudCover;    // share behind clouds
    float veilStrength;
    vec3 veilColor;
    float rimStrength;
    vec3 rimColor;
    float rimReach;
    float shaftStrength;  // 0 while the other source owns the shaft buffer
    vec3 shaftColor;
    float shaftSpread;
};

// Veil: analytic in the angle to the light, times its visibility V (so a light hidden by a
// block or a cloud takes its veil away); depthFactor keeps it off the camera-near hand.
vec3 celestialVeil(vec3 color, CelestialLight L, float theta, float depthFactor, out float veil) {
    float visibility = L.visibility * L.screenFade;
    veil = L.veilStrength * visibility * ambVeilFalloffSized(theta, L.halfSize, L.haloSize) * depthFactor * L.light;
    return mix(color, L.veilColor, clamp(veil, 0.0, 0.6));
}

// Edge rim: right around the light, on silhouette edges with open sky toward it (the gather),
// weighted by the depth normal: full on faces turned to the light, 65 % on backlit faces. A
// light hidden by a block still lights the edge a little (the silver lining around the
// occluder); a cloud in front of it takes the rim away. Not on clouds or the hand.
vec3 celestialRim(vec3 color, CelestialLight L, float theta, vec3 playerPosition, float sceneDepth, bool cloudPixel,
                  vec2 uv, out float rim) {
    rim = 0.0;
#ifdef RAYS_EDGE_RIM
    float rimVisibility = (L.visibility + 0.55 * max(1.0 - L.visibility - L.cloudCover, 0.0)) * L.screenFade;
    float rimFalloff = ambRimFalloffSized(theta, L.halfSize) * L.light * rimVisibility * smoothstep(0.6, 2.0, length(playerPosition));
    if (rimFalloff > 0.004 && L.inFront > 0.5 && !cloudPixel) {
        vec2 screen = vec2(viewWidth, viewHeight);
        float gather = raysRimGather(uv, L.screenUV, screen, L.halfSize * gbufferProjection[1][1] * 0.5 * viewHeight, L.rimReach);
        if (gather > 0.002) {
            vec3 normal = raysNormal(ivec2(gl_FragCoord.xy), sceneDepth, playerPosition, screen);
            float facing = mix(0.65, 1.0, smoothstep(-0.10, 0.30, dot(normal, L.direction)));
            rim = L.rimStrength * gather * rimFalloff * facing;
            color = mix(color, L.rimColor, clamp(rim, 0.0, 0.75));
        }
    }
#endif
    return color;
}

// Shafts through gaps: the quarter-resolution march (composite1) through the depth-aware
// upsample, strongest near the light, gone off screen and behind the camera. Screen-blended,
// so they can never push a colour past white.
vec3 celestialShafts(vec3 color, CelestialLight L, float theta, float sceneDepth, vec2 uv, out float shaft) {
    shaft = 0.0;
#ifdef RAYS_SHAFTS
    float shaftLight = L.shaftStrength * raysShaftFalloff(theta, L.halfSize, L.shaftSpread) * L.light * L.screenFade * L.inFront;
    if (shaftLight > 0.0005 && texture(colortex5, uv).a > 0.002) {
        float shafts = raysShaftUpsample(uv, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight));
        color += L.shaftColor * (shaftLight * shafts) * max(vec3(1.0) - color, vec3(0.0));
        shaft = shaftLight * shafts;
    }
#endif
    return color;
}
#endif
