// Shared Iris options. Disabled Boolean options remove their shader code at compile time.
// Iris rule: every option is declared on exactly ONE line ("#define X" or "//#define X").
// A second, conflicting declaration of the same name makes Iris drop the option (it then
// cannot be toggled from the menu or by a preset), so there are no duplicate lines here.
#define BLOOM // Quarter-resolution soft glow
#define WET_GROUND // Rain-reactive exposed ground
#define SHALLOW_WATER_LIGHTING // Existing shallow-water shafts and surface sparkle
#define PIXEL_CAUSTICS // Pixel-snapped Voronoi caustics on submerged surfaces
#define CAUSTICS_WALLS // Caustics on submerged side faces (walls, pillars, cliffs)
#define CAUSTICS_SCREEN_BLEND // Screen-style blend and mosaic via premultiplied water output; off = plain additive
#define WATER_DEPTH_TINT // Clear light-teal shallows that turn deep blue and opaque with depth
#define WATER_SKY_REFLECTION // Tier 1: analytic sky/cloud reflection with Fresnel and distance blend (no texture fetch)
#define WATER_SSR // Tier 2: screen-space planar reflection of terrain and clouds in final (needs Tier 1)
#define WATER_REFLECTION_IMPROVEMENT // Reflection add-on: palette sky, real cloud cells, fog-aware screen reflection, shallow/rain/night handling
//#define REFLECTION_DEBUG // Diagnostic views for the water reflection system
#define WAVE_LIGHTING // Soft sun/moon light on the vanilla animated wave texels
//#define WAVE_DEBUG // Diagnostic views for the wave lighting
//#define CAUSTICS_DEBUG // Diagnostic views for the caustic receiver
#define CAUSTICS_UNDERWATER_FLOOR // Caustics on the submerged floor and walls while the camera is underwater (never on the surface seen from below)
#define ATMOSPHERIC_HAZE // Analytic distance and height haze in final (used where the Ambience fog is off)
#define ATMOSPHERIC_GRADE // Warm sunlight, cool shade, and restrained vibrance
#define ATMOS_TONE_MAP // Existing cinematic shoulder and highlight finish
#define ATMOSPHERIC_PARTICLES // Sparse screen-space pollen motes
#define LEAF_TRANSLUCENCY // Subtle sun back-light on mapped leaves
#define ENTITY_SHADOWS // Render entities, block entities, and the player into the shadow map
#define PIXEL_SHADOWS // Stabilized world-grid position and nearest shadow texel
#define DIRECTIONAL_LIGHTING // Directional face lighting on blocks: the face turned to the sun (moon at night) is brighter, faces turned away get the sky ambient (Update 2B); off = the previous flat faces
#define PREVIOUS_SUN_LIFT // The previous small directional sun/moon lift: on water, the player, mobs and particles; on blocks only while DIRECTIONAL_LIGHTING is off
#define SUBSURFACE_TRANSMISSION // Back-light tint for leaves, plants, and translucent blocks
#define EMISSIVE_BLOCKS // Texture-masked boost for tagged terrain emitters
#define SKY_GRADE // View-direction sky gradient and color finish in final (used where the Ambience colours are off)
#define ATMOS_VIGNETTE // Subtle final-pass edge falloff
#define PROCEDURAL_STARS // Sparse sky-anchored stars in the final sky treatment
//#define PIXEL_WATER_SPARKLES // Sparse world-grid glints on the water surface
//#define ATMOS_DEBUG // Diagnostic views for sky, haze, biome blend, and bloom
//#define VV_DEBUG // Nine diagnostic views; extra MRT code exists only in this mode

// Ambience: environment colours, clouds, cloud shadows and layered fog.
#define AMBIENCE_COLORS // Time-of-day and biome palettes for sky, fog, clouds and terrain light; the sky meets the fog at the horizon
#define AMBIENCE_CLOUDS // Soft sky-tinted cloud lighting (gbuffers_clouds); off = vanilla cloud colours
#define AMBIENCE_FOG // Layered height fog with banks, sun scattering and distance layering (replaces the distance haze)
#define FOG_SCATTERING // Brighter, warmer haze toward the sun; cooler opposite it (sky and fog together)
#define FOG_ON_WATER // The Ambience fog also covers water at its distance; off = water keeps the previous haze
//#define FOG_BANDED_LOOK // Quantize the fog amount into a few dithered steps
#define CLOUD_SHADOW_ENABLE // Soft drifting shadows of the vanilla clouds on the ground
#define VANILLA_CLOUD_CELLS // Cloud shadows/reflection read the vanilla cloud cells (shaders/textures/clouds.png), aligned with the visible clouds; off = procedural cells
//#define HIDE_VANILLA_CLOUDS // Hide the vanilla clouds (use when VANILLA_CLOUD_CELLS is off)
//#define AMBIENCE_DEBUG // Diagnostic views for fog, sky, clouds, cloud shadows, reflections and grading

// Biome ambience: sky, fog and cloud colours and fog character per biome family (camera biome).
#define BIOME_AMBIENCE // Per-biome sky, fog and cloud colours and fog character, blended once per frame on the CPU
#define BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION // The water's sky reflection and its fog-aware screen reflection follow the biome
#define BIOME_PRECIPITATION // Biomes without rain (desert, savanna, badlands) keep a clear sky in rain; snowfall is brighter than rain
//#define BIOME_DESERT_DUST // Slight extra dust near the ground in deserts, badlands and savanna
//#define BIOME_DEBUG // Diagnostic views: family weights, palette swatches, horizon match, density, transition, palette table

// Sun, sky glow and soft rays: analytic and deterministic (no noise, no jitter, no shadow map).
#define SUN_GLOW // Analytic glow around the sun and moon: thin bloom, mid glow and a faint wide halo
#define SUN_RAYS // Gentle uniform rays: a slow, soft angular modulation of the mid glow (no noise)
#define SUN_VEIL // Warm light veil over terrain and clouds near the sun, scaled by how much of the sun is visible
#define SUN_EDGE_RIM // Thin warm rim and soft bleed on block edges turned to the sun, right around it (sun-directed depth taps)
#define SUN_SHAFTS // Very faint shafts through gaps (leaves, between blocks, between clouds): quarter-resolution radial march, no noise
//#define SUN_DEBUG // Diagnostic views for the sun glow, veil, rim, sky, horizon match, fog and dither

// Update 1: clouds hide the sun, dynamic shadow colours.
#define CLOUDS_BLOCK_SUN // Clouds hide the sun, moon and stars (opaque body, distance fade by colour, soft glow around a hidden sun); off = the previous translucent clouds
#define SHADOW_COLORS // Shadows take the hue of the ambient sky light and react to the surface (terrain receivers)
#define ENTITY_SHADOW_FLAG // Player and mob shadows get their own strength (shadow_entities writes an entity flag into shadowcolor0); off = one rule for all shadows
//#define LIGHT_DEBUG // Diagnostic views for the sun rays, cloud occlusion, shadow colours and underwater caustics

// Update 2A: the moon gets the sun's light system in cool night colours (one light source per frame).
#define MOON_RAYS // Moon glow and halo in cool night colours, faded by phase, weather and clouds; enables the moon veil, rim and shafts below; off = the previous moon glow
#define MOON_VEIL // Faint cool veil over terrain and clouds near the visible moon
#define MOON_EDGE_RIM // Faint cool rim on block edges turned to the moon (the sun rim's depth taps)
#define MOON_SHAFTS // Very faint cool shafts through gaps toward the moon (the sun shafts' pass and buffer; one source per frame)
//#define MOON_DEBUG // Diagnostic views for the moon light, the sun/moon handover and the sun identity check

// Update 2B: micro-detail lighting on blocks (the face lighting is DIRECTIONAL_LIGHTING above).
#define BLOCK_MICRO_DETAIL // Micro-detail light on selected blocks: only small details catch the light (sand grains, obsidian speckles, lit leaf texels, furrows), from the vanilla texture; replaces the plastic gloss on blocks
#define GLITTER_BLOCKS // Glitter: sand, red sand, snow, powder snow, gravel, calcite, diorite, deepslate, soul sand and soil (a few grains catch the sun)
#define SHEEN_BLOCKS // Sheen: farmland furrows, clay, mud, grass blocks, moss, dirt, stone, cobblestone, andesite, logs, planks, mushrooms (the lighter texels catch the sun)
#define GLOSS_BLOCKS // Gloss: ice, obsidian, amethyst, blackstone, basalt, quartz and polished stone, prismarine, glass, metal blocks and ores (sharp glints, faint sky reflection)
#define FOLIAGE_SPARKLE // Foliage: leaves, vines, glow lichen, moss carpet, lily pads, mangrove roots, grass, ferns and flowers (sun-caught texels; static, no wind)
//#define BLOCK_DEBUG // Diagnostic views for the face lighting and the micro-detail

// Golden-hour screenshot match. Each effect is independently compiled out when disabled.
#define GOLDEN_TARGET_SKY // Golden-hour zenith/horizon palette blend
#define GOLDEN_TARGET_HAZE // Extra amber distance haze and a cheap sun-facing phase term (only where the Ambience fog is off)
#define GOLDEN_TARGET_GRADE // Warm low-sun grade and gentle shadow lift
#define GOLDEN_TARGET_BACKLIGHT // Additional warm foliage/grass/flower edge light
#define GOLDEN_BLOCKY_BLOOM // Pixelate the existing quarter-resolution bloom source
#define GOLDEN_SOFT_VIGNETTE // Optional target-style vignette contribution
#define GOLDEN_FAKE_BIRDS // Procedural screen-space bird silhouettes; visual fake, not entities
//#define TARGET_DEBUG // Golden-hour diagnostics (compiled out when disabled)

#define GLOSS_STRENGTH 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.38 0.45] Plastic gloss strength (player, mobs, items; no longer on blocks)
#define HIGHLIGHT_SIZE 28 // [12 16 20 24 28 32 36 42 48] Highlight size (higher values make a tighter highlight)
#define GLOSS_FRESNEL 0.07 // [0.00 0.03 0.05 0.07 0.09 0.12 0.16 0.20] Fresnel rim of the plastic gloss (player and mobs)
#define PLASTIC_GLOSS_MIX 1.00 // [0.00 0.25 0.50 0.75 1.00] Blend out the original plastic gloss layer (player, mobs, items; no longer on blocks)
#define SHADOW_QUALITY 1 // [1 2 3] Shadow filtering: 1 tap, 4 taps, or 8 taps
#define SHADOW_PIXEL_GRID 16 // [8 16 32] World texels per block for stabilized shadow receivers
#define DIRECTIONAL_LIGHT_STRENGTH 0.08 // [0.00 0.03 0.05 0.08 0.12 0.18] Extra light on a block face turned straight to the sun, over the flat light (the brightest face)
#define WATER_REFLECTION_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Master water reflectivity multiplier
#define THIN_TRANSMISSION_STRENGTH 0.07 // [0.00 0.03 0.05 0.07 0.11 0.16] Back-light through thin materials
#define EMISSIVE_STRENGTH 0.42 // [0.00 0.15 0.28 0.42 0.60 0.85] Tagged emitter lift
#define EMISSIVE_THRESHOLD 0.58 // [0.30 0.42 0.58 0.70 0.82] Texture brightness needed for emissive lift
#define RAY_INTENSITY 0.18 // [0.00 0.05 0.10 0.18 0.22 0.30 0.40] Existing shallow-water shaft intensity
#define RAY_LENGTH 0.55 // [0.20 0.35 0.45 0.55 0.62 0.75 0.90] Existing shallow-water shaft reach
#define CAUSTICS_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50] Caustic intensity; 1.0 = measured reference swatches
#define VORONOI_QUALITY 2 // [1 2] Cell search: 1 = 2x2 (LOW), 2 = full 3x3
#define TEXELS_PER_BLOCK 16 // [8 16 32] Caustic texels per block; 16 matches vanilla textures
#define CELL_SIZE_TEXELS 8 // [6 7 8 10 12 14 16] Voronoi point spacing in texels; 8 matches the measured reference
#define CELL_CURVE 2.50 // [0.00 1.00 1.50 2.00 2.50 3.00 4.00] Smooth warp in texels that bends straight cell edges into curves
#define CELL_JITTER 0.85 // [0.30 0.50 0.60 0.75 0.85 1.00] Point randomness inside each cell; lower = more regular
#define LINE_WIDTH 0.90 // [0.75 0.90 1.00 1.25 1.50 2.00] Line width in texels (constant, measured from the cell bisector)
#define EDGE_HALO 0.35 // [0.00 0.25 0.35 0.45 0.65] One-sided dim halo next to lines; 0 = off
#define EDGE_DROPOUT 0.05 // [0.00 0.04 0.05 0.08 0.12 0.20] Share of 3-texel line stretches left as gaps
#define EDGE_TWINKLE 1.0 // [0.0 0.5 1.0 2.0 3.0] Per-edge brightness changes per second; 0 = static
#define ISOLATED_PIXELS 0.010 // [0.000 0.005 0.010 0.020 0.040] Chance of a lone bright texel near the lines
#define PEAK_AMOUNT 0.30 // [0.00 0.15 0.30 0.45 0.60 1.00] Share of the brightest stretches turned into the cream peak
#define WARMTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Peak colour: cool white to warm cream
#define CONTRAST 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00] 1 = calm floor gets no line light; lower adds a faint fill
#define MOSAIC_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Soft floor tone patches (-10 % / -3 % / +4 % at 1.0)
#define MOSAIC_CELL_SIZE 3 // [2 3 4] Mosaic patch size in texels
#define STEPS_PER_SECOND 8 // [2 4 6 8 10 12] Flip-book animation steps per second
#define CELL_ORBIT 2 // [0 1 2 3] Radius in texels of each point's stepped orbit; 0 = no deformation
#define DRIFT_SPEED 0.5 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0] Slow global drift in texels per second
#define DRIFT_DIRECTION 45 // [0 45 90 135 180 225 270 315] Global drift direction in degrees
#define CAUSTIC_FULL_DEPTH 2.0 // [0.0 1.0 2.0 3.0 4.0] Full-strength caustics through this depth in blocks
#define CAUSTIC_FADE_DEPTH 11.0 // [6.0 8.0 9.0 10.0 11.0 12.0 14.0] Lines fade to zero at this depth; the mosaic at 1.5x
#define WALL_STRENGTH 0.45 // [0.00 0.25 0.35 0.45 0.55 0.70 0.85 1.00] Wall caustics relative to the floor
#define WALL_DEPTH_FADE 6.0 // [2.0 4.0 6.0 8.0 10.0 12.0] Wall caustics fade to zero this many blocks below the surface
#define WALL_SUN_FACTOR 0.65 // [0.00 0.25 0.50 0.65 0.80 1.00] Sun-facing weight on walls; 1 - value is the minimum
#define WAVE_LIGHT_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00 1.40 2.00] Overall sun light on wave crests; 0 = plain base water
#define DIFFUSE_AMOUNT 0.25 // [0.00 0.10 0.25 0.40 0.60] Soft wrap-diffuse light on crests facing the sun
#define GLINT_AMOUNT 0.35 // [0.00 0.15 0.35 0.50 0.75 1.00] Sun glint on crests (strong toward a low sun)
#define GLINT_SIZE 0.20 // [0.10 0.15 0.20 0.30 0.40] Glint roughness; larger = wider, softer sun path
#define CREST_CONTRAST 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] How many texture texels count as crests
#define CREST_LEVELS 3 // [2 3 4] Crest brightness levels including the unlit base
#define WAVE_NORMAL_STRENGTH 0.12 // [0.00 0.06 0.12 0.18 0.25] Pseudo-normal tilt from the wave texture
#define WAVE_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10] Luma / wave / crest raw / crest / normal / diffuse / glint / shadow+sky / crest light / split screen
#define FRESNEL_STRENGTH 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] Angle-based (Fresnel) water reflectivity
#define FAR_REFLECTIVITY 0.85 // [0.00 0.40 0.60 0.75 0.85 0.95] Reflectivity reached at REFLECT_FAR_DISTANCE
#define REFLECT_NEAR_DISTANCE 6 // [2 4 6 8 12 16] Horizontal distance (blocks) where the distance blend starts
#define REFLECT_FAR_DISTANCE 60 // [30 40 50 60 80 100 128] Horizontal distance (blocks) where it is complete
#define REFLECTION_BLUR 3 // [1 3 5] Vertical taps of the screen-space reflection (1 = sharp)
#define REFLECTION_STRETCH 2 // [1 2 3 4 6] Screen pixels between the vertical taps
#define REFLECTION_WOBBLE 1.0 // [0.0 0.5 1.0 1.5 2.0] Vertical wobble of the reflection driven by the vanilla wave texels
#define WATER_SSR_REFINE 1 // [1 2 3] Planar refinement steps of the screen-space reflection (3 = Tier 3 quality)
#define CLOUD_REFLECTION 0.25 // [0.00 0.15 0.25 0.35 0.50 0.75] Faint cloud reflection (Tier 1)
#define STREAK_CONTRAST 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] How strongly wave crests catch the reflection
#define STREAK_DISTANCE_FADE 0.60 // [0.00 0.30 0.60 0.80 1.00] Fade of the streaks into the haze at the far end
#define STREAK_LOD_BIAS 0.0 // [-1.0 -0.5 0.0 0.5 1.0] Mip bias for the streak mask; higher = calmer far streaks
#define HORIZON_BLEND 1.00 // [0.00 0.25 0.50 0.75 1.00] Fade of terrain and water into the sky colour at the render distance (previous haze)
#define REFLECTION_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12] Reflect dir / tier 1 / tier 2 / tier 2 valid / UV / Fresnel / distance / reflectivity / column / opacity / crest / before-after fog
#define SHALLOW_TINT 1 // [0 1 2 3] Shallow water colour (< ~2 blocks): vanilla biome / turquoise / light teal / clear cyan
#define NEAR_WATER_TINT 1 // [0 1 2 3] Water colour near the camera at normal depth: dark biome / deep blue / navy / teal blue
#define FAR_WATER_TINT 1 // [0 1 2 3] Water's own colour far away, under the reflection: fog colour / lavender blue / steel blue / teal grey
#define WATER_OPACITY_NEAR 0.30 // [0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60] Water opacity near the camera in shallow water
#define WATER_OPACITY_FAR 0.90 // [0.50 0.70 0.80 0.90 0.95 1.00] Water opacity reached at REFLECT_FAR_DISTANCE
#define ABSORPTION_STRENGTH 0.25 // [0.10 0.15 0.20 0.25 0.32 0.40 0.55] Per-block shift to deep tint/opacity; also caustic absorption
#define SPARKLE_AMOUNT 0.12 // [0.00 0.05 0.08 0.12 0.18 0.25 0.35] Water surface sparkle amount
#define HAZE_DENSITY 0.0020 // [0.0005 0.0010 0.0018 0.0020 0.0024 0.0025 0.0035 0.0050] Distance haze density (previous haze)
#define HAZE_HEIGHT_FALLOFF 0.025 // [0.000 0.010 0.025 0.040 0.060] Thin haze with altitude (previous haze)
#define WARM_COOL_STRENGTH 0.10 // [0.00 0.04 0.08 0.10 0.14 0.20] Sun and shade color split
#define VIBRANCE_STRENGTH 0.08 // [0.00 0.04 0.08 0.12 0.18 0.25] Safe green vibrance
#define BIOME_TINT_STRENGTH 0.22 // [0.00 0.08 0.16 0.22 0.32 0.45] Previous biome haze tint (only where the Ambience fog or colours are off)
#define TONE_SHOULDER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Existing cinematic shoulder strength
#define BLOOM_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.07 0.10 0.14] Bloom strength
#define BLOOM_THRESHOLD 0.72 // [0.45 0.60 0.72 0.82 0.92] Bloom cutoff
#define PARTICLE_AMOUNT 0.06 // [0.00 0.03 0.06 0.10 0.16 0.24] Screen-space pollen amount
#define LEAF_TRANSMISSION 0.08 // [0.00 0.03 0.06 0.08 0.12 0.18] Leaf back-light strength
#define VIGNETTE_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.065 0.08 0.12] Vignette strength
#define CAUSTICS_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15] Axis / texel grid / cell ids / F1 / edge / line raw / line / edge level / mosaic / levels / column / submerged / shadow / final / water flag
#define ATMOS_DEBUG_MODE 1 // [1 2 3 4 5 6] Sunlit / (removed rays: black) / fog / biome / sky / bloom
#define VV_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9] Sunlit / (removed rays: black) / fog / biome / shadow / emissive / material / water / bloom
#define SKY_QUALITY 2 // [1 2] Coarse or fine procedural star grid
#define SKY_GRADIENT_STRENGTH 0.32 // [0.00 0.16 0.28 0.32 0.42 0.48 0.55 0.64] Analytic sky blend strength (previous sky grade)
#define STAR_AMOUNT 0.35 // [0.00 0.15 0.22 0.25 0.35 0.45 0.50 0.55 0.75] Procedural star density

// Sun and sky glow sliders.
#define SUN_STYLE 0 // [0 1] 0 = vanilla square (exact vanilla size and pixel rings, brighter), 1 = soft round disc of the same area
#define SUN_GLOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Thin bloom hugging the sun and the mid glow
#define SUN_HALO_SIZE 0.30 // [0.15 0.20 0.30 0.40 0.55 0.70] Wide halo radius in radians (0.30 = about 17 degrees); also the falloff of the sun scattering in the haze
#define SUN_HALO_STRENGTH 0.10 // [0.00 0.05 0.10 0.20 0.30 0.45] Wide halo: the sky gets lighter around the sun (0.10 = the sun reference)
#define RAY_VARIATION 0.14 // [0.00 0.06 0.10 0.14 0.18 0.25] Soft ray lobes in the mid glow; 0 = perfectly round glow
#define VEIL_STRENGTH 0.30 // [0.00 0.10 0.20 0.30 0.45 0.60] Warm veil over terrain and clouds near the visible sun
#define RIM_STRENGTH 0.80 // [0.00 0.20 0.35 0.50 0.65 0.80 1.00] Warm rim on silhouette edges turned to the sun (0.80 = fitted to the reference rim)
#define RIM_REACH 1.50 // [0.50 0.75 1.00 1.25 1.50 2.00 2.50] Rim taps reach: 1.00 = 2 to 14 pixels at 1080p (scaled with the resolution); 1.50 = the reference bleed; higher = wider soft bleed
#define RIM_TAPS 4 // [3 4 6] Sun-directed depth taps per rim pixel: 3 (LOW), 4, 6 (finest)
#define SHAFT_STRENGTH 0.10 // [0.00 0.05 0.10 0.15 0.20 0.30 0.45] Shafts through gaps; low = barely visible, like the reference
#define SHAFT_LENGTH 0.30 // [0.15 0.20 0.30 0.40 0.50] March length as a share of the distance to the sun (capped at half of it in screen heights)
#define SHAFT_SOFTNESS 0.50 // [0.25 0.35 0.50 0.70 1.00] Width of the Gaussian-like sample weights; higher = longer, softer shafts
#define SHAFT_SAMPLES 12 // [12 14 16] Fixed samples per quarter-resolution pixel (no jitter)
#define SUN_VISIBILITY_TAPS 13 // [9 13 21 29] Fixed depth taps around the sun for its visibility (vertex shader, once per frame)
#define SKY_DITHER 0.75 // [0.00 0.50 0.75 1.00 1.50] Static, invisible dither in 1/255 steps against banding; 0 = off (for testing)
#define SUN_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Angle / thin bloom / mid glow / wide halo / ray lobes / visibility / veil / rim / gradient / horizon-fog diff / cloud terms / fog amount / fog scatter / fog banks / dither x16 / banding test

// Moon sliders (Update 2A). The moon shares the sun's quality sliders (RIM_TAPS, SHAFT_SAMPLES,
// SUN_VISIBILITY_TAPS, SKY_DITHER): the same code and passes draw both.
#define MOON_LIGHT_INTENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Master for everything the moon adds (glow, halo, veil, rim, shafts, cloud patch, star dimming); 0 = none
#define MOON_GLOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Thin bloom and mid glow around the moon (1 = about 0.3 x the sun's glow at half its size)
#define MOON_GLOW_QUALITY 2 // [1 2] 1 = round glow; 2 = phase-aware glow (weaker beside the dark side of the disc)
#define MOON_HALO_SIZE 0.15 // [0.08 0.10 0.15 0.20 0.25 0.30] Wide moon halo radius in radians (0.15 = about 9 degrees, half the sun's)
#define MOON_HALO_STRENGTH 0.50 // [0.00 0.15 0.25 0.35 0.50 0.65 0.80] Wide halo: the night sky gets lighter around the moon
#define MOON_PHASE_INTENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00] How much the phase dims the moon light: 0 = every phase like a full moon, 1 = the measured lit share of the disc
#define MOON_VEIL_STRENGTH 0.06 // [0.00 0.03 0.06 0.10 0.15 0.20] Cool veil near the visible moon (0.06 = 0.2 x the sun's veil)
#define MOON_RIM_STRENGTH 0.25 // [0.00 0.10 0.15 0.20 0.25 0.30 0.40 0.50] Cool rim on edges turned to the moon (0.25 = about 0.3 x the sun's rim)
#define MOON_SHAFT_STRENGTH 0.015 // [0.000 0.010 0.015 0.025 0.040 0.060] Moon shafts through gaps (0.015 = 0.15 x the sun's shafts)
#define MOON_COLOR_COOLNESS 0.50 // [0.00 0.25 0.50 0.75 1.00] Moon colours: 0 = neutral cool white, 0.5 = cool blue, 1 = blue-violet
#define MOON_BIOME_TINT_STRENGTH 0.30 // [0.00 0.15 0.30 0.50 0.75 1.00] Biome tint of the moon light (jungle teal, desert warmer, snowy icy blue, swamp dim green-grey)
#define CLOUD_MOON_GLOW_THROUGH 0.20 // [0.00 0.10 0.20 0.30 0.45 0.60] Soft silver patch on a cloud in front of the moon (replaces the sky glow there)
#define MOON_STAR_DIMMING 0.50 // [0.00 0.25 0.50 0.75 1.00] Stars fade softly near the moon glow (only near the moon, never across the sky)
#define NIGHT_SKY_DITHER 0.33 // [0.00 0.33 0.50 0.75 1.00] Extra anti-banding dither in dark regions at night (x SKY_DITHER); 0 = off (for testing)
#define MOON_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13] Day weights / moon position / thin bloom / mid glow / halo / moon visibility / veil / rim / shafts x32 / cloud over the moon / moon total / dark banding test / sun identity check

// Block lighting sliders (Update 2B, change A: directional face lighting).
#define FACE_LIGHTING_QUALITY 2 // [1 2] Sky and torch share of the light: 1 = estimated, 2 = exact from the lightmap (one extra lightmap read)
#define FACE_CONTRAST 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] How much darker faces turned away from the sun get in clear daylight (1 = about 1.4 to 1.55 x between the lit and the shaded side)
#define SHADE_FLOOR 0.45 // [0.30 0.35 0.40 0.45 0.50 0.60 0.70] Minimum light of a shaded face, as a share of the flat light: faces never go darker
#define DIRECTIONAL_WRAP 0.08 // [0.00 0.04 0.08 0.12 0.16 0.25] Soft wrap of the sun light around the edge between lit and shaded
#define MOON_FACE_CONTRAST 0.30 // [0.00 0.15 0.30 0.45 0.60] Face contrast from the moon at night, as a share of the day contrast (also scales the night glints)
#define PLANT_NORMAL_UP_BLEND 0.70 // [0.00 0.25 0.50 0.70 0.85 1.00] Cross-shaped plants are lit as if facing up (no dark backs, no flicker)
#define AMBIENT_AMOUNT_BIAS 0.00 // [-0.10 -0.05 0.00 0.05 0.10] Small lift (+) or cut (-) of the sky ambient on shaded faces in sunlight

// Block micro-detail sliders (Update 2B, change B).
#define MICRO_DETAIL_QUALITY 2 // [1 2] 1 = glints only on sand and red sand (no per-texel hash elsewhere), leaves without waxy glints; 2 = every group
#define GLITTER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Glitter blocks: glint brightness
#define SHEEN_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Sheen blocks: brightness of the lit lighter texels
#define GLOSS_BLOCK_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Gloss blocks: glints, sheen and sky reflection (GLOSS_STRENGTH is the entity plastic)
#define FOLIAGE_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00] Leaves and foliage: sun-caught texels and waxy glints
#define GLINT_DENSITY_SCALE 1.00 // [0.25 0.50 0.60 0.75 1.00 1.50 2.00] How many texels can glint (never more than MAX_GLINT_COVERAGE)
#define BLOCK_GLINT_SIZE 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] Glint size: lower = sharper and rarer, higher = softer and more often lit
#define GLINT_ANGLE_STEPS 12 // [8 12 16 24 32] Glints switch in steps of the view angle: fewer = calmer, more = smoother motion
#define DETAIL_THRESHOLD 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] How much lighter than its texture a texel must be to catch the light (higher = fewer)
#define MAX_GLINT_COVERAGE 0.12 // [0.04 0.08 0.12 0.16 0.20 0.30] Largest share of texels per face that can ever glint
#define GLINT_FADE_START 16 // [8 12 16 24 32] Glints start to fade at this distance (blocks)
#define GLINT_FADE_END 48 // [24 32 48 64 96] Glints are gone at this distance (blocks)
#define TORCH_GLINT 0.05 // [0.00 0.05 0.10 0.20 0.35] Tiny warm glints where torchlight lights the block
#define BLOCK_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17] Normal / N.L / sun-facing / direct / ambient / vanilla face shade / material / texel id / detail D / glint raw / glint levels / footprint fade / distance fade / sheen / micro-detail / before-after split / face light

// Biome ambience sliders.
#define BIOME_SKY_STRENGTH 0.85 // [0.00 0.25 0.50 0.70 0.85 1.00] Biome tint of the mid sky
#define BIOME_FOG_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Biome tint of the horizon and the fog (one colour)
#define BIOME_CLOUD_TINT_STRENGTH 0.80 // [0.00 0.25 0.50 0.80 1.00] Biome tint of the clouds
#define BIOME_ZENITH_SHIFT 0.35 // [0.00 0.15 0.25 0.35 0.50 0.75 1.00] How much the zenith follows the biome (the sky stays blue)
#define BIOME_DENSITY_MULTIPLIER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] How much the biome fog density, height falloff and sun-scatter multipliers apply
#define BIOME_TRANSITION_TIME 10 // [4 6 8 10 12 16] Seconds the ambience takes to follow a new biome
#define BIOME_WARM_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of desert, savanna and badlands
#define BIOME_COLD_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of snowy lowlands, taiga and snowy peaks
#define BIOME_HUMID_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of jungle and swamp
#define BIOME_OCEAN_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25] Biome look of oceans, rivers and beaches
#define FORCE_BIOME_PREVIEW 0 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Debug: force one biome family (0 = off; numbers in the README)
#define BIOME_DEBUG_MODE 1 // [1 2 3 4 5 6] Family weights / palette swatches / horizon-fog diff / fog density / transition / palette table

// Ambience sliders.
#define ENV_WARMTH 0.50 // [0.00 0.25 0.50 0.75 1.00] Warm sunlight on lit surfaces
#define ENV_SHADOW_COOLNESS 0.60 // [0.00 0.25 0.40 0.60 0.80 1.00] Cool, soft sky light in shade (warm sand and rock resist it)
#define ENV_VIBRANCE 0.15 // [0.00 0.08 0.15 0.25 0.35] Gentle vibrance on dull colours, with a neon clamp
#define ENV_SNOW_TINT 0.60 // [0.00 0.30 0.60 1.00] Slight blue on snow and ice, with a highlight shoulder
#define ENV_DISTANCE_DESATURATION 0.60 // [0.00 0.30 0.45 0.60 0.80 1.00] Far terrain loses saturation inside the fog
#define ENV_LAVENDER 1.00 // [0.00 0.50 1.00 1.50] Lavender tone of the haze and horizon
#define CLOUD_OPACITY 1.00 // [0.40 0.50 0.55 0.65 0.75 0.85 0.95 1.00] Opacity of the cloud body; 1 = the sun, moon and stars are hidden behind clouds, 0.65 = the previous translucent look
#define CLOUD_SUN_GLOW_THROUGH 0.45 // [0.00 0.15 0.30 0.45 0.60 0.80] Soft bright patch on a cloud around the sun behind it (replaces the sky glow there)
#define CLOUD_TINT 1.00 // [0.00 0.50 0.75 1.00] Sky-derived cloud colour versus the vanilla cloud colour
#define CLOUD_BRIGHTNESS 1.00 // [0.80 0.90 1.00 1.10 1.20] Lit cloud faces: mix of the horizon colour toward lavender white
#define CLOUD_EDGE_HIGHLIGHT 0.50 // [0.00 0.25 0.50 0.75 1.00] Lighter, denser cloud side faces, which read as thin outlines
#define CLOUD_UNDERSIDE_DARKNESS 0.55 // [0.00 0.25 0.40 0.55 0.70 0.85 1.00] Cooler, deeper cloud undersides
#define CLOUD_SUN_LIGHT 0.20 // [0.00 0.10 0.20 0.30 0.45] Soft brightening of cloud faces turned to the sun
#define CLOUD_SHADOW_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00] Darkness of the cloud shadows (direct sun only)
#define CLOUD_SHADOW_SOFTNESS 0.50 // [0.00 0.25 0.50 0.75 1.00] Penumbra width (quality 2); 1 = a full 12-block ramp
#define CLOUD_SHADOW_GRID 2 // [0 1 2 4] Block grid the shadow edges step on; 0 = smooth
#define CLOUD_SHADOW_QUALITY 2 // [1 2] 1 = one fetch, hard cells; 2 = four fetches, soft edges
#define FOG_DENSITY 0.010 // [0.002 0.004 0.006 0.008 0.010 0.012 0.015 0.020] Fog density per block at the base height
#define FOG_HEIGHT_FALLOFF 0.035 // [0.010 0.020 0.035 0.050 0.070 0.100] How fast the fog thins with height
#define FOG_BASE_HEIGHT 63 // [40 50 63 70 80 96] World height of the densest fog layer
#define FOG_START 32 // [0 16 24 32 40 48 64] Blocks kept clear around the camera
#define FOG_END 1.00 // [0.70 0.80 0.90 1.00] Share of the render distance where the fog becomes opaque
#define FOG_BANK_QUALITY 1 // [0 1 2] Fog banks: 0 = off, 1 = one smooth noise sample, 2 = two smooth samples (more detail)
#define FOG_BANK_STRENGTH 0.30 // [0.00 0.15 0.30 0.45 0.65] Thickness variation of the fog banks (kept small: no visible grain)
#define FOG_BANK_SCALE 48 // [24 32 48 64 96 128] Fog bank cell size in blocks
#define FOG_DRIFT_SPEED 0.40 // [0.00 0.20 0.40 0.80 1.50] Fog bank drift in blocks per second
#define FOG_SUN_SCATTER 0.60 // [0.00 0.30 0.60 0.90 1.20] Haze glow around the sun (same falloff as the wide halo)
#define FOG_LEVELS 10 // [8 10 12] Fog steps for the banded look
#define AMBIENCE_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16] Fog / fog colour / banks / scatter / perspective / cloud mask / cloud shadow / cloud UV / sky / sky-fog diff / refl colour / refl valid / refl fog / refl split / grade split / cloud alignment

// Shadow colour sliders (terrain receivers; entities, water and the gloss are untouched).
#define SHADOW_COLOR_QUALITY 2 // [1 2] 1 = ambient tint only, 2 = + surface response (snow bluer, sand lilac, stone cool, grass blue-green, wood and dirt darker) and saturation
#define SHADOW_COLOR_SATURATION 0.15 // [0.00 0.08 0.15 0.25 0.35] Mild, luminance-preserving saturation boost in shade (neon clamp)
#define SHADOW_HUE_PUSH 0.50 // [0.00 0.25 0.50 0.75 1.00] Hue push of shaded colours toward the ambient sky light
#define SHADOW_MIN_DARKNESS 0.25 // [0.00 0.15 0.25 0.35 0.50] Entity shadow darkness left under clouds, overcast and rain (share of the full darkness)
#define SHADOW_MAX_DARKNESS 1.00 // [0.60 0.70 0.80 0.90 1.00] Entity shadow darkness in full sun (1 = as dark as terrain shadows, the previous look)
#define ENTITY_SHADOW_COLOR_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Shadow colour on player and mob shadows
#define TERRAIN_SHADOW_COLOR_STRENGTH 0.60 // [0.00 0.30 0.45 0.60 0.80 1.00] Shadow colour on terrain shadows and shaded faces (gentle: the approved terrain look)

// Underwater caustic sliders.
#define UNDERWATER_CAUSTIC_STRENGTH 0.80 // [0.00 0.40 0.60 0.80 1.00 1.20] Caustics seen with the camera underwater, relative to the outside view
#define UNDERWATER_SEA_LEVEL 63 // [56 60 62 63 64 66 70] Fallback water surface height when no sky light reaches the eye (oceans)
#define LIGHT_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17] V+cloud cover / sky mask / rim / shafts / cloud mask+depth / hidden by cloud / sun strength / shadow split / shadow ambient / entity flag / eye in water / camera depth / surface height / water flag / depth fade / fog transmittance / caustic light

#define MATCH_STRENGTH 65 // [0 10 20 25 35 42 50 65 80 82 100] 0=current pack, 100=full golden-hour reference
#define GOLDEN_HAZE_STRENGTH 0.22 // [0.00 0.08 0.14 0.22 0.30 0.42 0.55] Added target haze blend
#define GOLDEN_HAZE_PHASE 0.35 // [0.00 0.10 0.20 0.35 0.50 0.70] Sun-facing haze glow
#define GOLDEN_GRADE_STRENGTH 0.12 // [0.00 0.04 0.08 0.12 0.18 0.24] Extra golden-hour scene grade
#define GOLDEN_SHADOW_LIFT 0.025 // [0.000 0.010 0.020 0.025 0.040 0.060] Low-sun warm shadow lift
#define GOLDEN_BACKLIGHT_STRENGTH 0.10 // [0.00 0.04 0.07 0.10 0.15 0.22] Warm mapped-foliage edge light
#define GOLDEN_BLOOM_BLOCKINESS 0.75 // [0.00 0.25 0.50 0.75 1.00] Pixelation of existing bloom source
#define GOLDEN_BLOOM_PIXEL_SIZE 16 // [8 12 16 20 24 32] Screen-pixel bloom-source grid
#define GOLDEN_VIGNETTE_STRENGTH 0.025 // [0.00 0.010 0.020 0.025 0.040 0.060] Extra edge falloff
#define GOLDEN_SKY_TINT_STRENGTH 0.70 // [0.00 0.20 0.40 0.55 0.70 0.85 1.00] Golden-hour sky tint
#define FAKE_BIRD_AMOUNT 0.65 // [0.00 0.20 0.40 0.65 0.85 1.00] Sparse procedural bird visibility
#define FAKE_BIRD_SIZE 7 // [4 5 6 7 8 10] Bird silhouette width in screen pixels
#define FAKE_BIRD_SPEED 0.0025 // [0.0000 0.0010 0.0025 0.0040 0.0060] Screen drift per frame-time second
#define TARGET_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8] Sun glow (new) / (removed: black) / sky / fog / phase / (removed rays: black) / bloom / grade

const int shadowMapResolution = 1536; // [768 1024 1280 1536 2048 3072] Shadow map resolution
const float shadowDistance = 80.0; // [48.0 64.0 72.0 80.0 88.0 96.0] Shadow distance in blocks
const float shadowDistanceRenderMul = 1.0;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;

// Debug views force the features they inspect. These lines repeat the option names with the
// same default, so Iris merges them with the declarations above.
#if defined(REFLECTION_DEBUG) && !defined(WATER_SKY_REFLECTION)
#define WATER_SKY_REFLECTION
#endif
#if defined(REFLECTION_DEBUG) && !defined(WATER_SSR)
#define WATER_SSR
#endif
#if defined(WATER_SSR) && !defined(WATER_SKY_REFLECTION)
#undef WATER_SSR
#endif
#if defined(WAVE_DEBUG) && !defined(WAVE_LIGHTING)
#define WAVE_LIGHTING
#endif
#if defined(CAUSTICS_DEBUG) && !defined(PIXEL_CAUSTICS)
#define PIXEL_CAUSTICS
#endif

#ifdef TARGET_DEBUG
#ifndef GOLDEN_TARGET_SKY
#define GOLDEN_TARGET_SKY
#endif
#ifndef GOLDEN_TARGET_HAZE
#define GOLDEN_TARGET_HAZE
#endif
#ifndef GOLDEN_TARGET_GRADE
#define GOLDEN_TARGET_GRADE
#endif
#ifndef GOLDEN_BLOCKY_BLOOM
#define GOLDEN_BLOCKY_BLOOM
#endif
#ifndef BLOOM
#define BLOOM
#endif
#endif

#if defined(ATMOS_DEBUG)
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#if ATMOS_DEBUG_MODE == 6 && !defined(BLOOM)
#define BLOOM
#endif
#endif

#if defined(VV_DEBUG)
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#ifndef BLOOM
#define BLOOM
#endif
#ifndef PIXEL_SHADOWS
#define PIXEL_SHADOWS
#endif
#ifndef EMISSIVE_BLOCKS
#define EMISSIVE_BLOCKS
#endif
#endif

#if defined(AMBIENCE_DEBUG)
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#if (AMBIENCE_DEBUG_MODE >= 6 && AMBIENCE_DEBUG_MODE <= 8) && !defined(CLOUD_SHADOW_ENABLE)
#define CLOUD_SHADOW_ENABLE
#endif
#if (AMBIENCE_DEBUG_MODE >= 11 && AMBIENCE_DEBUG_MODE <= 14) && !defined(WATER_SSR) && defined(WATER_SKY_REFLECTION)
#define WATER_SSR
#endif
#endif

#if defined(SUN_DEBUG)
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#ifndef SUN_GLOW
#define SUN_GLOW
#endif
#if SUN_DEBUG_MODE == 5 && !defined(SUN_RAYS)
#define SUN_RAYS
#endif
#if (SUN_DEBUG_MODE == 6 || SUN_DEBUG_MODE == 7) && !defined(SUN_VEIL)
#define SUN_VEIL
#endif
#if SUN_DEBUG_MODE == 8 && !defined(SUN_EDGE_RIM)
#define SUN_EDGE_RIM
#endif
#endif

#if defined(BIOME_DEBUG)
#ifndef BIOME_AMBIENCE
#define BIOME_AMBIENCE
#endif
#ifndef AMBIENCE_COLORS
#define AMBIENCE_COLORS
#endif
#ifndef AMBIENCE_FOG
#define AMBIENCE_FOG
#endif
#endif

#if defined(LIGHT_DEBUG)
#if (LIGHT_DEBUG_MODE == 2 || LIGHT_DEBUG_MODE == 4) && !defined(SUN_SHAFTS)
#define SUN_SHAFTS
#endif
#if (LIGHT_DEBUG_MODE == 1 || LIGHT_DEBUG_MODE == 3) && !defined(SUN_EDGE_RIM)
#define SUN_EDGE_RIM
#endif
#if LIGHT_DEBUG_MODE >= 7 && LIGHT_DEBUG_MODE <= 10 && !defined(SHADOW_COLORS)
#define SHADOW_COLORS
#endif
#if LIGHT_DEBUG_MODE >= 11
#ifndef PIXEL_CAUSTICS
#define PIXEL_CAUSTICS
#endif
#ifndef CAUSTICS_UNDERWATER_FLOOR
#define CAUSTICS_UNDERWATER_FLOOR
#endif
#endif
#endif

#if defined(MOON_DEBUG)
#ifndef MOON_RAYS
#define MOON_RAYS
#endif
#if (MOON_DEBUG_MODE == 6 || MOON_DEBUG_MODE == 7) && !defined(MOON_VEIL)
#define MOON_VEIL
#endif
#if MOON_DEBUG_MODE == 8 && !defined(MOON_EDGE_RIM)
#define MOON_EDGE_RIM
#endif
#if MOON_DEBUG_MODE == 9 && !defined(MOON_SHAFTS)
#define MOON_SHAFTS
#endif
#endif

// Internal switches derived from the options above (not menu options).
// The moon's veil, rim and shafts are part of MOON_RAYS: off removes all of them. Its debug
// views need the moon code too (the forcing line above cannot bring MOON_RAYS back once it is
// switched off in the menu, because Iris rewrites every declaration line of an option).
#ifndef MOON_RAYS
#undef MOON_VEIL
#undef MOON_EDGE_RIM
#undef MOON_SHAFTS
#undef MOON_DEBUG
#endif
// Biome amount of the water's own Tier-1 reflection palette (gbuffers.vsh), and a separate
// biome-free palette in final for the screen reflection when the water must not follow it.
#if defined(BIOME_AMBIENCE) && defined(BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION)
#define AMB_WATER_BIOME 1.0
#else
#define AMB_WATER_BIOME 0.0
#endif
#if defined(BIOME_AMBIENCE) && !defined(BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION)
#define AMB_WATER_OWN_PALETTE
#endif
// BIOME_TRANSITION_TIME is used in shaders.properties only (the smoothing time of the
// biome uniforms); this reference keeps it visible to Iris.
#if BIOME_TRANSITION_TIME > 0
#endif
#if defined(WATER_REFLECTION_IMPROVEMENT) && !defined(WATER_SKY_REFLECTION)
#undef WATER_REFLECTION_IMPROVEMENT
#endif
// The cloud cell texture is read by the cloud shadows and by the improved cloud reflection.
#if defined(VANILLA_CLOUD_CELLS) && (defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT))
#define AMB_CLOUD_TEXTURE
#endif
// The sun visibility (fixed depth taps in final.vsh) feeds the veil and the edge rim.
#if defined(SUN_VEIL) || defined(SUN_EDGE_RIM)
#define AMB_SUN_VISIBILITY
#endif
// The moon's visibility (the same taps, at the moon's size) feeds its veil and rim.
#if defined(MOON_VEIL) || defined(MOON_EDGE_RIM)
#define AMB_MOON_VISIBILITY
#endif
// Shared ray code: the rim gather and the shaft pass serve the sun and the moon.
#if defined(SUN_EDGE_RIM) || defined(MOON_EDGE_RIM)
#define RAYS_EDGE_RIM
#endif
#if defined(SUN_SHAFTS) || defined(MOON_SHAFTS)
#define RAYS_SHAFTS
#endif
// Iris lists a Boolean option only if some shader source tests it with #ifdef/#ifndef
// (#if defined() does not count). These options are otherwise used only in #if expressions
// or in shaders.properties, so they get an explicit, empty reference here.
#ifdef ENTITY_SHADOWS
#endif
#ifdef PIXEL_WATER_SPARKLES
#endif
#ifdef CAUSTICS_UNDERWATER_FLOOR
#endif
#ifdef VANILLA_CLOUD_CELLS
#endif
#ifdef SUN_SHAFTS
#endif
#ifdef CLOUDS_BLOCK_SUN
#endif
#ifdef SHADOW_COLORS
#endif
#ifdef ENTITY_SHADOW_FLAG
#endif
#ifdef LIGHT_DEBUG
#endif
#ifdef MOON_RAYS
#endif
#ifdef MOON_VEIL
#endif
#ifdef MOON_EDGE_RIM
#endif
#ifdef MOON_SHAFTS
#endif
#ifdef MOON_DEBUG
#endif
#ifdef BLOCK_DEBUG
#endif
#ifdef PREVIOUS_SUN_LIFT
#endif
// Update 2B: the micro-detail runs only when at least one block group is on.
#if !defined(GLITTER_BLOCKS) && !defined(SHEEN_BLOCKS) && !defined(GLOSS_BLOCKS) && !defined(FOLIAGE_SPARKLE)
#undef BLOCK_MICRO_DETAIL
#endif
// Terrain programs read the entity flag only where entities are in the shadow map at all.
#if defined(SHADOW_COLORS) && defined(ENTITY_SHADOW_FLAG) && defined(ENTITY_SHADOWS)
#define SHADOW_ENTITY_FLAG_READ
#endif
