#version 330 compatibility

// Shadow pass for entities (Iris program shadow_entities; without it Iris uses shadow.vsh).
// Identical to shadow.vsh: same projection, same distortion, same shadow-map position.

#include "/lib/shadow_distortion.glsl"

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    gl_Position = ftransform();
    gl_Position.xyz = distortShadowClip(gl_Position.xyz);
}
