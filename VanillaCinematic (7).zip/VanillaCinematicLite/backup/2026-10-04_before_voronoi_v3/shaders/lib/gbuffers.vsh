uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;

#if defined(WATER_GBUFFER) || defined(TERRAIN_GBUFFER)
in vec2 mc_Entity;
#endif

#include "/lib/shadow_distortion.glsl"

out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vNormalView;
out vec3 vWorldPosition;
out vec3 vPlayerPosition;
out vec4 vShadowClip;
out vec3 vViewPosition;
out vec3 vWorldNormal;
out float vIsFluid;
out float vSunElevation;
out float vViewDistance;
out float vIsFoliage;
out float vIsThin;
out float vMaterialGroup;

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPosition = gbufferModelViewInverse * viewPosition;

    gl_Position = gl_ProjectionMatrix * viewPosition;
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;
    vec3 transformedNormal = gl_NormalMatrix * gl_Normal;
    vNormalView = transformedNormal * inversesqrt(max(dot(transformedNormal, transformedNormal), 0.000001));
    vWorldNormal = mat3(gbufferModelViewInverse) * vNormalView;
    vViewPosition = viewPosition.xyz;
    vViewDistance = length(viewPosition.xyz);
    vec3 worldSun = mat3(gbufferModelViewInverse) * sunPosition;
    vSunElevation = worldSun.y * inversesqrt(max(dot(worldSun, worldSun), 0.000001));
    vWorldPosition = cameraPosition + playerPosition.xyz;
    vPlayerPosition = playerPosition.xyz;
    vec4 shadowClip = shadowProjection * shadowModelView * playerPosition;
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    vShadowClip = shadowClip;
    vIsFluid = 0.0;
    vIsFoliage = 0.0;
    vIsThin = 0.0;
    vMaterialGroup = 0.0;
#ifdef WATER_GBUFFER
    // Iris sets mc_Entity.y = 1 on fluid-renderer geometry (-1 on blocks). Lava renders in
    // the solid layer, so in this translucent program any fluid quad is water: source,
    // flowing, waterlogged blocks and every visible face. block.1 (ID 1) is a fallback.
    vIsFluid = (mc_Entity.y > 0.5 || abs(mc_Entity.x - 1.0) < 0.5) ? 1.0 : 0.0;
    vMaterialGroup = mc_Entity.x;
    vIsThin = mc_Entity.x == 8.0 ? 1.0 : 0.0;
#endif
#ifdef TERRAIN_GBUFFER
    vMaterialGroup = mc_Entity.x;
    vIsFoliage = mc_Entity.x == 2.0 ? 1.0 : 0.0;
    vIsThin = (mc_Entity.x == 3.0 || mc_Entity.x == 8.0) ? 1.0 : 0.0;
#endif
}

