#include "/lib/settings.glsl"
#include "/lib/shadow_distortion.glsl"

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform float alphaTestRef;
uniform float rainStrength;
uniform float wetness;
uniform float frameTimeCounter;
uniform float fogStart;
uniform float fogEnd;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float atmosOverworld;
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform int isEyeInWater;

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_WATER_SPARKLES) || defined(PIXEL_SHADOWS)
uniform vec3 cameraPositionFract;
#endif

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_SHADOWS)
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
#endif

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_WATER_SPARKLES)
uniform ivec3 cameraPositionInt;
#endif

#ifdef PIXEL_CAUSTICS
uniform sampler2D depthtex1;
uniform sampler2D shadowtex1;
uniform mat4 gbufferProjectionInverse;
uniform ivec2 eyeBrightnessSmooth;
#endif

in vec2 vTexCoord;
in vec2 vLightCoord;
in vec4 vColor;
in vec3 vNormalView;
in vec3 vWorldPosition;
in vec3 vPlayerPosition;
in vec4 vShadowClip;
in vec3 vViewPosition;
in vec3 vWorldNormal;
in float vIsFluid;
in float vSunElevation;
in float vViewDistance;
in float vIsFoliage;
in float vIsThin;
in float vMaterialGroup;

vec3 safeNormalize(vec3 value) {
    return value * inversesqrt(max(dot(value, value), 0.000001));
}

float fastGlossCurve(float x) {
    float x2 = x * x;
    float x4 = x2 * x2;
    float x8 = x4 * x4;
    float x16 = x8 * x8;
#if HIGHLIGHT_SIZE <= 12
    return x8 * x4;
#elif HIGHLIGHT_SIZE <= 16
    return x16;
#elif HIGHLIGHT_SIZE <= 20
    return x16 * x4;
#elif HIGHLIGHT_SIZE <= 24
    return x16 * x8;
#elif HIGHLIGHT_SIZE <= 28
    return x16 * x8 * x4;
#elif HIGHLIGHT_SIZE <= 32
    return x16 * x16;
#elif HIGHLIGHT_SIZE <= 36
    return x16 * x16 * x4;
#elif HIGHLIGHT_SIZE <= 42
    return x16 * x16 * x8;
#else
    return x16 * x16 * x16;
#endif
}

float fastPowerFive(float x) {
    float x2 = x * x;
    return x2 * x2 * x;
}

float fastPowerFortyEight(float x) {
    float x2 = x * x;
    float x4 = x2 * x2;
    float x8 = x4 * x4;
    float x16 = x8 * x8;
    float x32 = x16 * x16;
    return x32 * x16;
}

float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

float getShadow(vec4 shadowClip, float ndotl, vec3 playerPosition, vec3 normalWorld) {
#ifdef PIXEL_SHADOWS
    // Snap the receiver on a world-anchored 16-texel/block plane before projection.
    // cameraPositionFract preserves the block-grid phase without large-float jitter.
    vec3 worldPhase = cameraPositionFract + playerPosition;
    vec3 absNormal = abs(normalWorld);
    float cells = float(SHADOW_PIXEL_GRID);
    if (absNormal.y >= max(absNormal.x, absNormal.z)) {
        worldPhase.xz = floor(worldPhase.xz * cells) / cells;
    } else if (absNormal.x >= absNormal.z) {
        worldPhase.zy = floor(worldPhase.zy * cells) / cells;
    } else {
        worldPhase.xy = floor(worldPhase.xy * cells) / cells;
    }
    vec3 snappedPlayer = worldPhase - cameraPositionFract + normalWorld * 0.008;
    shadowClip = shadowProjection * shadowModelView * vec4(snappedPlayer, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
#endif
    vec3 ndc = shadowClip.xyz / max(shadowClip.w, 0.00001);
    vec3 coord = ndc * 0.5 + 0.5;
    if (coord.x < 0.0 || coord.x > 1.0 || coord.y < 0.0 || coord.y > 1.0 || coord.z < 0.0 || coord.z > 1.0) {
        return 1.0;
    }

    float bias = 0.00065 + (1.0 - clamp(ndotl, 0.0, 1.0)) * 0.00085;
    vec2 texel = vec2(1.0 / float(shadowMapResolution));
#ifdef PIXEL_SHADOWS
    coord.xy = clamp((floor(coord.xy * float(shadowMapResolution)) + 0.5) * texel,
                     texel * 0.5, vec2(1.0) - texel * 0.5);
#endif
    // Interleave a tiny half-pixel kernel shift across the screen; no noise fetch or trig.
    vec2 jitter = (fract(gl_FragCoord.xy * 0.5) - vec2(0.25)) * 0.5;
    float visible = 0.0;
#if SHADOW_QUALITY == 1
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy).r);
    return visible;
#elif SHADOW_QUALITY == 2
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-0.5, -0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.5, -0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-0.5,  0.5) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.5,  0.5) + jitter)).r);
    return visible * 0.25;
#else
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0, -1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0,  0.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0,  0.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2(-1.0,  1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 0.0,  1.0) + jitter)).r);
    visible += step(coord.z - bias, texture(shadowtex0, coord.xy + texel * (vec2( 1.0,  1.0) + jitter)).r);
    return visible * 0.125;
#endif
}

// Written by the caustic route, consumed by the water program's output blend:
// rgb = visible-space caustic light, a = screen factor for the transmitted floor.
vec4 gCausticLight = vec4(0.0);

#if defined(PIXEL_CAUSTICS) || defined(PIXEL_WATER_SPARKLES)
// 240 blocks keeps 240 * TEXELS_PER_BLOCK divisible by every noise cell size
// (lcm(3, 4, 5, 6, 8) = 120), so the cell lattice tiles without a seam.
const int CAUSTIC_WRAP_BLOCKS = 240;

vec3 causticWrapWorld(vec3 cameraRelativePosition) {
    // 30,000,000 is a multiple of 240 beyond the world border, so the integer remainder
    // only sees non-negative operands (GLSL leaves % undefined for negative values).
    vec3 cameraWrapped = vec3((cameraPositionInt + ivec3(30000000)) % ivec3(CAUSTIC_WRAP_BLOCKS));
    return mod(cameraWrapped + cameraPositionFract + cameraRelativePosition, float(CAUSTIC_WRAP_BLOCKS));
}
#endif

#ifdef PIXEL_CAUSTICS
const int CAUSTIC_PERIOD = CAUSTIC_WRAP_BLOCKS * TEXELS_PER_BLOCK;
const uint CAUSTIC_KEEP = uint(LINE_DENSITY * 256.0);

// Integer hash (lowbias32 finalizer): a handful of integer ALU ops, no texture.
uint causticHash(ivec2 cell, uint seed) {
    uint h = uint(cell.x) * 0x8DA6B343u ^ uint(cell.y) * 0xD8163841u ^ seed * 0xCB1AB31Fu;
    h ^= h >> 16u;
    h *= 0x7FEB352Du;
    h ^= h >> 15u;
    h *= 0x846CA68Bu;
    h ^= h >> 16u;
    return h;
}

// One piecewise-constant noise cell (one hash per cell, nearest neighbour).
// Layer A staggers each cell row along x and layer B each column along y, so
// boundaries form staircases and T-junctions instead of a regular grid.
uint causticCellHash(ivec2 p, int cellSize, bool staggerRows, uint seed, float stepTime) {
    int lane = (staggerRows ? p.y : p.x) / cellSize;
    int shift = int((uint(lane) * 0x9E3779B1u + seed) >> 28u) % cellSize;
    if (staggerRows) p.x = (p.x + shift) % CAUSTIC_PERIOD;
    else p.y = (p.y + shift) % CAUSTIC_PERIOD;
    ivec2 cell = p / cellSize;
    uint cellSeed = seed;
#ifdef CAUSTIC_MORPH
    // Each cell re-rolls at its own hashed moment: the net morphs cell by cell
    // instead of popping as a whole, which also hides the drift loop.
    float phase = float((uint(cell.x) * 0x9E3779B1u ^ uint(cell.y) * 0x85EBCA77u) >> 24u) * (1.0 / 256.0);
    cellSeed += uint(floor(stepTime / float(MORPH_SECONDS) + phase)) * 0x632BE5ABu;
#endif
    return causticHash(cell, cellSeed);
}

// Outline of one layer. A texel is a line pixel when its quantized cell value
// (2 bits, i.e. floor(n * 4)) differs from the texel to the right or below and that
// cell edge survives the LINE_DENSITY keep test, which opens rectangles into
// brackets and L-shapes. Returns x = line, y = corner (right and bottom edges meet).
vec2 causticLayer(ivec2 t, int cellSize, bool staggerRows, uint seed, float stepTime) {
    uint c  = causticCellHash(t, cellSize, staggerRows, seed, stepTime);
    uint cr = causticCellHash(ivec2((t.x + 1) % CAUSTIC_PERIOD, t.y), cellSize, staggerRows, seed, stepTime);
    uint cb = causticCellHash(ivec2(t.x, (t.y + 1) % CAUSTIC_PERIOD), cellSize, staggerRows, seed, stepTime);
    bool right = ((c ^ cr) & 3u) != 0u && ((c >> 2u) & 255u) < CAUSTIC_KEEP;
    bool below = ((c ^ cb) & 3u) != 0u && ((c >> 10u) & 255u) < CAUSTIC_KEEP;
    bool line = right || below;
#if LINE_THICKNESS == 2
    // Second comparison offset: also mark the texel on the far side of each kept edge.
    uint cl = causticCellHash(ivec2((t.x + CAUSTIC_PERIOD - 1) % CAUSTIC_PERIOD, t.y), cellSize, staggerRows, seed, stepTime);
    uint cu = causticCellHash(ivec2(t.x, (t.y + CAUSTIC_PERIOD - 1) % CAUSTIC_PERIOD), cellSize, staggerRows, seed, stepTime);
    line = line || (((cl ^ c) & 3u) != 0u && ((cl >> 2u) & 255u) < CAUSTIC_KEEP)
                || (((cu ^ c) & 3u) != 0u && ((cu >> 10u) & 255u) < CAUSTIC_KEEP);
#endif
    return vec2(line ? 1.0 : 0.0, (right && below) ? 1.0 : 0.0);
}

struct CausticSample {
    float lineA;
    float lineB;
    float combined;
    int level; // 0 base, 1 mid, 2 light, 3 peak
};

// Orthogonal pixel network on the integer texel grid of one face plane.
CausticSample causticPattern(vec2 faceCoord, uint faceSeed) {
    float stepTime = floor(frameTimeCounter * float(STEPS_PER_SECOND)) / float(STEPS_PER_SECOND);
    ivec2 t = ivec2(floor(faceCoord * float(TEXELS_PER_BLOCK))) % CAUSTIC_PERIOD;
    // Flip-book drift in whole texels; float mod keeps negative directions in range.
    vec2 dirA = vec2(cos(radians(float(DRIFT_DIRECTION))), sin(radians(float(DRIFT_DIRECTION))));
    ivec2 offsetA = ivec2(mod(floor(stepTime * DRIFT_SPEED * dirA), float(CAUSTIC_PERIOD)));
    ivec2 tA = (t + offsetA) % CAUSTIC_PERIOD;
    vec2 layerA = causticLayer(tA, NOISE_CELL_SIZE_A, true, faceSeed, stepTime);
#if CAUSTIC_LAYERS == 2
    // Layer B drifts slower along a direction rotated by about 127 degrees, so the
    // two nets slide past each other and their crossings re-form every step.
    vec2 dirB = vec2(-0.6 * dirA.x - 0.8 * dirA.y, 0.8 * dirA.x - 0.6 * dirA.y);
    ivec2 offsetB = ivec2(mod(floor(stepTime * DRIFT_SPEED * 0.7 * dirB) + 37.0, float(CAUSTIC_PERIOD)));
    ivec2 tB = (t + offsetB) % CAUSTIC_PERIOD;
    vec2 layerB = causticLayer(tB, NOISE_CELL_SIZE_B, false, faceSeed ^ 0x5BD1E995u, stepTime);
#else
    vec2 layerB = vec2(0.0);
#endif
    // One per-texel hash attached to layer A, so peaks and isolated pixels drift with the net.
    float pick = float(causticHash(tA, faceSeed ^ 0x27D4EB2Fu) >> 8u) * (1.0 / 16777216.0);
    bool lineA = layerA.x > 0.5;
    bool lineB = layerB.x > 0.5;
    CausticSample result;
    result.lineA = layerA.x;
    result.lineB = layerB.x;
    result.combined = max(layerA.x, layerB.x);
    result.level = (lineA || lineB) ? 1 : 0;
    if ((lineA && lineB) || layerA.y > 0.5 || layerB.y > 0.5) result.level = 2;
    if (result.level == 2 && pick < PEAK_AMOUNT) result.level = 3;
    if (result.level == 0 && pick > 1.0 - ISOLATED_PIXELS) result.level = 2;
    return result;
}

// Visible-space light per level. Solved from swatches re-sampled in the reference
// (base #5D7586, mid #7F9093, light #94A199, peak #A7B19F) for the screen blend.
vec3 causticLevelColor(int level) {
    const vec3 MID = vec3(0.155, 0.133, 0.082);
    const vec3 LIGHT = vec3(0.250, 0.216, 0.125);
    vec3 peak = mix(vec3(0.280, 0.300, 0.310), vec3(0.340, 0.290, 0.170), WARMTH);
    if (level == 0) return MID * (1.0 - CONTRAST) * 0.5;
    return level == 1 ? MID : (level == 2 ? LIGHT : peak);
}

vec3 causticPlayerFromDepth(ivec2 pixel, float depth, vec2 screenSize) {
    vec2 uv = (vec2(pixel) + 0.5) / screenSize;
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
}

// Face axis of the opaque hit: 0 = X, 1 = Y, 2 = Z.
// Primary, zero taps: full-block faces lie exactly on integer world planes, so the axis
// whose coordinate sits on an integer (within depth precision) is the normal axis.
// Fallback for block edges (two axes near an integer), slabs and plants: the closer
// depth neighbour per screen axis, which stays on the same plane, and a cross product.
int causticFaceAxis(vec3 hitPlayer, ivec2 pixel, float hitDepth, vec2 screenSize) {
    vec3 phase = cameraPositionFract + hitPlayer;
    vec3 planeDist = abs(phase - floor(phase + 0.5));
    float tolerance = 0.002 + 3.0e-6 * dot(hitPlayer, hitPlayer);
    float nearest = min(planeDist.x, min(planeDist.y, planeDist.z));
    float farthest = max(planeDist.x, max(planeDist.y, planeDist.z));
    float second = planeDist.x + planeDist.y + planeDist.z - nearest - farthest;
    int axis = planeDist.y <= nearest ? 1 : (planeDist.x <= nearest ? 0 : 2);
    if (nearest < tolerance && second > tolerance) return axis;

    ivec2 maxPixel = ivec2(screenSize) - 1;
    ivec2 pixelL = clamp(pixel - ivec2(1, 0), ivec2(0), maxPixel);
    ivec2 pixelR = clamp(pixel + ivec2(1, 0), ivec2(0), maxPixel);
    ivec2 pixelD = clamp(pixel - ivec2(0, 1), ivec2(0), maxPixel);
    ivec2 pixelU = clamp(pixel + ivec2(0, 1), ivec2(0), maxPixel);
    float depthL = texelFetch(depthtex1, pixelL, 0).r;
    float depthR = texelFetch(depthtex1, pixelR, 0).r;
    float depthD = texelFetch(depthtex1, pixelD, 0).r;
    float depthU = texelFetch(depthtex1, pixelU, 0).r;
    bool useL = abs(depthL - hitDepth) < abs(depthR - hitDepth);
    bool useD = abs(depthD - hitDepth) < abs(depthU - hitDepth);
    ivec2 pixelH = useL ? pixelL : pixelR;
    ivec2 pixelV = useD ? pixelD : pixelU;
    float depthH = useL ? depthL : depthR;
    float depthV = useD ? depthD : depthU;
    if (depthH > 0.99999 || depthV > 0.99999) return axis;
    vec3 n = abs(cross(causticPlayerFromDepth(pixelH, depthH, screenSize) - hitPlayer,
                       causticPlayerFromDepth(pixelV, depthV, screenSize) - hitPlayer));
    if (dot(n, n) < 1.0e-12) return axis;
    return n.y >= max(n.x, n.z) ? 1 : (n.x >= n.z ? 0 : 2);
}

vec3 causticFaceNormal(int axis, float faceSign) {
    return axis == 0 ? vec3(faceSign, 0.0, 0.0) : (axis == 1 ? vec3(0.0, faceSign, 0.0) : vec3(0.0, 0.0, faceSign));
}

// Top/bottom faces use (x, z), X faces (z, y), Z faces (x, y): planar, so the net is
// continuous across block edges on one plane and never stretches on walls.
vec2 causticFaceCoord(vec3 wrappedWorld, int axis) {
    return axis == 0 ? wrappedWorld.zy : (axis == 1 ? wrappedWorld.xz : wrappedWorld.xy);
}

// A different seed per orientation keeps perpendicular and opposite faces unrelated.
uint causticFaceSeed(int axis, float faceSign) {
    return uint(axis * 2 + (faceSign > 0.0 ? 1 : 0) + 1) * 0x9E3779B9u;
}

// Floor: direct sun term. Walls: dimmer, fading below the surface, with a minimum
// sun-facing response so they never go fully dark. Ceilings get no direct caustics.
// A negative waterColumn means "unknown" (underwater-camera route).
float causticFaceMask(int axis, float faceSign, float ndotl, float waterColumn) {
    if (axis == 1) return faceSign > 0.0 ? ndotl : 0.0;
#ifdef CAUSTICS_WALLS
    float wallDepth = waterColumn < 0.0 ? 1.0 : 1.0 - smoothstep(0.0, WALL_DEPTH_FADE, waterColumn);
    return WALL_STRENGTH * wallDepth * ((1.0 - WALL_SUN_FACTOR) + WALL_SUN_FACTOR * ndotl);
#else
    return 0.0;
#endif
}

float singleReceiverShadow(vec3 playerPosition, vec3 normalWorld, float ndotl) {
    // The caustic fade ends well before LOW's shadow distance; avoid invalid samples beyond it.
    if (dot(playerPosition, playerPosition) > shadowDistance * shadowDistance) return 1.0;
#ifdef PIXEL_SHADOWS
    vec3 worldPhase = cameraPositionFract + playerPosition;
    vec3 absNormal = abs(normalWorld);
    float cells = float(SHADOW_PIXEL_GRID);
    if (absNormal.y >= max(absNormal.x, absNormal.z)) {
        worldPhase.xz = floor(worldPhase.xz * cells) / cells;
    } else if (absNormal.x >= absNormal.z) {
        worldPhase.zy = floor(worldPhase.zy * cells) / cells;
    } else {
        worldPhase.xy = floor(worldPhase.xy * cells) / cells;
    }
    playerPosition = worldPhase - cameraPositionFract + normalWorld * 0.008;
#endif
    vec4 clip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    clip.xyz = distortShadowClip(clip.xyz);
    if (clip.w <= 0.00001) return 1.0;
    vec3 coord = clip.xyz / clip.w * 0.5 + 0.5;
    if (coord.x < 0.0 || coord.x > 1.0 || coord.y < 0.0 || coord.y > 1.0 || coord.z < 0.0 || coord.z > 1.0) return 1.0;
    float bias = 0.00065 + (1.0 - clamp(ndotl, 0.0, 1.0)) * 0.00085;
#ifdef PIXEL_SHADOWS
    vec2 shadowTexel = vec2(1.0 / float(shadowMapResolution));
    coord.xy = clamp((floor(coord.xy * float(shadowMapResolution)) + 0.5) * shadowTexel,
                     shadowTexel * 0.5, vec2(1.0) - shadowTexel * 0.5);
#endif
    // Opaque-only depth prevents the transparent water surface from shadowing itself.
    return step(coord.z - bias, texture(shadowtex1, coord.xy).r);
}

#ifdef CAUSTICS_DEBUG
vec3 causticDebugView(int axis, vec2 faceCoord, CausticSample pattern, float waterColumn,
                      float submerged, float receiverShadow, vec3 light) {
#if CAUSTICS_DEBUG_MODE == 1
    return axis == 0 ? vec3(1.0, 0.15, 0.10) : (axis == 1 ? vec3(0.15, 1.0, 0.20) : vec3(0.15, 0.35, 1.0));
#elif CAUSTICS_DEBUG_MODE == 2
    ivec2 texelId = ivec2(floor(faceCoord * float(TEXELS_PER_BLOCK)));
    ivec2 blockId = ivec2(floor(faceCoord));
    float checker = ((texelId.x + texelId.y) & 1) == 0 ? 0.30 : 0.85;
    return checker * (((blockId.x + blockId.y) & 1) == 0 ? vec3(1.0, 0.45, 0.40) : vec3(0.40, 0.60, 1.0));
#elif CAUSTICS_DEBUG_MODE == 3
    return vec3(pattern.lineA);
#elif CAUSTICS_DEBUG_MODE == 4
    return vec3(pattern.lineB);
#elif CAUSTICS_DEBUG_MODE == 5
    return vec3(pattern.combined);
#elif CAUSTICS_DEBUG_MODE == 6
    return pattern.level == 0 ? vec3(0.06) : (pattern.level == 1 ? vec3(0.15, 0.45, 1.0) :
           (pattern.level == 2 ? vec3(0.20, 0.90, 0.30) : vec3(1.0, 0.85, 0.35)));
#elif CAUSTICS_DEBUG_MODE == 7
    return vec3(clamp(waterColumn / 12.0, 0.0, 1.0));
#elif CAUSTICS_DEBUG_MODE == 8
    return vec3(submerged);
#elif CAUSTICS_DEBUG_MODE == 9
    return vec3(receiverShadow);
#elif CAUSTICS_DEBUG_MODE == 10
    return light;
#else
    return vec3(0.0);
#endif
}
#endif

#endif

vec4 shadeFragment(out vec3 causticsDebug) {
    causticsDebug = vec3(0.0);
#ifdef CAUSTICS_DEBUG
#if CAUSTICS_DEBUG_MODE == 11 && defined(WATER_LAYER)
    // White means mc_Entity classified this rendered fragment as water.
    causticsDebug = vec3(vIsFluid > 0.5 ? 1.0 : 0.0);
#endif
#endif
    vec4 texel = texture(gtexture, vTexCoord) * vColor;
    if (texel.a < alphaTestRef) discard;

    vec2 lightCoord = clamp(vLightCoord, vec2(0.0), vec2(1.0));
    vec3 vanillaLight = texture(lightmap, lightCoord).rgb;
    vec3 base = texel.rgb * vanillaLight;

    vec3 Nview = safeNormalize(vNormalView);
    vec3 Nworld = safeNormalize(vWorldNormal);
    vec3 Vview = safeNormalize(-vViewPosition);
    vec3 Lview = safeNormalize(shadowLightPosition);
    vec3 Hview = safeNormalize(Lview + Vview);
    float day = smoothstep(-0.12, 0.14, vSunElevation);
    float nDotL = max(dot(Nview, Lview), 0.0);
    float litBySky = smoothstep(0.10, 0.95, lightCoord.y);
    float litByBlock = smoothstep(0.35, 1.0, lightCoord.x);
    float lightExposure = max(litBySky * 0.78, litByBlock * 0.10);
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;

    // MEDIUM: 4 reads only for sky-lit front faces. LOW uses 1; CINEMATIC uses 8.
    float shadow = 1.0;
    float shadowFacing = nDotL;
#ifdef LEAF_TRANSLUCENCY
    float leafBackDot = 0.0;
    if (vIsFoliage > 0.5) {
        leafBackDot = max(dot(-Nview, Lview), 0.0);
        shadowFacing = max(shadowFacing, leafBackDot);
    }
#endif
    if (litBySky > 0.05 && shadowFacing > 0.05) {
        shadow = getShadow(vShadowClip, nDotL, vPlayerPosition, Nworld);
    }
    // Apply shadowing to vanilla skylight only; lightmap, block light, and vanilla AO remain.
    base *= 1.0 - (1.0 - shadow) * litBySky * nDotL * overworld * 0.34;

#ifdef DIRECTIONAL_LIGHTING
    // Small directional lift over existing skylight; vanilla block-light warmth remains untouched.
    float directSun = litBySky * nDotL * shadow * day * (1.0 - rainStrength * 0.45) * overworld;
    float directMoon = litBySky * nDotL * shadow * (1.0 - day) * (1.0 - rainStrength * 0.65) * overworld * 0.22;
    base += base * DIRECTIONAL_LIGHT_STRENGTH *
            (vec3(1.00, 0.80, 0.56) * directSun + vec3(0.40, 0.58, 1.00) * directMoon);
#endif

#ifdef ATMOSPHERIC_GRADE
    // Warm daylight and cool shade stay subtle so the existing plastic response remains unchanged.
    vec3 warmDayTint = vec3(1.045, 0.990, 0.925);
    vec3 coolShadeTint = vec3(0.945, 0.980, 1.045);
    float directSunMask = litBySky * nDotL * shadow * overworld;
    float coolShadowMask = litBySky * (1.0 - shadow) * overworld;
    base *= mix(vec3(1.0), warmDayTint, directSunMask * WARM_COOL_STRENGTH);
    base *= mix(vec3(1.0), coolShadeTint, coolShadowMask * WARM_COOL_STRENGTH);
#endif

    float specular = fastGlossCurve(max(dot(Nview, Hview), 0.0));
    float fresnel = fastPowerFive(1.0 - max(dot(Nview, Vview), 0.0));
    float glossMask = lightExposure * mix(0.22, 1.0, shadow) * (0.28 + 0.72 * nDotL);
    vec3 lightTint = mix(vec3(0.62, 0.74, 1.0), vec3(1.0, 0.86, 0.67), day);
    vec3 highlight = lightTint * (specular * GLOSS_STRENGTH + fresnel * FRESNEL_STRENGTH) *
                     glossMask * PLASTIC_GLOSS_MIX;

#ifdef MATERIAL_RESPONSE
    float matteGroup = step(3.5, vMaterialGroup) * (1.0 - step(4.5, vMaterialGroup));
    float stoneGroup = step(4.5, vMaterialGroup) * (1.0 - step(5.5, vMaterialGroup));
    float polishedGroup = step(5.5, vMaterialGroup) * (1.0 - step(6.5, vMaterialGroup));
    float metalGroup = step(6.5, vMaterialGroup) * (1.0 - step(7.5, vMaterialGroup));
    float transmitGroup = step(7.5, vMaterialGroup) * (1.0 - step(8.5, vMaterialGroup));
    float roughSpec = specular * (matteGroup * 0.10 + stoneGroup * 0.30 + polishedGroup * 0.48 + metalGroup * 0.76 + transmitGroup * 0.58);
    float metalSpec = specular * specular * metalGroup * 0.30;
    float materialFresnel = fresnel * (polishedGroup * 0.12 + metalGroup * 0.24 + transmitGroup * 0.32);
    vec3 materialTint = vec3(0.92, 0.94, 0.98);
    materialTint = mix(materialTint, vec3(1.00, 0.82, 0.53), metalGroup * day);
    materialTint = mix(materialTint, vec3(0.56, 0.78, 0.90), transmitGroup);
    highlight += materialTint * (roughSpec + metalSpec + materialFresnel) * glossMask * MATERIAL_RESPONSE_STRENGTH;
#endif

#ifdef LEAF_TRANSLUCENCY
    if (vIsFoliage > 0.5 && overworld > 0.5) {
        float backLight = leafBackDot * litBySky * day * shadow;
        highlight += vec3(1.0, 0.78, 0.48) * backLight * LEAF_TRANSMISSION;
    }
#endif

#ifdef GOLDEN_TARGET_BACKLIGHT
    if (vIsFoliage > 0.5 && overworld > 0.5) {
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float targetLowSun = (1.0 - smoothstep(0.035, 0.40, abs(vSunElevation))) *
                             smoothstep(-0.18, 0.06, vSunElevation);
        float targetBackDot = max(dot(-Nview, Lview), 0.0);
        float targetBackLight = targetBackDot * litBySky * shadow * targetLowSun *
                                (1.0 - rainStrength * 0.55) * targetMatch;
        highlight += vec3(1.00, 0.63, 0.34) * targetBackLight * GOLDEN_BACKLIGHT_STRENGTH;
    }
#endif

#ifdef SUBSURFACE_TRANSMISSION
    if (vIsThin > 0.5 && overworld > 0.5) {
        float thinBackLight = max(dot(-Nview, Lview), 0.0) * litBySky * day * shadow;
        vec3 thinTint = vMaterialGroup > 7.5 ? vec3(0.48, 0.78, 0.92) : vec3(0.78, 0.92, 0.56);
        highlight += thinTint * thinBackLight * THIN_TRANSMISSION_STRENGTH;
    }
#endif

    float skyExposure = smoothstep(0.42, 0.96, lightCoord.y);
    float topSurface = smoothstep(0.70, 0.96, Nworld.y);

#ifndef WATER_LAYER
#ifdef WET_GROUND
    // LOW: rain-only branch with polynomial hash/triangle ripple; no fragment trig.
    if (wetness > 0.001 && topSurface > 0.01 && skyExposure > 0.01 && overworld > 0.5) {
        float wetMask = wetness * skyExposure * topSurface;
        float puddleNoise = cheapHash(floor(vWorldPosition.xz * 0.7));
        vec2 ripplePos = fract(vWorldPosition.xz * 0.32) - vec2(0.5);
        vec2 absRipplePos = abs(ripplePos);
        float rippleDistance = max(absRipplePos.x, absRipplePos.y) + 0.4142 * min(absRipplePos.x, absRipplePos.y);
        float ripplePhase = fract(rippleDistance * 6.6845 - frameTimeCounter * 0.414);
        float rippleTri = 1.0 - abs(ripplePhase * 2.0 - 1.0);
        float ripple = rippleTri * rippleTri * (3.0 - 2.0 * rippleTri);
        wetMask *= 0.68 + puddleNoise * 0.22 + ripple * 0.10;

        float luma = dot(base, vec3(0.2126, 0.7152, 0.0722));
        base = mix(base, vec3(luma), wetMask * 0.09);
        base *= 1.0 - wetMask * 0.10;

        vec3 Vworld = safeNormalize(cameraPosition - vWorldPosition);
        vec3 reflectedWorld = reflect(-Vworld, Nworld);
        vec3 fakeSky = mix(fogColor, skyColor, smoothstep(-0.08, 0.60, reflectedWorld.y));
        // LOW: analytic sky/fog-color reflection; no screen-space or ray-marched reflection.
        base += fakeSky * wetMask * (0.035 + 0.025 * ripple);
        highlight += fakeSky * wetMask * (0.10 + 0.08 * ripple) * specular;
    }
#endif
#else
    if (vIsFluid > 0.5) {
        // LOW: triangle-wave normal ripple; vertex positions and foliage remain static.
        float waveX = fract(vWorldPosition.x * 0.68 + frameTimeCounter * 0.143);
        float waveZ = fract(vWorldPosition.z * 0.77 - frameTimeCounter * 0.111);
        vec3 rippleNormal = vec3((1.0 - abs(waveX * 2.0 - 1.0) * 2.0) * 0.045, 0.0,
                                 (1.0 - abs(waveZ * 2.0 - 1.0) * 2.0) * 0.045);
        Nworld = safeNormalize(Nworld + rippleNormal);
        Nview = safeNormalize((gbufferModelView * vec4(Nworld, 0.0)).xyz);
        Hview = safeNormalize(Lview + Vview);
        specular = fastGlossCurve(max(dot(Nview, Hview), 0.0));
        float waterDay = day * (1.0 - rainStrength * 0.78) * overworld;
        float sparkleDot = max(dot(Nview, Hview), 0.0);
        float sparkle = fastPowerFortyEight(sparkleDot);
        sparkle *= lightExposure;
        float sparkleAmount = 0.0;
#ifdef SHALLOW_WATER_LIGHTING
        sparkleAmount = SPARKLE_AMOUNT;
#endif
        highlight += vec3(0.56, 0.82, 1.0) * (specular * (GLOSS_STRENGTH + 0.08) * PLASTIC_GLOSS_MIX + sparkle * sparkleAmount) * (0.25 + 0.75 * waterDay);

#ifdef WATER_SKY_REFLECTION
        if (isEyeInWater == 0 && dot(Nview, Vview) > 0.0) {
            vec3 waterViewWorld = safeNormalize(cameraPosition - vWorldPosition);
            vec3 reflectedWater = reflect(-waterViewWorld, Nworld);
            vec3 reflectedSky = mix(fogColor, skyColor, smoothstep(-0.12, 0.58, reflectedWater.y));
            float waterFresnel = 0.025 + 0.20 * fastPowerFive(1.0 - max(dot(Nworld, waterViewWorld), 0.0));
            base = mix(base, reflectedSky, clamp(waterFresnel * WATER_REFLECTION_STRENGTH * 8.0, 0.0, 0.48));
        }
#endif
#ifdef PIXEL_WATER_SPARKLES
        vec3 stableWaterWorld = causticWrapWorld(vPlayerPosition);
        vec2 sparkleCell = floor(stableWaterWorld.xz * float(TEXELS_PER_BLOCK)) / float(TEXELS_PER_BLOCK);
        float sparkleTick = floor(frameTimeCounter * float(STEPS_PER_SECOND)) / float(STEPS_PER_SECOND);
        float sparkleHash = cheapHash(sparkleCell + vec2(sparkleTick, -sparkleTick * 0.73));
        float pixelSparkle = step(1.0 - SPARKLE_AMOUNT * 0.10, sparkleHash) * sparkle * lightExposure;
        float exteriorSparkleFade = smoothstep(0.01, 0.20, -vPlayerPosition.y) *
                                    smoothstep(-0.02, 0.08, dot(Nview, Vview));
        pixelSparkle *= (isEyeInWater == 0 ? 1.0 : 0.0) * exteriorSparkleFade;
        highlight += vec3(0.76, 0.91, 1.0) * pixelSparkle * SPARKLE_AMOUNT * 0.12;
#endif
        base = mix(base, base * vec3(0.92, 1.02, 1.07), 0.12 * overworld);
    }
#endif

    vec3 color = base + highlight;

#ifdef EMISSIVE_BLOCKS
    float emissiveGroup = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup));
    float sourceLuma = dot(texel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float emissiveMask = emissiveGroup * smoothstep(EMISSIVE_THRESHOLD, 1.0, sourceLuma);
    color += texel.rgb * emissiveMask * EMISSIVE_STRENGTH;
#endif

#ifdef PIXEL_CAUSTICS
#if defined(WATER_LAYER)
    // Outside-camera route: runs on the visible water fragment, which is exactly where the
    // view ray enters the water (the depthtex0 surface), and shades the opaque hit behind
    // it from depthtex1. The light is handed to the water program's blend through
    // gCausticLight, so it lands on the floor before the water's own colour is added.
    float waterDistance = -vViewPosition.z;
    vec3 surfaceNormalWorld = safeNormalize(vWorldNormal);
    float surfaceFacing = dot(safeNormalize(vNormalView), Vview);
    // Top faces fade as the eye approaches the surface; side faces only need to face the camera.
    float outsideSurfaceFade = mix(1.0, smoothstep(0.01, 0.20, -vPlayerPosition.y), step(0.5, surfaceNormalWorld.y));
    float exteriorSurfaceGate = outsideSurfaceFade * step(0.0, surfaceFacing);

    if (vIsFluid > 0.5 && isEyeInWater == 0 && exteriorSurfaceGate > 0.001 && waterDistance < 48.0) {
        vec2 screenSize = vec2(textureSize(depthtex1, 0));
        ivec2 pixel = ivec2(gl_FragCoord.xy);
        float hitDepth = texelFetch(depthtex1, pixel, 0).r;
        if (hitDepth < 0.99999) {
            vec3 hitPlayer = causticPlayerFromDepth(pixel, hitDepth, screenSize);
            // Vertical water column in world blocks; cameraPosition cancels. Works for
            // floors and walls alike (a wall point uses its own height below the surface).
            float waterColumn = vPlayerPosition.y - hitPlayer.y;
            // Submerged-only: opaque hits above the entry point (shore blocks) get nothing.
            float submerged = step(0.02, waterColumn);
            int faceAxis = causticFaceAxis(hitPlayer, pixel, hitDepth, screenSize);
            float towardCamera = faceAxis == 0 ? -hitPlayer.x : (faceAxis == 1 ? -hitPlayer.y : -hitPlayer.z);
            float faceSign = towardCamera >= 0.0 ? 1.0 : -1.0;
            vec3 faceNormal = causticFaceNormal(faceAxis, faceSign);
            vec2 faceCoord = causticFaceCoord(causticWrapWorld(hitPlayer), faceAxis);
            vec3 Lworld = mat3(gbufferModelViewInverse) * Lview;
            float faceNdotL = max(dot(faceNormal, Lworld), 0.0);

            float depthFade = 1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, waterColumn);
            float distanceMask = 1.0 - smoothstep(40.0, 48.0, waterDistance);
            float daylight = smoothstep(0.025, 0.24, vSunElevation);
            float dryWeather = 1.0 - clamp(rainStrength, 0.0, 1.0);
            float waterSkyLight = smoothstep(0.22, 0.92, lightCoord.y);
            float causticMask = submerged * depthFade * distanceMask * daylight * dryWeather * waterSkyLight *
                                exteriorSurfaceGate * overworld *
                                causticFaceMask(faceAxis, faceSign, faceNdotL, waterColumn);
#ifdef CAUSTICS_DEBUG
            bool evaluateCaustics = true;
#else
            bool evaluateCaustics = causticMask > 0.0005;
#endif
            if (evaluateCaustics) {
                CausticSample pattern = causticPattern(faceCoord, causticFaceSeed(faceAxis, faceSign));
                float receiverShadow = 1.0;
#ifndef CAUSTICS_DEBUG
                // Base pixels add nothing unless CONTRAST < 1, so ~70% skip the shadow fetch.
                if (pattern.level > 0 || CONTRAST < 0.999)
#endif
                {
                    // Walls test the water half a block in front of them: a wall facing away
                    // from the sun is behind its own block in the light's view.
                    float shadowOffset = faceAxis == 1 ? 0.02 : 0.5;
                    receiverShadow = singleReceiverShadow(hitPlayer + faceNormal * shadowOffset, faceNormal, faceNdotL);
                }
                float shallowBoost = 1.0 + CAUSTICS_SHALLOW_BOOST * (1.0 - smoothstep(1.0, 2.0, waterColumn));
                // Red is absorbed first, so deeper floors and walls turn bluer.
                vec3 absorption = exp(-max(waterColumn, 0.0) * CAUSTICS_ABSORPTION * vec3(2.5, 1.0, 0.45));
                vec3 light = causticLevelColor(pattern.level) * absorption *
                             (causticMask * receiverShadow * shallowBoost * CAUSTICS_STRENGTH);
                gCausticLight = vec4(light, clamp(dot(light, vec3(1.0 / 3.0)), 0.0, 1.0));
#if defined(CAUSTICS_DEBUG) && CAUSTICS_DEBUG_MODE != 11
                causticsDebug = causticDebugView(faceAxis, faceCoord, pattern, waterColumn, submerged, receiverShadow, light);
#endif
            }
        }
    }
#elif defined(TERRAIN_LAYER) && defined(CAUSTICS_UNDERWATER_FLOOR)
    // Opt-in camera-underwater route on terrain, using the exact geometric normal.
    // The terrain pass cannot see the water surface: the eye light level stands in for the
    // column, and surfaces more than two blocks above the eye are skipped so shore blocks
    // seen through the surface from below stay clean. The water surface itself is never touched.
    if (isEyeInWater == 1 && overworld > 0.5 && vPlayerPosition.y < 2.0) {
        vec3 faceAbs = abs(vWorldNormal);
        int faceAxis = faceAbs.y >= max(faceAbs.x, faceAbs.z) ? 1 : (faceAbs.x >= faceAbs.z ? 0 : 2);
        float faceSign = (faceAxis == 0 ? vWorldNormal.x : (faceAxis == 1 ? vWorldNormal.y : vWorldNormal.z)) >= 0.0 ? 1.0 : -1.0;
        vec3 faceNormal = causticFaceNormal(faceAxis, faceSign);
        vec2 faceCoord = causticFaceCoord(causticWrapWorld(vPlayerPosition), faceAxis);
        vec3 Lworld = mat3(gbufferModelViewInverse) * Lview;
        float faceNdotL = max(dot(faceNormal, Lworld), 0.0);
        float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;
        float underwaterSkyProxy = smoothstep(0.06, 0.48, eyeSky);
        float distanceMask = 1.0 - smoothstep(32.0, 40.0, vViewDistance);
        float skyLight = smoothstep(0.18, 0.88, lightCoord.y);
        float daylight = smoothstep(0.025, 0.24, vSunElevation);
        float dryWeather = 1.0 - clamp(rainStrength, 0.0, 1.0);
        float causticMask = underwaterSkyProxy * distanceMask * skyLight * daylight * dryWeather *
                            causticFaceMask(faceAxis, faceSign, faceNdotL, -1.0);
#ifdef CAUSTICS_DEBUG
        bool evaluateCaustics = true;
#else
        bool evaluateCaustics = causticMask > 0.0005;
#endif
        if (evaluateCaustics) {
            CausticSample pattern = causticPattern(faceCoord, causticFaceSeed(faceAxis, faceSign));
            float receiverShadow = 1.0;
#ifndef CAUSTICS_DEBUG
            if (pattern.level > 0 || CONTRAST < 0.999)
#endif
            {
                float shadowOffset = faceAxis == 1 ? 0.02 : 0.5;
                receiverShadow = singleReceiverShadow(vPlayerPosition + faceNormal * shadowOffset, faceNormal, faceNdotL);
            }
            vec3 light = causticLevelColor(pattern.level) * (causticMask * receiverShadow * CAUSTICS_STRENGTH);
            // Opaque receiver: apply the screen blend directly.
            color = color * (1.0 - clamp(dot(light, vec3(1.0 / 3.0)), 0.0, 1.0)) + light;
#ifdef CAUSTICS_DEBUG
            causticsDebug = causticDebugView(faceAxis, faceCoord, pattern, -1.0, 1.0, receiverShadow, light);
#endif
        }
    }
#endif
#endif

#if !defined(ATMOSPHERIC_HAZE)
    // Preserve the pack's original fog when analytic haze is disabled.
    float distanceToCamera = vViewDistance;
    float fogSpan = max(fogEnd - fogStart, 1.0);
    float haze = smoothstep(fogStart + fogSpan * 0.42, fogEnd, distanceToCamera) * 0.20 * overworld;
    color = mix(color, fogColor, haze);
#else
    // The final analytic haze intentionally skips underwater cameras; keep vanilla water/lava fog here.
    if (isEyeInWater != 0) {
        float distanceToCamera = vViewDistance;
        float fogSpan = max(fogEnd - fogStart, 1.0);
        float liquidFog = smoothstep(fogStart + fogSpan * 0.42, fogEnd, distanceToCamera) * 0.20;
        color = mix(color, fogColor, liquidFog);
    }
#endif
    return vec4(color, texel.a);
}
