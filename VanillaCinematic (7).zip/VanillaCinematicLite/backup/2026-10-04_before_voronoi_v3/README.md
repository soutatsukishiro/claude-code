# Vanilla Cinematic Lite — stylized golden-hour update

This is an Iris shaderpack update based on the latest pasted task brief. The attached jungle image remains an atmospheric reference; the new savanna image is the golden-hour target, with a vanilla square sun, coarse amber flare, layered haze, olive grass, and distant silhouettes. The attached text is the active implementation specification, while the screenshots provide visual evidence only. The pack keeps Minecraft textures, block geometry, and static vegetation.

## Current target: golden-hour savanna screenshot

The target shows a very bright, hard-edged square sun high-right of the horizon, surrounded by broad cream-to-amber glow. The glow includes obvious coarse square bands, a long horizontal streak, and a faint vertical cross flare. A smaller round amber orb appears lower and left of the main sun. The sky is cream/gold with soft cloud haze; acacia-like tree forms, grass, flowers, and terrain remain recognizably vanilla but become olive and bronze in the warm light. Far ridges and trees fade into bright layered silhouettes. Tiny bird shapes cross the open sky. The scene has lifted warm air, gentle bloom, and a restrained vignette.

Visible evidence versus interpretation:

| Feature | Observation | Certainty |
| --- | --- | --- |
| Square sun and coarse glow | Bright square core with pixel-stepped halo, horizontal band, and weak cross flare | Directly visible; exact rendering technique is unknown |
| Lower round orb | Smaller warm disc below-left of the square sun | Its presence is visible; calling it a second light source is interpretation, so it is implemented as a fake flare |
| Sky and clouds | Gold/cream sky, bright cloud edges, muted undersides and hazy horizon | Visible; cloud-edge lighting is only approximated because the pack has no cloud-specific gbuffer route |
| Terrain grading and depth | Foreground remains detailed; distant trees and hills fade warm and pale | Directly visible; the haze model behind the reference is unknown |
| Backlit leaves and grasses | Warm edges and glowing foliage near the sun | Visible; a simple normal/light-map/shadow response is an approximation |
| Birds | Small dark wing-like silhouettes | Visible; they are represented as optional screen-space marks, never Minecraft entities |

### Gap analysis

“Exact” means the visible shape can be kept or recreated in the current route; it does not claim renderer parity with the reference. “Approximate” means an Iris-compatible effect with different implementation or limited coverage.

| # | Target feature | Pack before this update → new implementation | Match | Limitation |
| --- | --- | --- | --- |
| 1 | Square white sun, large pixel glow, horizontal and cross bands | Before: `SUN_STYLE=1` softened/replaced the vanilla disc and drew a smooth halo. Now: the target match restores the vanilla square plus `GOLDEN_SUN_GLOW` adds snapped, posterized bands | Approximate | Analytic screen-space glow, not the unknown reference bloom kernel; core size and footprint vary by resolution |
| 2 | Lower round glow orb | Before: none. Now: `SECONDARY_GOLDEN_ORB` in `final.fsh` adds a low-sun flare offset from the sun UV | Approximate | Deliberately fake lens flare, not a second celestial body or reflection |
| 3 | Amber sky and backlit clouds | Before: analytic gradient and vanilla cloud route. Now: `GOLDEN_TARGET_SKY` tints analytic sky pixels; final haze/grade can affect cloud pixels included in the final scene-depth route | Approximate | Vanilla cloud geometry/texture remains; no independent cloud-edge lighting, and cloud depth behavior depends on the renderer path |
| 4 | Warm low-contrast scene, olive grass and bronze leaves | Before: restrained warm/cool grade. Now: `GOLDEN_TARGET_GRADE` in `final.fsh`; direct-light grade remains in `gbuffers_forward.fsh` | Approximate | Camera biome uniforms tint the whole scene; no per-pixel biome map or flower-texture classifier |
| 5 | Layered golden distance haze | Before: existing analytic haze. Now: `GOLDEN_TARGET_HAZE` reuses its fog factor in `final.fsh` and adds a screen-space sun-facing weight | Approximate | One exponential attenuation and screen-space phase cannot recreate volumetric scattering |
| 6 | Warm canopy/grass rim and translucency | Before: mapped foliage back-light. Now: `GOLDEN_TARGET_BACKLIGHT` adds low-sun warmth using the foliage flag, normals, skylight and existing shadow result | Approximate | Only foliage groups mapped by `block.properties`; no true leaf transmission |
| 7 | Soft rays and glow around objects | Before: quarter-resolution shafts. Now: `GOLDEN_TARGET_RAYS` changes tint/intensity in the same `composite.fsh` route | Approximate | Eight to twelve depth taps are a screen-space shaft approximation, not volumetric shafts |
| 8 | Small birds | Before: none. Now: `GOLDEN_FAKE_BIRDS` draws three snapped V marks only in sky pixels | Impossible as real entities; approximate as a fake | No AI, depth interaction, collision, or world-space path; off in ULTRA LOW/LOW |
| 9 | Pale blue water and glint | Before: analytic reflection, shallow-water rays and caustics already existed. Now: retained unchanged by this update | Approximate | No scene SSR, refraction, or physically based water |
| 10 | Vignette and subtle bloom, crisp blocks | Before: quarter bloom and final vignette. Now: `GOLDEN_BLOCKY_BLOOM` snaps bloom-source coordinates in existing `composite.fsh` | Approximate | Bloom remains a five-tap low-resolution filter; vanilla texture pixels are not blurred |

The latest task treats the attached documents as requested specifications, not as facts about how the Bedrock add-on was built. Its implementation here does not claim to reproduce that add-on's internals.

## Golden-hour code review

| Area reviewed | Result |
| --- | --- |
| GLSL version and stage interfaces | The additions use the pack's existing `#version 330 compatibility`, `vSunUV`, `vSunElevation`, depth reconstruction, and `colortex5` route. No varyings or draw-buffer layouts were changed. |
| Iris uniforms | `viewWidth`/`viewHeight` are declared only in variants that use the screen grid; biome and camera uniforms are included by the corresponding feature guards. Confirm against the target Iris build because custom biome uniforms are supplied by `shaders.properties`. |
| Toggle behavior | New golden effects have independent `#define` switches. `MATCH_STRENGTH=0` suppresses all new target contributions and restores the existing round-sun treatment when that pre-existing option is selected. |
| Pass order and formats | Glow, haze, grade, and vignette stay in `final.fsh`; warm rays and blocky bloom source sampling stay in the existing quarter-resolution composite. No attachment or format directive changed. |
| Sky/surface separation | Sun, orb, and fake birds run only for depth-sky pixels and outside-water views. Target haze and grade operate on scene pixels; no texture samples or geometry changes were added to draw clouds separately. |
| Numeric guards | Screen dimensions, fog distance, glow levels, and existing normalization denominators retain nonzero guards. Weather masks clamp before being used as visibility. |
| Known limit | No Iris game compile, GPU capture, or hardware benchmark was available. This is a source-level compatibility review, not a runtime certification. `glslangValidator` is not installed in the workspace. |

## Performance plan and estimates

The pack retains the same six shader program routes: shadow, terrain/textured-lit/water gbuffers, composite, and final. The existing `colortex5` target remains quarter width × quarter height (one sixteenth of full-resolution pixel count). There is no new full-resolution pass. The pixel sun glow and golden color math are in the existing final shader and are skipped on non-sky pixels; target haze reuses the existing fog reconstruction and fog factor when that feature is enabled.

| Route | Before this update | After this update |
| --- | --- | --- |
| Final sky | Existing analytic gradient, square/round sun option, smooth halo | Same route plus screen-quantized target sun glow, target sky tint, optional orb and birds; disabled target switches add no target math |
| Final haze / grade | Existing analytic fog, biome tint, color grade, vignette | Same reconstruction and attenuation plus one reused-factor golden blend and small grade arithmetic; no raymarch or extra depth fetch |
| Composite shafts | Existing 8/10/12 quarter-res depth samples | Same sample counts; target only tints and scales the existing ray amount |
| Composite bloom | Existing five-tap quarter-res threshold | Same five taps; one optional coordinate snap before sampling |
| Program count / buffers | Six routes, `colortex5` at ¼ × ¼ dimensions | Still six routes and same buffers; no added attachment or full-resolution pass |

Very rough GPU-time estimates at 1920×1080 on a GTX 1650 (not measured):

| Added feature | Resolution / route | Approx. cost in LOW | Approx. cost in MEDIUM | Notes |
| --- | --- | ---: | ---: | --- |
| Coarse square sun core, blocky glow, flare band | Existing final pass; sky pixels only | 0.02–0.10 ms | 0.02–0.10 ms | Screen math only, with two soft falloff exponentials; no texture taps |
| Secondary flare orb | Existing final pass; sky pixels only | 0.00–0.02 ms | 0.00–0.02 ms | A few scalar operations and one distance |
| Golden sky tint and whole-scene grade | Existing final pass | 0.01–0.05 ms | 0.01–0.05 ms | Arithmetic only; low-sun/biome masks |
| Added haze color / sun-facing phase | Existing final haze branch | 0.00–0.03 ms | 0.00–0.03 ms | Reuses reconstructed position and fog factor; no extra depth fetch |
| Extra mapped foliage back-light | Existing terrain fragment shader | 0.00–0.03 ms | 0.00–0.03 ms | Arithmetic on foliage fragments; no extra shadow read |
| Golden ray tint/boost | Existing quarter-res ray taps | 0.00–0.01 ms | 0.00–0.01 ms | No sample-count increase |
| Blocky bloom source snap | Existing quarter-res bloom | 0.00 ms (LOW bloom off) | 0.00–0.02 ms | Changes UV arithmetic, not tap count |
| Fake bird marks | Existing final sky pixels | 0.00 ms (LOW off) | 0.00–0.04 ms | Three tiny masks, gated by daylight and match strength |
| **Golden-hour additions total** | **Existing routes only** | **about 0.03–0.20 ms** | **about 0.04–0.28 ms** | Driver, sky coverage, resolution scaling and compiler affect the result |

The best-case expected GPU-bound change from a 120 FPS baseline is approximately 0.4–2.8 FPS for the LOW estimate, and approximately 0.4–3.8 FPS for the MEDIUM estimate. This arithmetic is not a benchmark. The pack’s pre-existing effects, terrain load, chunk distance, shadow fill rate, and CPU bottlenecks are outside that delta. The 120 FPS LOW and 90 FPS MEDIUM goals remain targets to measure in-game; the source cannot guarantee them.

## Golden-hour art plan and palette

Palette hexes below are display-space visual estimates read from the screenshot by eye; they are not pixel-sampled measurements and are not claimed to be the source add-on's internal colors. Shader constants are linear-ish working values, so exact on-screen output also depends on Minecraft's output transform and resource pack lighting.

| Screenshot element | Suggested swatch | Use |
| --- | --- | --- |
| Sun core | `#FFFDF2` | Keep a white-hot square center with a slight warm edge, preserving the vanilla square outline |
| Inner glow | `#FFF0C2` | Bright area immediately around the sun |
| Outer glow / band | `#F5C56F` / `#FFE0A0` | Coarse amber halo and long low-contrast horizontal streak |
| Sky zenith | `#8F8060` | Muted, warm-gray upper sky rather than deep blue |
| Sky mid | `#EBCB83` | Cream-gold middle sky |
| Horizon | `#FFD995` | Pale luminous horizon blend |
| Near haze | `#F5D17E` | Warm yellow air over nearby distant forms |
| Far haze | `#DCA85E` | Lower-contrast amber silhouette color |
| Grass | `#98914A` | Olive foreground with yellow light on top-facing surfaces |
| Leaves | `#A28A43` | Bronze/olive canopy highlights; retain dark green shade texels |
| Soil / trunks | `#4B392D` | Warm dark brown, preserving texture contrast |
| Flowers | `#F4D532` | Saturated yellow blooms without a global neon boost |
| Water | `#A8D7E6` | Pale blue reflected-sky hint and existing water glint |

| Time / weather / biome | Suggested direction |
| --- | --- |
| Sunrise | Peach horizon (`#EFAF91`), gold-white sunlight, cool muted upper sky (`#75829A`) |
| Golden hour / savanna / desert | Cream and amber sky (`#EBCB83` → `#FFD995`), bronze foliage, olive grass; strongest match preset response |
| Sunset | Deeper amber and peach (`#D98762`), rays/gold reduced smoothly as the sun drops |
| Midday | Keep the original blue sky and neutral vanilla lighting dominant; pixel glow and golden grade fall away with sun elevation |
| Night | Existing calm blue/night sky (`#263856`); target golden sun/orb/birds/rays are faded out |
| Rain / thunder | Desaturate the golden overlay, retain denser neutral haze, fade sun glow and shafts |
| Jungle / swamp | Keep the existing teal haze (`#398D85` / `#72CBB8`) in front of golden accents |
| Cold biomes / ocean | Preserve the existing blue/cyan atmosphere (`#6C91B8` / `#99C7D3`) |
| Nether / End | Keep the existing dimension palette and skip the target overworld sun treatment |

This palette works with square block forms and crisp textures: the glow is quantized in screen space and in brightness, while world textures remain untouched. A coarser cell makes the glow visibly more pixelated; lower blockiness moves it toward a smooth analytic halo.

## Honest match to Vibrant Visuals

Mojang describes Vibrant Visuals through visible results such as directional sunlight and moving shadows, reflective water, volumetric lighting/fog, and different lighting response for block textures. The exact caustic, fog, and lighting shader implementation is not published in the material linked below, so this pack recreates the visible style with Iris-compatible approximations rather than claiming source-level parity. Mojang's public status pages currently describe Vibrant Visuals as available for Bedrock and in development for Java; this pack is a Java shaderpack approximation, not a Mojang Java port. [Mojang's feature overview](https://www.minecraft.net/en-us/vibrant-visuals-update), [Mojang's Java roadmap](https://www.minecraft.net/en-us/article/the-road-to-vibrant-visuals-on-java).

For the caustics goal, the recognizable behavior is focused, moving light on underwater surfaces, strongest in shallow sunlit water and reduced by shade, depth, rain, and night. The method here is an educated approximation: opaque depth reconstruction under visible water plus a low-cost analytic interference net. It does not refract light through a simulated wave surface, ray trace, or add geometry.

The 16-cells-per-block default anchors caustic cells to Minecraft's block texel scale. The pattern is made from hard snapped coordinates and stepped brightness bands, so it reads as block-art lighting rather than a smooth photographic caustic. Eight or 32 cells per block are available as coarser/finer variants.

## What changed

- Pixel-aligned shadow receivers snap their world-space tangent coordinates to a configurable 8/16/32-cell grid and sample the nearest shadow texel. The LOW/MEDIUM default is one tap to keep edges crisp and reduce bandwidth; HIGH/CINEMATIC can select a small 4- or 8-tap filter.
- Terrain blocks receive simple material groups from `block.properties`: matte earth/wood, stone, finished masonry, metals, glass/ice/slime/honey, foliage/thin plants, water, and selected emissive blocks.
- `PLASTIC_GLOSS_MIX` blends the existing gloss/Fresnel layer from its current strength down to zero. A separate, restrained material response adds block-family highlights.
- A small directional sun/moon fill uses the existing shadow light direction and skylight. Existing vanilla block light is preserved.
- Water can reflect an analytic blend of sky and fog color with a Fresnel term. The existing texture, ripple normal, pixel caustics, shallow-water rays, and glints remain.
- Leaves and mapped thin blocks get a small back-light tint. Vegetation vertices and positions are untouched.
- Selected terrain emitters get a texture-luminance-gated boost. The scene and shared effect buffers use Iris `RGBA16F`, allowing the existing quarter-buffer bloom to receive values above one.
- `VV_DEBUG` adds the nine requested diagnostics. The extra terrain debug output is compiled only when that switch is enabled.
- The caustic analytic waves now repeat on a seamless 256-block tile; the previous 20-block world-coordinate wrap could create pattern repetition/seams.

No new geometry or full-resolution pass was added. Existing six custom routes remain: shadow; terrain, textured-lit, and water gbuffers; composite; final.

## Gap analysis

| Vibrant Visuals goal | Existing pack before this update | Updated approximation / remaining limit |
| --- | --- | --- |
| Directional light and moving shadows | Shadow map and warm/cool grade; direct diffuse response was subtle | Mild sun/moon directional skylight lift plus the existing moving shadow map. Not a full physically based lighting model. |
| Pixel-aligned shadows | Shadow map and configurable filter, with no block-grid receiver snap | Receiver tangent coordinates snap to the 16-cell world grid by default; optional small multi-tap filter can soften edges. This is not a native voxel shadow renderer. |
| Haze and air shafts | Analytic haze and quarter-resolution depth/shadow shafts | Preserved and retained in existing routes. Haze is one analytic exponential in final; shafts use 8/10/12 taps. No volumetric integration. |
| Shallow-water lighting and caustics | Pixel caustics, depth masks, shallow-water rays, surface glints | Preserved, with stable world projection, block-grid quantization, stepped animation/pattern, one receiver shadow compare, and a caustic debug path. |
| Reflective water | Ripple shading and shallow tint; no screen reflection | Added a cheap analytic sky/fog reflection and Fresnel mix. No scene reflection or refraction. Optional SSR was left out because this pack has no water-normal buffer and an 8-step full-resolution ray would add cost and artifacts. |
| Thin-surface transmission | Leaf back-light only | Existing leaf term plus a small tint for selected plants/glass/ice/honey/slime groups. This is not true light transmission or subsurface scattering. |
| Per-family materials | One shared plastic gloss response | `block.properties` groups tune a subtle additional specular tint/strength; plastic stays independently blendable. Only terrain/water routes receive block IDs. |
| Emissives and glow | Thresholded quarter-resolution bloom | Selected terrain block textures are luminance-masked and boosted before existing bloom. Block-entity models, held items, mob eyes, and many animated emissive texture regions are outside the current routes. |
| Sky, sun, stars, clouds | Analytic gradient/halo/stars; vanilla cloud geometry | Sky and celestial work remains in final. Vanilla clouds are unchanged; the pack has no cloud gbuffer route for relighting or explicit horizon fading. Stars may not be cloud-occluded on every Iris configuration. |
| Static vanilla style | Textures and geometry are vanilla; vegetation is static | Preserved. No wind, geometry edits, texture blur, or required resource pack. |

## Code review and compatibility notes

| Severity | Finding | Change / disposition |
| --- | --- | --- |
| High | Default `colortex` format is normalized RGBA8 on most systems; additive atmosphere/emissive values can clamp. | Set `colortex0` and quarter-size `colortex5` to `RGBA16F` with Iris block-comment format directives. This costs additional VRAM/bandwidth. |
| High | Iris `mc_Entity.x` only identifies blocks in supported terrain/water stages; it is not a universal material ID for items, mobs, and block entities. | Material and emitter group effects are scoped to block IDs available on those routes. No item/entity ID taxonomy was invented. |
| Medium | Soft shadow taps blur the pixel-aligned edge target and multiply depth reads. | Added stabilized block-grid snapping and nearest texel sampling; the default uses one tap. Higher filters remain available. |
| Medium | A short, repeating coordinate wrap can make a procedural caustic net visibly repeat or jump. | Caustic waves now tile on a 256-block period with integer frequencies. |
| Medium | Camera-water and underwater-caustic gates can leak across the surface if based only on `isEyeInWater`. | Existing camera-side/sign gates remain; underwater terrain caustics remain opt-in. |
| Low | Native cloud lighting, true glass/ice transmission, and complete emissive entity/item handling are not represented by the available custom routes. | Kept vanilla clouds and routes; documented the cheap alternatives and the limits. |

Source review covered GLSL 330 compatibility, include paths, varying pairs, conditional uniforms, buffer outputs/clears, format directives, depth reconstruction, zero-vector guards, and compile-time options. It was not compiled inside Minecraft/Iris and was not measured on the requested GPUs. Iris version and driver behavior still require an in-game pass.

## Art direction and palettes

The screenshots guide the art direction; the hex palettes below are suggestions, not claimed Mojang or Realismcraft internals. GLSL uses linear RGB approximations and Iris biome uniforms, not literal hex values. Biome tinting follows the camera biome and blends smoothly, so it is not per-pixel biome classification.

| Time / weather | Palette (zenith → horizon or key light) | Treatment |
| --- | --- | --- |
| Sunrise | `#5B719F` → `#F2A98F` | Cool upper sky with soft peach horizon. |
| Morning | `#5F9CCB` → `#B8D7E7` | Clear blue, pale haze. |
| Midday | `#3E78B7` → `#C5DCEB` | Clean blue, warm-white direct highlights. |
| Afternoon | `#608DAF` → `#D9BF97` | Slight amber near the horizon. |
| Golden hour | `#D88C45` → `#F1C08D` | Soft amber shafts, warm birch highlights. |
| Sunset | `#655D83` → `#E27F72` | Muted violet and coral transition. |
| Dusk | `#2C3B65` → `#857095` | Blue-violet, gradual night blend. |
| Night | `#101A35` → `#465B87` | Calm blue haze and very faint moon response. |
| Rain | `#536D82` → `#9EABB6` | Cooler, softer contrast and denser haze. |
| Thunderstorm | `#263342` → `#586676` | Dark slate, shafts nearly gone. |
| Underwater | `#0E5271` → `#75C7C1` | Turquoise shallows into deeper blue. |

| Biome family | Palette | Treatment |
| --- | --- | --- |
| Jungle / swamp | `#398D85` → `#72CBB8` | Teal haze; green vibrance remains clamped and modest. |
| Forest / birch | `#E8A46B` → `#F3B89A` | Warm peach/amber distance color, cool shade. |
| Plains | `#8BB8C9` → `#CDD2BF` | Neutral blue air and gentle warm distance. |
| Desert / savanna | `#B97D4B` → `#E1BB83` | Dry amber light without a full-screen orange cast. |
| Snow / cold | `#6C91B8` → `#C6DBEC` | Soft cool-blue haze, preserve snow detail. |
| Ocean | `#4F91AD` → `#99C7D3` | Muted blue-green atmosphere and deeper water. |
| Cave | `#223144` → `#596B78` | Neutral-cool darkness; vanilla block light remains warm. |
| Nether / End | `#7A3D31` / `#614A91` | Dimension-tinted restrained haze; native dimension sky retained. |

## Performance and pass plan

No new pass was added. `colortex5` remains 25% width × 25% height (one sixteenth the pixel count) and shares bloom, shallow-water lighting, shafts, and particles. Haze, sky, tone, vibrance, and vignette stay in final. Material, caustic, direct-light, and wet-ground terms stay in existing gbuffers.

These are rough 1080p GTX 1650 estimates, not benchmark results. They vary with water coverage, shadowed pixel count, driver, chunk distance, and shader option state. “Before” refers to the checked-in pack immediately before this change.

| Effect | Before → after | Approximate GPU cost after | Notes |
| --- | --- | ---: | --- |
| Atmosphere rays | Existing 8–12 depth taps at quarter width/height → unchanged route, 8 LOW / 10 MEDIUM / 12 HIGH-CINEMATIC | 0.08–0.22 ms | Includes one shadow compare on eligible surface pixels; no new full-resolution pass. |
| Haze, sky, grade | Existing final-stage analytic haze/sky → preserved, dimension-aware and tone-gated | 0.08–0.22 ms | One exponential for haze; full-resolution but no extra pass. |
| Bloom and pollen | Existing quarter target → preserved; bloom now samples HDR colortex0 | 0.03–0.14 ms | Existing 5-tap cross filter, not a separable blur. Bloom/pollen are off in LOW. |
| Pixel caustics | Existing water-fragment depth reconstruction and pattern → seamless tile, current single shadow compare, snapped net | 0.05–0.30 ms | Highly dependent on visible water coverage; only runs on eligible shallow-water pixels. |
| Pixel shadows | Existing interpolated shadow clip and 1/4/8 compares → world snap plus nearest texel; default 1 compare | −0.02 to +0.03 ms | Fewer taps can offset the coordinate math; exact gain is driver/coverage dependent. |
| Material response and direct light | One plastic term → added group selection and subtle light/material arithmetic | 0.01–0.08 ms | No extra texture reads. |
| Water analytic reflection | No water-surface sky reflection → reflection/Fresnel only on visible outside-water fragments | 0.005–0.05 ms | Not SSR; cost scales with water coverage. |
| Emissive lift and thin back-light | No group-masked block emissive lift → texture luminance tests on mapped terrain | 0.005–0.04 ms | No new texture reads; half-float colortex0 adds roughly 8.3 MiB at 1920×1080 versus RGBA8. |
| Estimated whole requested atmosphere | Existing profile-level estimate 0.19–0.50 ms LOW / 0.25–0.78 ms MEDIUM → same passes with HDR target and debug compiled out | about 0.20–0.55 ms LOW / 0.26–0.85 ms MEDIUM | Does not include terrain, water, or caustic cost. These are not measured totals. |

The entry-GPU 120 FPS LOW and RTX 3050 90 FPS MEDIUM targets cannot be guaranteed from source review; CPU chunk work, resolution scale, render distance, and actual water/shadow coverage materially affect frame time. `ULTRA_LOW` removes most shader additions. Use a GPU frame capture for measured claims.

### Changelog and estimated frame-rate effect

The FPS conversion below assumes a GPU-bound baseline and is only arithmetic from the estimated milliseconds (`1000 / (baseline frame ms + added ms)`). It is not a benchmark; CPU limits and the shadow-filter change make actual frame-rate deltas nonlinear.

| Addition / visible difference | Estimated cost or saving | Approximate effect at 120 GPU-bound FPS |
| --- | ---: | ---: |
| World-grid shadow receiver snap, nearest texel; default MEDIUM changes from four compares to one | About −0.02 to +0.03 ms net | roughly +0.3 to −0.4 FPS; LOW already used one compare, so expect a small cost from snap math |
| Block-family material response and directional sun/moon lift | +0.01–0.08 ms | about −0.1 to −1.1 FPS |
| Analytic sky reflection on visible water | +0.005–0.05 ms on water fragments | about 0 to −0.7 FPS, depending on water coverage |
| Texture-masked emissive lift and thin-material back-light | +0.005–0.04 ms | about 0 to −0.6 FPS |
| Full-resolution scene buffer changes from RGBA8 to RGBA16F | approximately +8.3 MiB at 1080p and +0.02–0.10 ms bandwidth | about −0.3 to −1.4 FPS if bandwidth-bound |
| Caustic coordinate tile correction | No meaningful ALU increase | visually removes a possible short-period seam; essentially 0 FPS |
| `VV_DEBUG` views and MRT output | 0 when disabled; debug-only overhead when enabled | 0 in all normal presets |
| Existing quarter-resolution haze/rays/bloom/pollen | No new pass; estimates in the table above | Retained, not a new cost from this change |

Combined new full-resolution additions (including HDR buffer bandwidth) are very roughly +0.02–0.25 ms on LOW, partly offset by fewer shadow compares on MEDIUM. This spread is intentionally wide; it cannot establish that a particular GPU meets 120/90 FPS.

## Presets and controls

| Preset | Main costs and effects | Hardware guidance |
| --- | --- | --- |
| ULTRA LOW | 768 shadow map; simple analytic haze and low-match warm sky/square glow only; no rays, bloom, caustics, or birds. | Integrated graphics; highest FPS priority. |
| LOW | 1024 shadow map, 64-block distance, 8 quarter-buffer ray taps, one-tap pixel shadows, 8-step/s caustic net; bloom and birds off; match 42. | GTX 1050 Ti / GTX 1650 / RX 6400 target profile. |
| MEDIUM | 1536 shadow map, 80-block distance, 10 ray taps, bloom, pollen and fake birds; match 65. | Default balance / RTX 3050 target profile. |
| HIGH | 2048 shadow map, 12 ray taps, 4-tap shadows, fine caustic grid; match 82. | Higher-end desktop GPUs. |
| CINEMATIC | 3072 shadow map, 96-block distance, 12 ray taps, 8-tap shadows, finer glow pixels, stronger haze/glow and finest caustic grid; match 100. | Screenshots/high-end only. |

Settings are under **Match Strength**, **Sky and Sun**, **Golden Haze**, **Color Grading**, **Light Shafts and Bloom**, **Water and Caustics**, **Materials**, **Glow and Emissive**, **Performance**, and **Debug**.

Key controls:

- **Plastic gloss blend** (`PLASTIC_GLOSS_MIX`): 1.0 preserves the existing plastic layer; 0.0 removes only that layer.
- **Material response strength**: the added block-family highlight, independent of plastic gloss.
- **Shadow texels per block** (`SHADOW_PIXEL_GRID`): 8/16/32 world cells per block. The default 16 follows the 16×16 texture scale.
- **Caustic pixel grid / pattern quality / levels / steps per second / depth range / tint / strength**: controls the world-space caustic net and water mask. Current defaults keep caustics full through 2 blocks below the water surface and fade smoothly to zero at 11 blocks. `CAUSTICS_FULL_DEPTH` and `CAUSTICS_FADE_DEPTH` tune those thresholds; `SHALLOW_DEPTH_RANGE` controls the separate shallow-water shafts.
- **Ray samples / length / softness / intensity** and optional snapped-ray grid.
- **Haze density / height falloff / biome tint**, **green vibrance**, **bloom threshold/intensity**, and **emissive texture threshold/strength**.
- **Match strength** (`MATCH_STRENGTH`): 0 reproduces the shaderpack's prior look; 100 applies the full golden-hour target. LOW/MEDIUM/CINEMATIC start at 42/65/100.
- **Sun glow** (`GOLDEN_GLOW_PIXEL_SIZE`, `GOLDEN_GLOW_BLOCKINESS`, `GOLDEN_GLOW_LEVELS`, `GOLDEN_GLOW_STRENGTH`): controls square screen-pixel cells, hard steps, and glow brightness. `GOLDEN_SUN_CORE_SIZE` changes the overexposed square footprint.
- **Secondary orb** (`SECONDARY_GOLDEN_ORB`, `SECONDARY_ORB_SIZE`, `SECONDARY_ORB_STRENGTH`): optional artistic flare below-left of the sun; it is not a second world light.
- **Golden sky/haze/grade** (`GOLDEN_TARGET_SKY`, `GOLDEN_SKY_TINT_STRENGTH`, `GOLDEN_TARGET_HAZE`, `GOLDEN_HAZE_STRENGTH`, `GOLDEN_HAZE_PHASE`, `GOLDEN_TARGET_GRADE`, `GOLDEN_GRADE_STRENGTH`, `GOLDEN_SHADOW_LIFT`): sunrise/sunset and savanna-weighted ambience.
- **Ray and foliage warmth** (`GOLDEN_TARGET_RAYS`, `GOLDEN_RAY_BOOST`, `GOLDEN_TARGET_BACKLIGHT`, `GOLDEN_BACKLIGHT_STRENGTH`): reuses the existing quarter-res rays and existing foliage classification/shadow result.
- **Optional birds** (`GOLDEN_FAKE_BIRDS`, `FAKE_BIRD_AMOUNT`, `FAKE_BIRD_SIZE`, `FAKE_BIRD_SPEED`): only sky marks, not entities. Disabled in ULTRA LOW/LOW.
- Every feature added here has a Boolean compile-time define; numeric controls are in `shaders/lib/settings.glsl` and exposed in `shaders.properties`.

### Tuning guide

- **More Vibrant Visuals:** raise `DIRECTIONAL_LIGHT_STRENGTH` slightly, keep `MATERIAL_RESPONSE` on, and raise biome tint or haze only a little. Leave the plastic mix at 0.5–1.0 if you want the pack's original highlights.
- **More vanilla:** lower `PLASTIC_GLOSS_MIX`, `MATERIAL_RESPONSE_STRENGTH`, `DIRECTIONAL_LIGHT_STRENGTH`, bloom, and `SKY_GRADIENT_STRENGTH`; disable optional vignette/stars.
- **Less haze:** lower `HAZE_DENSITY`; lower `HAZE_HEIGHT_FALLOFF` if the ground-level buildup is too strong.
- **Softer shafts:** increase `ATMOS_RAY_SOFTNESS` and reduce `ATMOS_RAY_INTENSITY`; decrease `ATMOS_RAY_LENGTH` for shorter beams.
- **Less glossy:** reduce `PLASTIC_GLOSS_MIX` to remove the existing plastic response; reduce `MATERIAL_RESPONSE_STRENGTH` separately for quieter stone/metal/glass highlights.
- **Finer caustics:** set `CAUSTIC_GRID_SIZE` to 32 and/or raise `CAUSTIC_QUALITY`. The pattern remains cell-stepped by design.
- **Less emissive glow:** raise `EMISSIVE_THRESHOLD`, lower `EMISSIVE_STRENGTH`, or disable `EMISSIVE_BLOCKS`/`BLOOM`.
- **More vanilla water:** lower `WATER_REFLECTION_STRENGTH` or disable `WATER_SKY_REFLECTION`.
- **More like the golden-hour target:** raise `MATCH_STRENGTH`, then raise `GOLDEN_GLOW_STRENGTH` or `GOLDEN_HAZE_STRENGTH` in small increments.
- **Make the glow softer:** lower `GOLDEN_GLOW_BLOCKINESS`, increase `GOLDEN_GLOW_LEVELS`, and reduce `GOLDEN_BAND_STRENGTH` if the horizontal flare is too hard.
- **Make the glow more pixelated:** raise `GOLDEN_GLOW_BLOCKINESS` and `GOLDEN_GLOW_PIXEL_SIZE`; lower `GOLDEN_GLOW_LEVELS` for fewer, more obvious brightness bands.
- **Make the haze less strong:** lower `GOLDEN_HAZE_STRENGTH` first, then lower the general `HAZE_DENSITY` if the existing pack haze is also too heavy.
- **Make the image less yellow:** lower `MATCH_STRENGTH` or `GOLDEN_GRADE_STRENGTH`; set `GOLDEN_SKY_TINT_STRENGTH` lower to keep sky colors cooler.
- **Hide the fake birds:** turn off `GOLDEN_FAKE_BIRDS` or set `FAKE_BIRD_AMOUNT` to 0.
- **Move the flare orb:** the current implementation offsets it from the sun by a fixed screen-space amount; use `SECONDARY_ORB_SIZE`/strength or disable the toggle. Its screen offset is intentionally not exposed as a slider.
- **Tune canopy rays:** use `ATMOS_RAY_SOFTNESS`, `ATMOS_RAY_LENGTH`, and `ATMOS_RAY_INTENSITY`; `GOLDEN_RAY_BOOST` only adds target warmth/weight.

### Golden-hour screenshot comparison checklist

| Compare | If too weak | If too strong |
| --- | --- | --- |
| Square sun and glow footprint | Raise `MATCH_STRENGTH` or `GOLDEN_GLOW_STRENGTH`; raise `GOLDEN_SUN_CORE_SIZE` for a larger square | Lower `GOLDEN_GLOW_STRENGTH` or `GOLDEN_SUN_CORE_SIZE` |
| Glow blockiness / bands | Raise `GOLDEN_GLOW_BLOCKINESS`, pixel size, or band strength; reduce levels for chunkier steps | Lower pixel size/blockiness; increase levels |
| Secondary orb | Raise `SECONDARY_ORB_STRENGTH` or size | Lower its strength/size or disable `SECONDARY_GOLDEN_ORB` |
| Sky warmth | Raise `GOLDEN_SKY_TINT_STRENGTH` or match strength | Lower either control; keep `SKY_GRADIENT_STRENGTH` for the base pack look |
| Clouds | General haze/grade affect distant cloud pixels | Cloud geometry and direct cloud-edge light are vanilla; no slider can independently relight cloud undersides |
| Haze layers and horizon silhouettes | Raise `GOLDEN_HAZE_STRENGTH` gently | Lower target haze, then `HAZE_DENSITY` |
| Whole-scene golden grade | Raise `GOLDEN_GRADE_STRENGTH` | Lower grade strength or `MATCH_STRENGTH` |
| Backlit canopy and grass | Raise `GOLDEN_BACKLIGHT_STRENGTH`; check foliage IDs/shadow light | Lower strength or disable `GOLDEN_TARGET_BACKLIGHT` |
| Rays | Raise `ATMOS_RAY_INTENSITY` or `GOLDEN_RAY_BOOST` | Lower ray intensity/boost or disable either ray switch |
| Yellow flowers | Increase `VIBRANCE_STRENGTH` cautiously; the shader does not identify flower texels separately | Lower vibrance; there is no per-flower color slider |
| Water highlight | Raise `WATER_REFLECTION_STRENGTH` or existing sparkle amount | Lower them; no screen-space reflection is present |
| Vignette | Raise `GOLDEN_VIGNETTE_STRENGTH` | Lower it or disable `GOLDEN_SOFT_VIGNETTE` |

### Golden-hour test checklist

| Scene / state | Expected result |
| --- | --- |
| Sunrise and sunset, looking toward the sun | Square core with warm pixel bands, subtle horizon orb, golden haze and shafts fade in smoothly |
| Look away from the sun | Warm grade and haze remain subtle; flare and rays largely disappear from the sun cone |
| Noon | Sky returns toward the base palette; target glow/orb and warm ray boost fall off |
| Night | No golden sun or secondary orb; calm blue base sky, no strong rays or birds |
| Rain and thunderstorm | Sun glow/rays and golden grade soften; existing haze gets denser/desaturated |
| Savanna/desert | Warmest amber haze and bronze/olive grade |
| Forest/birch | Warm highlights but keep green shade texels readable |
| Jungle/swamp | Existing teal biome haze remains legible; golden overlay stays restrained |
| Snow/ocean | Existing cool palette remains dominant |
| Open sky with birds enabled | Three sparse snapped silhouettes drift slowly; disabled in LOW/ULTRA LOW |
| Under trees, indoors, under a roof | Atmospheric rays reduce with sky light/shadows; square sun effects remain sky-only |
| Water and crossing the surface | Existing water reflection/caustics gates behave as before; no new caustics are drawn on the visible surface |
| Nether/End | Golden overworld sun treatment stays gated out; native dimension mood remains |
| `MATCH_STRENGTH` 0 vs 100 | 0 matches the previous pack; 100 shows the strongest screenshot-inspired golden-hour additions |
| LOW at 1080p / 12 chunks | Birds and bloom off, 8 ray taps; measure GTX 1050 Ti/1650/RX 6400 rather than assuming the FPS target |
| MEDIUM at 1080p | 10 ray taps plus bloom and birds; measure on the RTX 3050 and compare against your own baseline |

### Golden-hour changelog and estimated frame cost

| Addition | Visible difference | Estimated added GPU time (GTX 1650, 1080p) |
| --- | --- | ---: |
| `MATCH_STRENGTH` and presets | Single 0–100 blend for target additions; profiles select 25/42/65/82/100 and their quality/toggle sets | No meaningful cost |
| Pixel sun core/glow/bands | White square-overlaid core and quantized amber square-grid halo/cross/horizontal streak | 0.02–0.10 ms, sky pixels only |
| Lower orb | Soft round screen flare below-left of the sun | 0.00–0.02 ms, sky pixels only |
| Golden sky and distant haze/phase | Cream/amber sky and warmer distant silhouettes around the sun | 0.01–0.08 ms; reuses existing scene and fog reconstruction |
| Warm scene grade and backlight | Golden low-sun tint/lift; mapped foliage and grass edges receive a small extra tint | 0.01–0.08 ms; no additional shadow sample |
| Ray tint/boost and blocky bloom source | Warmer existing shafts and pixel-grid bloom selection | 0.00–0.03 ms; existing tap counts unchanged |
| Optional fake birds | Three tiny sky-only screen marks | 0.00–0.04 ms; off in LOW/ULTRA LOW |

## Debug views

Turn on `VV_DEBUG` and select `VV_DEBUG_MODE`. These diagnostics are compiled out when `VV_DEBUG` is off.

For the new target-only checks, enable `TARGET_DEBUG` and select `TARGET_DEBUG_MODE`. This code is compiled out when the switch is off. Modes 6 and 7 read the existing quarter-resolution effect buffer; no diagnostic render pass is added.

| Target mode | View |
| --- | --- |
| 1 | Raw golden sun glow before tint contribution |
| 2 | Posterized glow contribution |
| 3 | Target warm sky palette |
| 4 | Warm haze mask/fog factor |
| 5 | Screen-space sun-facing haze phase |
| 6 | Quarter-resolution raw sun shafts |
| 7 | Quarter-resolution bloom buffer (the target is shared with other composite effects) |
| 8 | Left half before golden grade, right half after golden grade |

| Mode | Expected result |
| --- | --- |
| 1 — Sun-lit mask | Black in night/indoors, white in open sky and lit sun-facing receivers. |
| 2 — Raw shafts | Grayscale quarter-resolution ray intensity; brightest around alternating canopy gaps. |
| 3 — Fog factor | Black nearby and brighter with distance; sky pixels stay black. |
| 4 — Biome tint | Flat active palette color; transitions gradually as the camera biome changes. |
| 5 — Shadow factor | White for visible/unshadowed receivers, dark for shadowed/out-of-map receivers; quarter-resolution. |
| 6 — Emissive mask | Grayscale threshold result on supported, tagged terrain blocks only. |
| 7 — Material group | Matte brown, stone gray, polished purple, metal gold, transmission cyan, foliage green, water blue, emitter red. Unmapped/entity routes are dark gray. |
| 8 — Water mask | White on mapped water surfaces; black elsewhere. |
| 9 — Bloom buffer | Isolated low-resolution thresholded glow contribution. |

The older `ATMOS_DEBUG` and `CAUSTICS_DEBUG` controls remain available for their existing focused diagnostics.

## In-game test checklist

The source-level work is complete; use this checklist in Minecraft/Iris to verify visuals and performance.

| Scenario | Expected result |
| --- | --- |
| Sunrise / sunset | Smooth peach/coral sky band, warm directional tint, no abrupt transition. |
| Morning / noon | Clear blue sky, restrained warm direct light, no excessive orange cast. |
| Golden hour in birch forest | Amber/peach haze and faint shafts between trunks, like reference 2. |
| Jungle canopy | Soft diagonal shafts, teal/cyan distance haze, restrained pollen and green vibrance, like reference 1. |
| Night | Calm blue haze, no strong sun rays or caustics, subtle stars/moon response. |
| Rain / thunderstorm | Shafts and caustics fade; haze becomes cooler/denser and grading softens. |
| Plains / desert / savanna | Smooth neutral or amber palette blend; no hard biome boundary. |
| Snowy biome | Cool air; white surfaces retain visible texture detail. |
| Ocean / shallow water from shore | Depth tint, visible block-pixel caustics on submerged opaque surfaces, mild water reflection. |
| Deep water | Caustics stay full through 2 blocks, fade smoothly to zero at 11 blocks, and are absent below that. |
| Crossing water surface | Outside-camera caustics fade out as the eye enters water; never show the outside-water caustic overlay from below. |
| Underwater floor toggle | When `CAUSTICS_UNDERWATER_FLOOR` is enabled, faint terrain caustics use the conservative eye-light proxy. |
| Cave / indoors / under roof | No air shafts in sealed shade; caves remain dark, warm block light remains vanilla-like. |
| Window / canopy gaps | Shafts pass through visible openings; fully occluded regions stay subdued. |
| Look toward/away from sun; look straight up/down | Shafts fade with the sun-screen cone; sky effects do not spill over opaque terrain or singularly flicker. |
| Nether / End | Native dimension mood is retained with restrained dimension haze. |
| Far from spawn | Caustic grid remains anchored and repeats only at its seamless 256-block tile. Check for visible tile recognition. |
| Emissive blocks / leaves / glass | Supported blocks gain a subtle local glow/back-light; no actual transmitted light is expected. |
| Performance on targets | Measure LOW at 1080p/12 chunks on GTX 1050 Ti, GTX 1650, RX 6400; MEDIUM on RTX 3050. Source estimates are not benchmark data. |

## Troubleshooting Iris errors

1. Check the first `Shader compilation failed` or GLSL `ERROR` in `.minecraft/logs/latest.log`; the first program and line number are the useful part, not the final stack trace.
2. If a varying is undeclared, compare vertex `out` and fragment `in` names/types. `vMaterialGroup` and related values are shared by `/lib/gbuffers.vsh` and `/lib/gbuffers_forward.fsh`.
3. If the error mentions `colortex0Format` or `colortex5Format`, leave each Iris buffer format directive on its own line inside a block comment. `RGBA16F` is an Iris directive, not a GLSL identifier.
4. If a `RENDERTARGETS`/attachment error appears, try with `VV_DEBUG` off first; its material/emissive views add a `colortex2` MRT output only for the selected debug modes. The normal water mask remains in `colortex1`.
5. If an option seems unchanged, reselect the profile or reload shaders; profiles can override GUI defines. Confirm its Boolean switch and its slider are both enabled/raised.
6. If a block group does not tint, confirm the block has an ID in `shaders/block.properties` and is rendered in terrain/water. Block entities, items, and entities do not automatically inherit `mc_Entity.x`.
7. For a reproducible report, include Minecraft version, Iris version, GPU/driver, the first compile diagnostic, the selected profile, and the relevant setting values.

## Changed and unchanged files

All changed shader/config files below contain their complete contents in the pack folder and ZIP; no diffs or placeholders are required to use the pack.

Changed:

- `README.md`
- `shaders/block.properties`
- `shaders/composite.fsh`
- `shaders/final.fsh`
- `shaders/gbuffers_terrain.fsh`
- `shaders/gbuffers_textured_lit.fsh`
- `shaders/gbuffers_water.fsh`
- `shaders/lang/en_us.lang`
- `shaders/lib/gbuffers_forward.fsh`
- `shaders/lib/gbuffers.vsh`
- `shaders/lib/settings.glsl`
- `shaders/shaders.properties`

Unchanged:

- `shaders/composite.vsh`
- `shaders/final.vsh`
- `shaders/gbuffers_terrain.vsh`
- `shaders/gbuffers_textured_lit.vsh`
- `shaders/gbuffers_water.vsh`
- `shaders/shadow.fsh`
- `shaders/shadow.vsh`
- `shaders/lib/shadow_distortion.glsl`

## Caustics depth and shadow fix

The report describes a pattern visible only through very thin water. The source inspection found the strongest matching cause in `shaders/lib/gbuffers_forward.fsh`, `singleReceiverShadow()`: the caustic receiver test sampled `shadowtex0`. Iris defines `shadowtex0` as including all geometry, while `shadowtex1` excludes transparent geometry. When translucent water is included in the shadow pass, it can therefore occlude its own receiver. The caustic test now uses one `shadowtex1` sample, keeps its normal/depth bias, and treats positions outside the shadow map range as unshadowed instead of suppressing the effect. Whether water was actually present in the active runtime map depends on Iris shadow settings; no game log was attached to verify that runtime state.

Other findings:

- The caustic receiver depth was already measured vertically in the current pack, using the visible water fragment position and the perspective-divided `depthtex1` floor position. It was not the original view-ray metric described in the report. The defaults now match the requested 2-to-11-block fade.
- The quarter-resolution shallow-water shafts and tint in `shaders/composite.fsh` did use linear view-depth subtraction, which changes with camera angle. They now use the vertical difference between reconstructed `depthtex0` water and `depthtex1` floor positions.
- `block.properties` maps `minecraft:water` to ID 1. Iris reports `mc_Entity.y == 1` for fluids, so the current `mc_Entity.y > 0.5 && mc_Entity.x == 1.0` test covers still and flowing water states. The source water mesh position also handles partial flowing heights; it does not infer depth from block-boundary `fract()`.
- The caustic color is added in the translucent water fragment and adjusted by its alpha so blending transmits the increment onto the opaque floor. The mask is not stored in an 8-bit buffer before application; the scene target uses `RGBA16F`. I added a separate gentle exponential absorption and a blue-green depth tint.
- The view-angle fade on the visible water surface has been reduced to a front/back sign test. The outside-camera and surface-crossing fade remain, so default caustics remain hidden when the camera is underwater.

**Certain from source/API:** the old caustic helper read `shadowtex0`; `shadowtex1` is Iris's opaque-only sampler; the floor depth reconstruction perspective-divides by `w`; and the water ID/render-type test matches Iris's documented `mc_Entity` meaning. **Approximate:** the screenshot's precise runtime cause, the quality of opaque shadow coverage for every GPU/driver, and all timing estimates; the screenshot and Iris log were not available in the workspace.

The caustic controls, debug views and test pool of this earlier fix are superseded by **Pixel-network caustics (floor and walls)** below.

### Change log and performance estimate

- Replaced the caustic shadow lookup from `shadowtex0` to `shadowtex1`; this is the primary fix for translucent-water self-occlusion. It is the same single shadow fetch, with no additional pass.
- Set caustic fade defaults to 2/11 blocks and added shallow-boost and absorption controls. The pixel grid, posterized bands, stepped animation, and intensity controls remain.
- Changed the water shaft/tint thickness to vertical world-space depth and its receiver visibility to the opaque-only shadow map.
- Replaced the grazing-angle surface fade with a front/back test while retaining the camera crossing gate.
- Expanded debug views to eight choices; these compile only when `CAUSTICS_DEBUG` is on.

Estimated incremental cost on a GTX 1650 at 1080p: about **0.01–0.04 ms** for the caustic path (one exponential and a few arithmetic operations; the shadow lookup is replaced, not added), plus roughly **0.01–0.05 ms** for quarter-resolution water shaft depth reconstruction when that effect is enabled. These are source-based estimates, not measured results. Total caustic cost depends on visible water coverage and may approach or exceed 0.25 ms in a water-heavy scene; the 120 FPS LOW target still needs an in-game benchmark.


## Pixel-network caustics (floor and walls)

Rebuilt to match a Vibrant Visuals (Bedrock) reference screenshot and extended to submerged side faces. Bedrock's renderer is not public; everything below is matched from the still image or is an approximation, as marked.

### Reference, re-sampled

Colours were sampled from the reference file (inner floor region, 25,200 samples, sRGB as decoded, no colour management):

| Level | Brief estimate | Sampled | Share of floor |
| --- | --- | --- | --- |
| Base floor | `#5E8CA2`–`#6A97A8` | `#5D7586` | ~77 % |
| Mid | `#8FB0BC` | `#7F9093` | |
| Light | `#B7CFC9` | `#94A199` | ~23 % lines in total |
| Peak | `#E4DDA8` | `#A7B19F` (brightest `#B0B19D`) | ~1–2 % |

- Shape: confirmed. Thin orthogonal lines with L shapes, open rectangles, brackets and short steps; almost no curves.
- Grid: about 15 px per texel on the floor against about 20 px on the nearer dirt block, consistent with 16 texels per block (perspective prevents an exact proof).
- Coverage: about 23 % of floor pixels are lines (the brief said 25–35 %).
- Colours: greyer than the brief's estimates. The peak is warm (R ≈ G > B) but less saturated than `#E4DDA8`.
- Animation: speed and direction are not visible in a still image. The defaults are a guess and are exposed as sliders.

### Implementation summary

- **Pattern** (`causticPattern`, `lib/gbuffers_forward.fsh`): integer texel grid → two piecewise-constant value-noise layers (one integer hash per cell, rows of A and columns of B staggered) → outline where the 2-bit cell value differs from the texel to the right or below, kept per edge by `LINE_DENSITY` → union of the layers. Levels: one layer = mid, layer overlap or corner = light, a hashed share of those = peak, plus rare isolated pixels.
- **Wrap**: 240-block period. 240 × texels/block is divisible by every cell size, so the lattice never shows a seam. The camera integer is offset by 30,000,000 so GLSL `%` never sees a negative operand.
- **Face axis** (`causticFaceAxis`): full-block faces lie on integer world planes, so the axis whose coordinate is on an integer is the normal (zero taps). Block edges, slabs and plants fall back to the closer depth neighbour on each screen axis plus a cross product (four `texelFetch`). No normal buffer exists and none was added.
- **Masks**: vertical column = water-fragment Y − `depthtex1` hit Y. Also submerged-only, the full/fade depth, a wall depth fade, the face sun term with a wall minimum, the opaque-only `shadowtex1` sample (walls sample half a block in front of the face), and the night, rain, sky-light and 40–48 block distance fades.
- **Blend**: `gbuffers_water` writes premultiplied colour with `blend.gbuffers_water = ONE ONE_MINUS_SRC_ALPHA …`, which gives `water·a + L + floor·(1−a)·(1−k)`. That is a screen of the caustic light over the transmitted floor, applied before the water's own colour. Without caustics it is identical to the default alpha blend. `CAUSTICS_SCREEN_BLEND` off falls back to plain additive.
- **Water flag**: `mc_Entity.y > 0.5` (Iris fluid geometry) or block ID 1. This covers source, flowing and waterlogged water and every face.

### Sliders (Water and Caustics → Pixel Caustics)

| Option | Default | Notes |
| --- | --- | --- |
| `PIXEL_CAUSTICS` / `CAUSTICS_WALLS` / `CAUSTIC_MORPH` / `CAUSTICS_SCREEN_BLEND` | on | Compile-time toggles |
| `CAUSTICS_UNDERWATER_FLOOR` | off | Opt-in camera-underwater route (floors and walls) |
| `CAUSTICS_STRENGTH` | 1.00 | 1.0 reproduces the sampled swatches over the sampled base |
| `CAUSTIC_LAYERS` | 2 | 1 = single net (LOW) |
| `TEXELS_PER_BLOCK` | 16 | 8 / 16 / 32 |
| `NOISE_CELL_SIZE_A` / `_B` | 4 / 8 | Main net and sparser second net |
| `LINE_THICKNESS` | 1 | 2 adds a second comparison offset |
| `LINE_DENSITY` | 0.60 | LOW uses 0.75 with one layer |
| `ISOLATED_PIXELS` | 0.010 | |
| `PEAK_AMOUNT` | 0.30 | |
| `WARMTH` | 1.00 | Peak: cool white → sampled cream |
| `CONTRAST` | 1.00 | Below 1 adds a faint fill between lines (costs the shadow fetch everywhere) |
| `STEPS_PER_SECOND` | 8 | |
| `DRIFT_SPEED` | 1.5 texels/s | Not verifiable from the still |
| `DRIFT_DIRECTION` | 45° | Layer B is rotated ~127° and drifts at 0.7× |
| `MORPH_SECONDS` | 6 | Per-cell re-roll interval |
| `CAUSTIC_FULL_DEPTH` / `CAUSTIC_FADE_DEPTH` | 2 / 11 | Also used by the shallow-water shafts; `SHALLOW_DEPTH_RANGE` was removed |
| `CAUSTICS_SHALLOW_BOOST` / `CAUSTICS_ABSORPTION` | 0.20 / 0.018 | Absorption is per channel (red first), so depth turns bluer |
| `WALL_STRENGTH` / `WALL_DEPTH_FADE` / `WALL_SUN_FACTOR` | 0.55 / 6 / 0.65 | Minimum wall sun response = 1 − factor |

Presets set every caustic option explicitly. ULTRA LOW: caustics off (and the vanilla blend). LOW: floor only, one layer, 8 steps/s, no morph. MEDIUM: floor and walls, two layers, morph. HIGH: as MEDIUM at 10 steps/s. CINEMATIC: 10 steps/s, more isolated pixels, stronger and deeper wall caustics.

### Debug views (`CAUSTICS_DEBUG`, `CAUSTICS_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Face axis: floors green, X walls red, Z walls blue. Edges should not flicker. |
| 2 | Texel checker aligned with the block texture pixels; block parity alternates red/blue tint |
| 3 / 4 / 5 | Layer A / layer B / combined outline: pure black and white 1-texel lines |
| 6 | Levels: dark base, blue mid, green light, cream peak (peaks only on corners/crossings) |
| 7 | Vertical column 0–12 blocks as a gradient; it must not change when the camera tilts |
| 8 | Submerged mask: white below the water line, nothing above it |
| 9 | Opaque-only shadow: black only behind opaque occluders, never from the water itself |
| 10 | Final visible caustic light before blending |
| 11 | Water flag on every water face |

### Comparison checklist

| Difference from reference | Slider |
| --- | --- |
| Lines too thick / thin | `LINE_THICKNESS`, `TEXELS_PER_BLOCK` |
| Too busy / too sparse | `LINE_DENSITY`, then `CAUSTIC_LAYERS` |
| Cells too large / small | `NOISE_CELL_SIZE_A`, `NOISE_CELL_SIZE_B` |
| Not right-angled enough | Keep cell sizes ≥ 4 and `LINE_THICKNESS` 1 (the generator never makes curves) |
| Levels | Fixed at 4 (base, mid, light, peak); `PEAK_AMOUNT` |
| Peaks too warm / cool | `WARMTH` |
| Lone bright pixels | `ISOLATED_PIXELS` |
| Floor texture washed out | Lower `CAUSTICS_STRENGTH`; keep `CAUSTICS_SCREEN_BLEND` on |
| Calm floor too dark between lines | `CONTRAST` < 1 |
| Wall intensity | `WALL_STRENGTH`, `WALL_SUN_FACTOR`, `WALL_DEPTH_FADE` |
| Depth fade | `CAUSTIC_FULL_DEPTH`, `CAUSTIC_FADE_DEPTH`, `CAUSTICS_ABSORPTION` |
| Anything above the water line or on the water surface | None. That is a bug: check debug views 8 and 11. |

### Test pool

Build pools 1, 2, 4, 8 and 12 blocks deep with straight walls, a 1-block-wide wall and a pillar. Add a shore block above the water line, a sloped flowing-water edge, a roof over one part and a tree shading another.

- **Noon**: net on all floors, full through 2 blocks, dimmer at 4 and 8, gone at 11–12. Walls carry the same net, dimmer and bluer with depth, gone ~6 blocks down. Sun-facing walls are brighter; the others sit at 35 %. The roof and tree cast hard shadows. The shore block and the water surface stay clean.
- **Sunrise / sunset**: floors fade with sun height; walls facing the sun hold on longer. Walls whose water is shaded by the pool rim lose caustics (physically expected).
- **Night / rain**: no caustics.
- **Straight down vs grazing angle**: the same depth classes, because the column is vertical and independent of the view ray.
- **Crossing the surface**: the effect fades out as the eye nears the surface. Underwater it stays off unless `CAUSTICS_UNDERWATER_FLOOR` is on; then terrain gets the same net, skipping surfaces more than 2 blocks above the eye.
- **Flowing edge**: the entry point follows the sloped water mesh, so the column shrinks smoothly.

### Changelog and cost

- Replaced the sine-interference net with the orthogonal pixel network (hash-only, no texture taps).
- Added wall caustics with per-orientation planar coordinates and seeds.
- Replaced the depth-derivative receiver normal with the integer-plane test plus a robust neighbour fallback.
- Added the screen-style blend through a premultiplied water output.
- Changed the water flag to cover all fluid geometry.
- Removed `CAUSTIC_GRID_SIZE`, `CAUSTIC_QUALITY`, `CAUSTIC_LEVELS`, `CAUSTIC_ANIMATION_SPEED`, `CAUSTIC_TINT_WARMTH` and `SHALLOW_DEPTH_RANGE`. Renamed `CAUSTICS_FULL/FADE_DEPTH` to `CAUSTIC_FULL/FADE_DEPTH` and the step/grid options to `STEPS_PER_SECOND`/`TEXELS_PER_BLOCK`. Saved values for renamed options reset to their defaults.
- The shallow-water shafts now fade over 2–11 blocks instead of 3–7.
- Fixed a latent bug: the old `cameraPositionInt % 256` was undefined for negative coordinates.
- Estimated cost (GTX 1650, 1080p, not measured), per visible water pixel: 1 depth fetch, ~7–9 integer hashes, 1 shadow fetch on line pixels only, and 4 extra depth fetches on edge pixels. About 0.05–0.15 ms with heavy water coverage and 0.03–0.10 ms on LOW (one layer, no walls), against 0.05–0.30 ms for the previous path (three depth taps, three reconstructions and a shadow fetch on every pixel). No new pass or buffer. Verified only by compiling the pattern code in WebGL2 (GLSL ES 3.00), not in Iris.
