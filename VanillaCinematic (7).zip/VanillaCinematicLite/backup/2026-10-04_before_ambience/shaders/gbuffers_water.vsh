#version 330 compatibility
#define WATER_GBUFFER
#include "/lib/gbuffers.vsh"
