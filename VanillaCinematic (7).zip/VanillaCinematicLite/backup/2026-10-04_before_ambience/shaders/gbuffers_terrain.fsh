#version 330 compatibility

/*
const int colortex0Format = RGBA16F;
*/

#define TERRAIN_LAYER
#include "/lib/gbuffers_forward.fsh"

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
/* RENDERTARGETS: 0,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outDebugMaterial;
#elif defined(CAUSTICS_DEBUG)
const bool colortex1Clear = true;
const vec4 colortex1ClearColor = vec4(0.0);
/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outCausticsDebug;
#else
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
#endif

void main() {
    vec3 causticsDebug;
    outColor = shadeFragment(causticsDebug);
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
    vec4 debugTexel = texture(gtexture, vTexCoord) * vColor;
    float debugLuma = dot(debugTexel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float debugEmissive = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup)) *
                          smoothstep(EMISSIVE_THRESHOLD, 1.0, debugLuma);
#if VV_DEBUG_MODE == 6
    outDebugMaterial = vec4(vec3(debugEmissive), 1.0);
#else
    vec3 materialColor = vec3(0.08);
    if (vMaterialGroup == 1.0) materialColor = vec3(0.10, 0.38, 0.68);
    else if (vMaterialGroup == 2.0) materialColor = vec3(0.18, 0.48, 0.16);
    else if (vMaterialGroup == 3.0) materialColor = vec3(0.52, 0.72, 0.22);
    else if (vMaterialGroup == 4.0) materialColor = vec3(0.48, 0.29, 0.15);
    else if (vMaterialGroup == 5.0) materialColor = vec3(0.42, 0.44, 0.48);
    else if (vMaterialGroup == 6.0) materialColor = vec3(0.62, 0.40, 0.72);
    else if (vMaterialGroup == 7.0) materialColor = vec3(0.86, 0.62, 0.19);
    else if (vMaterialGroup == 8.0) materialColor = vec3(0.18, 0.68, 0.82);
    else if (vMaterialGroup == 9.0) materialColor = vec3(0.95, 0.22, 0.08);
    outDebugMaterial = vec4(materialColor, 1.0);
#endif
#elif defined(CAUSTICS_DEBUG)
    outCausticsDebug = vec4(causticsDebug, 1.0);
#endif
}

