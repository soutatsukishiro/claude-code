#version 330 compatibility

#include "/lib/gbuffers_forward.fsh"

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
/* RENDERTARGETS: 0,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outDebugMaterial;
#else
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
#endif

void main() {
    vec3 causticsDebug;
    outColor = shadeFragment(causticsDebug);
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
    // This route has no terrain block ID; show it as unclassified in the diagnostic.
    outDebugMaterial = vec4(0.08, 0.08, 0.08, 1.0);
#endif
}

