#version 330 compatibility
#define TERRAIN_GBUFFER
#include "/lib/gbuffers.vsh"
