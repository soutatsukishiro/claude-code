#version 330 compatibility

uniform sampler2D gtexture;
uniform float alphaTestRef;

in vec2 vTexCoord;
in vec4 vColor;

void main() {
    vec4 texel = texture(gtexture, vTexCoord) * vColor;
    if (texel.a < alphaTestRef) discard;
    // Shadow pass stores depth only for lighting; shadowcolor is deliberately ignored.
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
}

