#version 330 compatibility

#include "/lib/settings.glsl"

#ifdef BLOOM
uniform sampler2D colortex0;
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES) || (defined(VV_DEBUG) && (VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 2 || VV_DEBUG_MODE == 5))
uniform sampler2D depthtex0;
#endif

#ifdef SHALLOW_WATER_LIGHTING
uniform sampler2D colortex1;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex1;
uniform sampler2D noisetex;
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || (defined(VV_DEBUG) && (VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 2 || VV_DEBUG_MODE == 5))
uniform sampler2D shadowtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES) || defined(ATMOS_DEBUG)
uniform float rainStrength;
uniform float thunderStrength;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform bool hasSkylight;
uniform bool hasCeiling;
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES)
uniform float frameTimeCounter;
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES)
uniform float atmosOverworld;
#endif

#ifdef ATMOSPHERIC_RAYS
uniform float aspectRatio;
#endif

#if defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES) || defined(GOLDEN_BLOCKY_BLOOM) || defined(TARGET_DEBUG)
uniform float viewWidth;
uniform float viewHeight;
uniform float temperature;
uniform float rainfall;
uniform float atmosHumidBiome;
uniform float atmosCoolBiome;
uniform float atmosWoodlandBiome;
uniform float atmosSavannaBiome;
uniform float atmosDesertBiome;
#endif

in vec2 vTexCoord;
in vec2 vSunUV;
in float vSunElevation;
in float vSunInFront;
in vec2 vMoonUV;
in float vMoonElevation;
in float vMoonInFront;

/* RENDERTARGETS: 5 */
/*
const int colortex5Format = RGBA16F;
*/
layout(location = 0) out vec4 postEffects;

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS)
#include "/lib/shadow_distortion.glsl"
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES)
float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_RAYS)
vec4 reconstructView(vec2 uv, float depth) {
    return gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
}

float linearDepth(float depth) {
    vec4 viewH = reconstructView(vec2(0.0), depth);
    return -viewH.z / max(viewH.w, 0.0001);
}

vec3 reconstructWorldPosition(vec2 uv, float depth, out vec3 playerPosition) {
    vec4 viewH = reconstructView(uv, depth);
    vec3 viewPosition = viewH.xyz / max(viewH.w, 0.0001);
    playerPosition = (gbufferModelViewInverse * vec4(viewPosition, 1.0)).xyz;
    return cameraPosition + playerPosition;
}

float shadowVisibility(vec3 playerPosition) {
    vec4 shadowClip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    if (shadowClip.w <= 0.0001) return 0.0;
    vec3 shadowCoord = shadowClip.xyz / shadowClip.w * 0.5 + 0.5;
    if (shadowCoord.x < 0.0 || shadowCoord.x > 1.0 ||
        shadowCoord.y < 0.0 || shadowCoord.y > 1.0 ||
        shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
        return 0.0;
    }
    return step(shadowCoord.z - 0.00075, texture(shadowtex0, shadowCoord.xy).r);
}

#ifdef SHALLOW_WATER_LIGHTING
float opaqueWaterShadowVisibility(vec3 playerPosition) {
    if (dot(playerPosition, playerPosition) > shadowDistance * shadowDistance) return 1.0;
    vec4 shadowClip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    if (shadowClip.w <= 0.0001) return 1.0;
    vec3 shadowCoord = shadowClip.xyz / shadowClip.w * 0.5 + 0.5;
    if (shadowCoord.x < 0.0 || shadowCoord.x > 1.0 ||
        shadowCoord.y < 0.0 || shadowCoord.y > 1.0 ||
        shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
        return 1.0;
    }
    // This pass shades water receivers, so translucent water must not occlude its own light.
    return step(shadowCoord.z - 0.00075, texture(shadowtex1, shadowCoord.xy).r);
}
#endif
#endif

void main() {
    vec2 uv = vTexCoord;
    vec3 postAdd = vec3(0.0);
#if defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
    float debugSunLitMask = 0.0;
    float debugRawRays = 0.0;
    float debugShadowMask = 0.0;
    vec3 debugBloomBuffer = vec3(0.0);
#endif

#if (defined(ATMOS_DEBUG) && ATMOS_DEBUG_MODE == 1) || (defined(VV_DEBUG) && VV_DEBUG_MODE == 1) || (defined(VV_DEBUG) && VV_DEBUG_MODE == 5)
    if (hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        float debugDepth = texture(depthtex0, uv).r;
        float debugDay = smoothstep(0.025, 0.24, vSunElevation) * vSunInFront;
        float debugCameraSky = smoothstep(24.0, 96.0, float(eyeBrightnessSmooth.y));
        if (debugDepth > 0.99999) {
            debugSunLitMask = debugDay * debugCameraSky;
            debugShadowMask = debugSunLitMask;
        } else if (debugDay > 0.001 && debugCameraSky > 0.001) {
            vec3 debugPlayer;
            reconstructWorldPosition(uv, debugDepth, debugPlayer);
            float debugVisibility = shadowVisibility(debugPlayer);
            debugSunLitMask = debugDay * debugCameraSky * debugVisibility;
            debugShadowMask = debugVisibility;
        }
    }
#endif

#ifdef BLOOM
    vec2 sourceTexel = 1.0 / vec2(textureSize(colortex0, 0));
    vec2 bloomUV = uv;
#ifdef GOLDEN_BLOCKY_BLOOM
    vec2 bloomResolution = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
    float bloomCell = float(GOLDEN_BLOOM_PIXEL_SIZE);
    vec2 snappedBloomUV = (floor(uv * bloomResolution / bloomCell) + 0.5) * bloomCell / bloomResolution;
    bloomUV = mix(uv, snappedBloomUV, GOLDEN_BLOOM_BLOCKINESS * float(MATCH_STRENGTH) * 0.01);
#endif
    vec3 bright = max(texture(colortex0, bloomUV).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(-2.0, 0.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2( 2.0, 0.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(0.0, -2.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(0.0,  2.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    // Existing five-tap thresholded quarter-resolution glow, bilinearly upsampled in final.
    vec3 bloomContribution = bright * 0.11 * BLOOM_STRENGTH;
    postAdd += bloomContribution;
#if defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
    debugBloomBuffer = bloomContribution;
#endif
#endif

#ifdef SHALLOW_WATER_LIGHTING
    vec4 waterInfo = texture(colortex1, uv);
    if (waterInfo.r > 0.50 && vSunInFront > 0.5 && hasSkylight && !hasCeiling && atmosOverworld > 0.5) {
        float waterDepth = texture(depthtex0, uv).r;
        float floorDepth = texture(depthtex1, uv).r;
        if (floorDepth < 0.99999 && waterDepth < 0.99999 && waterDepth + 0.00001 < floorDepth) {
            float waterDistance = linearDepth(waterDepth);
            vec3 waterPlayer;
            vec3 waterWorld = reconstructWorldPosition(uv, waterDepth, waterPlayer);
            vec3 floorPlayer;
            vec3 floorWorld = reconstructWorldPosition(uv, floorDepth, floorPlayer);
            float waterColumn = max(waterWorld.y - floorWorld.y, 0.0);
            // Shares the caustic depth range (the old SHALLOW_DEPTH_RANGE slider was removed).
            float depthMask = 1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, waterColumn);
            float distanceFade = 1.0 - smoothstep(40.0, 48.0, waterDistance);
            float sunFade = smoothstep(0.025, 0.24, vSunElevation);
            float rainFade = 1.0 - clamp(rainStrength, 0.0, 1.0);
            float skyLight = smoothstep(0.22, 0.92, waterInfo.g);
            float shallowMask = depthMask * distanceFade;

            if (shallowMask > 0.002 && skyLight > 0.01 && sunFade > 0.01) {
            // The fluid mask is registered at full resolution; this is the existing quarter-res approximation.
            float directWaterLight = shallowMask * skyLight * sunFade * rainFade * opaqueWaterShadowVisibility(floorPlayer);
            vec2 scroll = vec2(frameTimeCounter * 0.0031, -frameTimeCounter * 0.0023);
            vec2 waterUV = fract(floorWorld.xz * 0.035 + scroll);
            vec2 rayStretch = (vSunUV - uv) * RAY_LENGTH * 0.24;
            float waterRaySum = 0.0;
            float waterRayWeight = 0.0;
            for (int i = 0; i < 6; ++i) {
                float t = float(i + 1) / 6.0;
                float weight = 1.0 - t * 0.35;
                waterRaySum += texture(noisetex, fract(waterUV + rayStretch * t + scroll * t)).r * weight;
                waterRayWeight += weight;
            }
            float waterRays = smoothstep(0.48, 0.70, waterRaySum / max(waterRayWeight, 0.001));
            postAdd += vec3(0.42, 0.72, 0.92) * waterRays * RAY_INTENSITY * 0.30 * directWaterLight;

            float waterDepthBlend = clamp(waterColumn / CAUSTIC_FADE_DEPTH, 0.0, 1.0);
            vec3 depthTint = mix(vec3(0.18, 0.72, 0.82), vec3(0.035, 0.17, 0.42), waterDepthBlend);
            postAdd += depthTint * directWaterLight * 0.06;
            }
        }
    }
#endif

#if defined(ATMOSPHERIC_RAYS) || defined(ATMOSPHERIC_PARTICLES)
    float cameraSkyFade = smoothstep(24.0, 96.0, float(eyeBrightnessSmooth.y));
#endif

#ifdef ATMOSPHERIC_RAYS
    if (hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        float sunStrength = smoothstep(0.025, 0.24, vSunElevation) * vSunInFront * cameraSkyFade;
        float nightFade = 1.0 - smoothstep(-0.12, 0.02, vSunElevation);
        float moonStrength = 0.025 * nightFade * smoothstep(0.015, 0.20, vMoonElevation) * vMoonInFront * cameraSkyFade;
        float moonMode = moonStrength > sunStrength ? 1.0 : 0.0;
        float celestialStrength = max(sunStrength, moonStrength);
        vec2 celestialUV = mix(vSunUV, vMoonUV, moonMode);
        float celestialInFront = mix(vSunInFront, vMoonInFront, moonMode);
        if (celestialStrength > 0.001 && celestialInFront > 0.5) {
        vec2 rayUV = uv;
#ifdef PIXEL_SNAPPED_RAYS
        vec2 fullResolution = vec2(viewWidth, viewHeight);
        vec2 snappedPixel = floor(uv * fullResolution / float(PIXEL_RAY_GRID)) * float(PIXEL_RAY_GRID)
                         + vec2(float(PIXEL_RAY_GRID) * 0.5);
        rayUV = snappedPixel / fullResolution;
#endif
        vec2 toSun = celestialUV - rayUV;
        float sunScreenDistance = length(toSun * vec2(aspectRatio, 1.0));
        float coneWidth = mix(0.46, 1.25, clamp(ATMOS_RAY_SOFTNESS * 8.0, 0.0, 1.0));
        float viewCone = 1.0 - smoothstep(0.18, coneWidth, sunScreenDistance);
        if (viewCone > 0.001) {
            float sceneDepth = texture(depthtex0, uv).r;
            float weatherFade = clamp(1.0 - rainStrength * 0.82 - thunderStrength * 0.18, 0.0, 1.0);
            float currentLit = 1.0;
            if (sceneDepth < 0.99999) {
                vec3 scenePlayer;
                reconstructWorldPosition(uv, sceneDepth, scenePlayer);
                currentLit = shadowVisibility(scenePlayer);
            }

            float jitter = cheapHash(floor(gl_FragCoord.xy) + vec2(floor(frameTimeCounter * 6.0), 17.0));
            vec2 rayDirection = toSun * ATMOS_RAY_LENGTH;
            vec2 perpendicular = vec2(-rayDirection.y, rayDirection.x);
            vec2 lateralJitter = perpendicular * ((jitter - 0.5) * ATMOS_RAY_SOFTNESS);
            float openSum = 0.0;
            float weightSum = 0.0;
            float weight = 1.0;
            for (int i = 0; i < ATMOS_RAY_SAMPLES; ++i) {
                float t = (float(i) + jitter) / float(ATMOS_RAY_SAMPLES);
                vec2 tapUV = clamp(rayUV + rayDirection * t + lateralJitter * t, vec2(0.001), vec2(0.999));
                float openSky = step(0.99995, texture(depthtex0, tapUV).r);
                openSum += openSky * weight;
                weightSum += weight;
                weight *= 0.78;
            }
            float opening = openSum / max(weightSum, 0.001);
            float beamContrast = 4.0 * opening * (1.0 - opening);
            float rayAmount = beamContrast * viewCone * celestialStrength * weatherFade * currentLit * ATMOS_RAY_INTENSITY;
#if defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
            debugRawRays = rayAmount;
#endif
#ifdef PIXEL_SNAPPED_RAYS
            rayAmount = floor(clamp(rayAmount / max(ATMOS_RAY_INTENSITY, 0.0001), 0.0, 1.0) * 4.0 + 0.5) * 0.25 * ATMOS_RAY_INTENSITY;
#endif

            float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.0, rainfall) * 0.25), 0.0, 1.0);
            float coldWeight = clamp(atmosCoolBiome, 0.0, 1.0);
            float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
            float twilight = (1.0 - moonMode) * (1.0 - smoothstep(0.035, 0.32, abs(vSunElevation)));
            vec3 sunRayTint = mix(vec3(1.00, 0.94, 0.82), vec3(0.95, 0.70, 0.50), twilight * 0.72);
            sunRayTint = mix(sunRayTint, vec3(0.52, 0.66, 0.86), moonMode);
            sunRayTint = mix(sunRayTint, vec3(0.45, 0.80, 0.73), humidWeight * BIOME_TINT_STRENGTH);
            sunRayTint = mix(sunRayTint, vec3(0.91, 0.64, 0.42), autumnWeight * BIOME_TINT_STRENGTH);
            sunRayTint = mix(sunRayTint, vec3(0.83, 0.65, 0.44), atmosDesertBiome * BIOME_TINT_STRENGTH * 0.70);
            sunRayTint = mix(sunRayTint, vec3(0.58, 0.72, 0.87), coldWeight * BIOME_TINT_STRENGTH);
#ifdef GOLDEN_TARGET_RAYS
            float targetRayMatch = float(MATCH_STRENGTH) * 0.01;
            float goldenRayWindow = max(twilight, autumnWeight * (1.0 - smoothstep(0.12, 0.50, max(vSunElevation, 0.0))));
            float targetRayMask = (1.0 - moonMode) * goldenRayWindow * (1.0 - rainStrength * 0.60);
            sunRayTint = mix(sunRayTint, vec3(1.00, 0.76, 0.48), clamp(targetRayMask * targetRayMatch * 0.72, 0.0, 0.72));
            rayAmount *= 1.0 + GOLDEN_RAY_BOOST * targetRayMask * targetRayMatch;
#endif
            postAdd += sunRayTint * rayAmount;

        }
        }
    }
#endif

#ifdef ATMOSPHERIC_PARTICLES
    if (hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        float particleSun = smoothstep(0.025, 0.24, vSunElevation) * vSunInFront;
        particleSun *= cameraSkyFade * clamp(1.0 - rainStrength * 0.82 - thunderStrength * 0.18, 0.0, 1.0);
        float openSky = step(0.99995, texture(depthtex0, uv).r);
        float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.0, rainfall) * 0.25), 0.0, 1.0);
        float woodlandWeight = clamp(max(atmosWoodlandBiome, atmosSavannaBiome), 0.0, 1.0);
        float forestFactor = max(woodlandWeight, humidWeight);
        vec2 screenCell = floor(uv * vec2(viewWidth, viewHeight) / 32.0);
        float particleTick = floor(frameTimeCounter * 1.5);
        float moteHash = cheapHash(screenCell + vec2(particleTick, particleTick * 0.37));
        float mote = step(0.987, moteHash) * openSky * particleSun * forestFactor * PARTICLE_AMOUNT;
        postAdd += vec3(1.0, 0.84, 0.62) * mote;
    }
#endif

#ifdef VV_DEBUG
#if VV_DEBUG_MODE == 1
    postEffects = vec4(vec3(debugSunLitMask), 0.0);
#elif VV_DEBUG_MODE == 2
    postEffects = vec4(vec3(debugRawRays), 0.0);
#elif VV_DEBUG_MODE == 5
    postEffects = vec4(vec3(debugShadowMask), 0.0);
#elif VV_DEBUG_MODE == 9
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    postEffects = vec4(0.0);
#endif
#elif defined(TARGET_DEBUG)
#if TARGET_DEBUG_MODE == 6
    postEffects = vec4(vec3(debugRawRays), 0.0);
#elif TARGET_DEBUG_MODE == 7
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    postEffects = vec4(0.0);
#endif
#elif defined(ATMOS_DEBUG)
#if ATMOS_DEBUG_MODE == 1
    postEffects = vec4(vec3(debugSunLitMask), 0.0);
#elif ATMOS_DEBUG_MODE == 2
    postEffects = vec4(vec3(debugRawRays), 0.0);
#elif ATMOS_DEBUG_MODE == 6
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    postEffects = vec4(vec3(0.0), 0.0);
#endif
#else
    postEffects = vec4(postAdd, 0.0);
#endif
}
