#version 330 compatibility

// colortex1 is white by default in Iris; the water mask needs an empty zero baseline.
const bool colortex1Clear = true;
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
// 8-bit unsigned channels: the packed reflection byte in B must survive exactly.
/*
const int colortex1Format = RGBA8;
*/

#define WATER_LAYER
#include "/lib/gbuffers_forward.fsh"

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWaterInfo;
layout(location = 2) out vec4 outDebugMaterial;
#else
/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWaterInfo;
#endif

#if defined(WAVE_DEBUG) && WAVE_DEBUG_MODE == 10
uniform float viewWidth;
#endif

void main() {
    vec3 causticsDebug;
    vec4 shaded = shadeFragment(causticsDebug);
    float transmission = 1.0 - shaded.a;
    vec3 waveLight = gWaveLight;
#if defined(WAVE_DEBUG) && WAVE_DEBUG_MODE == 10
    // Split screen: left half with the crest light, right half without.
    if (gl_FragCoord.x > 0.5 * viewWidth) waveLight = vec3(0.0);
#endif
    // Water seen through, premultiplied: water * a + (1 - a) * (floor * (1 - k) + L). The caustic
    // light L and the mosaic/screen factor k act on the floor BEFORE the water blend.
    vec3 below = shaded.rgb * shaded.a + transmission * gCausticLight.rgb;
    float floorFactor = transmission * (1.0 - gCausticLight.a);
    float reflectivity = 0.0;
    vec3 reflection = vec3(0.0);
#ifdef WATER_SKY_REFLECTION
    reflectivity = gWaterReflection.a;
    reflection = gWaterReflection.rgb;
#endif
    // Reflection on top: result = mix(water seen through, reflection, R). R also raises the
    // effective opacity, so the far, reflective surface hides the floor.
    vec3 premultiplied = mix(below, reflection, reflectivity);
    float alpha = 1.0 - (1.0 - reflectivity) * floorFactor;
    // Wave crest light sits on the surface itself: not transmitted, screened over the water.
    premultiplied += waveLight * clamp(1.0 - premultiplied, 0.0, 1.0);
#ifdef CAUSTICS_SCREEN_BLEND
    // shaders.properties sets blend ONE ONE_MINUS_SRC_ALPHA for this program. Without
    // caustics or reflection this equals the standard alpha blend.
    outColor = vec4(premultiplied, alpha);
#else
    // Standard alpha blend gives the same result: rgb * alpha + floor * (1 - alpha).
    outColor = vec4(premultiplied / max(alpha, 0.02), alpha);
#endif
    float fluid = vIsFluid > 0.5 ? 1.0 : 0.0;
    // B packs the Tier-2 reflection weight (5 bits) and a wave-driven wobble (3 bits) for final.
    float tier2Weight = 0.0;
    float wobble = 0.5;
#ifdef WATER_SSR
    tier2Weight = gReflectionTier2;
    wobble = gWaterWobble;
#endif
    float packedReflection = (floor(clamp(tier2Weight, 0.0, 1.0) * 31.0 + 0.5) * 8.0 + floor(wobble * 7.0 + 0.5)) / 255.0;
#if defined(VV_DEBUG) && VV_DEBUG_MODE == 8
    outWaterInfo = vec4(vec3(fluid), 1.0);
#elif defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10
    outWaterInfo = vec4(gWaveDebug, 1.0);
#elif defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 10
    outWaterInfo = vec4(vec3(alpha * fluid), 1.0);
#elif defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE != 3 && REFLECTION_DEBUG_MODE != 4 && REFLECTION_DEBUG_MODE != 5 && REFLECTION_DEBUG_MODE != 12
    outWaterInfo = vec4(gReflectionDebug, 1.0);
#elif defined(CAUSTICS_DEBUG)
    outWaterInfo = vec4(causticsDebug, 1.0);
#else
    // R = fluid marker, G = surface sky light, B = packed reflection data, A = fluid marker
    // (alpha 1 on water overwrites; 0 elsewhere leaves the target untouched).
    outWaterInfo = vec4(fluid, clamp(vLightCoord.y, 0.0, 1.0), packedReflection * fluid, fluid);
#endif

#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
    vec4 debugTexel = texture(gtexture, vTexCoord) * vColor;
    float debugLuma = dot(debugTexel.rgb, vec3(0.2126, 0.7152, 0.0722));
    float debugEmissive = step(8.5, vMaterialGroup) * (1.0 - step(9.5, vMaterialGroup)) *
                          smoothstep(EMISSIVE_THRESHOLD, 1.0, debugLuma);
#if VV_DEBUG_MODE == 6
    outDebugMaterial = vec4(vec3(debugEmissive), 1.0);
#else
    vec3 materialColor = vec3(0.08);
    if (vMaterialGroup == 1.0) materialColor = vec3(0.10, 0.38, 0.68);
    else if (vMaterialGroup == 2.0) materialColor = vec3(0.18, 0.48, 0.16);
    else if (vMaterialGroup == 3.0) materialColor = vec3(0.52, 0.72, 0.22);
    else if (vMaterialGroup == 4.0) materialColor = vec3(0.48, 0.29, 0.15);
    else if (vMaterialGroup == 5.0) materialColor = vec3(0.42, 0.44, 0.48);
    else if (vMaterialGroup == 6.0) materialColor = vec3(0.62, 0.40, 0.72);
    else if (vMaterialGroup == 7.0) materialColor = vec3(0.86, 0.62, 0.19);
    else if (vMaterialGroup == 8.0) materialColor = vec3(0.18, 0.68, 0.82);
    else if (vMaterialGroup == 9.0) materialColor = vec3(0.95, 0.22, 0.08);
    outDebugMaterial = vec4(materialColor, 1.0);
#endif
#endif
}
