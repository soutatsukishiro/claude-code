// Shared Iris options. Disabled Boolean options remove their shader code at compile time.
#define BLOOM // Quarter-resolution soft glow
//#define BLOOM
#define WET_GROUND // Rain-reactive exposed ground
//#define WET_GROUND
#define SHALLOW_WATER_LIGHTING // Existing shallow-water shafts and surface sparkle
//#define SHALLOW_WATER_LIGHTING
#define PIXEL_CAUSTICS // Pixel-snapped Voronoi caustics on submerged surfaces
//#define PIXEL_CAUSTICS
#define CAUSTICS_WALLS // Caustics on submerged side faces (walls, pillars, cliffs)
#define CAUSTICS_SCREEN_BLEND // Screen-style blend and mosaic via premultiplied water output; off = plain additive
#define WATER_DEPTH_TINT // Clear light-teal shallows that turn deep blue and opaque with depth
#define WATER_SSR // Tier 2: screen-space planar reflection of terrain and clouds in final (needs Tier 1)
//#define REFLECTION_DEBUG // Diagnostic views for the water reflection system
#define WAVE_LIGHTING // Soft sun/moon light on the vanilla animated wave texels
//#define WAVE_DEBUG // Diagnostic views for the wave lighting
#if defined(REFLECTION_DEBUG) && !defined(WATER_SKY_REFLECTION)
#define WATER_SKY_REFLECTION
#endif
#if defined(REFLECTION_DEBUG) && !defined(WATER_SSR)
#define WATER_SSR
#endif
#if defined(WATER_SSR) && !defined(WATER_SKY_REFLECTION)
#undef WATER_SSR
#endif
#if defined(WAVE_DEBUG) && !defined(WAVE_LIGHTING)
#define WAVE_LIGHTING
#endif
//#define CAUSTICS_DEBUG // Diagnostic views for the caustic receiver
//#define CAUSTICS_DEBUG
//#define CAUSTICS_UNDERWATER_FLOOR // Optional caustics on terrain while the camera is submerged; default off
#if defined(CAUSTICS_DEBUG) && !defined(PIXEL_CAUSTICS)
#define PIXEL_CAUSTICS
#endif
#define ATMOSPHERIC_RAYS // Quarter-resolution shafts through canopy gaps
//#define ATMOSPHERIC_RAYS
#define ATMOSPHERIC_HAZE // Analytic distance and height haze in final
//#define ATMOSPHERIC_HAZE
#define ATMOSPHERIC_GRADE // Warm sunlight, cool shade, and restrained vibrance
//#define ATMOSPHERIC_GRADE
#define ATMOS_TONE_MAP // Existing cinematic shoulder and highlight finish
//#define ATMOS_TONE_MAP
#define ATMOSPHERIC_PARTICLES // Sparse screen-space pollen motes
//#define ATMOSPHERIC_PARTICLES
#define LEAF_TRANSLUCENCY // Subtle sun back-light on mapped leaves
//#define LEAF_TRANSLUCENCY
#define ENTITY_SHADOWS // Render entities, block entities, and the player into the shadow map
//#define ENTITY_SHADOWS
#define PIXEL_SHADOWS // Stabilized world-grid position and nearest shadow texel
//#define PIXEL_SHADOWS
#define DIRECTIONAL_LIGHTING // Small sun/moon directional contribution on terrain
//#define DIRECTIONAL_LIGHTING
#define WATER_SKY_REFLECTION // Tier 1: analytic sky/cloud reflection with Fresnel and distance blend (no texture fetch)
//#define WATER_SKY_REFLECTION
#define MATERIAL_RESPONSE // Cheap terrain material groups from block.properties
//#define MATERIAL_RESPONSE
#define SUBSURFACE_TRANSMISSION // Back-light tint for leaves, plants, and translucent blocks
//#define SUBSURFACE_TRANSMISSION
#define EMISSIVE_BLOCKS // Texture-masked boost for tagged terrain emitters
//#define EMISSIVE_BLOCKS
#define SKY_GRADE // View-direction sky gradient and color finish in final
//#define SKY_GRADE
#define ATMOS_VIGNETTE // Subtle final-pass edge falloff
//#define ATMOS_VIGNETTE
#define PROCEDURAL_STARS // Sparse sky-anchored stars in the final sky treatment
//#define PROCEDURAL_STARS
#define CELESTIAL_GLOW // Soft halos around the vanilla sun and moon discs
//#define CELESTIAL_GLOW
//#define PIXEL_SNAPPED_RAYS // Quantize atmospheric shafts to a coarse screen grid
//#define PIXEL_SNAPPED_RAYS
//#define PIXEL_WATER_SPARKLES // Sparse world-grid glints on the water surface
//#define PIXEL_WATER_SPARKLES
//#define ATMOS_DEBUG // Diagnostic views for sky, rays, haze, biome blend, and bloom
//#define VV_DEBUG // Nine diagnostic views; extra MRT code exists only in this mode

// Golden-hour screenshot match. Each effect is independently compiled out when disabled.
#define GOLDEN_SUN_GLOW // Screen-space square sun core and pixel-stepped glow
#define GOLDEN_TARGET_SKY // Golden-hour zenith/horizon palette blend
#define SECONDARY_GOLDEN_ORB // Optional artistic flare orb; not a second Minecraft sun
#define GOLDEN_TARGET_HAZE // Extra amber distance haze and a cheap sun-facing phase term
#define GOLDEN_TARGET_GRADE // Warm low-sun grade and gentle shadow lift
#define GOLDEN_TARGET_RAYS // Additional soft golden-hour weight on the existing ray route
#define GOLDEN_TARGET_BACKLIGHT // Additional warm foliage/grass/flower edge light
#define GOLDEN_BLOCKY_BLOOM // Pixelate the existing quarter-resolution bloom source
#define GOLDEN_SOFT_VIGNETTE // Optional target-style vignette contribution
#define GOLDEN_FAKE_BIRDS // Procedural screen-space bird silhouettes; visual fake, not entities
//#define TARGET_DEBUG // Golden-hour diagnostics (compiled out when disabled)

#define GLOSS_STRENGTH 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.38 0.45] Gloss strength
#define HIGHLIGHT_SIZE 28 // [12 16 20 24 28 32 36 42 48] Highlight size (higher values make a tighter highlight)
#define FRESNEL_STRENGTH 0.07 // [0.00 0.03 0.05 0.07 0.09 0.12 0.16 0.20] Fresnel rim strength
#define PLASTIC_GLOSS_MIX 1.00 // [0.00 0.25 0.50 0.75 1.00] Blend out the original plastic gloss layer
#define SHADOW_QUALITY 1 // [1 2 3] Shadow filtering: 1 tap, 4 taps, or 8 taps
#define SHADOW_PIXEL_GRID 16 // [8 16 32] World texels per block for stabilized shadow receivers
#define DIRECTIONAL_LIGHT_STRENGTH 0.08 // [0.00 0.03 0.05 0.08 0.12 0.18] Directional sun/moon fill
#define WATER_REFLECTION_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Overall water reflectivity multiplier
#define MATERIAL_RESPONSE_STRENGTH 0.16 // [0.00 0.06 0.10 0.16 0.24 0.32] Non-plastic material response
#define THIN_TRANSMISSION_STRENGTH 0.07 // [0.00 0.03 0.05 0.07 0.11 0.16] Back-light through thin materials
#define EMISSIVE_STRENGTH 0.42 // [0.00 0.15 0.28 0.42 0.60 0.85] Tagged emitter lift
#define EMISSIVE_THRESHOLD 0.58 // [0.30 0.42 0.58 0.70 0.82] Texture brightness needed for emissive lift
#define RAY_INTENSITY 0.18 // [0.00 0.05 0.10 0.18 0.22 0.30 0.40] Existing shallow-water shaft intensity
#define RAY_LENGTH 0.55 // [0.20 0.35 0.45 0.55 0.62 0.75 0.90] Existing shallow-water shaft reach
#define CAUSTICS_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50] Caustic intensity; 1.0 = measured reference swatches
#define VORONOI_QUALITY 2 // [1 2] Cell search: 1 = 2x2 (LOW), 2 = full 3x3
#define TEXELS_PER_BLOCK 16 // [8 16 32] Caustic texels per block; 16 matches vanilla textures
#define CELL_SIZE_TEXELS 8 // [6 7 8 10 12 14 16] Voronoi point spacing in texels; 8 matches the measured reference
#define CELL_CURVE 2.50 // [0.00 1.00 1.50 2.00 2.50 3.00 4.00] Smooth warp in texels that bends straight cell edges into curves
#define CELL_JITTER 0.85 // [0.30 0.50 0.60 0.75 0.85 1.00] Point randomness inside each cell; lower = more regular
#define LINE_WIDTH 0.90 // [0.75 0.90 1.00 1.25 1.50 2.00] Line width in texels (constant, measured from the cell bisector)
#define EDGE_HALO 0.35 // [0.00 0.25 0.35 0.45 0.65] One-sided dim halo next to lines; 0 = off
#define EDGE_DROPOUT 0.05 // [0.00 0.04 0.05 0.08 0.12 0.20] Share of 3-texel line stretches left as gaps
#define EDGE_TWINKLE 1.0 // [0.0 0.5 1.0 2.0 3.0] Per-edge brightness changes per second; 0 = static
#define ISOLATED_PIXELS 0.010 // [0.000 0.005 0.010 0.020 0.040] Chance of a lone bright texel near the lines
#define PEAK_AMOUNT 0.30 // [0.00 0.15 0.30 0.45 0.60 1.00] Share of the brightest stretches turned into the cream peak
#define WARMTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Peak colour: cool white to warm cream
#define CONTRAST 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00] 1 = calm floor gets no line light; lower adds a faint fill
#define MOSAIC_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50] Soft floor tone patches (-10 % / -3 % / +4 % at 1.0)
#define MOSAIC_CELL_SIZE 3 // [2 3 4] Mosaic patch size in texels
#define STEPS_PER_SECOND 8 // [2 4 6 8 10 12] Flip-book animation steps per second
#define CELL_ORBIT 2 // [0 1 2 3] Radius in texels of each point's stepped orbit; 0 = no deformation
#define DRIFT_SPEED 0.5 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0] Slow global drift in texels per second
#define DRIFT_DIRECTION 45 // [0 45 90 135 180 225 270 315] Global drift direction in degrees
#define CAUSTIC_FULL_DEPTH 2.0 // [0.0 1.0 2.0 3.0 4.0] Full-strength caustics through this depth in blocks
#define CAUSTIC_FADE_DEPTH 11.0 // [6.0 8.0 9.0 10.0 11.0 12.0 14.0] Lines fade to zero at this depth; the mosaic at 1.5x
#define WALL_STRENGTH 0.45 // [0.00 0.25 0.35 0.45 0.55 0.70 0.85 1.00] Wall caustics relative to the floor
#define WALL_DEPTH_FADE 6.0 // [2.0 4.0 6.0 8.0 10.0 12.0] Wall caustics fade to zero this many blocks below the surface
#define WALL_SUN_FACTOR 0.65 // [0.00 0.25 0.50 0.65 0.80 1.00] Sun-facing weight on walls; 1 - value is the minimum
#define WAVE_LIGHT_STRENGTH 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00 1.40 2.00] Overall sun light on wave crests; 0 = plain base water
#define DIFFUSE_AMOUNT 0.25 // [0.00 0.10 0.25 0.40 0.60] Soft wrap-diffuse light on crests facing the sun
#define GLINT_AMOUNT 0.35 // [0.00 0.15 0.35 0.50 0.75 1.00] Sun glint on crests (strong toward a low sun)
#define GLINT_SIZE 0.20 // [0.10 0.15 0.20 0.30 0.40] Glint roughness; larger = wider, softer sun path
#define CREST_CONTRAST 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00] How many texture texels count as crests
#define CREST_LEVELS 3 // [2 3 4] Crest brightness levels including the unlit base
#define WAVE_NORMAL_STRENGTH 0.12 // [0.00 0.06 0.12 0.18 0.25] Pseudo-normal tilt from the wave texture
#define WAVE_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10] Luma / wave / crest raw / crest / normal / diffuse / glint / shadow+sky / crest light / split screen
#define FRESNEL_STRENGTH 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] Angle-based (Fresnel) reflectivity
#define FAR_REFLECTIVITY 0.85 // [0.00 0.40 0.60 0.75 0.85 0.95] Reflectivity reached at REFLECT_FAR_DISTANCE
#define REFLECT_NEAR_DISTANCE 6 // [2 4 6 8 12 16] Horizontal distance (blocks) where the distance blend starts
#define REFLECT_FAR_DISTANCE 60 // [30 40 50 60 80 100 128] Horizontal distance (blocks) where it is complete
#define REFLECTION_BLUR 3 // [1 3 5] Vertical taps of the screen-space reflection (1 = sharp)
#define REFLECTION_STRETCH 2 // [1 2 3 4 6] Screen pixels between the vertical taps
#define REFLECTION_WOBBLE 1.0 // [0.0 0.5 1.0 1.5 2.0] Vertical wobble of the reflection driven by the vanilla wave texels
#define WATER_SSR_REFINE 1 // [1 2 3] Planar refinement steps of the screen-space reflection (3 = Tier 3 quality)
#define CLOUD_REFLECTION 0.25 // [0.00 0.15 0.25 0.35 0.50 0.75] Faint procedural cloud reflection (Tier 1)
#define STREAK_CONTRAST 1.00 // [0.00 0.50 0.75 1.00 1.25 1.50] How strongly wave crests catch the reflection
#define STREAK_DISTANCE_FADE 0.60 // [0.00 0.30 0.60 0.80 1.00] Fade of the streaks into the haze at the far end
#define STREAK_LOD_BIAS 0.0 // [-1.0 -0.5 0.0 0.5 1.0] Mip bias for the streak mask; higher = calmer far streaks
#define HORIZON_BLEND 1.00 // [0.00 0.25 0.50 0.75 1.00] Fade of terrain and water into the sky colour at the render distance
#define REFLECTION_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12] Reflect dir / tier 1 / tier 2 / tier 2 valid / UV / Fresnel / distance / reflectivity / column / opacity / crest / before-after fog
#define SHALLOW_TINT 1 // [0 1 2 3] Shallow water colour (< ~2 blocks): vanilla biome / turquoise / light teal / clear cyan
#define NEAR_WATER_TINT 1 // [0 1 2 3] Water colour near the camera at normal depth: dark biome / deep blue / navy / teal blue
#define FAR_WATER_TINT 1 // [0 1 2 3] Water's own colour far away, under the reflection: fog colour / lavender blue / steel blue / teal grey
#define WATER_OPACITY_NEAR 0.30 // [0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60] Water opacity near the camera in shallow water
#define WATER_OPACITY_FAR 0.90 // [0.50 0.70 0.80 0.90 0.95 1.00] Water opacity reached at REFLECT_FAR_DISTANCE
#define ABSORPTION_STRENGTH 0.25 // [0.10 0.15 0.20 0.25 0.32 0.40 0.55] Per-block shift to deep tint/opacity; also caustic absorption
#define SPARKLE_AMOUNT 0.12 // [0.00 0.05 0.08 0.12 0.18 0.25 0.35] Water surface sparkle amount
#define ATMOS_RAY_INTENSITY 0.16 // [0.00 0.04 0.08 0.12 0.16 0.19 0.20 0.22 0.24] Soft sun-ray intensity
#define ATMOS_RAY_SOFTNESS 0.05 // [0.01 0.03 0.05 0.07 0.10] Soft ray spread
#define ATMOS_RAY_LENGTH 0.52 // [0.25 0.40 0.52 0.65 0.80] Soft ray reach
#define ATMOS_RAY_SAMPLES 10 // [8 10 12] Quarter-resolution depth taps
#define PIXEL_RAY_GRID 8 // [4 8 16] Screen pixels per optional snapped-ray cell
#define HAZE_DENSITY 0.0020 // [0.0005 0.0010 0.0018 0.0020 0.0024 0.0025 0.0035 0.0050] Distance haze density
#define HAZE_HEIGHT_FALLOFF 0.025 // [0.000 0.010 0.025 0.040 0.060] Thin haze with altitude
#define WARM_COOL_STRENGTH 0.10 // [0.00 0.04 0.08 0.10 0.14 0.20] Sun and shade color split
#define VIBRANCE_STRENGTH 0.08 // [0.00 0.04 0.08 0.12 0.18 0.25] Safe green vibrance
#define BIOME_TINT_STRENGTH 0.22 // [0.00 0.08 0.16 0.22 0.32 0.45] Biome haze palette strength
#define TONE_SHOULDER_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00] Existing cinematic shoulder strength
#define BLOOM_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.07 0.10 0.14] Bloom strength
#define BLOOM_THRESHOLD 0.72 // [0.45 0.60 0.72 0.82 0.92] Bloom cutoff
#define PARTICLE_AMOUNT 0.06 // [0.00 0.03 0.06 0.10 0.16 0.24] Screen-space pollen amount
#define LEAF_TRANSMISSION 0.08 // [0.00 0.03 0.06 0.08 0.12 0.18] Leaf back-light strength
#define VIGNETTE_STRENGTH 0.055 // [0.00 0.02 0.035 0.055 0.065 0.08 0.12] Vignette strength
#define CAUSTICS_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15] Axis / texel grid / cell ids / F1 / edge / line raw / line / edge level / mosaic / levels / column / submerged / shadow / final / water flag
#define ATMOS_DEBUG_MODE 1 // [1 2 3 4 5 6] Sunlit / rays / fog / biome / sky / bloom
#define VV_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8 9] Sunlit / rays / fog / biome / shadow / emissive / material / water / bloom
#define SKY_QUALITY 2 // [1 2] Coarse or fine procedural star grid
#define SKY_GRADIENT_STRENGTH 0.32 // [0.00 0.16 0.28 0.32 0.42 0.48 0.55 0.64] Analytic sky blend strength
#define SUN_STYLE 1 // [0 1] 0 keeps vanilla square; 1 adds a soft round disc treatment
#define SUN_DISC_SIZE 0.020 // [0.010 0.014 0.018 0.020 0.024 0.030] Soft sun disc half-width in screen UV
#define STAR_AMOUNT 0.35 // [0.00 0.15 0.22 0.25 0.35 0.45 0.50 0.55 0.75] Procedural star density
#define CELESTIAL_GLOW_STRENGTH 0.08 // [0.00 0.03 0.05 0.06 0.08 0.10 0.12 0.15 0.18] Sun/moon halo strength
#define CELESTIAL_GLOW_RADIUS 0.075 // [0.025 0.040 0.055 0.075 0.095 0.12] Screen-space halo radius

#define MATCH_STRENGTH 65 // [0 10 20 25 35 42 50 65 80 82 100] 0=current pack, 100=full golden-hour reference
#define GOLDEN_GLOW_STRENGTH 0.90 // [0.00 0.20 0.40 0.65 0.90 1.15 1.40] Blocky sun-glow intensity
#define GOLDEN_GLOW_PIXEL_SIZE 12 // [6 8 10 12 16 20 24 32] Screen-pixel cell size for the glow
#define GOLDEN_GLOW_BLOCKINESS 0.85 // [0.00 0.25 0.50 0.75 0.85 1.00] 0=smooth, 1=snapped pixels
#define GOLDEN_GLOW_LEVELS 8 // [4 6 8 10] Discrete glow brightness bands
#define GOLDEN_SUN_CORE_SIZE 0.10 // [0.04 0.06 0.08 0.10 0.12 0.14] Square sun half-size as screen height
#define GOLDEN_BAND_STRENGTH 0.35 // [0.00 0.15 0.25 0.35 0.50 0.75 1.00] Horizontal sun flare band
#define GOLDEN_CROSS_STRENGTH 0.10 // [0.00 0.05 0.10 0.15 0.25 0.35] Faint vertical cross flare
#define SECONDARY_ORB_STRENGTH 0.28 // [0.00 0.10 0.20 0.28 0.40 0.55 0.75] Horizon orb brightness
#define SECONDARY_ORB_SIZE 0.025 // [0.010 0.015 0.020 0.025 0.035 0.045] Orb radius as screen height
#define GOLDEN_HAZE_STRENGTH 0.22 // [0.00 0.08 0.14 0.22 0.30 0.42 0.55] Added target haze blend
#define GOLDEN_HAZE_PHASE 0.35 // [0.00 0.10 0.20 0.35 0.50 0.70] Sun-facing haze glow
#define GOLDEN_GRADE_STRENGTH 0.12 // [0.00 0.04 0.08 0.12 0.18 0.24] Extra golden-hour scene grade
#define GOLDEN_SHADOW_LIFT 0.025 // [0.000 0.010 0.020 0.025 0.040 0.060] Low-sun warm shadow lift
#define GOLDEN_BACKLIGHT_STRENGTH 0.10 // [0.00 0.04 0.07 0.10 0.15 0.22] Warm mapped-foliage edge light
#define GOLDEN_RAY_BOOST 0.25 // [0.00 0.10 0.20 0.25 0.40 0.60] Target look boost to existing shafts
#define GOLDEN_BLOOM_BLOCKINESS 0.75 // [0.00 0.25 0.50 0.75 1.00] Pixelation of existing bloom source
#define GOLDEN_BLOOM_PIXEL_SIZE 16 // [8 12 16 20 24 32] Screen-pixel bloom-source grid
#define GOLDEN_VIGNETTE_STRENGTH 0.025 // [0.00 0.010 0.020 0.025 0.040 0.060] Extra edge falloff
#define GOLDEN_SKY_TINT_STRENGTH 0.70 // [0.00 0.20 0.40 0.55 0.70 0.85 1.00] Golden-hour sky tint
#define FAKE_BIRD_AMOUNT 0.65 // [0.00 0.20 0.40 0.65 0.85 1.00] Sparse procedural bird visibility
#define FAKE_BIRD_SIZE 7 // [4 5 6 7 8 10] Bird silhouette width in screen pixels
#define FAKE_BIRD_SPEED 0.0025 // [0.0000 0.0010 0.0025 0.0040 0.0060] Screen drift per frame-time second
#define TARGET_DEBUG_MODE 1 // [1 2 3 4 5 6 7 8] Sun glow / blocky glow / sky / fog / phase / shafts / bloom / grade

#ifdef TARGET_DEBUG
#ifndef GOLDEN_SUN_GLOW
#define GOLDEN_SUN_GLOW
#endif
#ifndef GOLDEN_TARGET_SKY
#define GOLDEN_TARGET_SKY
#endif
#ifndef SECONDARY_GOLDEN_ORB
#define SECONDARY_GOLDEN_ORB
#endif
#ifndef GOLDEN_TARGET_HAZE
#define GOLDEN_TARGET_HAZE
#endif
#ifndef GOLDEN_TARGET_GRADE
#define GOLDEN_TARGET_GRADE
#endif
#ifndef GOLDEN_BLOCKY_BLOOM
#define GOLDEN_BLOCKY_BLOOM
#endif
#ifndef BLOOM
#define BLOOM
#endif
#ifndef ATMOSPHERIC_RAYS
#define ATMOSPHERIC_RAYS
#endif
#endif

const int shadowMapResolution = 1536; // [768 1024 1280 1536 2048 3072] Shadow map resolution
const float shadowDistance = 80.0; // [48.0 64.0 72.0 80.0 88.0 96.0] Shadow distance in blocks
const float shadowDistanceRenderMul = 1.0;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;

#if defined(ATMOS_DEBUG)
#ifndef ATMOSPHERIC_RAYS
#define ATMOSPHERIC_RAYS
#endif
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#if ATMOS_DEBUG_MODE == 6 && !defined(BLOOM)
#define BLOOM
#endif
#endif

#if defined(VV_DEBUG)
#ifndef ATMOSPHERIC_RAYS
#define ATMOSPHERIC_RAYS
#endif
#ifndef ATMOSPHERIC_HAZE
#define ATMOSPHERIC_HAZE
#endif
#ifndef SKY_GRADE
#define SKY_GRADE
#endif
#ifndef BLOOM
#define BLOOM
#endif
#ifndef PIXEL_SHADOWS
#define PIXEL_SHADOWS
#endif
#ifndef EMISSIVE_BLOCKS
#define EMISSIVE_BLOCKS
#endif
#endif
