// Cheap radial shadow-map distortion: concentrates a little more map area near screen center.
// This is a single-map approximation, not true cascaded shadow maps. Cost: low.
vec3 distortShadowClip(vec3 clipPosition) {
    float radius = length(clipPosition.xy);
    clipPosition.xy /= 1.0 + 0.12 * radius;
    clipPosition.z *= 0.5;
    return clipPosition;
}
