#version 330 compatibility
#include "/lib/gbuffers.vsh"
