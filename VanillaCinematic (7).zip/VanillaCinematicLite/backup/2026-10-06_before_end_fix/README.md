# Vanilla Cinematic Lite — stylized golden-hour update

This is an Iris shaderpack update based on the latest pasted task brief. The attached jungle image remains an atmospheric reference; the new savanna image is the golden-hour target, with a vanilla square sun, coarse amber flare, layered haze, olive grass, and distant silhouettes. The attached text is the active implementation specification, while the screenshots provide visual evidence only. The pack keeps Minecraft textures, block geometry, and static vegetation.

## Current target: golden-hour savanna screenshot

The target shows a very bright, hard-edged square sun high-right of the horizon, surrounded by broad cream-to-amber glow. The glow includes obvious coarse square bands, a long horizontal streak, and a faint vertical cross flare. A smaller round amber orb appears lower and left of the main sun. The sky is cream/gold with soft cloud haze; acacia-like tree forms, grass, flowers, and terrain remain recognizably vanilla but become olive and bronze in the warm light. Far ridges and trees fade into bright layered silhouettes. Tiny bird shapes cross the open sky. The scene has lifted warm air, gentle bloom, and a restrained vignette.

Visible evidence versus interpretation:

| Feature | Observation | Certainty |
| --- | --- | --- |
| Square sun and coarse glow | Bright square core with pixel-stepped halo, horizontal band, and weak cross flare | Directly visible; exact rendering technique is unknown |
| Lower round orb | Smaller warm disc below-left of the square sun | Its presence is visible; calling it a second light source is interpretation, so it is implemented as a fake flare |
| Sky and clouds | Gold/cream sky, bright cloud edges, muted undersides and hazy horizon | Visible; cloud-edge lighting is only approximated because the pack has no cloud-specific gbuffer route |
| Terrain grading and depth | Foreground remains detailed; distant trees and hills fade warm and pale | Directly visible; the haze model behind the reference is unknown |
| Backlit leaves and grasses | Warm edges and glowing foliage near the sun | Visible; a simple normal/light-map/shadow response is an approximation |
| Birds | Small dark wing-like silhouettes | Visible; they are represented as optional screen-space marks, never Minecraft entities |

### Gap analysis

“Exact” means the visible shape can be kept or recreated in the current route; it does not claim renderer parity with the reference. “Approximate” means an Iris-compatible effect with different implementation or limited coverage.

| # | Target feature | Pack before this update → new implementation | Match | Limitation |
| --- | --- | --- | --- |
| 1 | Square white sun, large pixel glow, horizontal and cross bands | Before: `SUN_STYLE=1` softened/replaced the vanilla disc and drew a smooth halo. Now: the target match restores the vanilla square plus `GOLDEN_SUN_GLOW` adds snapped, posterized bands | Approximate | Analytic screen-space glow, not the unknown reference bloom kernel; core size and footprint vary by resolution |
| 2 | Lower round glow orb | Before: none. Now: `SECONDARY_GOLDEN_ORB` in `final.fsh` adds a low-sun flare offset from the sun UV | Approximate | Deliberately fake lens flare, not a second celestial body or reflection |
| 3 | Amber sky and backlit clouds | Before: analytic gradient and vanilla cloud route. Now: `GOLDEN_TARGET_SKY` tints analytic sky pixels; final haze/grade can affect cloud pixels included in the final scene-depth route | Approximate | Vanilla cloud geometry/texture remains; no independent cloud-edge lighting, and cloud depth behavior depends on the renderer path |
| 4 | Warm low-contrast scene, olive grass and bronze leaves | Before: restrained warm/cool grade. Now: `GOLDEN_TARGET_GRADE` in `final.fsh`; direct-light grade remains in `gbuffers_forward.fsh` | Approximate | Camera biome uniforms tint the whole scene; no per-pixel biome map or flower-texture classifier |
| 5 | Layered golden distance haze | Before: existing analytic haze. Now: `GOLDEN_TARGET_HAZE` reuses its fog factor in `final.fsh` and adds a screen-space sun-facing weight | Approximate | One exponential attenuation and screen-space phase cannot recreate volumetric scattering |
| 6 | Warm canopy/grass rim and translucency | Before: mapped foliage back-light. Now: `GOLDEN_TARGET_BACKLIGHT` adds low-sun warmth using the foliage flag, normals, skylight and existing shadow result | Approximate | Only foliage groups mapped by `block.properties`; no true leaf transmission |
| 7 | Soft rays and glow around objects | Before: quarter-resolution shafts. Now: `GOLDEN_TARGET_RAYS` changes tint/intensity in the same `composite.fsh` route | Approximate | Eight to twelve depth taps are a screen-space shaft approximation, not volumetric shafts |
| 8 | Small birds | Before: none. Now: `GOLDEN_FAKE_BIRDS` draws three snapped V marks only in sky pixels | Impossible as real entities; approximate as a fake | No AI, depth interaction, collision, or world-space path; off in ULTRA LOW/LOW |
| 9 | Pale blue water and glint | Before: analytic reflection, shallow-water rays and caustics already existed. Now: retained unchanged by this update | Approximate | No scene SSR, refraction, or physically based water |
| 10 | Vignette and subtle bloom, crisp blocks | Before: quarter bloom and final vignette. Now: `GOLDEN_BLOCKY_BLOOM` snaps bloom-source coordinates in existing `composite.fsh` | Approximate | Bloom remains a five-tap low-resolution filter; vanilla texture pixels are not blurred |

The latest task treats the attached documents as requested specifications, not as facts about how the Bedrock add-on was built. Its implementation here does not claim to reproduce that add-on's internals.

## Golden-hour code review

| Area reviewed | Result |
| --- | --- |
| GLSL version and stage interfaces | The additions use the pack's existing `#version 330 compatibility`, `vSunUV`, `vSunElevation`, depth reconstruction, and `colortex5` route. No varyings or draw-buffer layouts were changed. |
| Iris uniforms | `viewWidth`/`viewHeight` are declared only in variants that use the screen grid; biome and camera uniforms are included by the corresponding feature guards. Confirm against the target Iris build because custom biome uniforms are supplied by `shaders.properties`. |
| Toggle behavior | New golden effects have independent `#define` switches. `MATCH_STRENGTH=0` suppresses all new target contributions and restores the existing round-sun treatment when that pre-existing option is selected. |
| Pass order and formats | Glow, haze, grade, and vignette stay in `final.fsh`; warm rays and blocky bloom source sampling stay in the existing quarter-resolution composite. No attachment or format directive changed. |
| Sky/surface separation | Sun, orb, and fake birds run only for depth-sky pixels and outside-water views. Target haze and grade operate on scene pixels; no texture samples or geometry changes were added to draw clouds separately. |
| Numeric guards | Screen dimensions, fog distance, glow levels, and existing normalization denominators retain nonzero guards. Weather masks clamp before being used as visibility. |
| Known limit | No Iris game compile, GPU capture, or hardware benchmark was available. This is a source-level compatibility review, not a runtime certification. `glslangValidator` is not installed in the workspace. |

## Performance plan and estimates

The pack retains the same six shader program routes: shadow, terrain/textured-lit/water gbuffers, composite, and final. The existing `colortex5` target remains quarter width × quarter height (one sixteenth of full-resolution pixel count). There is no new full-resolution pass. The pixel sun glow and golden color math are in the existing final shader and are skipped on non-sky pixels; target haze reuses the existing fog reconstruction and fog factor when that feature is enabled.

| Route | Before this update | After this update |
| --- | --- | --- |
| Final sky | Existing analytic gradient, square/round sun option, smooth halo | Same route plus screen-quantized target sun glow, target sky tint, optional orb and birds; disabled target switches add no target math |
| Final haze / grade | Existing analytic fog, biome tint, color grade, vignette | Same reconstruction and attenuation plus one reused-factor golden blend and small grade arithmetic; no raymarch or extra depth fetch |
| Composite shafts | Existing 8/10/12 quarter-res depth samples | Same sample counts; target only tints and scales the existing ray amount |
| Composite bloom | Existing five-tap quarter-res threshold | Same five taps; one optional coordinate snap before sampling |
| Program count / buffers | Six routes, `colortex5` at ¼ × ¼ dimensions | Still six routes and same buffers; no added attachment or full-resolution pass |

Very rough GPU-time estimates at 1920×1080 on a GTX 1650 (not measured):

| Added feature | Resolution / route | Approx. cost in LOW | Approx. cost in MEDIUM | Notes |
| --- | --- | ---: | ---: | --- |
| Coarse square sun core, blocky glow, flare band | Existing final pass; sky pixels only | 0.02–0.10 ms | 0.02–0.10 ms | Screen math only, with two soft falloff exponentials; no texture taps |
| Secondary flare orb | Existing final pass; sky pixels only | 0.00–0.02 ms | 0.00–0.02 ms | A few scalar operations and one distance |
| Golden sky tint and whole-scene grade | Existing final pass | 0.01–0.05 ms | 0.01–0.05 ms | Arithmetic only; low-sun/biome masks |
| Added haze color / sun-facing phase | Existing final haze branch | 0.00–0.03 ms | 0.00–0.03 ms | Reuses reconstructed position and fog factor; no extra depth fetch |
| Extra mapped foliage back-light | Existing terrain fragment shader | 0.00–0.03 ms | 0.00–0.03 ms | Arithmetic on foliage fragments; no extra shadow read |
| Golden ray tint/boost | Existing quarter-res ray taps | 0.00–0.01 ms | 0.00–0.01 ms | No sample-count increase |
| Blocky bloom source snap | Existing quarter-res bloom | 0.00 ms (LOW bloom off) | 0.00–0.02 ms | Changes UV arithmetic, not tap count |
| Fake bird marks | Existing final sky pixels | 0.00 ms (LOW off) | 0.00–0.04 ms | Three tiny masks, gated by daylight and match strength |
| **Golden-hour additions total** | **Existing routes only** | **about 0.03–0.20 ms** | **about 0.04–0.28 ms** | Driver, sky coverage, resolution scaling and compiler affect the result |

The best-case expected GPU-bound change from a 120 FPS baseline is approximately 0.4–2.8 FPS for the LOW estimate, and approximately 0.4–3.8 FPS for the MEDIUM estimate. This arithmetic is not a benchmark. The pack’s pre-existing effects, terrain load, chunk distance, shadow fill rate, and CPU bottlenecks are outside that delta. The 120 FPS LOW and 90 FPS MEDIUM goals remain targets to measure in-game; the source cannot guarantee them.

## Golden-hour art plan and palette

Palette hexes below are display-space visual estimates read from the screenshot by eye; they are not pixel-sampled measurements and are not claimed to be the source add-on's internal colors. Shader constants are linear-ish working values, so exact on-screen output also depends on Minecraft's output transform and resource pack lighting.

| Screenshot element | Suggested swatch | Use |
| --- | --- | --- |
| Sun core | `#FFFDF2` | Keep a white-hot square center with a slight warm edge, preserving the vanilla square outline |
| Inner glow | `#FFF0C2` | Bright area immediately around the sun |
| Outer glow / band | `#F5C56F` / `#FFE0A0` | Coarse amber halo and long low-contrast horizontal streak |
| Sky zenith | `#8F8060` | Muted, warm-gray upper sky rather than deep blue |
| Sky mid | `#EBCB83` | Cream-gold middle sky |
| Horizon | `#FFD995` | Pale luminous horizon blend |
| Near haze | `#F5D17E` | Warm yellow air over nearby distant forms |
| Far haze | `#DCA85E` | Lower-contrast amber silhouette color |
| Grass | `#98914A` | Olive foreground with yellow light on top-facing surfaces |
| Leaves | `#A28A43` | Bronze/olive canopy highlights; retain dark green shade texels |
| Soil / trunks | `#4B392D` | Warm dark brown, preserving texture contrast |
| Flowers | `#F4D532` | Saturated yellow blooms without a global neon boost |
| Water | `#A8D7E6` | Pale blue reflected-sky hint and existing water glint |

| Time / weather / biome | Suggested direction |
| --- | --- |
| Sunrise | Peach horizon (`#EFAF91`), gold-white sunlight, cool muted upper sky (`#75829A`) |
| Golden hour / savanna / desert | Cream and amber sky (`#EBCB83` → `#FFD995`), bronze foliage, olive grass; strongest match preset response |
| Sunset | Deeper amber and peach (`#D98762`), rays/gold reduced smoothly as the sun drops |
| Midday | Keep the original blue sky and neutral vanilla lighting dominant; pixel glow and golden grade fall away with sun elevation |
| Night | Existing calm blue/night sky (`#263856`); target golden sun/orb/birds/rays are faded out |
| Rain / thunder | Desaturate the golden overlay, retain denser neutral haze, fade sun glow and shafts |
| Jungle / swamp | Keep the existing teal haze (`#398D85` / `#72CBB8`) in front of golden accents |
| Cold biomes / ocean | Preserve the existing blue/cyan atmosphere (`#6C91B8` / `#99C7D3`) |
| Nether / End | Keep the existing dimension palette and skip the target overworld sun treatment |

This palette works with square block forms and crisp textures: the glow is quantized in screen space and in brightness, while world textures remain untouched. A coarser cell makes the glow visibly more pixelated; lower blockiness moves it toward a smooth analytic halo.

## Honest match to Vibrant Visuals

Mojang describes Vibrant Visuals through visible results such as directional sunlight and moving shadows, reflective water, volumetric lighting/fog, and different lighting response for block textures. The exact caustic, fog, and lighting shader implementation is not published in the material linked below, so this pack recreates the visible style with Iris-compatible approximations rather than claiming source-level parity. Mojang's public status pages currently describe Vibrant Visuals as available for Bedrock and in development for Java; this pack is a Java shaderpack approximation, not a Mojang Java port. [Mojang's feature overview](https://www.minecraft.net/en-us/vibrant-visuals-update), [Mojang's Java roadmap](https://www.minecraft.net/en-us/article/the-road-to-vibrant-visuals-on-java).

For the caustics goal, the recognizable behavior is focused, moving light on underwater surfaces, strongest in shallow sunlit water and reduced by shade, depth, rain, and night. The method here is an educated approximation: opaque depth reconstruction under visible water plus a low-cost analytic interference net. It does not refract light through a simulated wave surface, ray trace, or add geometry.

The 16-cells-per-block default anchors caustic cells to Minecraft's block texel scale. The pattern is made from hard snapped coordinates and stepped brightness bands, so it reads as block-art lighting rather than a smooth photographic caustic. Eight or 32 cells per block are available as coarser/finer variants.

## What changed

- Pixel-aligned shadow receivers snap their world-space tangent coordinates to a configurable 8/16/32-cell grid and sample the nearest shadow texel. The LOW/MEDIUM default is one tap to keep edges crisp and reduce bandwidth; HIGH/CINEMATIC can select a small 4- or 8-tap filter.
- Terrain blocks receive simple material groups from `block.properties`: matte earth/wood, stone, finished masonry, metals, glass/ice/slime/honey, foliage/thin plants, water, and selected emissive blocks.
- `PLASTIC_GLOSS_MIX` blends the existing gloss/Fresnel layer from its current strength down to zero. A separate, restrained material response adds block-family highlights.
- A small directional sun/moon fill uses the existing shadow light direction and skylight. Existing vanilla block light is preserved.
- Water can reflect an analytic blend of sky and fog color with a Fresnel term. The existing texture, ripple normal, pixel caustics, shallow-water rays, and glints remain.
- Leaves and mapped thin blocks get a small back-light tint. Vegetation vertices and positions are untouched.
- Selected terrain emitters get a texture-luminance-gated boost. The scene and shared effect buffers use Iris `RGBA16F`, allowing the existing quarter-buffer bloom to receive values above one.
- `VV_DEBUG` adds the nine requested diagnostics. The extra terrain debug output is compiled only when that switch is enabled.
- The caustic analytic waves now repeat on a seamless 256-block tile; the previous 20-block world-coordinate wrap could create pattern repetition/seams.

No new geometry or full-resolution pass was added. Existing six custom routes remain: shadow; terrain, textured-lit, and water gbuffers; composite; final.

## Gap analysis

| Vibrant Visuals goal | Existing pack before this update | Updated approximation / remaining limit |
| --- | --- | --- |
| Directional light and moving shadows | Shadow map and warm/cool grade; direct diffuse response was subtle | Mild sun/moon directional skylight lift plus the existing moving shadow map. Not a full physically based lighting model. |
| Pixel-aligned shadows | Shadow map and configurable filter, with no block-grid receiver snap | Receiver tangent coordinates snap to the 16-cell world grid by default; optional small multi-tap filter can soften edges. This is not a native voxel shadow renderer. |
| Haze and air shafts | Analytic haze and quarter-resolution depth/shadow shafts | Preserved and retained in existing routes. Haze is one analytic exponential in final; shafts use 8/10/12 taps. No volumetric integration. |
| Shallow-water lighting and caustics | Pixel caustics, depth masks, shallow-water rays, surface glints | Preserved, with stable world projection, block-grid quantization, stepped animation/pattern, one receiver shadow compare, and a caustic debug path. |
| Reflective water | Ripple shading and shallow tint; no screen reflection | Added a cheap analytic sky/fog reflection and Fresnel mix. No scene reflection or refraction. Optional SSR was left out because this pack has no water-normal buffer and an 8-step full-resolution ray would add cost and artifacts. |
| Thin-surface transmission | Leaf back-light only | Existing leaf term plus a small tint for selected plants/glass/ice/honey/slime groups. This is not true light transmission or subsurface scattering. |
| Per-family materials | One shared plastic gloss response | `block.properties` groups tune a subtle additional specular tint/strength; plastic stays independently blendable. Only terrain/water routes receive block IDs. |
| Emissives and glow | Thresholded quarter-resolution bloom | Selected terrain block textures are luminance-masked and boosted before existing bloom. Block-entity models, held items, mob eyes, and many animated emissive texture regions are outside the current routes. |
| Sky, sun, stars, clouds | Analytic gradient/halo/stars; vanilla cloud geometry | Sky and celestial work remains in final. Vanilla clouds are unchanged; the pack has no cloud gbuffer route for relighting or explicit horizon fading. Stars may not be cloud-occluded on every Iris configuration. |
| Static vanilla style | Textures and geometry are vanilla; vegetation is static | Preserved. No wind, geometry edits, texture blur, or required resource pack. |

## Code review and compatibility notes

| Severity | Finding | Change / disposition |
| --- | --- | --- |
| High | Default `colortex` format is normalized RGBA8 on most systems; additive atmosphere/emissive values can clamp. | Set `colortex0` and quarter-size `colortex5` to `RGBA16F` with Iris block-comment format directives. This costs additional VRAM/bandwidth. |
| High | Iris `mc_Entity.x` only identifies blocks in supported terrain/water stages; it is not a universal material ID for items, mobs, and block entities. | Material and emitter group effects are scoped to block IDs available on those routes. No item/entity ID taxonomy was invented. |
| Medium | Soft shadow taps blur the pixel-aligned edge target and multiply depth reads. | Added stabilized block-grid snapping and nearest texel sampling; the default uses one tap. Higher filters remain available. |
| Medium | A short, repeating coordinate wrap can make a procedural caustic net visibly repeat or jump. | Caustic waves now tile on a 256-block period with integer frequencies. |
| Medium | Camera-water and underwater-caustic gates can leak across the surface if based only on `isEyeInWater`. | Existing camera-side/sign gates remain; underwater terrain caustics remain opt-in. |
| Low | Native cloud lighting, true glass/ice transmission, and complete emissive entity/item handling are not represented by the available custom routes. | Kept vanilla clouds and routes; documented the cheap alternatives and the limits. |

Source review covered GLSL 330 compatibility, include paths, varying pairs, conditional uniforms, buffer outputs/clears, format directives, depth reconstruction, zero-vector guards, and compile-time options. It was not compiled inside Minecraft/Iris and was not measured on the requested GPUs. Iris version and driver behavior still require an in-game pass.

## Art direction and palettes

The screenshots guide the art direction; the hex palettes below are suggestions, not claimed Mojang or Realismcraft internals. GLSL uses linear RGB approximations and Iris biome uniforms, not literal hex values. Biome tinting follows the camera biome and blends smoothly, so it is not per-pixel biome classification.

| Time / weather | Palette (zenith → horizon or key light) | Treatment |
| --- | --- | --- |
| Sunrise | `#5B719F` → `#F2A98F` | Cool upper sky with soft peach horizon. |
| Morning | `#5F9CCB` → `#B8D7E7` | Clear blue, pale haze. |
| Midday | `#3E78B7` → `#C5DCEB` | Clean blue, warm-white direct highlights. |
| Afternoon | `#608DAF` → `#D9BF97` | Slight amber near the horizon. |
| Golden hour | `#D88C45` → `#F1C08D` | Soft amber shafts, warm birch highlights. |
| Sunset | `#655D83` → `#E27F72` | Muted violet and coral transition. |
| Dusk | `#2C3B65` → `#857095` | Blue-violet, gradual night blend. |
| Night | `#101A35` → `#465B87` | Calm blue haze and very faint moon response. |
| Rain | `#536D82` → `#9EABB6` | Cooler, softer contrast and denser haze. |
| Thunderstorm | `#263342` → `#586676` | Dark slate, shafts nearly gone. |
| Underwater | `#0E5271` → `#75C7C1` | Turquoise shallows into deeper blue. |

| Biome family | Palette | Treatment |
| --- | --- | --- |
| Jungle / swamp | `#398D85` → `#72CBB8` | Teal haze; green vibrance remains clamped and modest. |
| Forest / birch | `#E8A46B` → `#F3B89A` | Warm peach/amber distance color, cool shade. |
| Plains | `#8BB8C9` → `#CDD2BF` | Neutral blue air and gentle warm distance. |
| Desert / savanna | `#B97D4B` → `#E1BB83` | Dry amber light without a full-screen orange cast. |
| Snow / cold | `#6C91B8` → `#C6DBEC` | Soft cool-blue haze, preserve snow detail. |
| Ocean | `#4F91AD` → `#99C7D3` | Muted blue-green atmosphere and deeper water. |
| Cave | `#223144` → `#596B78` | Neutral-cool darkness; vanilla block light remains warm. |
| Nether / End | `#7A3D31` / `#614A91` | Dimension-tinted restrained haze; native dimension sky retained. |

## Performance and pass plan

No new pass was added. `colortex5` remains 25% width × 25% height (one sixteenth the pixel count) and shares bloom, shallow-water lighting, shafts, and particles. Haze, sky, tone, vibrance, and vignette stay in final. Material, caustic, direct-light, and wet-ground terms stay in existing gbuffers.

These are rough 1080p GTX 1650 estimates, not benchmark results. They vary with water coverage, shadowed pixel count, driver, chunk distance, and shader option state. “Before” refers to the checked-in pack immediately before this change.

| Effect | Before → after | Approximate GPU cost after | Notes |
| --- | --- | ---: | --- |
| Atmosphere rays | Existing 8–12 depth taps at quarter width/height → unchanged route, 8 LOW / 10 MEDIUM / 12 HIGH-CINEMATIC | 0.08–0.22 ms | Includes one shadow compare on eligible surface pixels; no new full-resolution pass. |
| Haze, sky, grade | Existing final-stage analytic haze/sky → preserved, dimension-aware and tone-gated | 0.08–0.22 ms | One exponential for haze; full-resolution but no extra pass. |
| Bloom and pollen | Existing quarter target → preserved; bloom now samples HDR colortex0 | 0.03–0.14 ms | Existing 5-tap cross filter, not a separable blur. Bloom/pollen are off in LOW. |
| Pixel caustics | Existing water-fragment depth reconstruction and pattern → seamless tile, current single shadow compare, snapped net | 0.05–0.30 ms | Highly dependent on visible water coverage; only runs on eligible shallow-water pixels. |
| Pixel shadows | Existing interpolated shadow clip and 1/4/8 compares → world snap plus nearest texel; default 1 compare | −0.02 to +0.03 ms | Fewer taps can offset the coordinate math; exact gain is driver/coverage dependent. |
| Material response and direct light | One plastic term → added group selection and subtle light/material arithmetic | 0.01–0.08 ms | No extra texture reads. |
| Water analytic reflection | No water-surface sky reflection → reflection/Fresnel only on visible outside-water fragments | 0.005–0.05 ms | Not SSR; cost scales with water coverage. |
| Emissive lift and thin back-light | No group-masked block emissive lift → texture luminance tests on mapped terrain | 0.005–0.04 ms | No new texture reads; half-float colortex0 adds roughly 8.3 MiB at 1920×1080 versus RGBA8. |
| Estimated whole requested atmosphere | Existing profile-level estimate 0.19–0.50 ms LOW / 0.25–0.78 ms MEDIUM → same passes with HDR target and debug compiled out | about 0.20–0.55 ms LOW / 0.26–0.85 ms MEDIUM | Does not include terrain, water, or caustic cost. These are not measured totals. |

The entry-GPU 120 FPS LOW and RTX 3050 90 FPS MEDIUM targets cannot be guaranteed from source review; CPU chunk work, resolution scale, render distance, and actual water/shadow coverage materially affect frame time. `ULTRA_LOW` removes most shader additions. Use a GPU frame capture for measured claims.

### Changelog and estimated frame-rate effect

The FPS conversion below assumes a GPU-bound baseline and is only arithmetic from the estimated milliseconds (`1000 / (baseline frame ms + added ms)`). It is not a benchmark; CPU limits and the shadow-filter change make actual frame-rate deltas nonlinear.

| Addition / visible difference | Estimated cost or saving | Approximate effect at 120 GPU-bound FPS |
| --- | ---: | ---: |
| World-grid shadow receiver snap, nearest texel; default MEDIUM changes from four compares to one | About −0.02 to +0.03 ms net | roughly +0.3 to −0.4 FPS; LOW already used one compare, so expect a small cost from snap math |
| Block-family material response and directional sun/moon lift | +0.01–0.08 ms | about −0.1 to −1.1 FPS |
| Analytic sky reflection on visible water | +0.005–0.05 ms on water fragments | about 0 to −0.7 FPS, depending on water coverage |
| Texture-masked emissive lift and thin-material back-light | +0.005–0.04 ms | about 0 to −0.6 FPS |
| Full-resolution scene buffer changes from RGBA8 to RGBA16F | approximately +8.3 MiB at 1080p and +0.02–0.10 ms bandwidth | about −0.3 to −1.4 FPS if bandwidth-bound |
| Caustic coordinate tile correction | No meaningful ALU increase | visually removes a possible short-period seam; essentially 0 FPS |
| `VV_DEBUG` views and MRT output | 0 when disabled; debug-only overhead when enabled | 0 in all normal presets |
| Existing quarter-resolution haze/rays/bloom/pollen | No new pass; estimates in the table above | Retained, not a new cost from this change |

Combined new full-resolution additions (including HDR buffer bandwidth) are very roughly +0.02–0.25 ms on LOW, partly offset by fewer shadow compares on MEDIUM. This spread is intentionally wide; it cannot establish that a particular GPU meets 120/90 FPS.

## Presets and controls

| Preset | Main costs and effects | Hardware guidance |
| --- | --- | --- |
| ULTRA LOW | 768 shadow map; simple analytic haze and low-match warm sky/square glow only; no rays, bloom, caustics, or birds. | Integrated graphics; highest FPS priority. |
| LOW | 1024 shadow map, 64-block distance, 8 quarter-buffer ray taps, one-tap pixel shadows, 8-step/s caustic net; bloom and birds off; match 42. | GTX 1050 Ti / GTX 1650 / RX 6400 target profile. |
| MEDIUM | 1536 shadow map, 80-block distance, 10 ray taps, bloom, pollen and fake birds; match 65. | Default balance / RTX 3050 target profile. |
| HIGH | 2048 shadow map, 12 ray taps, 4-tap shadows, fine caustic grid; match 82. | Higher-end desktop GPUs. |
| CINEMATIC | 3072 shadow map, 96-block distance, 12 ray taps, 8-tap shadows, finer glow pixels, stronger haze/glow and finest caustic grid; match 100. | Screenshots/high-end only. |

Settings are under **Match Strength**, **Sky and Sun**, **Golden Haze**, **Color Grading**, **Light Shafts and Bloom**, **Water and Caustics**, **Materials**, **Glow and Emissive**, **Performance**, and **Debug**.

Key controls:

- **Plastic gloss blend** (`PLASTIC_GLOSS_MIX`): 1.0 preserves the existing plastic layer; 0.0 removes only that layer.
- **Material response strength**: the added block-family highlight, independent of plastic gloss.
- **Shadow texels per block** (`SHADOW_PIXEL_GRID`): 8/16/32 world cells per block. The default 16 follows the 16×16 texture scale.
- **Caustic pixel grid / pattern quality / levels / steps per second / depth range / tint / strength**: controls the world-space caustic net and water mask. Current defaults keep caustics full through 2 blocks below the water surface and fade smoothly to zero at 11 blocks. `CAUSTICS_FULL_DEPTH` and `CAUSTICS_FADE_DEPTH` tune those thresholds; `SHALLOW_DEPTH_RANGE` controls the separate shallow-water shafts.
- **Ray samples / length / softness / intensity** and optional snapped-ray grid.
- **Haze density / height falloff / biome tint**, **green vibrance**, **bloom threshold/intensity**, and **emissive texture threshold/strength**.
- **Match strength** (`MATCH_STRENGTH`): 0 reproduces the shaderpack's prior look; 100 applies the full golden-hour target. LOW/MEDIUM/CINEMATIC start at 42/65/100.
- **Sun glow** (`GOLDEN_GLOW_PIXEL_SIZE`, `GOLDEN_GLOW_BLOCKINESS`, `GOLDEN_GLOW_LEVELS`, `GOLDEN_GLOW_STRENGTH`): controls square screen-pixel cells, hard steps, and glow brightness. `GOLDEN_SUN_CORE_SIZE` changes the overexposed square footprint.
- **Secondary orb** (`SECONDARY_GOLDEN_ORB`, `SECONDARY_ORB_SIZE`, `SECONDARY_ORB_STRENGTH`): optional artistic flare below-left of the sun; it is not a second world light.
- **Golden sky/haze/grade** (`GOLDEN_TARGET_SKY`, `GOLDEN_SKY_TINT_STRENGTH`, `GOLDEN_TARGET_HAZE`, `GOLDEN_HAZE_STRENGTH`, `GOLDEN_HAZE_PHASE`, `GOLDEN_TARGET_GRADE`, `GOLDEN_GRADE_STRENGTH`, `GOLDEN_SHADOW_LIFT`): sunrise/sunset and savanna-weighted ambience.
- **Ray and foliage warmth** (`GOLDEN_TARGET_RAYS`, `GOLDEN_RAY_BOOST`, `GOLDEN_TARGET_BACKLIGHT`, `GOLDEN_BACKLIGHT_STRENGTH`): reuses the existing quarter-res rays and existing foliage classification/shadow result.
- **Optional birds** (`GOLDEN_FAKE_BIRDS`, `FAKE_BIRD_AMOUNT`, `FAKE_BIRD_SIZE`, `FAKE_BIRD_SPEED`): only sky marks, not entities. Disabled in ULTRA LOW/LOW.
- Every feature added here has a Boolean compile-time define; numeric controls are in `shaders/lib/settings.glsl` and exposed in `shaders.properties`.

### Tuning guide

- **More Vibrant Visuals:** raise `DIRECTIONAL_LIGHT_STRENGTH` slightly, keep `MATERIAL_RESPONSE` on, and raise biome tint or haze only a little. Leave the plastic mix at 0.5–1.0 if you want the pack's original highlights.
- **More vanilla:** lower `PLASTIC_GLOSS_MIX`, `MATERIAL_RESPONSE_STRENGTH`, `DIRECTIONAL_LIGHT_STRENGTH`, bloom, and `SKY_GRADIENT_STRENGTH`; disable optional vignette/stars.
- **Less haze:** lower `HAZE_DENSITY`; lower `HAZE_HEIGHT_FALLOFF` if the ground-level buildup is too strong.
- **Softer shafts:** increase `ATMOS_RAY_SOFTNESS` and reduce `ATMOS_RAY_INTENSITY`; decrease `ATMOS_RAY_LENGTH` for shorter beams.
- **Less glossy:** reduce `PLASTIC_GLOSS_MIX` to remove the existing plastic response; reduce `MATERIAL_RESPONSE_STRENGTH` separately for quieter stone/metal/glass highlights.
- **Finer caustics:** set `CAUSTIC_GRID_SIZE` to 32 and/or raise `CAUSTIC_QUALITY`. The pattern remains cell-stepped by design.
- **Less emissive glow:** raise `EMISSIVE_THRESHOLD`, lower `EMISSIVE_STRENGTH`, or disable `EMISSIVE_BLOCKS`/`BLOOM`.
- **More vanilla water:** lower `WATER_REFLECTION_STRENGTH` or disable `WATER_SKY_REFLECTION`.
- **More like the golden-hour target:** raise `MATCH_STRENGTH`, then raise `GOLDEN_GLOW_STRENGTH` or `GOLDEN_HAZE_STRENGTH` in small increments.
- **Make the glow softer:** lower `GOLDEN_GLOW_BLOCKINESS`, increase `GOLDEN_GLOW_LEVELS`, and reduce `GOLDEN_BAND_STRENGTH` if the horizontal flare is too hard.
- **Make the glow more pixelated:** raise `GOLDEN_GLOW_BLOCKINESS` and `GOLDEN_GLOW_PIXEL_SIZE`; lower `GOLDEN_GLOW_LEVELS` for fewer, more obvious brightness bands.
- **Make the haze less strong:** lower `GOLDEN_HAZE_STRENGTH` first, then lower the general `HAZE_DENSITY` if the existing pack haze is also too heavy.
- **Make the image less yellow:** lower `MATCH_STRENGTH` or `GOLDEN_GRADE_STRENGTH`; set `GOLDEN_SKY_TINT_STRENGTH` lower to keep sky colors cooler.
- **Hide the fake birds:** turn off `GOLDEN_FAKE_BIRDS` or set `FAKE_BIRD_AMOUNT` to 0.
- **Move the flare orb:** the current implementation offsets it from the sun by a fixed screen-space amount; use `SECONDARY_ORB_SIZE`/strength or disable the toggle. Its screen offset is intentionally not exposed as a slider.
- **Tune canopy rays:** use `ATMOS_RAY_SOFTNESS`, `ATMOS_RAY_LENGTH`, and `ATMOS_RAY_INTENSITY`; `GOLDEN_RAY_BOOST` only adds target warmth/weight.

### Golden-hour screenshot comparison checklist

| Compare | If too weak | If too strong |
| --- | --- | --- |
| Square sun and glow footprint | Raise `MATCH_STRENGTH` or `GOLDEN_GLOW_STRENGTH`; raise `GOLDEN_SUN_CORE_SIZE` for a larger square | Lower `GOLDEN_GLOW_STRENGTH` or `GOLDEN_SUN_CORE_SIZE` |
| Glow blockiness / bands | Raise `GOLDEN_GLOW_BLOCKINESS`, pixel size, or band strength; reduce levels for chunkier steps | Lower pixel size/blockiness; increase levels |
| Secondary orb | Raise `SECONDARY_ORB_STRENGTH` or size | Lower its strength/size or disable `SECONDARY_GOLDEN_ORB` |
| Sky warmth | Raise `GOLDEN_SKY_TINT_STRENGTH` or match strength | Lower either control; keep `SKY_GRADIENT_STRENGTH` for the base pack look |
| Clouds | General haze/grade affect distant cloud pixels | Cloud geometry and direct cloud-edge light are vanilla; no slider can independently relight cloud undersides |
| Haze layers and horizon silhouettes | Raise `GOLDEN_HAZE_STRENGTH` gently | Lower target haze, then `HAZE_DENSITY` |
| Whole-scene golden grade | Raise `GOLDEN_GRADE_STRENGTH` | Lower grade strength or `MATCH_STRENGTH` |
| Backlit canopy and grass | Raise `GOLDEN_BACKLIGHT_STRENGTH`; check foliage IDs/shadow light | Lower strength or disable `GOLDEN_TARGET_BACKLIGHT` |
| Rays | Raise `ATMOS_RAY_INTENSITY` or `GOLDEN_RAY_BOOST` | Lower ray intensity/boost or disable either ray switch |
| Yellow flowers | Increase `VIBRANCE_STRENGTH` cautiously; the shader does not identify flower texels separately | Lower vibrance; there is no per-flower color slider |
| Water highlight | Raise `WATER_REFLECTION_STRENGTH` or existing sparkle amount | Lower them; no screen-space reflection is present |
| Vignette | Raise `GOLDEN_VIGNETTE_STRENGTH` | Lower it or disable `GOLDEN_SOFT_VIGNETTE` |

### Golden-hour test checklist

| Scene / state | Expected result |
| --- | --- |
| Sunrise and sunset, looking toward the sun | Square core with warm pixel bands, subtle horizon orb, golden haze and shafts fade in smoothly |
| Look away from the sun | Warm grade and haze remain subtle; flare and rays largely disappear from the sun cone |
| Noon | Sky returns toward the base palette; target glow/orb and warm ray boost fall off |
| Night | No golden sun or secondary orb; calm blue base sky, no strong rays or birds |
| Rain and thunderstorm | Sun glow/rays and golden grade soften; existing haze gets denser/desaturated |
| Savanna/desert | Warmest amber haze and bronze/olive grade |
| Forest/birch | Warm highlights but keep green shade texels readable |
| Jungle/swamp | Existing teal biome haze remains legible; golden overlay stays restrained |
| Snow/ocean | Existing cool palette remains dominant |
| Open sky with birds enabled | Three sparse snapped silhouettes drift slowly; disabled in LOW/ULTRA LOW |
| Under trees, indoors, under a roof | Atmospheric rays reduce with sky light/shadows; square sun effects remain sky-only |
| Water and crossing the surface | Existing water reflection/caustics gates behave as before; no new caustics are drawn on the visible surface |
| Nether/End | Golden overworld sun treatment stays gated out; native dimension mood remains |
| `MATCH_STRENGTH` 0 vs 100 | 0 matches the previous pack; 100 shows the strongest screenshot-inspired golden-hour additions |
| LOW at 1080p / 12 chunks | Birds and bloom off, 8 ray taps; measure GTX 1050 Ti/1650/RX 6400 rather than assuming the FPS target |
| MEDIUM at 1080p | 10 ray taps plus bloom and birds; measure on the RTX 3050 and compare against your own baseline |

### Golden-hour changelog and estimated frame cost

| Addition | Visible difference | Estimated added GPU time (GTX 1650, 1080p) |
| --- | --- | ---: |
| `MATCH_STRENGTH` and presets | Single 0–100 blend for target additions; profiles select 25/42/65/82/100 and their quality/toggle sets | No meaningful cost |
| Pixel sun core/glow/bands | White square-overlaid core and quantized amber square-grid halo/cross/horizontal streak | 0.02–0.10 ms, sky pixels only |
| Lower orb | Soft round screen flare below-left of the sun | 0.00–0.02 ms, sky pixels only |
| Golden sky and distant haze/phase | Cream/amber sky and warmer distant silhouettes around the sun | 0.01–0.08 ms; reuses existing scene and fog reconstruction |
| Warm scene grade and backlight | Golden low-sun tint/lift; mapped foliage and grass edges receive a small extra tint | 0.01–0.08 ms; no additional shadow sample |
| Ray tint/boost and blocky bloom source | Warmer existing shafts and pixel-grid bloom selection | 0.00–0.03 ms; existing tap counts unchanged |
| Optional fake birds | Three tiny sky-only screen marks | 0.00–0.04 ms; off in LOW/ULTRA LOW |

## Debug views

Turn on `VV_DEBUG` and select `VV_DEBUG_MODE`. These diagnostics are compiled out when `VV_DEBUG` is off.

For the new target-only checks, enable `TARGET_DEBUG` and select `TARGET_DEBUG_MODE`. This code is compiled out when the switch is off. Modes 6 and 7 read the existing quarter-resolution effect buffer; no diagnostic render pass is added.

| Target mode | View |
| --- | --- |
| 1 | Raw golden sun glow before tint contribution |
| 2 | Posterized glow contribution |
| 3 | Target warm sky palette |
| 4 | Warm haze mask/fog factor |
| 5 | Screen-space sun-facing haze phase |
| 6 | Quarter-resolution raw sun shafts |
| 7 | Quarter-resolution bloom buffer (the target is shared with other composite effects) |
| 8 | Left half before golden grade, right half after golden grade |

| Mode | Expected result |
| --- | --- |
| 1 — Sun-lit mask | Black in night/indoors, white in open sky and lit sun-facing receivers. |
| 2 — Raw shafts | Grayscale quarter-resolution ray intensity; brightest around alternating canopy gaps. |
| 3 — Fog factor | Black nearby and brighter with distance; sky pixels stay black. |
| 4 — Biome tint | Flat active palette color; transitions gradually as the camera biome changes. |
| 5 — Shadow factor | White for visible/unshadowed receivers, dark for shadowed/out-of-map receivers; quarter-resolution. |
| 6 — Emissive mask | Grayscale threshold result on supported, tagged terrain blocks only. |
| 7 — Material group | Matte brown, stone gray, polished purple, metal gold, transmission cyan, foliage green, water blue, emitter red. Unmapped/entity routes are dark gray. |
| 8 — Water mask | White on mapped water surfaces; black elsewhere. |
| 9 — Bloom buffer | Isolated low-resolution thresholded glow contribution. |

The older `ATMOS_DEBUG` and `CAUSTICS_DEBUG` controls remain available for their existing focused diagnostics.

## In-game test checklist

The source-level work is complete; use this checklist in Minecraft/Iris to verify visuals and performance.

| Scenario | Expected result |
| --- | --- |
| Sunrise / sunset | Smooth peach/coral sky band, warm directional tint, no abrupt transition. |
| Morning / noon | Clear blue sky, restrained warm direct light, no excessive orange cast. |
| Golden hour in birch forest | Amber/peach haze and faint shafts between trunks, like reference 2. |
| Jungle canopy | Soft diagonal shafts, teal/cyan distance haze, restrained pollen and green vibrance, like reference 1. |
| Night | Calm blue haze, no strong sun rays or caustics, subtle stars/moon response. |
| Rain / thunderstorm | Shafts and caustics fade; haze becomes cooler/denser and grading softens. |
| Plains / desert / savanna | Smooth neutral or amber palette blend; no hard biome boundary. |
| Snowy biome | Cool air; white surfaces retain visible texture detail. |
| Ocean / shallow water from shore | Depth tint, visible block-pixel caustics on submerged opaque surfaces, mild water reflection. |
| Deep water | Caustics stay full through 2 blocks, fade smoothly to zero at 11 blocks, and are absent below that. |
| Crossing water surface | Outside-camera caustics fade out as the eye enters water; never show the outside-water caustic overlay from below. |
| Underwater floor toggle | When `CAUSTICS_UNDERWATER_FLOOR` is enabled, faint terrain caustics use the conservative eye-light proxy. |
| Cave / indoors / under roof | No air shafts in sealed shade; caves remain dark, warm block light remains vanilla-like. |
| Window / canopy gaps | Shafts pass through visible openings; fully occluded regions stay subdued. |
| Look toward/away from sun; look straight up/down | Shafts fade with the sun-screen cone; sky effects do not spill over opaque terrain or singularly flicker. |
| Nether / End | Native dimension mood is retained with restrained dimension haze. |
| Far from spawn | Caustic grid remains anchored and repeats only at its seamless 256-block tile. Check for visible tile recognition. |
| Emissive blocks / leaves / glass | Supported blocks gain a subtle local glow/back-light; no actual transmitted light is expected. |
| Performance on targets | Measure LOW at 1080p/12 chunks on GTX 1050 Ti, GTX 1650, RX 6400; MEDIUM on RTX 3050. Source estimates are not benchmark data. |

## Troubleshooting Iris errors

1. Check the first `Shader compilation failed` or GLSL `ERROR` in `.minecraft/logs/latest.log`; the first program and line number are the useful part, not the final stack trace.
2. If a varying is undeclared, compare vertex `out` and fragment `in` names/types. `vMaterialGroup` and related values are shared by `/lib/gbuffers.vsh` and `/lib/gbuffers_forward.fsh`.
3. If the error mentions `colortex0Format` or `colortex5Format`, leave each Iris buffer format directive on its own line inside a block comment. `RGBA16F` is an Iris directive, not a GLSL identifier.
4. If a `RENDERTARGETS`/attachment error appears, try with `VV_DEBUG` off first; its material/emissive views add a `colortex2` MRT output only for the selected debug modes. The normal water mask remains in `colortex1`.
5. If an option seems unchanged, reselect the profile or reload shaders; profiles can override GUI defines. Confirm its Boolean switch and its slider are both enabled/raised.
6. If a block group does not tint, confirm the block has an ID in `shaders/block.properties` and is rendered in terrain/water. Block entities, items, and entities do not automatically inherit `mc_Entity.x`.
7. For a reproducible report, include Minecraft version, Iris version, GPU/driver, the first compile diagnostic, the selected profile, and the relevant setting values.

## Changed and unchanged files

All changed shader/config files below contain their complete contents in the pack folder and ZIP; no diffs or placeholders are required to use the pack.

Changed:

- `README.md`
- `shaders/block.properties`
- `shaders/composite.fsh`
- `shaders/final.fsh`
- `shaders/gbuffers_terrain.fsh`
- `shaders/gbuffers_textured_lit.fsh`
- `shaders/gbuffers_water.fsh`
- `shaders/lang/en_us.lang`
- `shaders/lib/gbuffers_forward.fsh`
- `shaders/lib/gbuffers.vsh`
- `shaders/lib/settings.glsl`
- `shaders/shaders.properties`

Unchanged:

- `shaders/composite.vsh`
- `shaders/final.vsh`
- `shaders/gbuffers_terrain.vsh`
- `shaders/gbuffers_textured_lit.vsh`
- `shaders/gbuffers_water.vsh`
- `shaders/shadow.fsh`
- `shaders/shadow.vsh`
- `shaders/lib/shadow_distortion.glsl`

## Caustics depth and shadow fix

The report describes a pattern visible only through very thin water. The source inspection found the strongest matching cause in `shaders/lib/gbuffers_forward.fsh`, `singleReceiverShadow()`: the caustic receiver test sampled `shadowtex0`. Iris defines `shadowtex0` as including all geometry, while `shadowtex1` excludes transparent geometry. When translucent water is included in the shadow pass, it can therefore occlude its own receiver. The caustic test now uses one `shadowtex1` sample, keeps its normal/depth bias, and treats positions outside the shadow map range as unshadowed instead of suppressing the effect. Whether water was actually present in the active runtime map depends on Iris shadow settings; no game log was attached to verify that runtime state.

Other findings:

- The caustic receiver depth was already measured vertically in the current pack, using the visible water fragment position and the perspective-divided `depthtex1` floor position. It was not the original view-ray metric described in the report. The defaults now match the requested 2-to-11-block fade.
- The quarter-resolution shallow-water shafts and tint in `shaders/composite.fsh` did use linear view-depth subtraction, which changes with camera angle. They now use the vertical difference between reconstructed `depthtex0` water and `depthtex1` floor positions.
- `block.properties` maps `minecraft:water` to ID 1. Iris reports `mc_Entity.y == 1` for fluids, so the current `mc_Entity.y > 0.5 && mc_Entity.x == 1.0` test covers still and flowing water states. The source water mesh position also handles partial flowing heights; it does not infer depth from block-boundary `fract()`.
- The caustic color is added in the translucent water fragment and adjusted by its alpha so blending transmits the increment onto the opaque floor. The mask is not stored in an 8-bit buffer before application; the scene target uses `RGBA16F`. I added a separate gentle exponential absorption and a blue-green depth tint.
- The view-angle fade on the visible water surface has been reduced to a front/back sign test. The outside-camera and surface-crossing fade remain, so default caustics remain hidden when the camera is underwater.

**Certain from source/API:** the old caustic helper read `shadowtex0`; `shadowtex1` is Iris's opaque-only sampler; the floor depth reconstruction perspective-divides by `w`; and the water ID/render-type test matches Iris's documented `mc_Entity` meaning. **Approximate:** the screenshot's precise runtime cause, the quality of opaque shadow coverage for every GPU/driver, and all timing estimates; the screenshot and Iris log were not available in the workspace.

The caustic controls, debug views and test pool of this earlier fix are superseded by **Voronoi caustics v3 (floor and walls)** below.

### Change log and performance estimate

- Replaced the caustic shadow lookup from `shadowtex0` to `shadowtex1`; this is the primary fix for translucent-water self-occlusion. It is the same single shadow fetch, with no additional pass.
- Set caustic fade defaults to 2/11 blocks and added shallow-boost and absorption controls. The pixel grid, posterized bands, stepped animation, and intensity controls remain.
- Changed the water shaft/tint thickness to vertical world-space depth and its receiver visibility to the opaque-only shadow map.
- Replaced the grazing-angle surface fade with a front/back test while retaining the camera crossing gate.
- Expanded debug views to eight choices; these compile only when `CAUSTICS_DEBUG` is on.

Estimated incremental cost on a GTX 1650 at 1080p: about **0.01–0.04 ms** for the caustic path (one exponential and a few arithmetic operations; the shadow lookup is replaced, not added), plus roughly **0.01–0.05 ms** for quarter-resolution water shaft depth reconstruction when that effect is enabled. These are source-based estimates, not measured results. Total caustic cost depends on visible water coverage and may approach or exceed 0.25 ms in a water-heavy scene; the 120 FPS LOW target still needs an in-game benchmark.


## Voronoi caustics v3 (floor and walls)

This replaces the orthogonal-maze generator, its sliders and its "visible-space" blend. The reference is a Bedrock Vibrant Visuals pool floor seen straight down; Bedrock's renderer is not public, so everything below is either measured from the attached image or an approximation, as marked.

### Measured from the reference (decoded pixels, sRGB, no colour management)

| Property | Brief estimate | Measured | Certainty |
| --- | --- | --- | --- |
| Texel grid | 16 / block | ≈ 9.5 px per texel on both the floor and the brown block, i.e. 16 / block | Measured |
| Cell shape | Rounded 5–6-sided polygons | Confirmed: closed, rounded polygons with staircase edges | Visual |
| Cell size | 10–14 texels | Mean scanline chord ≈ 5–6 texels, which means a point spacing of about 7–9 texels. Floor-texture speckle makes this noisy. | Measured, ± 2 texels |
| Line width | 1–2 texels | Median line run ≈ 1 texel (8–9 px) | Measured |
| Line coverage | 12–20 % | ≈ 10 % (bright stretches) to 20 % (all line pixels) | Measured |
| Base floor | `#8DB4D0` | `#7A97A7` (median); light patches `#7F9DB0` | Measured |
| Mosaic (dark patches) | `#6F9BBE` | `#6988A0`, ≈ −10 % against the base; light patches ≈ +4 % | Measured |
| Line mid / light | `#B7D2D2` / `#D5E3D6` | `#A3B7BA` / `#B7CAC3` | Measured |
| Peak | `#EDE6BE` | `#C4CBBB` / `#C3D3C6` (top 0.5 %), warm R ≈ G > B | Measured |
| Wall | Light cyan-grey, faint lines | `#688099`–`#7187A0`, only ≈ 2–3 % bright pixels | Measured |
| Animation | – | Not visible in a still; all motion values are guesses exposed as sliders | Unknown |

The measured colours are darker and greyer than the eye estimates. That may be partly display gamma; the shader is calibrated to the measured values. Part of the mosaic in the reference is probably the sand texture itself.

### Why the previous version looked wrong (current Java screenshot: base `#42597F`, lines `#6F85A3`–`#8A9FB5`)

| Symptom | Cause | Fix |
| --- | --- | --- |
| Orthogonal maze, 4–8 texel cells | `causticLayer` / `causticCellHash` (value-noise outline against the texel to the right/below) in `lib/gbuffers_forward.fsh` | Removed with `CAUSTIC_LAYERS`, `NOISE_CELL_SIZE_A/B`, `LINE_THICKNESS`, `LINE_DENSITY`, `CAUSTIC_MORPH` and `MORPH_SECONDS`; replaced by the Voronoi F2 − F1 generator |
| Lines look painted on the water, with the water texture showing through them | Not a depthtex0 error: the receiver always came from depthtex1. The v2 blend added the light at full strength regardless of water opacity ("visible-space" compensation in `gbuffers_water.fsh`), so it read as a surface overlay. | Light is now added to the floor and multiplied by the water transmission (1 − a) |
| Navy, nearly opaque water; no floor visible | Vanilla texture alpha and biome blue, plus the pack's shading; no depth-dependent opacity | `WATER_DEPTH_TINT`: light teal and 25 % opacity in the shallows, deep blue and ≥ 80 % opacity with depth |
| Uniform grey lines, no peaks, no mosaic | Fixed four-level palette on a maze | Per-edge twinkle, junction boost, cream peaks, one-sided halo, three-tone mosaic |

### Generator (`causticPattern`)

1. Integer texel coordinate on the face plane (wrap period 210 blocks, divisible by every cell and mosaic size), plus a slow whole-texel global drift.
2. One jittered feature point per cell, at integer texel positions, so distances are exact integers. Each point orbits its cell on an octagon in whole-texel steps at its own rate (`CELL_ORBIT`), so the net deforms like a caustic.
3. 3×3 search (MEDIUM and up) or the 2×2 cells nearest the texel (LOW). Tracks F1, F2, F3 and the two nearest cell ids.
4. A line pixel is `F2 − F1 < LINE_WIDTH` texels, evaluated at texel centres, which gives hard staircases.
5. Brightness: 70 % per-edge hash (the unordered cell pair, re-rolled `EDGE_TWINKLE` times a second at a per-edge phase) plus 30 % per-3-texel stretch hash, plus a boost where borders meet (F3 − F1 small). The result picks mid or light; the brightest stretches become a cream peak (`PEAK_AMOUNT`). `EDGE_DROPOUT` turns some stretches into gaps.
6. Halo: one dim texel next to lines on the side of the lower cell id (`EDGE_HALO`).
7. Isolated texels: rare light pixels within 3 texels of a line.
8. Mosaic: nearest-neighbour value noise at `MOSAIC_CELL_SIZE`, three tones (−10 % / −3 % / +4 % × `MOSAIC_STRENGTH`) applied as a floor scale, never additive grey.

The level colours are additive floor light solved so that a floor under 25 %-opacity light-teal water reproduces the measured swatches. A WebGL2 render of the generator gave floor avg `#7995A3` (reference `#7A97A7`), line avg `#AABDB9` (reference `#A3B7BA`–`#B7CAC3`) and 19.8 % line coverage (17.7 % with the LOW 2×2 search).

### Blend and water

`gbuffers_water` writes premultiplied colour (`blend.gbuffers_water = ONE ONE_MINUS_SRC_ALPHA …`):

`result = water·a + (1 − a) · (floor · (1 − k) + L)`

Here L is the caustic light and k is a half-strength screen term minus the mosaic tone. The caustics land on the floor before the water tint is added and are seen through the water. Without caustics this is exactly the standard alpha blend. With `CAUSTICS_SCREEN_BLEND` off the shader falls back to additive `(1 − a)·L` with no mosaic.

`WATER_DEPTH_TINT` uses the same depthtex1 receiver: `deepMix = 1 − exp(−max(column − 1, 0) · ABSORPTION_STRENGTH)` blends `SHALLOW_TINT` → `DEEP_TINT` and `SHALLOW_OPACITY` → max(vanilla alpha, 0.8). With the defaults that is about 22 % deep at 2 blocks, 83 % at 8 and 94 % at 12. The vanilla water texture survives only as a ±15 % brightness ripple. It is not applied when the camera is underwater.

### Sliders (Water and Caustics → Pixel Caustics; water tint options on the Water screen)

| Option | Default | Notes |
| --- | --- | --- |
| `PIXEL_CAUSTICS`, `CAUSTICS_WALLS`, `CAUSTICS_SCREEN_BLEND`, `WATER_DEPTH_TINT` | on | Compile-time |
| `CAUSTICS_UNDERWATER_FLOOR` | off | Opt-in camera-underwater route (same generator, exact normals) |
| `CAUSTICS_STRENGTH` | 1.00 | 1.0 reproduces the measured swatches |
| `VORONOI_QUALITY` | 2 | 1 = 2×2 search: slightly more regular cells and the occasional straight cut where F2 is missed |
| `TEXELS_PER_BLOCK` | 16 | 8 / 16 / 32 |
| `CELL_SIZE_TEXELS` | 8 | Measured. 10–12 matches the brief's estimate; at 12, use `LINE_WIDTH` 1.0 for similar coverage |
| `CELL_JITTER` | 0.85 | LOW 0.60 to suit the 2×2 search |
| `LINE_WIDTH` | 0.75 texels | 1.0–1.25 for thicker lines |
| `EDGE_HALO` | 0.45 | 0 = off |
| `EDGE_DROPOUT` | 0.05 | Gaps per 3-texel stretch |
| `EDGE_TWINKLE` | 1.0 /s | 0 = static brightness |
| `ISOLATED_PIXELS` | 0.010 | |
| `PEAK_AMOUNT` | 0.30 | |
| `WARMTH` | 1.00 | Peak: cool white → measured cream |
| `CONTRAST` | 1.00 | Below 1 adds a faint fill between lines |
| `MOSAIC_STRENGTH` / `MOSAIC_CELL_SIZE` | 1.00 / 3 | |
| `STEPS_PER_SECOND` | 8 | |
| `CELL_ORBIT` | 2 texels | LOW 1; 0 = no deformation |
| `DRIFT_SPEED` / `DRIFT_DIRECTION` | 0.5 texels/s / 45° | Not verifiable from a still |
| `CAUSTIC_FULL_DEPTH` / `CAUSTIC_FADE_DEPTH` | 2 / 11 blocks | The mosaic fades 1.5× slower; the shallow-water shafts share the range |
| `WALL_STRENGTH` / `WALL_DEPTH_FADE` / `WALL_SUN_FACTOR` | 0.45 / 6 / 0.65 | Minimum wall sun response = 1 − factor |
| `SHALLOW_TINT` / `DEEP_TINT` | 1 / 1 | Light teal / deep blue (0 = vanilla biome colour) |
| `SHALLOW_OPACITY` / `ABSORPTION_STRENGTH` | 0.25 / 0.25 | Absorption also tints deep caustics bluer |

Presets define every caustic and water option.
- ULTRA LOW: caustics off; depth tint on, which is one depth fetch per water pixel.
- LOW: floor only, 2×2 search, 8 steps/s, orbit 1, no halo.
- MEDIUM: floor and walls, 3×3 search.
- HIGH: as MEDIUM plus water sparkles.
- CINEMATIC: 10 steps/s, more isolated pixels, stronger and deeper walls.

### Debug views (`CAUSTICS_DEBUG`, `CAUSTICS_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Face axis: floors green, X walls red, Z walls blue, stable at edges |
| 2 | 16-per-block texel checker aligned with the block texture; blocks alternate red/blue tint |
| 3 | Random flat colours per Voronoi cell: rounded 5–7-sided polygons about 8–10 texels across |
| 4 | F1: dark at each feature point, brighter towards the cell borders |
| 5 | Edge value F2 − F1: black thin network along the borders, bright cell centres |
| 6 / 7 | Line mask before / after dropout: white 1-texel staircases; mode 7 has small gaps |
| 8 | Per-edge brightness on the lines: whole edges in different greys that change about once a second |
| 9 | Mosaic alone: 3-texel grey patches in three tones |
| 10 | Levels: dark floor, navy halo, blue mid, green light, cream peak (rare, on bright stretches) |
| 11 | Vertical water column 0–12 blocks, independent of camera pitch |
| 12 | Submerged mask: white below the water line only |
| 13 | Opaque-only shadow: dark only behind opaque occluders |
| 14 | Final caustic light added to the floor |
| 15 | Water flag on every water face |

### Screenshot comparison

This session has no screen-capture or computer-use tool, so no game window was captured. Only the two attached images were measured. To iterate against Bedrock, provide these, taken under identical conditions:
- Conditions: noon (`/time set 6000`), `/weather clear`, the same coordinates, pitch −90 (straight down) and yaw 0, the same FOV, render distance, GUI scale and resolution, HUD hidden (F1), no entities or particles.
- Shots, from each game:
  1. The floor from straight above.
  2. The floor at 45°.
  3. A side wall.
  4. A flowing-water edge.
  5. About 12 consecutive frames (2 s) of the floor, or a short screen recording. These set the drift, orbit and twinkle defaults.
- Java extras: debug modes 3, 7 and 10 from the same camera.

### Test pool (identical in Java and Bedrock)

1. Flat area at y = 63. Dig a 9 × 15 pit stepped in five 3-wide bands with floors at 1, 2, 4, 8 and 12 blocks below the rim.
2. Floor material: sand in the left half, stone in the right half. Walls: smooth stone, straight.
3. In the 4-deep band, a 1 × 1 pillar up to the surface. In the 8-deep band, a 1-block-wide wall across the band.
4. A dirt block on the rim, one above the water line, as the shore block.
5. Fill with water source blocks to y = 63. At one short end, remove the rim and let water flow down a 3-block slope for the sloped edge.
6. Roof: a 3 × 3 stone slab platform 4 blocks above the 2-deep band. Plant an oak tree beside the 1-deep band.

| Situation | Correct result |
| --- | --- |
| Noon, straight down | Clear light-teal water; the sand or stone texture is readable. Polygon net about 8–10 texels per cell, light teal-white lines with some cream stretches and soft mosaic patches. Full strength to 2 blocks, fading by 11; the mosaic lingers to about 16. Walls carry a fainter net down to about 6 blocks. Hard shadows under the roof and tree. The dirt block and the water surface stay clean. |
| Sunrise / sunset | Floors fade with sun height; sun-facing walls hold longer; walls whose water is in the rim's shadow lose caustics (expected) |
| Night / rain | No caustics; the water tint remains |
| Grazing angle | The same depth classes (the column is vertical); the net is foreshortened but not stretched on walls |
| Crossing the surface | The effect fades as the eye nears the surface; underwater it is off unless `CAUSTICS_UNDERWATER_FLOOR` is on |
| 12-deep band | Deep blue and mostly opaque; no lines; a faint mosaic only near 11–16 blocks |

### Comparison checklist

| Difference | Slider |
| --- | --- |
| Cells too big / small | `CELL_SIZE_TEXELS` |
| Cells too regular / chaotic | `CELL_JITTER` (and `VORONOI_QUALITY` 2) |
| Lines too thin / thick | `LINE_WIDTH`, `EDGE_HALO` |
| Too many / few gaps | `EDGE_DROPOUT` |
| Twinkle too busy / static | `EDGE_TWINKLE`, `STEPS_PER_SECOND` |
| Mosaic too strong / invisible | `MOSAIC_STRENGTH`, `MOSAIC_CELL_SIZE` |
| Too few / many cream peaks | `PEAK_AMOUNT`, `WARMTH` |
| Lone bright pixels | `ISOLATED_PIXELS` |
| Floor not visible enough | `SHALLOW_OPACITY` ↓, `ABSORPTION_STRENGTH` ↓, `SHALLOW_TINT` |
| Overall brightness | `CAUSTICS_STRENGTH` |
| Wall response | `WALL_STRENGTH`, `WALL_SUN_FACTOR`, `WALL_DEPTH_FADE` |
| Depth fade | `CAUSTIC_FULL_DEPTH`, `CAUSTIC_FADE_DEPTH` |
| Anything above the water line | None. That is a bug: check debug modes 12 and 15. |

### Changelog and cost

- Removed the orthogonal maze generator and its options; added the Voronoi F2 − F1 generator, per-edge twinkle, junction boost, halo, dropout, isolated texels and the mosaic.
- The caustic light is now transmitted by (1 − a), so it sits on the floor seen through the water.
- Added `WATER_DEPTH_TINT`: shallow clear teal → deep blue, with depth-based opacity.
- Removed `CAUSTICS_SHALLOW_BOOST` and `CAUSTICS_ABSORPTION`; `ABSORPTION_STRENGTH` drives both the water and the caustic absorption.
- Wrap period changed from 240 to 210 blocks so every new cell size tiles.
- Debug selector extended to 15 views.
- Estimated cost (GTX 1650, 1080p, not measured), per water pixel within 48 blocks:
  - MEDIUM (3×3): about 9 + 5 integer hashes, ~400 ALU ops, one depth and one shadow fetch.
  - LOW (2×2): ~250 ops.
  - Water covering 30–40 % of the screen: about 0.10–0.25 ms MEDIUM and 0.06–0.15 ms LOW.
  - A screen filled with near water (looking down into a lake) can reach ~0.5 ms on MEDIUM, above the 0.35 ms budget; LOW stays near 0.35 ms. Use `VORONOI_QUALITY` 1 to lower it.
  - The depth tint alone (ULTRA LOW) is one fetch plus ~40 ops per water pixel.
- No new pass or buffer.
- Verified by compiling the generator in WebGL2 (GLSL ES 3.00) in both search modes; not compiled inside Iris.
- Backup of all pre-v3 files: `backup/2026-10-04_before_voronoi_v3/`.

## v3.1: smoother caustic curves and sun-lit vanilla wave pixels

### Caustic smoothing (patterns otherwise unchanged)

- **Curved edges** (`CELL_CURVE`, default 2.5 texels): a smooth, seamless domain warp (periods of about 3–4 cells) bends the straight Voronoi edges into arcs. Each texel is still evaluated once at its centre, so the output is still hard pixels.
- **Constant-width lines**: the line test now uses the exact distance to the bisector of the two nearest points instead of F2 − F1. This removes the thick clumps where borders meet. `LINE_WIDTH` 0.90 gives ≈ 20 % coverage, like before.
- **Softer brightness**: per-edge weight 0.8 / stretch weight 0.2, junction boost 0.18, `EDGE_HALO` 0.35.

The WebGL2 check rendered rounder cells at the same scale and colours, with 20.6 % line coverage.

### Sun-lit vanilla wave pixels (`WAVE_LIGHTING`)

**Source.** The vanilla animated `water_still` / `water_flow` texture stays the only wave source; frames, shapes and texel grid are untouched. Measured from the 1.21.1 jar, `water_still` is grayscale with alpha 0.706, mean luminance 0.694 and only four tones: 0.647 (50 %), 0.682 (35 %), 0.761 (10 %) and 0.827 (5 %). `water_flow` has mean 0.662. With a mean of 0.68 and the threshold `smoothstep(0.03, 0.13, L − 0.68)` quantized to `CREST_LEVELS` (default 3), the 0.761 tone becomes "soft" and the 0.827 tone "bright". The darker texels are never lit.

**Pseudo-normal.**
- Two one-texel taps (`textureGrad` with the centre's derivatives). On the sprite's last row/column, the tap steps back instead of forward; the sprite bounds come from `mc_midTexCoord`.
- A cotangent frame from screen derivatives of position and UV, taken before the alpha discard. It follows any face orientation and the rotated UVs of flowing water.
- Tilt: `WAVE_NORMAL_STRENGTH` × gradient / 0.08, where 0.08 is the measured typical crest-edge step.

**Lighting.**
- Wrap diffuse `dot(N, L)·0.5 + 0.5` × `DIFFUSE_AMOUNT`.
- Blinn-Phong glint (roughness `GLINT_SIZE`) × view Fresnel × `GLINT_AMOUNT`. This gives a pixel glint path toward a low sun and stays weak looking down at noon.
- Sun height: ×1.5 at low and mid sun, warm tint near the horizon, faint cool moon at night.
- Masks: sky light, rain (−85 %), 24–56 block distance fade, grazing fade, one opaque-only `shadowtex1` lookup.
- Stepped sparkle: `SPARKLE_AMOUNT` of the bright crests twinkle at `STEPS_PER_SECOND`, driven by the glint.

**Blend.** The light is added on the surface (not transmitted), screened over the water colour. On base texels it is exactly zero, so the base water is unchanged.

**Anti-shimmer.** Uses the texture's own mip chain (`textureGrad` with the real derivatives flattens crest contrast and gradients with distance) plus explicit distance and grazing fades. There is no LOD-bias slider, because the vanilla atlas mips already do the work and a bias would sharpen the crawl it is meant to hide.

**What it replaces.** With `WAVE_LIGHTING` on, the procedural triangle-wave ripple, the plastic water gloss and `PIXEL_WATER_SPARKLES` are bypassed on water. `WAVE_LIGHT_STRENGTH` 0 therefore leaves the plain base water, with nothing left over. With `WAVE_LIGHTING` off, the previous water shading returns.

**Presets.** ULTRA LOW off; LOW–CINEMATIC on, with the same defaults: strength 0.60, diffuse 0.25, glint 0.35, size 0.20, contrast 1.0, levels 3, tilt 0.12.

**Cost.** About two texture taps, one shadow lookup (only on lit crests) and ~120 ALU ops per visible water pixel: roughly 0.02–0.06 ms at 1080p on a GTX 1650 (not measured).

### Wave debug views (`WAVE_DEBUG`, `WAVE_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Texture luminance: the vanilla wave pattern in grey, animating as in vanilla |
| 2 | Wave = L − mean: mid grey base, brighter crest rows |
| 3 / 4 | Crest mask before / after quantization: mode 4 shows only black, grey and white texels |
| 5 | Pseudo-normal (tangent x / y in red / green): flat ≈ (0.5, 0.5); crest edges tinted |
| 6 | Wrap diffuse: brighter when the sun is high or on crests facing it |
| 7 | Glint: a band of bright texels toward a low sun; almost black with the sun behind you |
| 8 | Red = opaque shadow, green = sky light, blue = combined mask: red drops under roofs/trees, green in caves |
| 9 | Crest light alone (×2) |
| 10 | Split screen: left half with crest light, right half without (normal grading) |

### Acceptance test

1. Clear weather, `/time set 23500` (sunrise), facing the sun over a lake. The crest pixels warm up and a glint path of texels forms toward the sun. Turn 180°: only a soft lift on the crests remains.
2. `/time set 6000` (noon), looking down. The wave rows are slightly lighter than in vanilla, the glint is weak, and the shapes and animation match vanilla. Check with debug mode 10.
3. Set `WAVE_LIGHT_STRENGTH` to 0: the water equals the base water and the crests are not lit.
4. Under a roof, in a cave, in heavy rain, at night: no light (rain −85 %; night only a faint cool moon response).
5. Walk and turn over far water: no crawling; the effect fades with distance and at grazing angles.

## v3.2: water reflection system and horizon blend

### Screenshots, measured (decoded pixels)

| Region | Target (Bedrock VV) | Current (Java) |
| --- | --- | --- |
| Sky, high | `#9DAEDB` | `#77ABE4` |
| Horizon | soft haze, no line | hard pale band `#B1CAE7` |
| Far water | `#939EBA` | `#53798C` |
| Mid water | `#6B7DA4` | `#345584` |
| Near water | `#4D5D85` | `#2F547E` |
| Water under the ice mountain | `#7B8FC0` (beside it `#818FB2`) | no reflection |

The target's far water is the sky/haze colour, and the reflection under the mountain is lighter and bluer, low contrast and vertically smeared. The current surface is dark and see-through to the horizon, where it ends in a hard band.

### Causes found in the code

| Symptom | Cause | File / function |
| --- | --- | --- |
| Hard pale band at the horizon | With `ATMOSPHERIC_HAZE` on, the gbuffers skip vanilla fog, and final's exponential haze (density 0.002) is far from opaque at the render distance. The water ends abruptly against the vanilla sky dome, whose horizon is `fogColor`. | `final.fsh` haze block; `gbuffers_forward.fsh` fog section |
| See-through to the horizon | Opacity depended only on the vertical column, never on angle or distance | `gbuffers_forward.fsh`, `WATER_DEPTH_TINT` block |
| No sky / cloud / terrain reflection | Only `mix(fogColor, skyColor)` with a weak Fresnel capped at 0.48 | old `WATER_SKY_REFLECTION` block |
| Streaks constant with distance | No distance term on the wave texture | – |

### Implementation

**Tier 1** (`WATER_SKY_REFLECTION`, all presets), in `lib/water_reflection.glsl`, shared by gbuffers_water and final:
- The vanilla sky dome approximation plus the pack's sky grade and golden tint.
- A soft sun glow.
- Faint pixel-edged procedural clouds: one cloud-plane intersection at y = 192 and two hashes on the 12-block grid. These are not the real cloud shapes.
- No texture fetch.

**Blend** (`gbuffers_water`):
- `R = max(Fresnel(F0 = 0.02) × FRESNEL_STRENGTH, D × FAR_REFLECTIVITY) × WATER_REFLECTION_STRENGTH`, where `D = smoothstep(REFLECT_NEAR_DISTANCE, REFLECT_FAR_DISTANCE, horizontal distance)`.
- Output: `mix(water seen through, reflection, R)`, done in premultiplied form, so `R` also raises the opacity.
- Water seen through:
  - near: own colour from `SHALLOW_TINT` (column under ~2 blocks), `NEAR_WATER_TINT` and depth absorption;
  - far: shifts to `FAR_WATER_TINT`, with opacity from `WATER_OPACITY_NEAR` to `WATER_OPACITY_FAR`.
- Caustics stay on the floor before this blend.

**Streaks**: the vanilla wave texels (crest threshold 0.68, `STREAK_LOD_BIAS` mip bias) catch more reflection and get paler with distance. Gaps stay closer to the base water. They fade into the haze (`STREAK_DISTANCE_FADE`) and at grazing angles. The sun-lit wave light stays an additive layer on top.

**Tier 2** (`WATER_SSR`, LOW and up), in `final.fsh` (`waterScreenReflection`):
- **Data from the water pass**: the water program packs, into colortex1.B, the share of `R` that final may replace (flat tops only, outside the water) and a 3-bit wobble taken from the wave texel.
- **Reflected point**: final reads the surface from `depthtex0` and projects the reflected ray at the render distance. It then refines once per `WATER_SSR_REFINE` with the depth seen there; 3 steps is the "Tier 3" quality. No ray march is needed because the plane is known.
- **Sampling**: `REFLECTION_BLUR` vertical taps of `colortex0`, spaced by `REFLECTION_STRETCH` and snapped to a 2-pixel grid.
- **Validity**: valid only for objects above the water plane, on screen, and farther than 1 block (which excludes the hand). It fades at screen edges. Sky samples keep Tier 1, which already matches the sky.
- **Result**: `scene + weight × (environment − Tier 1)`, applied before haze and grading.
- **No read/write hazard**: colortex0 and depthtex0 are written by the gbuffers and only read in final.

**Non-flat water, underwater**: flowing tops get weight ≈ 0 (Tier 1 only). With the camera underwater, everything is skipped and the vanilla underside stays.

**Tier 3** is the extra planar refinement steps, not a full ray march for non-flat water. A true 8-step march would cost about 0.1–0.3 ms more for little gain on flat oceans, so it was left out.

**Horizon** (`HORIZON_BLEND`): terrain and water fade into the same sky function over 55–95 % of the render distance (`far`), so there is no pale band.

### Options (Water and Caustics → Water Reflections)

| Option | Default | Presets UL / L / M / H / C |
| --- | --- | --- |
| `WATER_SKY_REFLECTION` | on | on everywhere |
| `WATER_SSR` | on | off / on / on / on / on |
| `REFLECTION_BLUR` (taps) | 3 | 1 / 1 / 3 / 5 / 5 |
| `WATER_SSR_REFINE` | 1 | 1 / 1 / 1 / 2 / 3 |
| `CLOUD_REFLECTION` | 0.25 | 0 / 0.15 / 0.25 / 0.35 / 0.35 |
| `WATER_REFLECTION_STRENGTH`, `FRESNEL_STRENGTH`, `FAR_REFLECTIVITY` | 1.00, 1.00, 0.85 | same |
| `REFLECT_NEAR_DISTANCE` / `REFLECT_FAR_DISTANCE` | 6 / 60 blocks | same |
| `REFLECTION_STRETCH` / `REFLECTION_WOBBLE` | 2 px / 1.0 | same |
| `STREAK_CONTRAST` / `STREAK_DISTANCE_FADE` / `STREAK_LOD_BIAS` | 1.00 / 0.60 / 0.0 | same |
| `HORIZON_BLEND` | 1.00 | same |
| `SHALLOW_TINT` / `NEAR_WATER_TINT` / `FAR_WATER_TINT` | turquoise / deep blue / lavender | same |
| `WATER_OPACITY_NEAR` / `WATER_OPACITY_FAR` | 0.30 / 0.90 | same |

`DEEP_TINT` was renamed `NEAR_WATER_TINT` and `SHALLOW_OPACITY` was renamed `WATER_OPACITY_NEAR`; saved values for those reset. `SHALLOW_TINT` 1 is now turquoise; the v3 light teal is option 2.

**Properties audit:**
- Defaults or preset values missing from their slider lists were added: `EDGE_DROPOUT`, `MATCH_STRENGTH`, `SKY_GRADIENT_STRENGTH`, `STAR_AMOUNT`, `CELESTIAL_GLOW_STRENGTH`, `ATMOS_RAY_INTENSITY`, `HAZE_DENSITY`.
- `GOLDEN_SKY_TINT_STRENGTH` was on no screen; it is now under Sky.
- Nine options were set by only some presets, so switching presets could carry a value over: `ATMOS_RAY_INTENSITY`, `ATMOS_RAY_SAMPLES`, `ATMOSPHERIC_HAZE`, `CELESTIAL_GLOW_STRENGTH`, `DIRECTIONAL_LIGHTING`, `HAZE_DENSITY`, `SKY_GRADIENT_STRENGTH`, `SKY_QUALITY`, `STAR_AMOUNT`. All five presets now set the same 114 options.
- The other 50 options are set by no preset, so they always keep your own value.

### Debug views (`REFLECTION_DEBUG`, `REFLECTION_DEBUG_MODE`)

| Mode | Correct result |
| ---: | --- |
| 1 | Reflected vector: mostly green (up), with red/blue shifts at the sides |
| 2 | Tier 1 alone: sky colours, paler toward the horizon, faint blocky clouds |
| 3 | Tier 2 colour: terrain and clouds mirrored under their objects; black where invalid |
| 4 | Tier 2 validity: white under objects above water, black elsewhere (sky, edges) |
| 5 | Reflection UV as red/green: a smooth gradient, flipped vertically compared with the water |
| 6 | Fresnel: near 0 looking down, near 1 at grazing angles |
| 7 | Distance D: black within 6 blocks, white from 60 |
| 8 | Final per-texel reflectivity, with streaks visible |
| 9 | Vertical water column (0–12 blocks) |
| 10 | Final water opacity: low near and shallow, high far |
| 11 | Crest mask of the streaks |
| 12 | Left: before haze, horizon blend and grading; right: normal |

### Screenshot comparison

No screen-capture tool is available in this session, so nothing was captured; only the two attached images were measured.

To compare, take these from the same world, at noon, in clear weather, from the same spot, with the HUD hidden (F1) and the same FOV, render distance and resolution:
- the shore looking out at about 5°, then 20°, 45° and straight down;
- a view with the ice mountain and spire on the right;
- a shallow bank;
- the same views at sunset.

Java extras: reflection debug modes 4 and 12.

### Test scene

1. A wide ocean with a shore.
2. A sand shelf 1–2 blocks deep (shallow bank) and kelp at 4–6 blocks.
3. A 12-deep section.
4. On the right shore: a packed-ice mountain about 20 blocks tall and a 1×1 stone spire 15 tall.
5. A flowing-water slope.
6. A 3×3 roof over the shallow water.

| Situation | Expected |
| --- | --- |
| Noon, at the horizon | Far water turns the sky colour and merges with the sky (no band); near water is darker blue with the floor visible; the mountain and spire are mirrored as soft, lighter, vertically stretched streaks |
| 20° / 45° | Less reflection, more floor; the streaks are still brighter in the distance |
| Straight down | Mostly the water seen through (Fresnel ≈ 0.02); turquoise shallow bank, caustics visible |
| Sunrise / sunset | Warm sun glow and golden sky reflected; sun-lit wave glint path on top |
| Night | Dark, cool sky reflection; no sun glow |
| Rain | Softer and wobblier reflection, fewer clouds, about 25 % lower reflectivity |
| Under the roof | Tier 1 dimmed to 12 % (from the stored sky light); Tier 2 still mirrors what is on screen above the water |
| Flowing slope | Tier 1 only (no screen-space reflection) |
| Crossing the surface | Underwater: the vanilla underside, no reflection |

### Comparison checklist

| Difference | Slider |
| --- | --- |
| Horizon line visible | `HORIZON_BLEND` ↑ |
| Far water too dark / bright | `FAR_REFLECTIVITY`, `FAR_WATER_TINT`, `REFLECT_FAR_DISTANCE` |
| Near water colour | `NEAR_WATER_TINT`, `SHALLOW_TINT` |
| Too transparent / opaque | `WATER_OPACITY_NEAR`, `WATER_OPACITY_FAR`, `ABSORPTION_STRENGTH` |
| Reflection too strong / weak | `WATER_REFLECTION_STRENGTH`, `FRESNEL_STRENGTH` |
| Reflection too sharp / too smeared | `REFLECTION_BLUR`, `REFLECTION_STRETCH` |
| Reflection too still / too wobbly | `REFLECTION_WOBBLE` |
| Gap between an object and its reflection | `WATER_SSR_REFINE` ↑ |
| Clouds in the water | `CLOUD_REFLECTION` |
| Streaks too bright / faint with distance | `STREAK_CONTRAST`, `STREAK_DISTANCE_FADE`, `STREAK_LOD_BIAS` |

### Cost (GTX 1650, 1080p, estimated, not measured)

- **Tier 1 and blend** (gbuffers_water): ~120 ALU ops and one extra texture tap per water pixel, about 0.02–0.05 ms.
- **Tier 2** (final):
  - one colortex1 read on every pixel (early out), about 0.03 ms;
  - per water pixel, LOW 4 taps, MEDIUM 6, HIGH 9, CINEMATIC 10;
  - with 40 % water: LOW ≈ 0.08–0.12 ms, MEDIUM ≈ 0.12–0.20 ms, CINEMATIC ≈ 0.20–0.28 ms;
  - with the screen full of water, MEDIUM can reach ≈ 0.3 ms.
- **Horizon blend**: ≈ 0.01–0.02 ms.
- No new pass or buffer. colortex1 is now explicitly RGBA8 (it already was by default).
- The library, final's reflection and the water block were compiled and linked in WebGL2; nothing was compiled inside Iris.
- Backup of all pre-reflection files: `backup/2026-10-04_before_reflections/`.


## v4: Ambience (environment colours, clouds, cloud shadows, layered fog, reflection add-on)

**Game version.** The log shows Minecraft **26.3** (Iris 1.11.7, Sodium 0.9.2), not 1.21.1. The cloud
facts below were read from the 26.3 client jar and the Iris 1.11.7 jar on this machine.

### Crash fix (first run of v4)
`customTexture.vclClouds = minecraft:textures/environment/clouds.png` crashed the game on entering a
world (`IllegalStateException: Close the existing render pass before performing additional commands`,
3 crash reports, 17:22-17:28). 26.3 never uploads `clouds.png` to the GPU (the CloudRenderer reads it on
the CPU), so Iris loaded it lazily during the first draw that bound the sampler, inside an open render
pass. Fix: `shaders/textures/clouds.png` (a copy of the vanilla image taken from the local 26.3 jar, for
personal use: remove it before sharing the pack) loaded as a pack PNG when the pipeline is created.
Toggle: `VANILLA_CLOUD_CELLS` (off = procedural cells, no texture at all).

### Reference (judged by eye; the image arrived inline, so no pixel sampling)
| Element | Reference | Previous pack (measured from the 13:50 screenshots) |
|---|---|---|
| Zenith / mid / horizon | ~#7F9FDC / ~#9DB2E4 / ~#C2CDEC, no line | #619ADB / #6CA3E1 / #75A7DD, pale band #B9D0EB at the horizon |
| Haze | thick lavender veil, rosy on the red mountain, thinner on its lit face, a bank over the summit | almost none: far badlands #81533B, far dunes #A9A186 |
| Clouds | flat blocky, white-lavender ~#E0E0F2, bright white outlines, slightly translucent | vanilla white, fogged twice (vanilla fallback + final haze) |
| Sand lit / shade | ~#E8CC9C / soft ~#D0C6B0 | #E3D3A5 / #8E866A (neutral, high contrast) |
| Far terrain | lighter, lavender, low contrast, silhouettes readable | saturated, crisp |
| Water | turquoise shallows, lavender-blue far water | approved, unchanged |
Matched with certainty: the cloud grid, height and scroll (from the jars), the sky-equals-fog-at-horizon
rule. Approximations: every colour (eye estimates from a compressed image), fog density and layering,
the bank pattern, cloud lighting (vanilla clouds have no internals to copy).

### Code review (issue - file/function - severity - fix)
| Issue | Where | Severity | Fix |
|---|---|---|---|
| 17 Boolean options declared twice (`#define X` + `//#define X`): Iris dropped them; BLOOM, ATMOSPHERIC_RAYS, SKY_GRADE, PIXEL_CAUSTICS, ATMOSPHERIC_HAZE, PIXEL_SHADOWS, EMISSIVE_BLOCKS were stuck ON (presets could not turn them off, so ULTRA LOW ran bloom, rays, particles...) | lib/settings.glsl | High | one declaration per option |
| `FRESNEL_STRENGTH` defined twice (0.07 rim, 1.00 water): the plastic rim on player/mobs used 1.00 since v3.2 | settings.glsl / gbuffers_forward shadeFragment | High | rim renamed `GLOSS_FRESNEL` (0.07) |
| `shadowEntities = ENTITY_SHADOWS` ignored by Iris (needs true/false) | shaders.properties | Medium | `#ifdef ENTITY_SHADOWS` blocks |
| Options never tested with `#ifdef` are invisible to Iris (ENTITY_SHADOWS, PIXEL_WATER_SPARKLES, CAUSTICS_UNDERWATER_FLOOR, VANILLA_CLOUD_CELLS) | settings.glsl | Medium | explicit empty `#ifdef` references |
| Clouds fogged twice (Iris vanilla fallback fog + final haze) and erased beyond 95 % of the render distance | final haze | Medium | gbuffers_clouds with its own haze + colortex1 cloud marker; final skips fog on clouds |
| Haze far too weak (0.2 at 150 blocks) and not tied to the sky colour (hard pale band) | final evaluateFogFactor | Medium | Ambience fog: closed-form height fog, far end = sky colour |
| No dithering on fog / most of the sky (8-bit banding) | final | Low | 4x4 ordered dither before output |
| Sky dome mostly vanilla (SKY_GRADE blends 32 %), horizon = vanilla fog colour | final sky block | Low | palette sky, full replacement near the horizon |
| Presets left 50 options undefined (inherited between presets) | shaders.properties | Low | all 5 presets define all 201 options (generated) |
| Toggles that multiply by zero: MATCH_STRENGTH 0 still runs the golden code; WATER_REFLECTION_STRENGTH 0 still runs reflection code | final, gbuffers | Low | left as is (each has its own compile-time toggle) |
| Checked and fine: depth linearisation, matrix order, sky pixels skipped by surface effects, HDR targets (colortex0/5 RGBA16F, colortex1 RGBA8 data only), underwater fog separate, Nether/End use their own haze | - | - | - |

### Cloud shadows: Option A, aligned (verified facts, honest limits)
- **Verified in the jars:** cell 12 blocks; layer 4 blocks thick (fast clouds: flat plane at the base);
  scroll `x + ((gameTime mod width*400) + partialTick) * 0.03` blocks; `z + 3.96`; cell empty when alpha < 10;
  Iris uniforms `cloudTime` (computed with the same 0.03 factor) and `cloudHeight` (cloud-height environment
  attribute, fallback 192).
- **Method:** receiver -> along the sun direction to the middle of the layer (`cloudHeight + 2`) -> the vanilla
  cell there. Quality 1 = one fetch, hard cells; quality 2 = bilinear coverage of 4 cells + soft threshold
  (`CLOUD_SHADOW_SOFTNESS` x 12 blocks, wider with a low sun). Receivers snap to a `CLOUD_SHADOW_GRID`
  block grid, so edges step like pixels. Applied as a product with the shadow map (independent occluders)
  to the direct-sun terms only (sun share, warm/cool response, gloss, leaf back-light), plus wave glints,
  caustics (both on the water fragment), rays and shallow-water shafts (composite) and the haze (final).
- **Not verified in game:** that Iris' `cloudTime` is in blocks (the 0.03 constant says so). Debug view 16
  checks it: every cloud pixel must turn green.
- **Limits:** the projection uses the middle of the 4-block layer (up to ~2 blocks of offset at a low sun;
  fast clouds sit at the base); `cloudTime` is game time, so `/time` jumps move clouds and shadows together;
  the shadows cannot know whether clouds are disabled in Video Settings (turn `CLOUD_SHADOW_ENABLE` off);
  a resource pack's own clouds.png is not followed (the pack copy is vanilla); receivers inside or above the
  layer get no cloud shadow; far from spawn, x/z are wrapped with integer camera coordinates (no drift).

### Palettes (hex). Sources: midday zenith/mid/horizon/clouds from the reference by eye; the rest are suggestions
| Palette | Sky zenith | Sky mid | Sky horizon = fog far | Fog near | Cloud top | Cloud edge | Cloud underside | Sunlight | Sky light (shade) |
|---|---|---|---|---|---|---|---|---|---|
| night | #070C1E | #0E1630 | #1A2440 | #18223C | #222A44 | #2C3654 | #141A2E | #5A6A9A | #28324E |
| dusk | #1E2850 | #3C4474 | #6C6488 | #5A5A80 | #5C5C80 | #8A7090 | #34385A | #6070A0 | #4A5480 |
| sunset | #4A5E9C | #9A84B0 | #F49A6C | #D89A8C | #F0A890 | #FFB070 | #6E6890 | #FF9A5C | #8C90C0 |
| golden hour (pm) | #6A84C4 | #B0A4CC | #F8C49C | #F0BC9C | #F8D2B8 | #FFD08C | #A498B8 | #FFC888 | #B4B8DC |
| afternoon | #7C9CDA | #A0B2E0 | #C6CAE8 | #CCC4E0 | #E6DEEC | #FFF2E6 | #C6C4DC | #FFE6C4 | #C6CCEA |
| midday | #7F9FDC | #9DB2E4 | #C2CDEC | #C8C4E6 | #E4E2F4 | #F6F5FC | #D0D2EC | #FFF1DC | #C8D4F0 |
| dawn | #202C58 | #404A7C | #70688E | #5E5E86 | #60607E | #907898 | #363C60 | #6878A8 | #4E5888 |
| sunrise | #4E64A4 | #A08CB8 | #F4A88C | #DCA4A0 | #F2B4A4 | #FFC0A0 | #727098 | #FFA878 | #9098C8 |
| golden hour (am) | #6E88C8 | #A8A8D4 | #F0C8B8 | #E8C0B8 | #F4D6CC | #FFE0B8 | #A4A0C4 | #FFD2A0 | #B8C0E4 |
| morning | #7A9AD8 | #9AB0E2 | #C4CAEA | #CAC2E2 | #E4DCF0 | #FFF2F2 | #C4C6E0 | #FFEAD0 | #C4CEEE |
| rain (day) | #8A929E | #9AA2AC | #A8AEB6 | #A4AAB2 | #A6ABB4 | #B4B8C0 | #7E848E | #C8CCD0 | #A4ACB8 |
| thunder (day) | #4A505C | #565C68 | #646A74 | #5E646E | #5C626C | #6A707A | #3C424C | #8A9098 | #5C6470 |
Biome families (haze ratio relative to the coastal reference, camera biome smoothed over 20 s):
ocean/beach/river #B8C8E8 (reference), snowy/icy #C8D4F0, plains/forest #B0C8E0, taiga #A8BEC8,
jungle/swamp/mushroom #98CCC4 (teal), desert #E2D2B8, badlands #EAC0A8 (peach), savanna #DCCCA4,
mountains #B8BCE4. Strength = `BIOME_TINT_STRENGTH` x 2.5 (0.22 -> 0.55); rays keep the old 1x weight.

### Ambience menu (Ambience -> Colors / Clouds / Cloud Shadows / Fog / Water Reflections)
| Option | Default | Effect |
|---|---|---|
| AMBIENCE_COLORS | on | palettes for sky, fog, clouds and terrain light; sky = fog at the horizon |
| ENV_SKY_PALETTE | 0.85 | palette sky over the vanilla dome (horizon always 100 %) |
| ENV_LAVENDER | 1.00 | 0 = neutral blue haze, 1.5 = more lavender |
| ENV_WARMTH / ENV_SHADOW_COOLNESS | 0.50 / 0.60 | warm sunlit faces / cool soft shade (sand and rock resist) |
| ENV_VIBRANCE | 0.15 | vibrance on dull colours, never above 80 % saturation |
| ENV_SNOW_TINT | 0.60 | blue on snow/ice + highlight shoulder |
| ENV_DISTANCE_DESATURATION | 0.60 | far terrain loses saturation inside the fog |
| BIOME_TINT_STRENGTH | 0.22 | biome palettes (x2.5 for Ambience) |
| AMBIENCE_CLOUDS, CLOUD_OPACITY, CLOUD_TINT, HIDE_VANILLA_CLOUDS | on, 0.80, 1.00, off | palette cloud lighting |
| CLOUD_SHADOW_ENABLE, VANILLA_CLOUD_CELLS | on, on | cloud shadows; aligned vanilla cells |
| CLOUD_SHADOW_STRENGTH / SOFTNESS / GRID / QUALITY | 0.60 / 0.50 / 2 / 2 | darkness, penumbra, block step, 1 or 4 fetches |
| AMBIENCE_FOG | on | layered height fog (replaces the distance haze in the overworld) |
| FOG_DENSITY / FOG_HEIGHT_FALLOFF / FOG_BASE_HEIGHT | 0.010 / 0.035 / 63 | density, thinning with height, densest layer |
| FOG_START / FOG_END | 32 / 1.00 | clear zone around you; share of the render distance where it is opaque |
| FOG_BANK_QUALITY / STRENGTH / SCALE / DRIFT_SPEED | 1 / 0.45 / 48 / 0.40 | banks: off/blocky/smooth, thickness, cell size, drift |
| FOG_SCATTERING, FOG_SUN_SCATTER | on, 0.60 | glow toward the sun, cooler opposite |
| FOG_ON_WATER | on | off = water keeps the previous haze |
| FOG_BANDED_LOOK, FOG_LEVELS | off, 10 | dithered fog steps |
| WATER_REFLECTION_IMPROVEMENT | on | A/B of the reflection add-on |
| WATER_REFLECTION_STRENGTH | 1.00 | master reflectivity (1.00 = the approved water) |

### Water reflection add-on (`WATER_REFLECTION_IMPROVEMENT`; off = v3.2 exactly)
Changed: `lib/water_reflection.glsl` new `waterSkyReflectionImproved` (palette sky, real cloud cells at the
reflected cloud-plane point, cooler/weaker at night); `gbuffers_forward.fsh` shadeFragment reflection block
(calls it, shallow banks under ~2 blocks reflect 35 %, night x0.75, none in the Nether); `final.fsh`
`waterScreenReflection` (same Tier 1, fog-aware: haze between the reflected object and the water is applied
with the height-fog transmittance of that segment, then final's fog adds the camera-water part; reflected
clouds are skipped because they carry their own haze; rain lowers contrast). Not touched: water tint,
opacity, wave sprite light, streaks, caustics, the blend in gbuffers_water.

### Pass order after v4
shadow -> gbuffers_terrain / textured_lit (cloud shadow once per fragment, terrain response) ->
gbuffers_water (cloud shadow on glints and caustics, Tier-1 reflection) -> gbuffers_clouds (palette
lighting + haze, writes colortex0 and the colortex1 cloud marker) -> composite, quarter resolution
(rays x cloud shadow, ray mask -> colortex5.a, shafts x cloud shadow) -> final (Tier-2 reflection reads
colortex0/depthtex0, sky treatment, Ambience fog with the cloud shadow and colortex5.a, grading,
dither). No buffer is read and written in the same pass; no new pass or buffer (colortex5.a and the
colortex1 alpha on cloud pixels were unused).

### Debug (`AMBIENCE_DEBUG`, `AMBIENCE_DEBUG_MODE`) and expected look
1 fog amount (black near, grey mid, white at the render distance) - 2 fog colour (lavender, warmer toward
the sun) - 3 banks (mid grey = neutral, large blocky patches) - 4 sun scattering (soft disc around the sun)
- 5 perspective/desaturation (grows with distance) - 6 cloud mask at the cloud plane (blocky 12-block cells)
- 7 cloud shadow on the ground (soft blocky shapes that drift toward -X (west)) - 8 cloud-plane UV (smooth red/green
ramp, repeating every 3072 blocks) - 9 palette sky only - 10 sky vs fog at the horizon (must be black) -
11 water reflection colour - 12 reflection validity - 13 reflection fog (grows for far reflected objects) -
14 water without/with the screen-space reflection (split) - 15 terrain response without/with (split) -
16 cloud alignment (all cloud pixels green).

### Cost (GTX 1650, 1080p, estimated, not measured)
| Feature | Before | After |
|---|---|---|
| Palette (vertex shaders) | - | ~0.02 ms (terrain vertices) |
| Terrain response | - | ~0.03 ms |
| Cloud shadows: gbuffers + composite + final | - | q1 ~0.03 ms, q2 ~0.07 ms |
| Fog (final) | haze ~0.05 ms | ~0.10 ms (banks 1: +0.02, banks 2: +0.04) |
| Cloud lighting | vanilla | ~0.01 ms |
| Reflection add-on | - | ~0.03 ms (one cloud fetch, segment fog) |
| Output dither | - | ~0.005 ms |
Totals: ULTRA LOW ~+0.12 ms (and much faster than before, because bloom/rays/particles are finally off),
LOW ~+0.15 ms (its screen-space reflection is now off: -0.10 ms), MEDIUM ~+0.25 ms, HIGH/CINEMATIC ~+0.3 ms.

### Test scene
Bay with turquoise shallows and deep water, sand beach, a red-brown mountain 150-250 blocks away, snow,
a forest, flat grass and a high peak; 12 chunks, FOV 70, HUD off.
Expected: **noon** lavender haze, far mountain ghosted and rosy, clouds bright with white outlines, soft
blocky cloud shadows drifting west (-X); **sunrise/sunset** peach-pink horizon, golden cloud rims, long weak
shadows; **dusk** violet-blue; **night** calm dark-blue haze, no cloud shadows; **rain** grey, denser and
lower fog, no cloud shadows; **thunder** darker grey; **horizon** no line; **looking down** shadows on
blocks with stepped edges; **Y 190-210** inside/above the layer no cloud shadow, thin fog; **underwater**
unchanged; **Nether** previous vanilla-like haze; **End** subtle previous haze; **far from spawn** no shimmer.

### Comparison checklist (slider to move)
haze density - FOG_DENSITY | haze height - FOG_HEIGHT_FALLOFF, FOG_BASE_HEIGHT | banks - FOG_BANK_* |
far mountain ghosting - FOG_END, FOG_DENSITY, ENV_DISTANCE_DESATURATION | sky-horizon blend - ENV_SKY_PALETTE
(debug 10) | lavender - ENV_LAVENDER, BIOME_TINT_STRENGTH | terrain warmth - ENV_WARMTH, ENV_SHADOW_COOLNESS |
snow - ENV_SNOW_TINT | cloud colour - CLOUD_TINT, CLOUD_OPACITY | cloud shadow darkness/softness -
CLOUD_SHADOW_STRENGTH/SOFTNESS/GRID | reflection strength - WATER_REFLECTION_STRENGTH, FRESNEL_STRENGTH |
reflection softness - REFLECTION_BLUR, REFLECTION_STRETCH | reflection fog - FOG_DENSITY (debug 13).

### Tuning tips
- **Less haze:** FOG_DENSITY 0.006, FOG_START 48. **More:** FOG_DENSITY 0.015.
- **More lavender:** ENV_LAVENDER 1.5. **Bluer:** ENV_LAVENDER 0.5.
- **No cloud shadows:** CLOUD_SHADOW_ENABLE off (also if clouds are off in Video Settings).
- **Sharper reflections:** REFLECTION_BLUR 1, REFLECTION_WOBBLE 0.5.
- **Vanilla-like fog:** AMBIENCE_FOG off (the previous distance haze returns); everything off: the three
  AMBIENCE_* toggles + CLOUD_SHADOW_ENABLE + WATER_REFLECTION_IMPROVEMENT.

### What it cannot do (honest)
No true volumetrics: the fog is not lit from inside shadows (the only shafts are the existing screen-space
rays, used as a brightness hint), it does not interact with transparent objects, and the banks are 2D noise
sampled at one or two points per pixel. Biome palettes follow the camera biome, not each pixel.

### Verification
WebGL2 (GLSL ES 3.00, stricter than GLSL 330) harness: every program compiled and linked for 35 option
sets (defaults, all 5 presets, Ambience off, option combinations, the 16 Ambience debug views and other
debug modes): 245/245 passed. Not run inside Iris: the clouds.png pack texture path, the `cloudTime` unit,
Iris' cloud vertex data, and the look itself still need an in-game check.

## v5: sun, sky glow, clouds, horizon and fog rebuild

Full report (reference measurements, gap table, code review, design note, changelog, test
plan, tuning tips, open questions): [SUN_SKY_REBUILD_REPORT.md](SUN_SKY_REBUILD_REPORT.md).

- **Removed:**
  - the old screen-space sun rays (random jitter, hard depth steps, a shadow-map read,
    quarter-res upscale);
  - the stepped golden sun glow and its second square core;
  - the flare orb;
  - the screen-space celestial halo.
- **Added:**
  - one analytic sun, with the vanilla size, orientation and pixel rings (the vanilla quad is
    off: `sun=false`);
  - a thin bloom plus mid glow plus a faint wide halo fitted to the sun reference;
  - gentle uniform ray lobes;
  - a warm veil and edge rim scaled by a fixed-tap sun visibility;
  - static triangular dither.
- **One sky function** (`ambienceSky`) for:
  - the sky;
  - the fog at every distance;
  - the clouds' haze;
  - the sky behind translucent clouds (gbuffers_skybasic writes it);
  - the water's Tier-1 reflection.

  Terrain at the fog end equals the sky behind it, so there is no horizon line.
- **Clouds:** colours derived from the sky, translucent, with lighter side faces and deeper
  undersides. Composites match the cloud reference within 1–3 8-bit steps (WebGL render).
- **Fog banks:** smooth value noise with a wrap-safe drift.
- **Debug:** SUN_DEBUG, 16 views.
- **Menu:** Ambience → Sun and Sky Glow.
- **Backup:** `backup/2026-10-04_before_sun_rebuild/`.

## v6: biome-dependent ambience

Full report (measurements, Iris biome uniforms, gap table, code review, palette and mapping
tables, test plan, tuning): [BIOME_AMBIENCE_REPORT.md](BIOME_AMBIENCE_REPORT.md).

- **Families.** 16 biome families plus a base, mapped by exact vanilla biome ids (`biome` +
  `BIOME_*`). All 67 biomes of 26.3 are covered; unknown or modded biomes use the base (the v5
  look).
- **Blending.** Colours and fog character are blended once per frame on the CPU (Iris custom
  uniforms), with no per-pixel cost. The tint is applied on top of the time-of-day, golden-hour
  and weather palettes; sky, fog and clouds stay one function, so there is no horizon line.
- **Fog character.** Density, height falloff, sun scatter and haze saturation change per biome;
  optional desert/badlands dust.
- **Weather.** Biomes without precipitation stay clear in rain; snow looks brighter than rain.
- **Nether and End.** Per-biome tints on the vanilla fog. Their weights now switch instantly at
  portals.
- **Menu.** Ambience → Biome Ambience. Debug: BIOME_DEBUG (6 views), FORCE_BIOME_PREVIEW.
- **Backup.** `backup/2026-10-04_before_biome_ambience/`.

## Update 1: soft sun rays, clouds that hide the sun, shadow colours, underwater caustics

Full report (reference measurements, code review, verified Iris and vanilla facts, design notes,
costs, test plan, screenshot list): [UPDATE1_REPORT.md](UPDATE1_REPORT.md).
Backup: `backup/2026-10-04_before_update1/`.

- **Rays.**
  - A thin golden rim and a soft bleed on silhouette edges right around the sun, from
    sun-directed depth taps. The rim colour is fitted to the reference (#D4B585).
  - Optional faint shafts through gaps (quarter resolution, deterministic, depth-aware upsample).
  - The sky glow and the veil are unchanged; no noise anywhere.
- **Clouds.**
  - Opaque by default (CLOUD_OPACITY 1.0), so they hide the sun, moon and stars.
  - Far clouds fade into the haze by colour, not by alpha.
  - A soft patch shows where the sun is behind a cloud.
  - Colours are fitted to the reference: underside #DACEE0.
- **Shadows.**
  - Shade takes the hue of the sky light (time, weather, biome) and reacts to the surface: snow
    blue, sand grey-lilac, stone cool, grass blue-green, wood and dirt darker.
  - Player and mob shadows have their own strength through an entity flag written by the new
    shadow_entities program. They are weaker under clouds and in rain, but never gone.
- **Underwater.**
  - Caustics are now on by default while you swim. The water surface height is estimated from the
    sky light at your eye.
  - Nothing appears on the surface seen from below or on blocks above it, and nothing pops when
    you cross it.

**Tuning tips**

- *Softer rays:* RIM_STRENGTH 0.50-0.65 and RIM_REACH 2.00 (wider, gentler bleed).
- *No shafts:* SUN_SHAFTS off. This also removes the composite1 pass and the shaft mask.
- *A warmer glow on stone near the sun (closer to the reference):* VEIL_STRENGTH 0.45-0.60.
- *Stronger shadow tint:* SHADOW_HUE_PUSH 0.75-1.00 and TERRAIN_SHADOW_COLOR_STRENGTH 0.80-1.00.
- *Gentler shadow tint:* TERRAIN_SHADOW_COLOR_STRENGTH 0.30, or SHADOW_COLOR_QUALITY 1.
- *Player shadow stays dark in clouds and rain:* SHADOW_MIN_DARKNESS 0.50.
- *Clouds slightly translucent again:* CLOUD_OPACITY 0.85 (the sun shows faintly through). Use 0.65
  with CLOUDS_BLOCK_SUN off for the exact previous clouds.
- *Less glow on a cloud in front of the sun:* CLOUD_SUN_GLOW_THROUGH 0.15-0.30.
- *Underwater caustics off:* CAUSTICS_UNDERWATER_FLOOR off. Use UNDERWATER_CAUSTIC_STRENGTH for
  calmer or brighter ones.
- *Debug:* LIGHT_DEBUG with modes 1-17. The list is in the report.

## Update 2A: moon rays

Full report (how the sun and moon worked before, sun-versus-moon table, code review, measured
values, identity proof, design notes, costs, test plan, screenshot list):
[UPDATE2A_REPORT.md](UPDATE2A_REPORT.md). Backup: `backup/2026-10-05_before_update2a/`.

- **The moon gets the sun's light system, in cool night colours.** A thin cool-white bloom
  hugging the vanilla moon square, a round mid glow and a very wide faint halo (a lighter version
  of the local night sky). Plus a faint cool veil, a thin pale-blue rim on edges turned to the
  moon, and very faint shafts through gaps.
- **The vanilla moon is untouched.** Its phase sprite and square shape stay. Nothing glows on the
  disc itself, so the dark part of a crescent stays dark. The previous glow sat under the disc and
  washed out its craters.
- **Phases.** The glow follows the lit share of the disc, measured on the 26.3 moon sprites:
  full 1.00, gibbous 0.69, quarter 0.52, crescent 0.25, new 0.12. With the phase-aware glow
  (quality 2) it leans toward the lit side.
- **Only at night, only one light at a time.** The moon's light fades in as the sun sinks and the
  sky darkens (half at about -8 degrees, full from about -12). It fades out at the horizon, in
  rain (like the vanilla moon) and in thunder, and is off underwater, in the Nether and the End.
  The sun and moon are opposite each other, so only one can be on screen. The ray passes
  (visibility taps, rim, shafts) run for one source per frame.
- **Clouds hide the moon** (opaque clouds, Update 1) and get a faint silver patch where the moon
  is behind them.
- **Stars fade softly near the moon.** A little extra dither in dark night regions removes
  banding in the halo.
- **The sun is unchanged.** With MOON_RAYS off the image is bit-identical to the previous build,
  and with MOON_RAYS on the daytime image is bit-identical too. Both were verified with the
  pack's real programs in a WebGL test harness (see the report).

**Tuning tips**

- *Stronger moon rays:* MOON_LIGHT_INTENSITY 1.25-1.50. Or raise only the parts you want:
  MOON_RIM_STRENGTH 0.40, MOON_VEIL_STRENGTH 0.10-0.15, MOON_SHAFT_STRENGTH 0.025-0.040.
- *No rays at night (glow only):* MOON_VEIL, MOON_EDGE_RIM and MOON_SHAFTS off (the ULTRA LOW
  setup).
- *Bluer moon:* MOON_COLOR_COOLNESS 0.75-1.00 (1 = blue-violet). *Whiter moon:* 0.00-0.25.
- *Less glow on a full moon:* MOON_GLOW_STRENGTH 0.50-0.75, or a smaller halo with
  MOON_HALO_SIZE 0.10 and MOON_HALO_STRENGTH 0.25.
- *Every phase as bright as a full moon:* MOON_PHASE_INTENSITY 0.00.
- *Clearer biome moonlight* (jungle teal, desert warmer, snowy icy blue, swamp dim green-grey):
  MOON_BIOME_TINT_STRENGTH 0.75-1.00. The default 0.30 is deliberately small.
- *Turn the moon's light off:* MOON_RAYS off. This brings back the previous moon glow exactly.
  For no moon glow at all, keep MOON_RAYS on and set MOON_LIGHT_INTENSITY 0.00.
- *Stars right next to the moon:* MOON_STAR_DIMMING 0.00.
- *Banding test:* NIGHT_SKY_DITHER 0.00 (and SKY_DITHER 0.00) to see the raw gradients, or
  MOON_DEBUG view 12.
- *Debug:* MOON_DEBUG with modes 1-13. The expected look of each view is listed below.

**MOON_DEBUG views (expected look)**

1. Weights over a whole day. x = sun altitude (-90 to +90 degrees), yellow = sun rays, blue =
   moon rays, white line = now. Two smooth curves that overlap only a little near 0 degrees.
2. Moon position. Disc square (light blue) and sprite quad (dark blue) outlined on the sky,
   crosshairs at the moon (blue) and sun (yellow) when in front of the camera, altitude bars at
   the left.
3. Thin bloom alone (x4). 4. Mid glow alone (x4). 5. Wide halo alone (x2). All smooth with no
   rings, black on the disc itself, leaning to the lit side with quality 2.
6. Moon visibility V (blue) and the share behind clouds (cyan), full screen. Changes smoothly
   while an edge or a cloud crosses the moon.
7. Moon veil alone (x8). Faint, smooth, on terrain near the moon only.
8. Moon rim alone (x4). Thin light only on silhouette edges turned to the moon.
9. Moon shafts alone (x32). Faint streaks from gaps toward the moon.
10. Clouds over the moon. Cloud pixels in front of the disc are blue, other clouds grey, and the
    silver patch is in green. The bar on top shows V (blue) and cloud cover (cyan).
11. Everything the moon adds (x4). Dark everywhere except around the moon.
12. Dark banding test. Each 8-bit step becomes a stripe. On the left, without dither, wide rings
    mean banding; on the right, with the final dither, the stripes dissolve into fine static grain.
13. Sun identity check. Red = the sky's sun part now vs before, green = the sun's veil, rim and
    shafts now vs the previous code, both x4096. It must be black at all times; a faint blue tint
    only means the moon has light.

## Update 2B: block lighting

Full report (screenshot analysis, diagnosis, code review, design notes, material table, test
results, test plan, screenshot list): [UPDATE2B_REPORT.md](UPDATE2B_REPORT.md). Backup:
`backup/2026-10-05_before_update2b/`.

- **Directional face lighting** (`DIRECTIONAL_LIGHTING`, "Block Lighting" screen):
  - the face of a block turned to the sun is clearly brighter (about 1.4-1.6 x the face turned away
    at mid sun); faces turned away get only the cool sky ambient, never black;
  - at noon the tops are brightest; at night the moon gives a faint cool difference; rain and
    clouds soften it;
  - sunlit ground keeps its previous brightness; walls and undersides get the contrast;
  - before, Iris removed vanilla's per-face shading and the pack had only an 8 % lift, so all faces
    looked the same.
- **Micro-detail** (`BLOCK_MICRO_DETAIL`, "Block Micro-Detail" screen): only small details of
  selected blocks catch the light, taken from the vanilla texture:
  - sparse texel-sized glints on sand, snow and ice;
  - purple-blue glints and sky-tinted speckles on obsidian;
  - lit texels on leaves, furrows on farmland, faint mica on stone;
  - metal, ore and amethyst glints.
  It replaces the plastic gloss on blocks (the player and mobs keep theirs). Glints are static
  squares that change only as you move, and fade out with distance and wherever texels become
  smaller than a pixel.
- **Unchanged:** water, entities, particles, the sky, sun, moon, clouds and fog are bit-identical to
  the previous build in every preset (see the report).

**Tuning tips**

- *More contrast between faces:* `FACE_CONTRAST` 1.25-1.50. *Less:* 0.50-0.75. *Shaded faces never
  this dark:* raise `SHADE_FLOOR` (0.50-0.60) or `AMBIENT_AMOUNT_BIAS` (+0.05).
- *More contrast at night:* `MOON_FACE_CONTRAST` 0.45-0.60.
- *Fewer sparkles on sand:* `GLINT_DENSITY_SCALE` 0.50, or `GLITTER_STRENGTH` 0.50 for weaker ones.
  *More:* `MAX_GLINT_COVERAGE` 0.16-0.20 and `BLOCK_GLINT_SIZE` 1.25.
- *No sparkles on leaves:* `FOLIAGE_STRENGTH` 0.00 keeps nothing; `MICRO_DETAIL_QUALITY` 1 keeps the
  leaf sheen but removes the waxy glints; `FOLIAGE_SPARKLE` off removes both.
- *Stronger obsidian glints:* `GLOSS_BLOCK_STRENGTH` 1.50-2.00 and `BLOCK_GLINT_SIZE` 1.25 (this also
  strengthens ice, metals and the other gloss blocks).
- *Calmer glints while moving:* `GLINT_ANGLE_STEPS` 8. *Smoother motion:* 24-32.
- *Turn all micro-detail off:* `BLOCK_MICRO_DETAIL` off (or the ULTRA LOW preset). *Turn the face
  lighting off:* `DIRECTIONAL_LIGHTING` off brings back the previous flat faces.
- *The previous small sun lift on water and entities:* `PREVIOUS_SUN_LIFT` (on in every preset except
  ULTRA LOW, as before).
- *Debug:* `BLOCK_DEBUG` with modes 1-17; view 16 is a before/after split, view 17 the face light
  factor (x 0.5). The expected look of each view is in the report, section 13.

## Patch 2.1: sky pixel fix and adaptive eyes

Full report (screenshot analysis, diagnosis with proof, design notes, test results, in-game test
plan, screenshot list): [PATCH21_REPORT.md](PATCH21_REPORT.md). Backup:
`backup/2026-10-05_before_patch21/`.

- **Sky pixel fix** (`SKY_PIXEL_FIX`, Sky and Stars screen):
  - The small dark dots and dashes in the daytime sky were the pack's own fake birds
    (`GOLDEN_FAKE_BIRDS`, on in MEDIUM, HIGH and CINEMATIC).
  - The bird shape is a thin V sampled once per 7-pixel cell, so it never drew a bird: it drew 0
    to 3 isolated grey-blue squares at fixed screen heights that slowly drift sideways.
  - The fix removes them and adds a safety net, at no cost for valid pixels: an invalid sky value
    (NaN, infinity) is replaced by the plain analytic sky.
  - Nothing else in the sky changes: the stars, sun, moon, glow and clouds are bit for bit the
    same.
  - With the fix off, the birds come back (the bird options only work with the fix off).
- **Adaptive eyes** (`ADAPTIVE_EYES`, new Adaptive Eyes screen):
  - In caves, dark interiors and at night the view slowly brightens as your eyes adapt: about
    6 s to 90 %, up to 2.2 x the light in caves and 1.5 x outdoors at night. It still looks
    like a cave or a night.
  - Stepping into daylight gives a short, soft over-bright moment that settles in about 1 s.
  - Very bright places (snow, desert, beaches at midday) get a gentle extra contrast and
    vibrance.
  - Ordinary outdoor daylight (sky light 13 or more, sun up, clear) is exactly the previous image.
  - The adaptation follows the light at the camera, not where you look, so turning the head never
    pumps. MEDIUM and up also measure the scene (a one-pixel pass), but only as a small, slow
    correction.
  - A daylight window seen from a cave keeps its detail (highlight roll-off). Dark walls get a
    little extra lift (local lift) without making the window brighter.
  - Torches stay warm, the HUD is not affected, the hand is lit like the world.
  - Blindness, Darkness and Night Vision are never brightened further. The Nether and the End
    adapt at 0.3 x strength.

**Tuning tips**

- *Darker caves:* `ADAPT_MAX_BRIGHTEN` 1.8 (or 1.4), or `ADAPT_DARK_STRENGTH` 0.50-0.75. *Brighter
  caves:* `ADAPT_MAX_BRIGHTEN` 2.6-3.0 and `ADAPT_LOCAL_LIFT_STRENGTH` 1.5.
- *Faster adaptation:* `ADAPT_TO_DARK_TIME` 3-4 (seconds) and `ADAPT_TO_BRIGHT_TIME` 800 (shown
  as 0.8 s). *Slower, more natural:* 8-10 s.
- *No over-bright flash:* `BRIGHT_FLASH` 0.00. *A stronger dazzle:* 0.75-1.00.
- *Stronger punch in daylight:* `BRIGHT_PUNCH` 1.50-2.00 (still only in very bright places). To
  give ordinary daylight some punch too, raise `BRIGHT_PUNCH_REFERENCE_SHIFT`. This CHANGES the
  approved daytime look.
- *Night stays darker:* `ADAPT_NIGHT_LIMIT` 1.2 (1.0 = no brightening at night).
- *No cool night-vision tint:* `PURKINJE_STRENGTH` 0.00.
- *Turn the eyes off:* `ADAPTIVE_EYES` off: the previous image everywhere.
- *Cheapest:* the ULTRA LOW preset (the light at the camera only, no flash, no punch).
- *Debug:* `ADAPT_DEBUG` (modes 1-10) and `SKY_DEBUG` (modes 1-12). The expected look of each
  view is in the report, section 12.

## Update 3: underwater, the Nether, the End

Full report (screenshot analysis, code review, design notes, End flash research, identity proof,
calibration, performance, test plan, screenshot list, questions): [UPDATE3_REPORT.md](UPDATE3_REPORT.md).
Backup: `backup/2026-10-05_before_update3/`. New screens: **Underwater**, **Nether**, **The End**.

- **Underwater** (only with the camera in water):
  - The water is no longer almost transparent: an absorption fog removes red first, then green;
    blue sets the visibility (about 36 blocks).
  - The water darkens with depth: royal blue, navy at about 15 to 20 blocks, almost black beyond 40.
  - Biome water colours (warm, cold, river, swamp).
  - Brighter looking up and toward the light.
  - Darker at night and in rain, clearer with Night Vision or Conduit Power.
  - The surface seen from below is a bright ceiling with the vanilla streaks, with the Snell window
    (MEDIUM and up).
  - Soft light shafts: analytic in LOW, shadow-aware in MEDIUM and up, so floating blocks cut dark
    gaps.
- **The Nether:**
  - A dense fog in the colour of the biome, the same colour for the fog, the ceiling and the far
    distance.
  - Warm block light with a barely visible flicker.
  - Brighter lava, fire and glowstone (never past white).
  - A warm haze near the lava sea.
- **The End:**
  - A dark violet sky, haze and ambient light between flashes.
  - Minecraft 26.3's own End flash becomes a light, in time with the game's flash sound:
    - a violet glow in the sky;
    - light on the surfaces turned toward it, replacing the game's flat brightening;
    - shadows opposite it (MEDIUM and up);
    - a denser glowing haze, soft shafts, glints on obsidian.
  - No exposure pumping; a photosensitivity cap on by default; much weaker flashes during the
    dragon fight.
- The Overworld, and every environment with the three ambiences off, is bit for bit the previous
  image.

**Tuning tips**

- *Clearer water:* `UNDERWATER_VISIBILITY` 48-64. *Murkier:* 24-28, or `UNDERWATER_FOG_DENSITY`
  1.25-1.50.
- *Same water colour at any depth:* `UNDERWATER_DEPTH_DARKENING` 0.00. *Darker sooner:* 1.25-1.50.
- *Open ocean colour in every biome:* `UNDERWATER_BIOME_TINT_STRENGTH` 0.00.
- *Stronger shafts:* `UW_SHAFT_STRENGTH` 1.50-2.00 and `UW_SHAFT_CONTRAST` 1.25. *Calmer:*
  `UW_SHAFT_DRIFT_SPEED` 0.10, or 0.00 for still shafts. *Bigger light cells:*
  `UW_SHAFT_PATTERN_SCALE` 16-24.
- *A dimmer surface from below:* `SURFACE_FROM_BELOW_BRIGHTNESS` 0.75. *A harder Snell edge:*
  `SNELL_WINDOW_SOFTNESS` 2-4.
- *Thinner Nether fog:* `NETHER_FOG_DENSITY` 0.50-0.75. *Vanilla red everywhere:*
  `NETHER_FOG_BIOME_TINT` 0.00.
- *Less orange light:* `NETHER_LIGHT_COLOR_WARMTH` 0.50. *No flicker:* `NETHER_LIGHT_FLICKER` 0.00.
  *Brighter lava and glowstone:* `NETHER_EMISSIVE_BOOST` 0.50.
- *Vanilla End colours:* `END_AMBIENT_TINT` 0.00 (the grey-green light). *Thicker End haze:*
  `END_FOG_DENSITY` 1.50.
- *Gentler flashes:* `FLASH_INTENSITY` 0.50-0.75, or `FLASH_FOG_BOOST` 1.5. *No flashes at all:*
  `END_FLASHES` off (the game's own sky sprite and lightmap flash remain) or `FLASH_INTENSITY` 0.
- *A bigger glow:* `FLASH_HALO_SIZE` 0.60-0.80. *Softer shadows:* `FLASH_SHADOW_STRENGTH` 0.50.
  *One flash colour:* `FLASH_COLOR_VARIATION` 0.00.
- *Photosensitivity:* keep `FLASH_PHOTOSENSITIVITY_LIMIT` on, or set `FLASH_PULSE` 0.00 for a single
  smooth rise. Shaders cannot see vanilla's "Hide Lightning Flashes" option; use `END_FLASHES` off.
- *Debug:* `UNDERWATER_DEBUG` (1-9), `NETHER_DEBUG` (1-6), `END_DEBUG` (1-12); the expected look is in
  the report, section 11.
