#version 330 compatibility

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
// Needed by lib/ambience.glsl (the palette is evaluated here, once per frame in practice).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#ifdef AMB_SUN_VISIBILITY
uniform sampler2D depthtex0;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// Cloud marker written by gbuffers_clouds: A = 1, R = 0, G = the face's opacity.
#define FINAL_VSH_CLOUD_MARKER
uniform sampler2D colortex1;
#endif
#endif

#include "/lib/ambience.glsl"

out vec2 vTexCoord;
out float vSunElevation;
out float vMoonElevation;
out vec2 vSunUV;
out float vSunInFront;
out vec2 vMoonUV;
out float vMoonInFront;

// Ambience palette for this frame (sky, fog, clouds, light) and the world sun direction.
flat out vec3 vSunWorld;
flat out vec3 vPalZenith;
flat out vec3 vPalMid;
flat out vec3 vPalHorizon;
flat out vec3 vPalFogNear;
flat out vec3 vPalCloudTop;
flat out vec3 vPalCloudUnder;
flat out vec3 vPalSkyLight;
flat out vec3 vPalGlow;
flat out float vPalGolden;
// Sun visibility V (0..1) and the on-screen fade of the veil, identical for every vertex.
flat out float vSunVisibility;
flat out float vSunScreenFade;
#ifdef AMB_WATER_OWN_PALETTE
// The palette without the biome look, for the screen-space water reflection (it must match
// the water's own Tier-1 reflection when BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off).
flat out vec3 vWaterZenith;
flat out vec3 vWaterMid;
flat out vec3 vWaterHorizon;
flat out vec3 vWaterCloudTop;
flat out vec3 vWaterCloudUnder;
flat out vec3 vWaterGlow;
flat out float vWaterGolden;
#endif

#ifdef AMB_SUN_VISIBILITY
// One visibility tap: open sky = 1, a cloud = its transparency, anything else = 0. Taps
// outside the screen count as open; the veil fades out off screen anyway.
float sunTap(vec2 uv) {
    if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) return 1.0;
#ifdef FINAL_VSH_CLOUD_MARKER
    vec4 info = textureLod(colortex1, uv, 0.0);
    if (info.a > 0.5 && info.r < 0.5) return 1.0 - info.g;
#endif
    return textureLod(depthtex0, uv, 0.0).r > 0.99999 ? 1.0 : 0.0;
}

// A ring of taps at a fixed radius (in sun half-sizes) and angular phase: a deterministic
// pattern, no random offsets, so V is the same every frame for the same view.
void sunRing(vec2 centre, vec2 halfSize, int count, float radius, float phase, inout float sum, inout float weight) {
    for (int i = 0; i < count; ++i) {
        float a = phase + 6.2831853 * float(i) / float(count);
        sum += sunTap(centre + vec2(cos(a), sin(a)) * halfSize * radius);
        weight += 1.0;
    }
}
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec3 sunWorld = mat3(gbufferModelViewInverse) * sunPosition;
    float sunLength2 = dot(sunWorld, sunWorld);
    sunWorld = sunLength2 > 0.000001 ? sunWorld * inversesqrt(sunLength2) : vec3(0.0, 1.0, 0.0);
    vSunElevation = sunWorld.y;

    vec3 moonWorld = mat3(gbufferModelViewInverse) * moonPosition;
    float moonLength2 = dot(moonWorld, moonWorld);
    moonWorld = moonLength2 > 0.000001 ? moonWorld * inversesqrt(moonLength2) : vec3(0.0, -1.0, 0.0);
    vMoonElevation = moonWorld.y;

    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    vMoonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = vMoonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);

    vSunWorld = sunWorld;
    AmbPalette pal = ambiencePalette(sunWorld);
    vPalZenith = pal.zenith;
    vPalMid = pal.mid;
    vPalHorizon = pal.horizon;
    vPalFogNear = pal.fogNear;
    vPalCloudTop = pal.cloudTop;
    vPalCloudUnder = pal.cloudUnder;
    vPalSkyLight = pal.skyLight;
    vPalGlow = pal.glow;
    vPalGolden = pal.golden;
#ifdef AMB_WATER_OWN_PALETTE
    AmbPalette waterPal = ambiencePaletteBiome(sunWorld, 0.0);
    vWaterZenith = waterPal.zenith;
    vWaterMid = waterPal.mid;
    vWaterHorizon = waterPal.horizon;
    vWaterCloudTop = waterPal.cloudTop;
    vWaterCloudUnder = waterPal.cloudUnder;
    vWaterGlow = waterPal.glow;
    vWaterGolden = waterPal.golden;
#endif

    // Sun visibility: fixed taps inside the sun square, read once per vertex (a few dozen
    // fetches per frame in total). The fade takes the veil away smoothly once the sun is
    // outside the screen (NDC 1.0 to 1.35) or behind the camera.
    vSunVisibility = 1.0;
    vSunScreenFade = 0.0;
#ifdef AMB_SUN_VISIBILITY
    if (vSunInFront > 0.5) {
        vec2 ndc = sunClip.xy / sunClip.w;
        vSunScreenFade = 1.0 - smoothstep(1.0, 1.35, max(abs(ndc.x), abs(ndc.y)));
        vec2 halfSize = vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * (0.5 * AMB_SUN_HALF);
        float sum = sunTap(vSunUV);
        float weight = 1.0;
#if SUN_VISIBILITY_TAPS == 9
        sunRing(vSunUV, halfSize, 8, 0.70, 0.0, sum, weight);
#elif SUN_VISIBILITY_TAPS == 13
        sunRing(vSunUV, halfSize, 6, 0.50, 0.0, sum, weight);
        sunRing(vSunUV, halfSize, 6, 1.00, 0.5236, sum, weight);
#elif SUN_VISIBILITY_TAPS == 21
        sunRing(vSunUV, halfSize, 8, 0.45, 0.0, sum, weight);
        sunRing(vSunUV, halfSize, 12, 0.95, 0.2618, sum, weight);
#else
        sunRing(vSunUV, halfSize, 8, 0.35, 0.0, sum, weight);
        sunRing(vSunUV, halfSize, 8, 0.70, 0.3927, sum, weight);
        sunRing(vSunUV, halfSize, 12, 1.00, 0.2618, sum, weight);
#endif
        vSunVisibility = sum / weight;
    }
#endif
}
