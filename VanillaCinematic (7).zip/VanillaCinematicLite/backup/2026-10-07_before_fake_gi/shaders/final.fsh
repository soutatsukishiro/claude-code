#version 330 compatibility

#include "/lib/settings.glsl"

// The shared sky functions (Ambience palette sky and fog, water reflection, horizon blend) are
// used by the sky treatment, the fog and the screen-space water reflection: always available.
#define FINAL_WATER_SKY

// colortex1 carries the water marker (R), its sky light (G), packed reflection data (B) and,
// on cloud pixels written by gbuffers_clouds, the cloud marker (A = 1 with R = 0, G = the
// face's opacity). gbuffers_clouds runs whenever the Ambience colours or clouds are on.
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
#define AMB_CLOUD_MARKER
#endif
#if defined(AMB_CLOUD_MARKER) || defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG) || (defined(AMBIENCE_FOG) && !defined(FOG_ON_WATER))
#define AMB_FINAL_INFO
#endif

uniform sampler2D colortex0;
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG) || defined(RAYS_SHAFTS) || defined(UNDERWATER_SHAFTS) || defined(EMISSIVE_GLOW) || defined(LIGHT_DEBUG)
uniform sampler2D colortex5;
#endif
#if defined(VV_DEBUG) || defined(WATER_SSR) || defined(AMB_FINAL_INFO) || ((defined(CAUSTICS_DEBUG) || defined(REFLECTION_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10)) && !defined(ATMOS_DEBUG))
uniform sampler2D colortex1;
#endif
uniform mat4 gbufferProjection;
#ifdef WATER_SSR
uniform mat4 gbufferModelView;
#endif
uniform vec3 sunPosition;
uniform float far;
// Needed by lib/ambience.glsl.
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform ivec2 eyeBrightnessSmooth;
#if defined(VV_DEBUG) && (VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7)
uniform sampler2D colortex2;
#endif
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform float temperature;
uniform float rainfall;
uniform float fogDensity;
uniform float atmosHumidBiome;
uniform float atmosCoolBiome;
uniform float atmosWoodlandBiome;
uniform float atmosSavannaBiome;
uniform float atmosPlainsBiome;
uniform float atmosDesertBiome;
uniform float atmosNether;
uniform float atmosEnd;
uniform vec3 cameraPosition;
uniform int moonPhase;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float thunderStrength;
uniform float aspectRatio;
uniform float atmosOverworld;
uniform bool hasSkylight;
uniform bool hasCeiling;

in vec2 vTexCoord;
in float vSunElevation;
in float vMoonElevation;
in vec2 vSunUV;
in float vSunInFront;
in vec2 vMoonUV;
in float vMoonInFront;

// Ambience palette of this frame (final.vsh).
flat in vec3 vSunWorld;
flat in vec3 vPalZenith;
flat in vec3 vPalMid;
flat in vec3 vPalHorizon;
flat in vec3 vPalFogNear;
flat in vec3 vPalCloudTop;
flat in vec3 vPalCloudUnder;
flat in vec3 vPalSkyLight;
flat in vec3 vPalGlow;
flat in float vPalGolden;
// Sun visibility from the fixed taps in final.vsh, the share of the sun behind clouds, and the
// on-screen fade of the veil, rim and shafts.
flat in float vSunVisibility;
flat in float vSunCloudCover;
flat in float vSunScreenFade;
#ifdef MOON_RAYS
// The moon for this frame (final.vsh): direction and light; tint and night weight; lit side;
// visibility, cloud cover, on-screen fade and shaft gate.
flat in vec4 vMoonWorldLight;
flat in vec4 vMoonTintNight;
flat in vec2 vMoonSide;
flat in vec4 vMoonRays;
#ifdef MOON_SHAFTS
flat in float vSunShaftGate;
#endif
#endif
#if defined(LIGHT_DEBUG) && defined(CAUSTICS_UNDERWATER_FLOOR)
// Estimated water surface above an underwater camera (custom uniform, shaders.properties).
uniform float vclWaterSurfaceY;
#endif
#ifdef AMB_WATER_OWN_PALETTE
flat in vec3 vWaterZenith;
flat in vec3 vWaterMid;
flat in vec3 vWaterHorizon;
flat in vec3 vWaterCloudTop;
flat in vec3 vWaterCloudUnder;
flat in vec3 vWaterGlow;
flat in float vWaterGolden;
#endif
// lib/ambience.glsl comes early: the previous haze functions below use its Nether/End tints.
#include "/lib/ambience.glsl"
// Rim gather, depth normal, shaft upsample and the CelestialLight veil/rim/shaft composition
// (deterministic, no noise, no shadow map).
#define RAYS_FINAL
#include "/lib/sun_rays.glsl"
#if defined(SKY_PIXEL_FIX) || defined(SKY_DEBUG)
// Patch 2.1, part B: the sky's validity test (safety net and the invalid-value view).
#include "/lib/sky_guard.glsl"
#endif
#ifdef ADAPTIVE_EYES
// Patch 2.1, part A: the exposure stage; its numbers for this frame come from final.vsh.
#define ADAPT_STAGE
#include "/lib/adaptive_eyes.glsl"
flat in vec4 vAdaptA;
flat in vec4 vAdaptB;
#ifdef ADAPT_DEBUG
flat in vec4 vAdaptDebug;
flat in float vAdaptDebugGain;
uniform sampler2D colortex6;
#endif
#endif
// Update 3: underwater, Nether and End ambience (lib/dimension_ambience.glsl): the background fog,
// the Nether and End skies and fogs, the underwater and flash shafts (and the tier-1 function for the
// underwater debug view).
#define UW_TIER1_FUNCTIONS
// The End sky texture is read here only (customTexture.vclEndSky, shaders.properties).
#define END_SKY_TEXTURE
#include "/lib/dimension_ambience.glsl"
#ifdef END_FLASHES
// The End flash for this frame (final.vsh): world direction + envelope; screen position, in front,
// on-screen fade. endFlashIntensity (Iris, raw): the game draws its flash sprite while it is above 1e-5.
flat in vec4 vFlashA;
flat in vec4 vFlashB;
uniform float endFlashIntensity;
#endif
#ifdef END_DEBUG
uniform vec3 shadowLightPosition;
uniform vec3 moonPosition;
uniform int worldTime;
#if END_DEBUG_MODE == 8
uniform sampler2D shadowtex0;
#endif
#endif

vec3 safeNormalize(vec3 value) {
    return value * inversesqrt(max(dot(value, value), 0.000001));
}

#ifdef GOLDEN_FAKE_BIRDS
float targetBirdMask(vec2 screenUV, vec2 centerUV) {
    float cell = max(float(FAKE_BIRD_SIZE), 1.0);
    vec2 screen = vec2(viewWidth, viewHeight);
    vec2 p = (screenUV - centerUV) * screen / cell;
    float wingLine = abs(p.y - (0.30 - 0.46 * abs(p.x)));
    return step(abs(p.x), 1.05) * (1.0 - step(0.12, wingLine));
}
#endif

float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

vec3 worldViewRay(vec2 uv) {
    vec4 rayH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 0.5, 1.0);
    vec3 viewRay = safeNormalize(rayH.xyz);
    return safeNormalize(mat3(gbufferModelViewInverse) * viewRay);
}

vec3 evaluateAtmosphereColor(float viewUp, float twilight, float night) {
    vec3 haze = mix(fogColor, skyColor, smoothstep(-0.15, 0.70, viewUp) * 0.22);
    float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.15, rainfall) * 0.25), 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome * (0.65 + 0.35 * (1.0 - smoothstep(0.10, 0.75, temperature))), 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    float desertWeight = clamp(atmosDesertBiome * 0.75, 0.0, 1.0);
    float plainsWeight = clamp(atmosPlainsBiome * 0.30, 0.0, 1.0);

    haze = mix(haze, vec3(0.91, 0.64, 0.42), autumnWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.45, 0.80, 0.73), humidWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.58, 0.72, 0.87), coldWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.83, 0.65, 0.44), desertWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.65, 0.77, 0.80), plainsWeight * BIOME_TINT_STRENGTH);
    haze = mix(haze, vec3(0.95, 0.70, 0.50), twilight * 0.10);
    haze = mix(haze, vec3(0.40, 0.52, 0.70), night * 0.32);
    // Nether and End: a small tint on top of the vanilla fog colour (per Nether biome with
    // BIOME_AMBIENCE; the previous fixed tints without it).
    haze = mix(haze, ambNetherFogTint(), clamp(atmosNether, 0.0, 1.0) * 0.30);
    haze = mix(haze, ambEndFogTint(), clamp(atmosEnd, 0.0, 1.0) * 0.28);
    return haze;
}

vec3 evaluateSkyGradient(vec3 worldDirection) {
    float day = smoothstep(-0.10, 0.20, vSunElevation);
    float twilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);

    vec3 dayZenith = vec3(0.16, 0.40, 0.68);
    vec3 dayHorizon = vec3(0.58, 0.77, 0.89);
    vec3 twilightHorizon = vec3(0.96, 0.63, 0.46);
    vec3 nightZenith = vec3(0.035, 0.060, 0.145);
    vec3 nightHorizon = vec3(0.12, 0.17, 0.29);
    vec3 zenith = mix(nightZenith, dayZenith, day);
    vec3 horizon = mix(nightHorizon, dayHorizon, day);
    horizon = mix(horizon, twilightHorizon, twilight * 0.86);

    float horizonBlend = 1.0 - smoothstep(0.02, 0.90, max(worldDirection.y, 0.0));
    vec3 gradient = mix(zenith, horizon, horizonBlend);
    vec3 fogMatchedHorizon = evaluateAtmosphereColor(0.0, twilight, night);
    gradient = mix(gradient, fogMatchedHorizon, horizonBlend * 0.22);

    float humidWeight = clamp(atmosHumidBiome, 0.0, 1.0);
    float coldWeight = clamp(atmosCoolBiome, 0.0, 1.0);
    float autumnWeight = clamp(max(atmosWoodlandBiome * smoothstep(0.30, 0.85, temperature), atmosSavannaBiome * 0.75), 0.0, 1.0);
    gradient = mix(gradient, vec3(0.48, 0.74, 0.76), humidWeight * BIOME_TINT_STRENGTH * 0.38);
    gradient = mix(gradient, vec3(0.63, 0.75, 0.88), coldWeight * BIOME_TINT_STRENGTH * 0.32);
    gradient = mix(gradient, vec3(0.90, 0.65, 0.44), autumnWeight * BIOME_TINT_STRENGTH * 0.36);

    float luma = dot(gradient, vec3(0.2126, 0.7152, 0.0722));
    vec3 rainySky = mix(vec3(luma), vec3(0.43, 0.53, 0.64), 0.50);
    gradient = mix(gradient, rainySky, clamp(rainStrength, 0.0, 1.0) * 0.72);
    gradient = mix(gradient, vec3(0.22, 0.28, 0.37), clamp(thunderStrength, 0.0, 1.0) * 0.48);
    gradient = mix(gradient, ambNetherFogTint(), clamp(atmosNether, 0.0, 1.0) * 0.22);
    gradient = mix(gradient, ambEndFogTint(), clamp(atmosEnd, 0.0, 1.0) * 0.24);
    return max(gradient, vec3(0.0));
}

#include "/lib/water_reflection.glsl"

AmbPalette finalPalette() {
    AmbPalette p;
    p.zenith = vPalZenith;
    p.mid = vPalMid;
    p.horizon = vPalHorizon;
    p.fogNear = vPalFogNear;
    p.cloudTop = vPalCloudTop;
    p.cloudEdge = vPalCloudTop;
    p.cloudUnder = vPalCloudUnder;
    p.sunLight = vec3(1.0);
    p.skyLight = vPalSkyLight;
    p.glow = vPalGlow;
    p.golden = vPalGolden;
    return p;
}

// The palette the water reflection reads: the frame palette, or the biome-free one when
// BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off (it must match the water's own Tier 1).
AmbPalette finalWaterPalette() {
    AmbPalette p = finalPalette();
#ifdef AMB_WATER_OWN_PALETTE
    p.zenith = vWaterZenith;
    p.mid = vWaterMid;
    p.horizon = vWaterHorizon;
    p.fogNear = vWaterHorizon;
    p.cloudTop = vWaterCloudTop;
    p.cloudEdge = vWaterCloudTop;
    p.cloudUnder = vWaterCloudUnder;
    p.glow = vWaterGlow;
    p.golden = vWaterGolden;
#endif
    return p;
}

// Camera sky exposure (0 deep in a cave, 1 under open sky): caves get a thinner haze.
float ambienceCaveLight() {
    return smoothstep(0.05, 0.60, float(eyeBrightnessSmooth.y) / 240.0);
}

// The sun as a celestial light for the veil, rim and shafts: its approved constants, exactly
// the values the previous sun code used (eyeSky = the camera's sky exposure term).
CelestialLight finalSunLight(float eyeSky) {
    CelestialLight L;
    L.direction = vSunWorld;
    L.screenUV = vSunUV;
    L.inFront = vSunInFront;
    L.screenFade = vSunScreenFade;
    L.halfSize = AMB_SUN_HALF;
    L.haloSize = SUN_HALO_SIZE;
    L.light = ambSunGlowVisibility(vSunWorld) * eyeSky;
    L.visibility = vSunVisibility;
    L.cloudCover = vSunCloudCover;
    vec3 glowColor = ambSunGlowColor(vSunWorld);
    L.veilStrength = VEIL_STRENGTH;
    L.veilColor = glowColor;
    L.rimStrength = RIM_STRENGTH;
    L.rimColor = ambRimColor(vSunWorld);
    L.rimReach = RIM_REACH;
    L.shaftStrength = SHAFT_STRENGTH;
#ifdef MOON_SHAFTS
    // 0 while the moon owns the shaft buffer (never while the sun can show shafts).
    L.shaftStrength *= vSunShaftGate;
#endif
    L.shaftColor = glowColor;
    L.shaftSpread = 1.0;
    return L;
}

#ifdef MOON_RAYS
AmbMoon finalMoon() {
    AmbMoon m;
    m.dir = vMoonWorldLight.xyz;
    m.light = vMoonWorldLight.w;
    m.tint = vMoonTintNight.rgb;
    m.side = vMoonSide;
    return m;
}

// The moon as a celestial light: smaller (AMB_MOON_HALF), much fainter, cool colours tinted by
// the biome; its rim reaches 0.75 x as far (thinner), its shaft cone is narrower (spread 0.75).
CelestialLight finalMoonLight(float eyeSky) {
    CelestialLight L;
    vec3 tint = vMoonTintNight.rgb;
    L.direction = vMoonWorldLight.xyz;
    L.screenUV = vMoonUV;
    L.inFront = vMoonInFront;
    L.screenFade = vMoonRays.z;
    L.halfSize = AMB_MOON_HALF;
    L.haloSize = MOON_HALO_SIZE;
    L.light = vMoonWorldLight.w * eyeSky;
    L.visibility = vMoonRays.x;
    L.cloudCover = vMoonRays.y;
    L.veilStrength = MOON_VEIL_STRENGTH;
    L.veilColor = min(AMB_MOON_VEIL * tint, vec3(1.0));
    L.rimStrength = MOON_RIM_STRENGTH;
    L.rimColor = min(AMB_MOON_RIM * tint, vec3(1.0));
    L.rimReach = 0.75 * RIM_REACH;
    L.shaftStrength = MOON_SHAFT_STRENGTH * vMoonRays.w;
    L.shaftColor = min(AMB_MOON_SHAFT * tint, vec3(1.0));
    L.shaftSpread = 0.75;
    return L;
}
#endif

// Night boost of the static output dither (MOON_RAYS): dark regions at night get up to
// (1 + NIGHT_SKY_DITHER) x SKY_DITHER, where 8-bit steps band most easily. It is added as a
// separate term that only runs at night, so the daytime dither stays the previous expression
// exactly (bit for bit).
float finalNightDitherBoost(vec3 color) {
#ifdef MOON_RAYS
    return NIGHT_SKY_DITHER * vMoonTintNight.a * (1.0 - smoothstep(0.0, 0.20, ambLuma(color)));
#else
    return 0.0;
#endif
}

#ifdef FLASH_FOG_SHADOWS
// Update 4.1: depth-aware upsample of the flash fog's lit share. As raysShaftUpsample (the four nearest
// quarter-resolution texels, bilinear weights times depth similarity), but at a silhouette where none of
// those four lies at this pixel's depth (within 15 %), for example a thin strip of distant ground beside a
// pillar that hides the flash, it takes the texel of the 3 x 3 quarter-resolution neighbourhood whose depth
// is closest: the bilinear average there was the pillar's 0, a dark rim of 2 to 4 px.
float endFlashFogUpsample(vec2 uv, float pixelDistance, vec2 fullSize) {
    vec2 quarterSize = vec2(textureSize(colortex5, 0));
    vec2 position = uv * quarterSize - 0.5;
    ivec2 base = ivec2(floor(position));
    vec2 f = position - floor(position);
    ivec2 maxQuarter = ivec2(quarterSize) - 1;
    ivec2 maxTexel = ivec2(fullSize) - 1;
    float invDistance = 1.0 / max(pixelDistance, 0.5);
    float sum = 0.0;
    float weightSum = 0.0;
    float closest = 1.0e6;
    for (int j = 0; j < 2; ++j) {
        for (int i = 0; i < 2; ++i) {
            ivec2 q = clamp(base + ivec2(i, j), ivec2(0), maxQuarter);
            float bilinear = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
            ivec2 centre = clamp(ivec2((vec2(q) + 0.5) * fullSize / quarterSize), ivec2(0), maxTexel);
            float relative = abs(raysLinearDepth(texelFetch(depthtex0, centre, 0).r) - pixelDistance) * invDistance;
            closest = min(closest, relative);
            float weight = bilinear * (exp(-12.0 * relative) + 1.0e-4);
            sum += weight * texelFetch(colortex5, q, 0).a;
            weightSum += weight;
        }
    }
    float value = sum / max(weightSum, 1.0e-6);
    if (closest > 0.15) {
        ivec2 own = clamp(ivec2(uv * quarterSize), ivec2(0), maxQuarter);
        float best = closest;
        for (int j = -1; j <= 1; ++j) {
            for (int i = -1; i <= 1; ++i) {
                ivec2 q = clamp(own + ivec2(i, j), ivec2(0), maxQuarter);
                ivec2 centre = clamp(ivec2((vec2(q) + 0.5) * fullSize / quarterSize), ivec2(0), maxTexel);
                float relative = abs(raysLinearDepth(texelFetch(depthtex0, centre, 0).r) - pixelDistance) * invDistance;
                if (relative < best) {
                    best = relative;
                    value = texelFetch(colortex5, q, 0).a;
                }
            }
        }
    }
    return value;
}
#endif

#ifdef END_FLASHES
// Update 4.1: the lit share of this pixel's view ray in the flash fog (composite1's screen-space volumetric
// shadow in colortex5.a), read only where composite1 wrote it this frame: the same test as composite1.vsh and
// composite1.fsh (flash on and in front, its screen point within -0.6..1.6, this pixel within 1.2 screen heights
// of it); 1 everywhere else. composite1 fades its value to 1 toward both limits (the glow there can still be
// 15 to 25 / 255 with the flash 65 to 70 degrees off to the side), so the switch never shows. Depth-aware
// upsample (endFlashFogUpsample), so a pillar right in front of the flash never takes the sky's lit share
// from a neighbouring quarter-resolution texel, nor the ground beside it the pillar's shadow.
float endFlashFogVisibility(vec2 uv, float sceneDepth) {
#ifdef FLASH_FOG_SHADOWS
    vec2 toFlash = (vFlashB.xy - uv) * vec2(viewWidth / viewHeight, 1.0);
    bool owned = vclFlash > 0.001 && vFlashB.z > 0.5 &&
                 all(greaterThan(vFlashB.xy, vec2(-0.6))) && all(lessThan(vFlashB.xy, vec2(1.6))) &&
                 dot(toFlash, toFlash) < 1.44;
    if (!owned) return 1.0;
    return clamp(endFlashFogUpsample(uv, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight)), 0.0, 1.0);
#else
    return 1.0;
#endif
}
#endif

// Update 3: the same boost for the dark gradients of deep water, the Nether haze and the End sky
// (never in the Overworld above water, so that image stays bit for bit the previous one).
float finalDimensionDitherBoost(vec3 color) {
    float here = 0.0;
#ifdef UNDERWATER_AMBIENCE
    if (isEyeInWater == 1) here = 1.0;
#endif
#ifdef NETHER_AMBIENCE
    if (atmosNether > 0.5) here = 1.0;
#endif
#ifdef END_AMBIENCE
    if (atmosEnd > 0.5) here = 1.0;
#endif
    return NIGHT_SKY_DITHER * here * (1.0 - smoothstep(0.0, 0.25, ambLuma(color)));
}

#ifdef END_FLASH_SHAFTS
// The End flash as a celestial light for the shafts only (lib/sun_rays.glsl, the sun's functions):
// no veil and no rim (the flash has no visible source); a wider cone than the sun's.
CelestialLight finalFlashLight() {
    CelestialLight L;
    L.direction = vFlashA.xyz;
    L.screenUV = vFlashB.xy;
    L.inFront = vFlashB.z;
    L.screenFade = vFlashB.w;
    L.halfSize = 0.06;
    L.haloSize = FLASH_HALO_SIZE;
    L.light = vFlashA.w * (1.0 - endDragonFight());
    L.visibility = 1.0;
    L.cloudCover = 0.0;
    L.veilStrength = 0.0;
    L.veilColor = vec3(0.0);
    L.rimStrength = 0.0;
    L.rimColor = vec3(0.0);
    L.rimReach = RIM_REACH;
    L.shaftStrength = FLASH_SHAFT_STRENGTH;
    L.shaftColor = endFlashColor();
    L.shaftSpread = 1.25;
    return L;
}
#endif

#if defined(UNDERWATER_SHAFTS) && !defined(UNDERWATER_SHAFTS_TIER2)
// Tier 1 underwater shafts are computed at quarter resolution in composite (lib/dimension_ambience.glsl,
// uwShaftTier1, over UW_SHAFT_LENGTH blocks whatever the scene) into colortex5's alpha, the sun shafts'
// channel (free with the camera underwater). That field depends on the view direction only, so one
// bilinear fetch upsamples it without halos; the water in front of this pixel scales it (the full ray
// in open water, less in front of near objects).
float uwTier1Shafts(float pixelDistance) {
    return texture(colortex5, vTexCoord).a * (1.0 - exp(-3.0 * pixelDistance / float(UW_SHAFT_LENGTH)));
}
#endif
#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
// The sun's veil, rim and shafts exactly as final wrote them before Update 2A (inline constants
// and falloffs), for the identity check view: the CelestialLight path must give the same colour.
vec3 finalSunRaysPrevious(vec3 color, vec3 viewDirection, vec3 playerPosition, float sceneDepth, bool cloudPixel) {
    float theta = ambAngle(viewDirection, vSunWorld);
    float sunLight = ambSunGlowVisibility(vSunWorld) * smoothstep(0.10, 0.45, float(eyeBrightnessSmooth.y) / 240.0);
#ifdef SUN_VEIL
    float visibility = vSunVisibility * vSunScreenFade;
    float depthFactor = 1.0 - exp(-length(playerPosition) / 6.0);
    float veilFalloff = 0.65 * exp(-max(theta - AMB_SUN_HALF, 0.0) / (1.2 * AMB_SUN_HALF)) + 0.35 * exp(-theta / SUN_HALO_SIZE);
    float veil = VEIL_STRENGTH * visibility * veilFalloff * depthFactor * sunLight;
    color = mix(color, ambSunGlowColor(vSunWorld), clamp(veil, 0.0, 0.6));
#endif
#ifdef SUN_EDGE_RIM
    float rimVisibility = (vSunVisibility + 0.55 * max(1.0 - vSunVisibility - vSunCloudCover, 0.0)) * vSunScreenFade;
    float rimFalloff = exp(-max(theta - AMB_SUN_HALF, 0.0) / (0.6 * AMB_SUN_HALF)) * sunLight * rimVisibility * smoothstep(0.6, 2.0, length(playerPosition));
    if (rimFalloff > 0.004 && vSunInFront > 0.5 && !cloudPixel) {
        vec2 screen = vec2(viewWidth, viewHeight);
        float gather = raysRimGather(vTexCoord, vSunUV, screen, AMB_SUN_HALF * gbufferProjection[1][1] * 0.5 * viewHeight, RIM_REACH);
        if (gather > 0.002) {
            vec3 normal = raysNormal(ivec2(gl_FragCoord.xy), sceneDepth, playerPosition, screen);
            float facing = mix(0.65, 1.0, smoothstep(-0.10, 0.30, dot(normal, vSunWorld)));
            float rim = RIM_STRENGTH * gather * rimFalloff * facing;
            color = mix(color, ambRimColor(vSunWorld), clamp(rim, 0.0, 0.75));
        }
    }
#endif
#ifdef SUN_SHAFTS
    float shaftLight = SHAFT_STRENGTH * (exp(-max(theta - 0.075, 0.0) / 0.22) * (1.0 - smoothstep(0.45, 0.80, theta))) * sunLight * vSunScreenFade * vSunInFront;
    if (shaftLight > 0.0005 && texture(colortex5, vTexCoord).a > 0.002) {
        float shafts = raysShaftUpsample(vTexCoord, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight));
        color += ambSunGlowColor(vSunWorld) * (shaftLight * shafts) * max(vec3(1.0) - color, vec3(0.0));
    }
#endif
    return color;
}
#endif

// Angular size of one pixel (anti-aliasing width of the analytic sun's edges).
float finalPixelAngle() {
    return 2.0 / max(gbufferProjection[1][1] * viewHeight, 1.0);
}

// Existing cinematic tone shoulder and highlight warmth (unchanged).
vec3 finalToneMap(vec3 color, float overworld) {
    float day = smoothstep(-0.12, 0.15, vSunElevation);
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float shadowTone = 1.0 - smoothstep(0.08, 0.72, luminance);
    float highlightTone = smoothstep(0.22, 0.90, luminance);
    color *= mix(vec3(1.0), vec3(0.94, 0.98, 1.035), shadowTone * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    color *= mix(vec3(1.0), vec3(1.025, 1.008, 0.975), highlightTone * day * 0.12 * TONE_SHOULDER_STRENGTH * overworld);
    vec3 softClip = color / (1.0 + max(color, vec3(0.0)) * 0.12);
    return mix(color, softClip, 0.58 * TONE_SHOULDER_STRENGTH * overworld);
}

#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG)
// Values stashed for the debug views.
float gDebugFogAmount = 0.0;
vec3 gDebugFogColor = vec3(0.0);
float gDebugBank = 1.0;
float gDebugScatter = 0.0;
float gDebugDesaturation = 0.0;
float gDebugCloudMask = 0.0;
float gDebugCloudShadow = 1.0;
vec2 gDebugCloudUV = vec2(0.0);
vec3 gDebugReflectionColor = vec3(0.0);
float gDebugReflectionValid = 0.0;
float gDebugReflectionFog = 0.0;
float gDebugVeil = 0.0;
float gDebugRim = 0.0;
#endif
#ifdef LIGHT_DEBUG
float gLightDebugRim = 0.0;
float gLightDebugShaft = 0.0;
#endif
#ifdef MOON_DEBUG
float gMoonDebugVeil = 0.0;
float gMoonDebugRim = 0.0;
float gMoonDebugShaft = 0.0;
vec3 gMoonDebugRaysBefore = vec3(0.0);
vec3 gMoonDebugRaysAfter = vec3(0.0);
vec3 gMoonDebugSunBefore = vec3(0.0);
vec3 gMoonDebugSunAfter = vec3(0.0);
float gMoonDebugTerrain = 0.0;
#endif

#ifdef WATER_SSR
bool waterProjectToScreen(vec3 playerPosition, out vec2 uv) {
    vec4 clip = gbufferProjection * (gbufferModelView * vec4(playerPosition, 1.0));
    uv = clip.xy / max(clip.w, 0.0001) * 0.5 + 0.5;
    return clip.w > 0.0001;
}

vec3 waterPlayerFromDepth(vec2 uv, float depth) {
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
}

// Tier 2: screen-space planar reflection. The water top is a horizontal plane at this
// pixel's surface height, so no ray march is needed: the reflected ray is projected at the
// render distance, then refined with the depth seen there (WATER_SSR_REFINE steps).
// colortex0 holds the scene the gbuffers produced; final only reads it, so there is no
// read/write hazard. The objects reflected stand above the water line, so their pixels are
// not covered by water. Returns the change to add: weight * (environment - Tier 1).
vec3 waterScreenReflection(vec2 uv, out vec4 debugInfo) {
    debugInfo = vec4(0.0);
    vec4 info = texture(colortex1, uv);
    if (info.r < 0.5 || isEyeInWater != 0) return vec3(0.0);
    float packedValue = floor(info.b * 255.0 + 0.5);
    float weight = floor(packedValue / 8.0) / 31.0;
    float wobble = mod(packedValue, 8.0) / 7.0 * 2.0 - 1.0;

    vec3 surface = waterPlayerFromDepth(uv, texture(depthtex0, uv).r);
    vec3 viewDir = safeNormalize(surface);
    vec3 reflectDir = vec3(viewDir.x, abs(viewDir.y), viewDir.z);
    float weather = clamp(rainStrength, 0.0, 1.0);
    // Exactly the Tier-1 colour the water program blended in (same function, flat normal).
#ifdef WATER_REFLECTION_IMPROVEMENT
    vec3 skyTier1 = waterSkyReflectionImproved(reflectDir, vSunWorld, ambWrappedWorld(surface), finalWaterPalette(),
                                               CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#else
    vec3 skyTier1 = waterSkyReflection(reflectDir, vSunElevation, CLOUD_REFLECTION * (1.0 - 0.7 * weather)) *
                    mix(0.12, 1.0, smoothstep(0.30, 0.90, info.g));
#endif

    vec2 reflectUV;
    bool onScreen = waterProjectToScreen(surface + reflectDir * far, reflectUV);
    for (int i = 0; i < WATER_SSR_REFINE; ++i) {
        float refineDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
        if (refineDepth > 0.99999 || !onScreen) break;
        vec3 seen = waterPlayerFromDepth(reflectUV, refineDepth);
        onScreen = waterProjectToScreen(surface + reflectDir * distance(seen, surface), reflectUV);
    }

    // Wobble with the vanilla wave texels, rougher in rain, snapped to a 2-pixel grid.
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    float roughness = 1.0 + weather * 1.5;
    reflectUV.y += wobble * REFLECTION_WOBBLE * roughness * 3.0 * pixel.y;
    reflectUV = (floor(reflectUV / (2.0 * pixel)) + 0.5) * 2.0 * pixel;

    float hitDepth = texture(depthtex0, clamp(reflectUV, vec2(0.0), vec2(1.0))).r;
    vec3 hit = waterPlayerFromDepth(reflectUV, hitDepth);
    float edgeFade = smoothstep(0.0, 0.05, reflectUV.x) * smoothstep(0.0, 0.05, 1.0 - reflectUV.x) *
                     smoothstep(0.0, 0.05, reflectUV.y) * smoothstep(0.0, 0.05, 1.0 - reflectUV.y);
    // Valid: on screen, an object above the water plane (not water, floor or sky), and not the
    // hand or other camera-near geometry. Sky samples keep Tier 1, which already matches the sky.
    bool aboveWater = hitDepth < 0.99999 && hit.y > surface.y + 0.05 && dot(hit, hit) > 1.0;
    float valid = (onScreen && aboveWater) ? edgeFade : 0.0;

    // Soft, vertically stretched, low contrast: vertical taps around the reflected point.
    vec3 environment = vec3(0.0);
    for (int k = 0; k < REFLECTION_BLUR; ++k) {
        float offset = (float(k) - float(REFLECTION_BLUR - 1) * 0.5) * float(REFLECTION_STRETCH) * roughness;
        environment += texture(colortex0, clamp(reflectUV + vec2(0.0, offset * pixel.y), vec2(0.0), vec2(1.0))).rgb;
    }
    environment /= float(REFLECTION_BLUR);
#ifdef WATER_REFLECTION_IMPROVEMENT
    float reflectionFog = 0.0;
#ifdef AMBIENCE_FOG
    // Fog-aware: the reflected light first crosses the haze between the reflected object and
    // the water; final's fog then adds the camera-to-water part, so far reflected mountains
    // ghost out like the real ones (exact for uniform fog, close for the height profile).
    // Reflected clouds carry their own haze from gbuffers_clouds and are left alone.
    bool hitIsCloud = false;
#ifdef AMBIENCE_CLOUDS
    vec4 hitInfo = texture(colortex1, clamp(reflectUV, vec2(0.0), vec2(1.0)));
    hitIsCloud = hitInfo.a > 0.5 && hitInfo.r < 0.5;
#endif
    if (valid > 0.0 && !hitIsCloud && atmosOverworld > 0.5) {
        float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
        float segmentT = ambienceSegmentTransmittance(distance(hit, surface), cameraY + surface.y, cameraY + hit.y);
        AmbPalette waterPalette = finalWaterPalette();
        vec3 segmentColor = ambienceFogNear(reflectDir, vSunWorld, waterPalette.fogNear, waterPalette.glow) * mix(0.25, 1.0, ambienceCaveLight());
        environment = mix(segmentColor, environment, segmentT);
        reflectionFog = 1.0 - segmentT;
    }
#endif
    // Rain roughens the reflection (lower contrast); at night it is cooler like Tier 1.
    environment = mix(environment, vec3(ambLuma(environment)), 0.25 * weather);
    environment *= mix(vec3(1.0), vec3(0.80, 0.88, 1.05), 1.0 - smoothstep(-0.20, 0.05, vSunWorld.y));
#ifdef AMBIENCE_DEBUG
    gDebugReflectionFog = reflectionFog;
    gDebugReflectionValid = valid;
#endif
#endif
    environment = mix(environment, skyTier1, 0.20 + 0.35 * weather);
#ifdef AMBIENCE_DEBUG
    gDebugReflectionColor = mix(skyTier1, environment, valid);
#endif

#ifdef REFLECTION_DEBUG
#if REFLECTION_DEBUG_MODE == 5
    debugInfo = vec4(clamp(reflectUV, vec2(0.0), vec2(1.0)), 0.0, valid);
#else
    debugInfo = vec4(environment * valid, valid);
#endif
#endif
    return weight * valid * (environment - skyTier1);
}
#endif

#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(ATMOS_DEBUG)
float evaluateFogFactor(float viewDistance, float worldY) {
    float heightAboveSea = max(worldY - 63.0, 0.0);
    float heightFactor = 1.0 / (1.0 + heightAboveSea * HAZE_HEIGHT_FALLOFF);
    float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
    float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
    float weatherDensity = 1.0 + rainStrength * 0.22 + thunderStrength * 0.38 + twilight * 0.20 + night * 0.10;
    float biomeFogScale = mix(0.80, 1.20, clamp(fogDensity, 0.0, 1.0));
    float dimensionFogScale = mix(1.0, 0.55, clamp(atmosNether, 0.0, 1.0));
    dimensionFogScale = mix(dimensionFogScale, 0.30, clamp(atmosEnd, 0.0, 1.0));
    return 1.0 - exp(-viewDistance * HAZE_DENSITY * heightFactor * weatherDensity * biomeFogScale * dimensionFogScale);
}
#endif

#ifdef PROCEDURAL_STARS
float evaluateProceduralStars(vec3 worldDirection) {
    float nightFade = 1.0 - smoothstep(-0.22, 0.06, vSunElevation);
    float weatherFade = (1.0 - clamp(rainStrength, 0.0, 1.0)) *
                        (1.0 - clamp(thunderStrength, 0.0, 1.0) * 0.95);
    float moonBrightness = abs(4.0 - float(moonPhase)) * 0.25;
    float moonFade = 1.0 - moonBrightness * 0.28;
    float upperSky = smoothstep(-0.04, 0.10, worldDirection.y);
    float starGridScale;
#if SKY_QUALITY == 1
    starGridScale = 58.0;
#else
    starGridScale = 104.0;
#endif
    vec2 projected = worldDirection.xz / max(abs(worldDirection.y), 0.08) * starGridScale;
    vec2 cell = floor(projected);
    vec2 localPoint = fract(projected) - 0.5;
    float cellHash = cheapHash(cell);
    float star = step(1.0 - STAR_AMOUNT * 0.045, cellHash);
    float pixel = 1.0 - smoothstep(0.025, 0.11, length(localPoint));
    float twinkle = 0.68 + 0.32 * cheapHash(cell + vec2(floor(frameTimeCounter * 1.3), 29.0));
    return star * pixel * twinkle * nightFade * weatherFade * moonFade * upperSky * atmosOverworld;
}
#endif

#ifdef SKY_DEBUG
// Debug copy of the fake-bird shape (GOLDEN_FAKE_BIRDS), so view 8 can show where the birds are
// at this moment even when SKY_PIXEL_FIX has removed them from the image.
float skyDebugBirdMask(vec2 screenUV, vec2 centerUV) {
    float cell = max(float(FAKE_BIRD_SIZE), 1.0);
    vec2 p = (screenUV - centerUV) * vec2(viewWidth, viewHeight) / cell;
    float wingLine = abs(p.y - (0.30 - 0.46 * abs(p.x)));
    return step(abs(p.x), 1.05) * (1.0 - step(0.12, wingLine));
}

float skyDebugBirds(vec2 uv) {
    float birdTime = frameTimeCounter * FAKE_BIRD_SPEED;
    vec2 birdScreen = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
    float birdCell = max(float(FAKE_BIRD_SIZE), 1.0);
    vec2 birdPixelUV = (floor(uv * birdScreen / birdCell) + 0.5) * birdCell / birdScreen;
    float birds = skyDebugBirdMask(birdPixelUV, vec2(fract(0.16 + birdTime), 0.84));
    birds += skyDebugBirdMask(birdPixelUV, vec2(fract(0.49 + birdTime * 0.78), 0.78));
    birds += skyDebugBirdMask(birdPixelUV, vec2(fract(0.76 + birdTime * 1.12), 0.88));
    return birds;
}

// The sky as final composes it on the Ambience path (analytic sky + what vanilla drew + the
// quarter-resolution layer + procedural stars + the birds while they are drawn), for any pixel:
// the outlier view compares a pixel with its neighbours. isSky = the pixel is open sky.
vec3 skyDebugCompose(ivec2 px, out bool isSky) {
    vec2 uv = (vec2(px) + 0.5) / vec2(viewWidth, viewHeight);
    bool cloud = false;
#ifdef AMB_CLOUD_MARKER
    vec4 info = texelFetch(colortex1, px, 0);
    cloud = info.a > 0.5 && !(info.r > 0.5);
#endif
    isSky = texelFetch(depthtex0, px, 0).r > 0.99999 && !cloud;
    if (!isSky) return vec3(0.0);
    vec3 dir = worldViewRay(uv);
    vec3 scene = texelFetch(colortex0, px, 0).rgb;
    vec3 aux = vec3(0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(EMISSIVE_GLOW)
    aux = texture(colortex5, uv).rgb;
#endif
#ifdef MOON_RAYS
    vec3 skyNow = ambienceSkyFullMoon(dir, vSunWorld, finalPalette(), finalMoon(), finalPixelAngle());
#else
    vec3 skyNow = ambienceSkyFull(dir, vSunWorld, finalPalette(), ambMoonBrightness(moonPhase), finalPixelAngle());
#endif
    vec3 c = skyNow + max(scene - skyNow - vec3(0.004), vec3(0.0)) * smoothstep(0.035, 0.07, dir.y) + aux;
#ifdef PROCEDURAL_STARS
    float stars = evaluateProceduralStars(dir);
#ifdef MOON_RAYS
    stars *= ambMoonStarDimming(dir, finalMoon());
#endif
    c += vec3(0.72, 0.84, 1.0) * stars * 0.22;
#endif
#ifdef GOLDEN_FAKE_BIRDS
    float birdMatch = float(MATCH_STRENGTH) * 0.01;
    float birdDay = smoothstep(-0.10, 0.12, vSunElevation) * clamp(1.0 - rainStrength * 0.90 - thunderStrength * 0.40, 0.0, 1.0);
    c = mix(c, vec3(0.13, 0.10, 0.075), clamp(skyDebugBirds(uv) * FAKE_BIRD_AMOUNT * birdDay * birdMatch, 0.0, 0.82));
#endif
    return c;
}
#endif

void main() {
#if defined(LIGHT_DEBUG) && (LIGHT_DEBUG_MODE == 7 || LIGHT_DEBUG_MODE == 9 || LIGHT_DEBUG_MODE == 10 || LIGHT_DEBUG_MODE == 13 || LIGHT_DEBUG_MODE == 15 || LIGHT_DEBUG_MODE == 16 || LIGHT_DEBUG_MODE == 17)
    // Values written by the terrain program into its colour, shown without fog or grading.
    gl_FragColor = vec4(texture(colortex0, vTexCoord).rgb, 1.0);
    return;
#endif
#if (defined(NETHER_DEBUG) && (NETHER_DEBUG_MODE == 4 || NETHER_DEBUG_MODE == 5)) || (defined(END_DEBUG) && (END_DEBUG_MODE == 6 || END_DEBUG_MODE == 7))
    // Update 3: values written by the terrain program (emissive mask, block light hue, flash light,
    // flash shadow), shown without fog or grading.
    gl_FragColor = vec4(texture(colortex0, vTexCoord).rgb, 1.0);
    return;
#endif
#ifdef TARGET_DEBUG
    float targetDebugSun = 0.0;
    vec3 targetDebugSky = vec3(0.0);
    float targetDebugFog = 0.0;
    float targetDebugPhase = 0.0;
    vec3 targetDebugBeforeGrade = vec3(0.0);
    vec3 targetDebugAfterGrade = vec3(0.0);
#endif
#ifdef VV_DEBUG
#if VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 2 || VV_DEBUG_MODE == 5 || VV_DEBUG_MODE == 9
    vec3 quarterDebug = texture(colortex5, vTexCoord).rgb;
#if VV_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(quarterDebug.r), 1.0);
#else
    gl_FragColor = vec4(quarterDebug, 1.0);
#endif
#elif VV_DEBUG_MODE == 6 || VV_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex2, vTexCoord).rgb, 1.0);
#elif VV_DEBUG_MODE == 8
    gl_FragColor = vec4(vec3(texture(colortex1, vTexCoord).r), 1.0);
#elif VV_DEBUG_MODE == 3
    float debugDepth = texture(depthtex0, vTexCoord).r;
    if (debugDepth < 0.99999) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, debugDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
#elif VV_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), 1.0);
#else
    gl_FragColor = vec4(1.0, 0.0, 1.0, 1.0);
#endif
    return;
#endif

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 1 || ATMOS_DEBUG_MODE == 2 || ATMOS_DEBUG_MODE == 6
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
    return;
#endif
#elif defined(CAUSTICS_DEBUG) || (defined(WAVE_DEBUG) && WAVE_DEBUG_MODE != 10) || (defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE != 3 && REFLECTION_DEBUG_MODE != 4 && REFLECTION_DEBUG_MODE != 5 && REFLECTION_DEBUG_MODE != 12)
    // Raw diagnostic written by the water/terrain programs, shown without grading.
    gl_FragColor = vec4(texture(colortex1, vTexCoord).rgb, 1.0);
    return;
#endif

    vec4 scene = texture(colortex0, vTexCoord);
    vec3 color = scene.rgb;

#ifdef WATER_SSR
    // Swap the Tier-1 sky colour baked into the water for the reflected environment, before
    // haze and grading so the reflection is fogged by the water's own distance.
    vec4 reflectionDebug;
    vec3 screenReflection = waterScreenReflection(vTexCoord, reflectionDebug);
#if defined(AMBIENCE_DEBUG) && AMBIENCE_DEBUG_MODE == 14
    // Split view: left half without the screen-space reflection, right half with it.
    if (vTexCoord.x < 0.5) screenReflection = vec3(0.0);
#endif
    color += screenReflection;
#if defined(REFLECTION_DEBUG) && (REFLECTION_DEBUG_MODE == 3 || REFLECTION_DEBUG_MODE == 4 || REFLECTION_DEBUG_MODE == 5)
#if REFLECTION_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(reflectionDebug.a), 1.0);
#else
    gl_FragColor = vec4(reflectionDebug.rgb, 1.0);
#endif
    return;
#endif
#endif

    float sceneDepth = texture(depthtex0, vTexCoord).r;

    // What is this pixel? Clouds carry their own haze and are composed over the palette sky
    // in display colours, so they get neither the fog nor the tone curve here; water uses the
    // Ambience fog unless FOG_ON_WATER is off.
    bool cloudPixel = false;
    bool waterPixel = false;
#ifdef AMB_FINAL_INFO
    vec4 ambienceInfo = texture(colortex1, vTexCoord);
    waterPixel = ambienceInfo.r > 0.5;
#ifdef AMB_CLOUD_MARKER
    cloudPixel = ambienceInfo.a > 0.5 && !waterPixel;
#endif
#endif
    bool skyPixel = sceneDepth > 0.99999 && !cloudPixel;
    float overworld = (hasSkylight && !hasCeiling && atmosOverworld > 0.5) ? 1.0 : 0.0;
    float moonBrightness = ambMoonBrightness(moonPhase);

    // Bloom, shallow-water shafts and pollen from the quarter-resolution pass.
    vec3 auxiliary = vec3(0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(EMISSIVE_GLOW)
    auxiliary = texture(colortex5, vTexCoord).rgb;
    color += auxiliary;
#endif

#ifdef ATMOS_TONE_MAP
    bool displayReferred = false;
#ifdef AMBIENCE_COLORS
    displayReferred = overworld > 0.5 && isEyeInWater == 0 && (skyPixel || cloudPixel);
#endif
    if (!displayReferred) color = finalToneMap(color, overworld);
#endif

    if (skyPixel && isEyeInWater == 0) {
        vec3 worldDirection = worldViewRay(vTexCoord);
#ifdef SKY_PIXEL_FIX
        // Analytic colour of this sky pixel, used only if the result below were invalid.
        vec3 skyFallback = skyColor;
#endif
#ifdef AMBIENCE_COLORS
        if (overworld > 0.5) {
            // The sky is rebuilt from the same function gbuffers_skybasic used, so the sun, its
            // glow and the gradient are exact and smooth. What vanilla drew on top of that sky
            // (moon and stars; the vanilla sun is disabled) is the positive difference; below
            // the sky disc's rim (about 2 degrees) colortex0 holds the vanilla clear colour, so
            // that band takes nothing from it.
#ifdef MOON_RAYS
            vec3 skyNow = ambienceSkyFullMoon(worldDirection, vSunWorld, finalPalette(), finalMoon(), finalPixelAngle());
#else
            vec3 skyNow = ambienceSkyFull(worldDirection, vSunWorld, finalPalette(), moonBrightness, finalPixelAngle());
#endif
            vec3 celestial = max(scene.rgb - skyNow - vec3(0.004), vec3(0.0)) * smoothstep(0.035, 0.07, worldDirection.y);
            color = skyNow + celestial + auxiliary;
#ifdef SKY_PIXEL_FIX
            skyFallback = skyNow;
#endif
#ifdef TARGET_DEBUG
            targetDebugSky = skyNow;
#endif
        } else
#endif
        {
#if defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
        bool dimensionSky = false;
#ifdef NETHER_AMBIENCE
        if (atmosNether > 0.5) {
            // Update 3, the Nether: the empty background is the fog itself (the same function), so the
            // far distance and the ceiling dissolve into it without a band.
            float netherCameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
            color = netherFogColor(worldDirection, netherCameraY + 48.0 * worldDirection.y) + auxiliary;
            dimensionSky = true;
        }
#endif
#ifdef END_AMBIENCE
        if (atmosEnd > 0.5) {
            // The End (Update 4): the smooth Vibrant Visuals sky (lib/dimension_ambience.glsl: #0A060E at the
            // horizon, #0E0916 higher up, #100A19 at the zenith, the void below a little darker), the same
            // function as the fog over terrain, so the far terrain and the island's edge melt into it.
            // colortex0 is not used for the sky itself, so the sky is the same whatever the game drew: during
            // the dragon fight the game draws no sky at all (the boss bar's world fog skips the whole sky
            // pass, so colortex0 holds only the clear colour), after it the vanilla box and the flash sprite,
            // and with Minecraft 26.3's End sky light Iris 1.11.7 draws its horizon fan (a flat band up to
            // about 5 degrees, discarded in gbuffers_skybasic). Only what is clearly brighter than the vanilla
            // sky can ever be is kept from colortex0 (fireworks, beams, the dragon's death rays), except
            // around the flash while the game draws its sprite.
            color = endSkyFull(worldDirection);
            vec3 endOverlay = max(scene.rgb - vec3(END_SKY_OVERLAY_FLOOR), vec3(0.0));
#ifdef END_FLASHES
            if (endFlashIntensity > 1.0e-5 || vclFlash > 0.0005) {
                // The sprite is a 120-block square 100 blocks away along the flash: within 40.3 degrees of it
                // (cos 0.763); nothing is kept there while it is drawn, everything from 48 degrees (cos 0.669).
                endOverlay *= 1.0 - smoothstep(0.669, 0.763, dot(worldDirection, vFlashA.xyz));
            }
            float endFight = endDragonFight();
            if (vFlashA.w > 0.0) {
                // The flash glow in the fog toward the flash (Vibrant Visuals: the fog lights up, no sprite),
                // also while the dragon is alive (END_DRAGON_FOG off).
                color += min(endFlashGlow(ambAngle(worldDirection, vFlashA.xyz), endFlashColor(), vFlashA.w) *
                             (FLASH_SKY_GLOW_STRENGTH * (1.0 - endFight)), vec3(0.75));
            }
            color = mix(color, endFogColor(worldDirection), 0.6 * endFight);
#endif
            color += endOverlay + auxiliary;
            dimensionSky = true;
        }
#endif
        if (!dimensionSky) {
#endif
        // Previous sky treatment (Ambience colours off, or the Nether and the End).
        vec3 skyGradient = skyColor;
#ifdef SKY_GRADE
        skyGradient = evaluateSkyGradient(worldDirection);
        float dimensionWeight = clamp(atmosOverworld + atmosNether + atmosEnd, 0.0, 1.0);
        color += (skyGradient - skyColor) * SKY_GRADIENT_STRENGTH * dimensionWeight;
        float dither = (cheapHash(floor(gl_FragCoord.xy)) - 0.5) * (0.75 / 255.0);
        color += vec3(dither * SKY_GRADIENT_STRENGTH);
#endif

#ifdef GOLDEN_TARGET_SKY
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(vSunElevation));
        float daySide = smoothstep(-0.16, -0.005, vSunElevation);
        float targetSkyWeather = clamp(1.0 - rainStrength * 0.58 - thunderStrength * 0.32, 0.0, 1.0);
        float warmBiomeSky = clamp(max(atmosSavannaBiome * 0.55, atmosWoodlandBiome * 0.24), 0.0, 1.0);
        float warmSkyMask = max(twilightSky * daySide, warmBiomeSky * (1.0 - smoothstep(-0.10, 0.18, vSunElevation)));
        warmSkyMask *= targetSkyWeather * atmosOverworld;
        float skyHorizonMix = 1.0 - smoothstep(0.015, 0.90, max(worldDirection.y, 0.0));
        vec3 goldenZenith = vec3(0.46, 0.37, 0.27);
        vec3 goldenHorizon = vec3(1.00, 0.72, 0.39);
        vec3 goldenSky = mix(goldenZenith, goldenHorizon, skyHorizonMix);
        color = mix(color, goldenSky, targetMatch * warmSkyMask * GOLDEN_SKY_TINT_STRENGTH);
#ifdef TARGET_DEBUG
        targetDebugSky = goldenSky;
#endif
#endif

#ifdef SUN_GLOW
        // The new analytic glow around the vanilla sun (drawn by vanilla on this path), kept
        // off the square itself so its centre is never overwritten.
        if (overworld > 0.5) {
            AmbGlow legacyGlow = ambCelestialGlow(worldDirection, vSunWorld, moonBrightness);
            float outside = 1.0 - ambSunDisc(worldDirection, vSunWorld, finalPixelAngle()).a;
            color = mix(color, ambSunGlowColor(vSunWorld), clamp(legacyGlow.core + legacyGlow.mid, 0.0, 0.92) * outside);
#ifndef MOON_RAYS
            color = mix(color, vec3(0.78, 0.86, 1.00), clamp(legacyGlow.moon, 0.0, 0.60));
#endif
        }
#endif
#ifdef MOON_RAYS
        // The moon's glow and halo around the vanilla moon (never on its disc).
        if (overworld > 0.5) color = ambMoonGlowApply(color, worldDirection, finalMoon(), finalPixelAngle());
#endif
#if defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
        }
#endif
        }

#if defined(TARGET_DEBUG) && defined(SUN_GLOW)
        AmbGlow targetGlow = ambCelestialGlow(worldDirection, vSunWorld, moonBrightness);
        targetDebugSun = clamp(targetGlow.core + targetGlow.mid, 0.0, 1.0);
#endif

#ifdef PROCEDURAL_STARS
        float stars = evaluateProceduralStars(worldDirection);
#ifdef MOON_RAYS
        // Stars inside the moon's glow fade softly (the vanilla stars do the same in the sky pass).
        stars *= ambMoonStarDimming(worldDirection, finalMoon());
#endif
        color += vec3(0.72, 0.84, 1.0) * stars * 0.22;
#endif

#ifdef GOLDEN_FAKE_BIRDS
        float birdMatch = float(MATCH_STRENGTH) * 0.01;
        float birdTime = frameTimeCounter * FAKE_BIRD_SPEED;
        float birdDay = smoothstep(-0.10, 0.12, vSunElevation) *
                        clamp(1.0 - rainStrength * 0.90 - thunderStrength * 0.40, 0.0, 1.0);
        if (birdDay * birdMatch * FAKE_BIRD_AMOUNT > 0.001) {
            vec2 birdScreen = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
            float birdCell = max(float(FAKE_BIRD_SIZE), 1.0);
            vec2 birdPixelUV = (floor(vTexCoord * birdScreen / birdCell) + 0.5) * birdCell / birdScreen;
            float birds = targetBirdMask(birdPixelUV, vec2(fract(0.16 + birdTime), 0.84));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.49 + birdTime * 0.78), 0.78));
            birds += targetBirdMask(birdPixelUV, vec2(fract(0.76 + birdTime * 1.12), 0.88));
            color = mix(color, vec3(0.13, 0.10, 0.075), clamp(birds * FAKE_BIRD_AMOUNT * birdDay * birdMatch, 0.0, 0.82));
        }
#endif
#ifdef SKY_PIXEL_FIX
        // Safety net: an invalid sky value (NaN, infinity) becomes the analytic sky; valid values
        // are untouched.
        if (!skyColorValid(color)) color = skyGuardFallback(skyFallback);
#endif
    }

#ifdef UNDERWATER_AMBIENCE
    if (skyPixel && isEyeInWater == 1) {
        // Update 3: beyond everything the gbuffers drew the water is fully fogged (the background showed
        // the daylight sky before, which made the water look transparent toward the far distance).
        bool uwBackgroundHere = true;
#if defined(UNDERWATER_DEBUG) && UNDERWATER_DEBUG_MODE == 9
        uwBackgroundHere = vTexCoord.x >= 0.5;   // split view: left half without
#endif
        if (uwBackgroundHere) color = mix(color, uwFogColor(worldViewRay(vTexCoord)) + auxiliary, clamp(vclUwFade, 0.0, 1.0));
    }
#endif

#ifdef ATMOS_DEBUG
#if ATMOS_DEBUG_MODE == 3
    if (sceneDepth < 0.99999 && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        vec3 debugViewPosition = debugViewH.xyz / max(debugViewH.w, 0.0001);
        vec3 debugPlayerPosition = (gbufferModelViewInverse * vec4(debugViewPosition, 1.0)).xyz;
        float debugFog = evaluateFogFactor(length(debugViewPosition), cameraPosition.y + debugPlayerPosition.y);
        gl_FragColor = vec4(vec3(debugFog), 1.0);
    } else {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
    return;
#elif ATMOS_DEBUG_MODE == 4
    float debugTwilight = 1.0 - smoothstep(0.015, 0.28, abs(vSunElevation));
    float debugNight = 1.0 - smoothstep(-0.28, -0.06, vSunElevation);
    gl_FragColor = vec4(max(evaluateAtmosphereColor(0.0, debugTwilight, debugNight), vec3(0.0)), 1.0);
    return;
#elif ATMOS_DEBUG_MODE == 5
    vec3 debugSkyDirection = worldViewRay(vTexCoord);
    gl_FragColor = vec4(evaluateSkyGradient(debugSkyDirection), 1.0);
    return;
#endif
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    vec3 colorBeforeFog = color;
#endif
    // Camera-relative position of the surface (fog, veil); zero on sky pixels.
    vec3 playerPosition = vec3(0.0);
    if (!skyPixel) {
        vec4 viewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
        playerPosition = (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 0.0001), 1.0)).xyz;
    }
#ifdef UNDERWATER_AMBIENCE
    // Update 3: the underwater absorption fog, once per pixel by the distance of the nearest surface
    // (depthtex0). Underwater that is exactly the water between the eye and what is seen: the surface
    // seen from below included (what shows through it lies above the water). The bloom and the caustics
    // are fogged with everything else; the background was fogged above.
    if (!skyPixel && isEyeInWater == 1) {
        bool uwFogFinalHere = true;
#if defined(UNDERWATER_DEBUG) && UNDERWATER_DEBUG_MODE == 9
        uwFogFinalHere = vTexCoord.x >= 0.5;   // split view: left half without
#endif
        float uwDistance = length(playerPosition);
        if (uwFogFinalHere) color = uwApplyFog(color, uwDistance, playerPosition / max(uwDistance, 1.0e-4));
    }
#endif
#if defined(ATMOSPHERIC_HAZE) || defined(GOLDEN_TARGET_HAZE) || defined(AMBIENCE_FOG) || defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
    if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0 && (overworld > 0.5 || atmosNether > 0.5 || atmosEnd > 0.5)) {
        vec3 worldPosition = cameraPosition + playerPosition;
        float viewDistance = length(playerPosition);
        float twilight = 1.0 - smoothstep(0.035, 0.32, abs(vSunElevation));
        float night = 1.0 - smoothstep(-0.38, -0.08, vSunElevation);
        float viewUp = playerPosition.y / max(viewDistance, 0.0001);
        vec3 hazeColor = evaluateAtmosphereColor(viewUp, twilight, night);
        float targetFogFactor = 0.0;

        bool ambienceFogHere = false;
#ifdef AMBIENCE_FOG
        ambienceFogHere = overworld > 0.5;
#ifndef FOG_ON_WATER
        if (waterPixel) ambienceFogHere = false;
#endif
#endif

        // Update 3: the Nether and End fogs replace the previous small tints there (the haze at 0.55 x
        // and 0.30 x density with 30 % / 28 % of a tint, evaluateAtmosphereColor and evaluateFogFactor).
        bool dimensionFogHere = false;
#ifdef NETHER_AMBIENCE
        if (atmosNether > 0.5) {
            // Dense biome fog: the same colour function as the empty background (no band at the far
            // distance or the ceiling), the lava-sea glow from the height of the middle of the ray.
            vec3 netherDir = playerPosition / max(viewDistance, 1.0e-4);
            float netherAmount = netherFogAmount(viewDistance);
            vec3 netherColor = netherFogColor(netherDir, worldPosition.y - 0.5 * playerPosition.y);
            color = mix(color, netherColor, netherAmount);
            hazeColor = netherColor;
            targetFogFactor = netherAmount;
            dimensionFogHere = true;
        }
#endif
#ifdef END_AMBIENCE
        if (atmosEnd > 0.5) {
            // Thin dark haze (Update 4: the sky's own colour, so the ground keeps its colour to the island's edge
            // as on the reference and distant islands fade into the sky behind them), and the far border into the
            // sky colour of that direction: between flashes exactly as before.
            // Update 4.1, a flash: its glow is light in the air in front of the surface (lib/dimension_ambience.glsl,
            // endFlashInscatter), over the lit part of the view ray (composite1's screen-space volumetric shadow),
            // so dark pillars and mobs in front of the glow are hazed violet as in Vibrant Visuals while bright end
            // stone only turns violet; at the far border it meets exactly the glowing sky. A flash no longer
            // thickens the dark haze (the ground away from the flash keeps its value, as in Vibrant Visuals).
            vec3 endDir = playerPosition / max(viewDistance, 1.0e-4);
            vec3 endColor = endFogColor(endDir);
            float endBoost = 1.0;
#ifdef END_FLASHES
            float endFight = endDragonFight();
            endBoost = mix(1.0, 3.0, endFight);
#endif
            float endBorder = smoothstep(far * 0.55, far * 0.95, length(playerPosition.xz)) * HORIZON_BLEND;
            float endAmount = max(endFogAmount(viewDistance, endBoost), endBorder);
            // Update 4.2: the ambient haze, the sky's light in the air in front of the surface (dark pillars and
            // mobs rise to about the sky's brightness and flatten, as in Vibrant Visuals; end stone is unchanged),
            // before the haze and the far border, so the render distance still meets exactly the sky.
            color = endGammaAdd(color, endAmbientHazeShare(viewDistance) * endGammaPow(endColor));
            color = mix(color, endColor, endAmount);
            hazeColor = endColor;
#ifdef END_FLASHES
            if (vFlashA.w > 0.0) {
                vec3 endGlow = min(endFlashGlow(ambAngle(endDir, vFlashA.xyz), endFlashColor(), vFlashA.w) *
                                   (FLASH_SKY_GLOW_STRENGTH * (1.0 - endFight)), vec3(0.75));
                float endLit = 1.0;
                // The visibility is read only where the glow can show (above 0.5 / 255).
                if (dot(endGlow, vec3(0.2126, 0.7152, 0.0722)) > 0.002) endLit = endFlashFogVisibility(vTexCoord, sceneDepth);
                // The far border is folded into the share (the haze above already mixed it in once): at the render
                // distance hazed = B, so the result is exactly the glowing sky B + G, and with G = 0 (a flash starting
                // or ending) it is exactly the haze above, so nothing pops when the envelope crosses zero.
                color = endFlashInscatter(color, endColor, endGlow, max(endFlashFogShare(viewDistance, endLit), endBorder));
                hazeColor = endColor + endGlow;
            }
#endif
            targetFogFactor = endAmount;
            dimensionFogHere = true;
        }
#endif

        if (ambienceFogHere) {
#ifdef AMBIENCE_FOG
            // The cloud shadow on this surface darkens and cools the near haze in front of it.
            // Final cannot see the gbuffers' value (no free buffer channel), so it re-reads the
            // same cells: one fetch (quality 1) or four (quality 2), cached 256x256 texture.
            float cloudShadowHere = 1.0;
#ifdef CLOUD_SHADOW_ENABLE
            float cloudMask;
            vec2 cloudUV;
            cloudShadowHere = ambienceCloudShadow(playerPosition + vec3(0.0, 0.1, 0.0), vSunWorld, cloudMask, cloudUV);
#ifdef AMBIENCE_DEBUG
            gDebugCloudMask = cloudMask;
            gDebugCloudShadow = cloudShadowHere;
            gDebugCloudUV = cloudUV;
#endif
#endif
            AmbFog fog = ambienceFog(playerPosition, vSunWorld, finalPalette(), far, cloudShadowHere, ambienceCaveLight());
#ifdef FOG_BANDED_LOOK
            // Pixel-art option: a few fog steps, ordered-dithered so the steps do not band.
            float fogLevels = float(FOG_LEVELS);
            fog.amount = min(floor(fog.amount * fogLevels + ambBayer4(gl_FragCoord.xy)) / fogLevels, 1.0);
#endif
            color = ambienceApplyFog(color, fog);
            targetFogFactor = fog.amount;
            hazeColor = fog.color;
#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG)
            gDebugFogAmount = fog.amount;
            gDebugFogColor = fog.color;
            gDebugBank = fog.bank;
            gDebugScatter = fog.scatter;
            gDebugDesaturation = fog.desaturation;
#endif
#endif
        } else if (!dimensionFogHere) {
#ifdef ATMOSPHERIC_HAZE
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
        float distanceBlend = smoothstep(24.0, 112.0, viewDistance);
        color *= mix(vec3(1.0), vec3(0.95, 0.98, 1.035), distanceBlend * targetFogFactor * 0.45);
        float rainLumaForHaze = dot(color, vec3(0.2126, 0.7152, 0.0722));
        color = mix(color, vec3(rainLumaForHaze) * vec3(0.96, 1.0, 1.05), targetFogFactor * rainStrength * 0.10);
        color = mix(color, hazeColor, targetFogFactor);
#elif defined(GOLDEN_TARGET_HAZE)
        targetFogFactor = evaluateFogFactor(viewDistance, worldPosition.y);
#endif
        // Horizon blend: near the render distance, terrain and water fade into the colour of the
        // sky behind them (like vanilla's border fog). Overworld: the same sky function as the
        // water's Tier-1 reflection; the Nether and the End keep their vanilla-like fog colour.
        float borderFog = smoothstep(far * 0.55, far * 0.95, length(playerPosition.xz)) * HORIZON_BLEND;
        vec3 borderColor = overworld > 0.5 ? reflectionSkyBase(safeNormalize(playerPosition), vSunElevation) : hazeColor;
        color = mix(color, borderColor, borderFog);

#ifdef GOLDEN_TARGET_HAZE
        // Extra amber haze, only where the Ambience fog is off (it would break the horizon
        // match, since the sky does not get it).
        float targetMatch = float(MATCH_STRENGTH) * 0.01;
        float targetWarmTime = smoothstep(-0.16, 0.07, vSunElevation) *
                               (1.0 - smoothstep(0.14, 0.54, max(vSunElevation, 0.0)));
        float savannaHaze = clamp(max(atmosSavannaBiome, atmosDesertBiome * 0.42), 0.0, 1.0);
        float warmHazeMask = max(1.0 - smoothstep(0.035, 0.34, abs(vSunElevation)), savannaHaze * targetWarmTime);
        float targetWeather = clamp(1.0 - rainStrength * 0.70 - thunderStrength * 0.35, 0.0, 1.0);
        vec2 hazeScreenDelta = (vTexCoord - vSunUV) * vec2(aspectRatio, 1.0);
        float hazePhase = 1.0 - smoothstep(0.035, 0.62, length(hazeScreenDelta));
        hazePhase *= hazePhase * vSunInFront * smoothstep(-0.10, 0.14, vSunElevation);
        vec3 goldenHazeColor = mix(hazeColor, vec3(0.99, 0.70, 0.43), warmHazeMask);
        float extraGoldenFog = targetFogFactor * GOLDEN_HAZE_STRENGTH * targetMatch * warmHazeMask * targetWeather;
        extraGoldenFog *= clamp(0.58 + hazePhase * GOLDEN_HAZE_PHASE, 0.0, 1.0);
        color = mix(color, goldenHazeColor, clamp(extraGoldenFog, 0.0, 0.72));
#ifdef TARGET_DEBUG
        targetDebugFog = clamp(targetFogFactor * warmHazeMask, 0.0, 1.0);
        targetDebugPhase = clamp(hazePhase, 0.0, 1.0);
#endif
#endif
        }
    }
#endif

#if defined(AMBIENCE_DEBUG) || defined(SUN_DEBUG) || defined(BIOME_DEBUG)
    vec3 colorAfterFog = color;
#endif

#if defined(AMB_SUN_VISIBILITY) || defined(SUN_SHAFTS) || defined(AMB_MOON_VISIBILITY) || defined(MOON_SHAFTS)
    // Veil, edge rim and shafts: a light's glow over what stands in front of it (terrain and
    // clouds; never on sky pixels, which carry the analytic glow), for the sun and then the moon,
    // through the same CelestialLight functions (lib/sun_rays.glsl). The veil is analytic (angle
    // to the light) times its visibility V; the rim adds light-directed depth taps right around
    // it on faces turned to it; the shafts come from the quarter-resolution march (composite1)
    // through a depth-aware upsample. No noise, no jitter, no shadow map. The two lights are
    // opposite, so at most one is on screen: the per-pixel work never doubles; the shafts have
    // one buffer and belong to one source per frame.
    if (!skyPixel && overworld > 0.5 && isEyeInWater == 0) {
        vec3 viewDirection = worldViewRay(vTexCoord);
        float eyeSky = smoothstep(0.10, 0.45, float(eyeBrightnessSmooth.y) / 240.0);
        float depthFactor = 1.0 - exp(-length(playerPosition) / 6.0);
#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
        gMoonDebugSunBefore = color;
        gMoonDebugTerrain = 1.0;
#endif
#if defined(AMB_SUN_VISIBILITY) || defined(SUN_SHAFTS)
        {
            // The sun: faint shafts and the rim are low by default, strongest near the sun, gone
            // off screen, behind the camera, below the horizon, in rain, indoors and underwater.
            CelestialLight sun = finalSunLight(eyeSky);
            float theta = ambAngle(viewDirection, sun.direction);
#ifdef SUN_VEIL
            float veil;
            color = celestialVeil(color, sun, theta, depthFactor, veil);
#ifdef SUN_DEBUG
            gDebugVeil = veil;
#endif
#endif
#ifdef SUN_EDGE_RIM
            // Which edges face the sun is decided by the taps (open sky toward the sun on screen:
            // no rim on edges turned away); the normal weights the rim (65 % on backlit faces,
            // which carry the reference's rim when the camera looks up at the sun).
            float rim;
            color = celestialRim(color, sun, theta, playerPosition, sceneDepth, cloudPixel, vTexCoord, rim);
            if (rim > 0.0) {
#ifdef SUN_DEBUG
                gDebugRim = rim;
#endif
#ifdef LIGHT_DEBUG
                gLightDebugRim = rim;
#endif
            }
#endif
#ifdef SUN_SHAFTS
            float shaft;
            color = celestialShafts(color, sun, theta, sceneDepth, vTexCoord, shaft);
#ifdef LIGHT_DEBUG
            if (shaft > 0.0) gLightDebugShaft = shaft;
#endif
#endif
        }
#endif
#if defined(MOON_DEBUG) && MOON_DEBUG_MODE == 13
        gMoonDebugSunAfter = color;
#endif
#ifdef MOON_RAYS
        // The moon, only while it has light (night, above the horizon, not rained out).
        if (vMoonWorldLight.w > 0.0) {
#ifdef MOON_DEBUG
            gMoonDebugRaysBefore = color;
#endif
            CelestialLight moon = finalMoonLight(eyeSky);
            float moonTheta = ambAngle(viewDirection, moon.direction);
#ifdef MOON_VEIL
            float moonVeil;
            color = celestialVeil(color, moon, moonTheta, depthFactor, moonVeil);
#ifdef MOON_DEBUG
            gMoonDebugVeil = moonVeil;
#endif
#endif
#ifdef MOON_EDGE_RIM
            float moonRim;
            color = celestialRim(color, moon, moonTheta, playerPosition, sceneDepth, cloudPixel, vTexCoord, moonRim);
#ifdef MOON_DEBUG
            gMoonDebugRim = moonRim;
#endif
#endif
#ifdef MOON_SHAFTS
            float moonShaft;
            color = celestialShafts(color, moon, moonTheta, sceneDepth, vTexCoord, moonShaft);
#ifdef MOON_DEBUG
            gMoonDebugShaft = moonShaft;
#endif
#endif
#ifdef MOON_DEBUG
            gMoonDebugRaysAfter = color;
#endif
        }
#endif
    }
#endif

#if defined(END_FLASH_SHAFTS) || defined(UNDERWATER_SHAFTS)
    float shaftDebug = 0.0;
#endif
#ifdef END_FLASH_SHAFTS
    if (!skyPixel && atmosEnd > 0.5 && isEyeInWater == 0 && vFlashA.w > 0.0) {
        // Update 3: soft purple shafts through gaps toward the flash: the sun shafts' march (composite1,
        // over composite's open-sky mask) and depth-aware upsample, cone-masked around the flash, only
        // while it is on (one light per frame: the sun and the moon never shine in the End).
        CelestialLight flashLight = finalFlashLight();
        color = celestialShafts(color, flashLight, ambAngle(worldViewRay(vTexCoord), flashLight.direction), sceneDepth, vTexCoord, shaftDebug);
    }
#endif
#ifdef UNDERWATER_SHAFTS
    if (isEyeInWater == 1 && vclUwShaft > 0.0005) {
        // Update 3: light shafts from the surface (lit and dark regions), screen-blended so they never
        // pass white: tier 1 gathers the analytic surface pattern along the view ray; tier 2 the
        // shadow-aware march of composite (blurred in composite1) through the depth-aware upsample.
        vec3 uwViewDir = worldViewRay(vTexCoord);
#ifdef UNDERWATER_SHAFTS_TIER2
        float uwShafts = raysShaftUpsample(vTexCoord, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight));
#else
        float uwShafts = uwTier1Shafts(skyPixel ? 1.0e4 : length(playerPosition));
#endif
        float uwShaftLight = uwShafts * uwShaftLobe(uwViewDir) * vclUwShaft * clamp(vclUwFade, 0.0, 1.0) * (0.42 * UW_SHAFT_STRENGTH);
#if defined(UNDERWATER_DEBUG) && UNDERWATER_DEBUG_MODE == 9
        if (vTexCoord.x < 0.5) uwShaftLight = 0.0;
#endif
        color += uwShaftColor() * uwShaftLight * max(vec3(1.0) - color, vec3(0.0));
        shaftDebug = uwShaftLight;
    }
#endif

#ifdef ADAPTIVE_EYES
    // Adaptive eyes (Patch 2.1): one exposure for everything the eye sees, applied here because
    // all light is composed at this point (scene, bloom, sky, fog, veil, rim, shafts) and the
    // grading, vignette, dither and 8-bit write still follow. At the reference light (normal
    // outdoor daylight) the gain is exactly 1, nothing else is active and the stage is skipped,
    // so the image is bit for bit the previous one.
#ifdef ADAPT_DEBUG
    vec3 adaptBefore = color;
#endif
    bool adaptHere = vAdaptA.x != 1.0 || vAdaptA.w != 0.0 || vAdaptB.x != 1.0;
#if defined(ADAPT_DEBUG) && ADAPT_DEBUG_MODE == 7
    // Split view: the left half without the exposure stage, the right half with it.
    adaptHere = adaptHere && vTexCoord.x >= 0.5;
#endif
    if (adaptHere) color = adaptApply(color, auxiliary, vAdaptA, vAdaptB);
#endif

#ifdef TARGET_DEBUG
    targetDebugBeforeGrade = color;
#endif

#ifdef GOLDEN_TARGET_GRADE
    float targetMatch = float(MATCH_STRENGTH) * 0.01;
    float goldenHour = (1.0 - smoothstep(0.035, 0.34, abs(vSunElevation))) *
                       smoothstep(-0.16, 0.045, vSunElevation);
    float warmRegion = clamp(max(atmosSavannaBiome * 0.52, atmosDesertBiome * 0.20), 0.0, 1.0);
    float goldenGradeMask = max(goldenHour, warmRegion * (1.0 - smoothstep(0.18, 0.52, max(vSunElevation, 0.0))));
    goldenGradeMask *= overworld * clamp(1.0 - rainStrength * 0.42 - thunderStrength * 0.30, 0.0, 1.0);
    vec3 gradeLumaColor = vec3(dot(color, vec3(0.2126, 0.7152, 0.0722)));
    vec3 goldenTint = vec3(1.00, 0.91, 0.77);
    color *= mix(vec3(1.0), goldenTint, goldenGradeMask * GOLDEN_GRADE_STRENGTH * targetMatch);
    float darkSurface = 1.0 - smoothstep(0.06, 0.44, dot(color, vec3(0.2126, 0.7152, 0.0722)));
    color += vec3(1.0, 0.57, 0.28) * darkSurface * goldenGradeMask * GOLDEN_SHADOW_LIFT * targetMatch;
    color = mix(color, max(gradeLumaColor, vec3(0.0)), rainStrength * targetMatch * 0.025 * overworld);
#endif

#ifdef TARGET_DEBUG
    targetDebugAfterGrade = color;
#endif

#ifdef ATMOSPHERIC_GRADE
    // Restrained green vibrance with a 0..1 saturation safety clamp.
    float greenChroma = color.g - max(color.r, color.b);
    float greenMask = smoothstep(0.015, 0.18, greenChroma) * overworld * (1.0 - rainStrength * 0.35);
    vec3 safeColor = clamp(color, vec3(0.0), vec3(1.0));
    float safeLuma = dot(safeColor, vec3(0.2126, 0.7152, 0.0722));
    vec3 vibrantColor = clamp(mix(vec3(safeLuma), safeColor, 1.0 + VIBRANCE_STRENGTH), vec3(0.0), vec3(1.0));
    color = mix(color, vibrantColor, greenMask);
#endif

#ifdef ATMOSPHERIC_GRADE
    float rainLuma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float stormDesaturation = rainStrength * 0.11 + thunderStrength * 0.08;
    color = mix(color, vec3(rainLuma) * vec3(0.96, 1.00, 1.05), stormDesaturation * overworld);
#endif

#if defined(ATMOS_VIGNETTE) || defined(GOLDEN_SOFT_VIGNETTE)
    vec2 vignettePos = (vTexCoord - vec2(0.5)) * vec2(aspectRatio, 1.0);
    float vignette = smoothstep(0.12, 0.72, dot(vignettePos, vignettePos));
    float vignetteStrength = 0.0;
#ifdef ATMOS_VIGNETTE
    vignetteStrength += VIGNETTE_STRENGTH;
#endif
#ifdef GOLDEN_SOFT_VIGNETTE
    vignetteStrength += GOLDEN_VIGNETTE_STRENGTH * float(MATCH_STRENGTH) * 0.01;
#endif
    color *= 1.0 - vignette * vignetteStrength * overworld;
#endif

#ifdef TARGET_DEBUG
#if TARGET_DEBUG_MODE == 1
    gl_FragColor = vec4(vec3(targetDebugSun), 1.0);
#elif TARGET_DEBUG_MODE == 2
    // The pixelated golden glow was removed.
    gl_FragColor = vec4(vec3(0.0), 1.0);
#elif TARGET_DEBUG_MODE == 3
    gl_FragColor = vec4(max(targetDebugSky, vec3(0.0)), 1.0);
#elif TARGET_DEBUG_MODE == 4
    gl_FragColor = vec4(vec3(targetDebugFog), 1.0);
#elif TARGET_DEBUG_MODE == 5
    gl_FragColor = vec4(vec3(targetDebugPhase), 1.0);
#elif TARGET_DEBUG_MODE == 6
    gl_FragColor = vec4(vec3(texture(colortex5, vTexCoord).r), 1.0);
#elif TARGET_DEBUG_MODE == 7
    gl_FragColor = vec4(texture(colortex5, vTexCoord).rgb, 1.0);
#else
    gl_FragColor = vec4(vTexCoord.x < 0.5 ? targetDebugBeforeGrade : targetDebugAfterGrade, 1.0);
#endif
    return;
#endif

#if defined(REFLECTION_DEBUG) && REFLECTION_DEBUG_MODE == 12
    // Left half: before haze, horizon blend and grading; right half: the normal result.
    if (vTexCoord.x < 0.5) color = colorBeforeFog;
#endif

#ifdef AMBIENCE_DEBUG
    {
        // Ambience diagnostics; the expected look of each view is listed in the README.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
#if AMBIENCE_DEBUG_MODE == 1
        debugOut = vec3(gDebugFogAmount);
#elif AMBIENCE_DEBUG_MODE == 2
        debugOut = gDebugFogColor;
#elif AMBIENCE_DEBUG_MODE == 3
        debugOut = vec3(clamp(gDebugBank * 0.5, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 4
        float debugHalo;
        float debugScatter;
        ambienceSkyTerms(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden, debugHalo, debugScatter);
        debugOut = vec3(clamp(debugScatter, 0.0, 1.0));
#elif AMBIENCE_DEBUG_MODE == 5
        debugOut = vec3(gDebugDesaturation);
#elif AMBIENCE_DEBUG_MODE == 6
        debugOut = vec3(gDebugCloudMask);
#elif AMBIENCE_DEBUG_MODE == 7
        debugOut = vec3(gDebugCloudShadow);
#elif AMBIENCE_DEBUG_MODE == 8
        debugOut = vec3(gDebugCloudUV, 0.0);
#elif AMBIENCE_DEBUG_MODE == 9
        debugOut = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
#elif AMBIENCE_DEBUG_MODE == 10
        // Terrain that should have dissolved into the sky (last 15 % before the fog end) minus
        // the sky colour behind it, x8. Expected: black everywhere.
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif AMBIENCE_DEBUG_MODE == 11
        debugOut = gDebugReflectionColor;
#elif AMBIENCE_DEBUG_MODE == 12
        debugOut = vec3(gDebugReflectionValid);
#elif AMBIENCE_DEBUG_MODE == 13
        debugOut = vec3(gDebugReflectionFog);
#elif AMBIENCE_DEBUG_MODE == 14 || AMBIENCE_DEBUG_MODE == 15
        // Split views (left without, right with); the line marks the split.
        if (abs(vTexCoord.x - 0.5) < 0.75 / viewWidth) debugOut = vec3(1.0);
#elif AMBIENCE_DEBUG_MODE == 16
        // Cloud alignment: on cloud pixels, green if the vanilla cell at that point is filled
        // (shadows and reflections use the same cells), red if it is empty. Expected: all green.
        debugOut = color * 0.35;
#if defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT)
        vec4 debugInfo = texture(colortex1, vTexCoord);
        if (sceneDepth < 0.99999 && debugInfo.a > 0.5 && debugInfo.r < 0.5) {
            vec4 debugViewH = gbufferProjectionInverse * vec4(vTexCoord * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
            vec3 debugPlayer = (gbufferModelViewInverse * vec4(debugViewH.xyz / max(debugViewH.w, 0.0001), 1.0)).xyz;
            vec3 debugWorld = ambWrappedWorld(debugPlayer - debugDir * 0.05);
            vec2 debugCell = floor(vec2(debugWorld.x + mod(cloudTime, ambCloudPeriod()), debugWorld.z + AMB_CLOUD_Z_OFFSET) / AMB_CLOUD_CELL);
            debugOut = ambCloudCell(debugCell) > 0.5 ? vec3(0.1, 0.9, 0.2) : vec3(0.95, 0.1, 0.1);
        }
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef SUN_DEBUG
    {
        // Sun, sky and fog diagnostics; the expected look of each view is in the README (v5).
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        AmbGlow debugGlow = ambCelestialGlow(debugDir, vSunWorld, moonBrightness);
        float debugHalo;
        float debugScatter;
        ambienceSkyTerms(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden, debugHalo, debugScatter);
#if SUN_DEBUG_MODE == 1
        // Angle to the sun: a smooth radial gradient, black at the sun.
        debugOut = vec3(ambAngle(debugDir, vSunWorld) / 3.14159265);
#elif SUN_DEBUG_MODE == 2
        debugOut = vec3(debugGlow.core);
#elif SUN_DEBUG_MODE == 3
        debugOut = vec3(debugGlow.mid);
#elif SUN_DEBUG_MODE == 4
        debugOut = vec3(debugHalo / max(SUN_HALO_STRENGTH, 0.001));
#elif SUN_DEBUG_MODE == 5
        // Ray lobes: mid grey = no modulation; soft light and dark wedges around the sun.
        debugOut = vec3(0.5 + 0.5 * (debugGlow.rays - 1.0) / max(RAY_VARIATION, 0.001));
#elif SUN_DEBUG_MODE == 6
        // Sun visibility V as a full-screen tint: it changes smoothly as a block covers the sun.
        debugOut = mix(color * 0.25, vec3(1.0, 0.85, 0.3), vSunVisibility * vSunScreenFade * 0.75);
#elif SUN_DEBUG_MODE == 7
        debugOut = vec3(gDebugVeil);
#elif SUN_DEBUG_MODE == 8
        debugOut = vec3(gDebugRim);
#elif SUN_DEBUG_MODE == 9
        debugOut = ambSkyGradient(debugDir, vPalZenith, vPalMid, vPalHorizon);
#elif SUN_DEBUG_MODE == 10
        // Terrain in the last 15 % before the fog end minus the sky behind it, x8: black.
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif SUN_DEBUG_MODE == 11
        // Cloud terms are written by gbuffers_clouds (red top, green side, blue underside).
        debugOut = cloudPixel ? scene.rgb : color * 0.3;
#elif SUN_DEBUG_MODE == 12
        debugOut = vec3(gDebugFogAmount);
#elif SUN_DEBUG_MODE == 13
        debugOut = vec3(clamp(debugScatter, 0.0, 1.0));
#elif SUN_DEBUG_MODE == 14
        // Fog banks: mid grey = average density, smooth large patches, no grain.
        debugOut = vec3(clamp(0.5 + (gDebugBank - 1.0) / max(2.0 * FOG_BANK_STRENGTH, 0.001), 0.0, 1.0));
#elif SUN_DEBUG_MODE == 15
        // The dither, amplified x16: a fine, even, static grain.
        debugOut = vec3(0.5 + ambDither(gl_FragCoord.xy) * SKY_DITHER / 255.0 * 16.0);
#elif SUN_DEBUG_MODE == 16
        // Banding test: each 8-bit step of the final colour becomes a visible stripe. Wide
        // clean stripes = banding; with the dither the stripes dissolve into a fine grain.
        vec3 codes = floor(clamp(color + ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0), 0.0, 1.0) * 255.0 + 0.5);
        debugOut = mod(codes, 4.0) / 3.0;
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef BIOME_DEBUG
    {
        // Biome ambience diagnostics; the expected look of each view is in the README (v6).
        vec3 debugOut = color * 0.6;
        vec2 uv = vTexCoord;
        // Normalised family weights (0 = base), from the CPU blend or the forced family.
        float w[17];
#if FORCE_BIOME_PREVIEW > 0
        for (int i = 0; i < 17; ++i) w[i] = (i == FORCE_BIOME_PREVIEW) ? 1.0 : 0.0;
#else
        w[0] = bfBase;
        w[1] = bfOcean * bfScale;
        w[2] = bfWarmOcean * bfScale;
        w[3] = bfSnowy * bfScale;
        w[4] = bfPlains * bfScale;
        w[5] = bfForest * bfScale;
        w[6] = bfDarkForest * bfScale;
        w[7] = bfTaiga * bfScale;
        w[8] = bfJungle * bfScale;
        w[9] = bfSwamp * bfScale;
        w[10] = bfDesert * bfScale;
        w[11] = bfSavanna * bfScale;
        w[12] = bfBadlands * bfScale;
        w[13] = bfWindswept * bfScale;
        w[14] = bfPeaks * bfScale;
        w[15] = bfCherry * bfScale;
        w[16] = bfMushroom * bfScale;
#endif
        float pixel = 1.0 / viewWidth;
        // Stacked weight bar along the top of the screen (used by views 1 and 5): each family's
        // horizon colour, as wide as its weight, black separators; red at the right end would
        // mean the weights do not add up to 1.
        vec3 bar = vec3(1.0, 0.0, 0.0);
        float acc = 0.0;
        for (int i = 0; i < 17; ++i) {
            if (uv.x >= acc && uv.x < acc + w[i]) bar = AMB_BIOME_HORIZON[i];
            if (w[i] > 0.002 && abs(uv.x - acc) < pixel) bar = vec3(0.0);
            acc += w[i];
        }
        float maxWeight = 0.0;
        for (int i = 0; i < 17; ++i) maxWeight = max(maxWeight, w[i]);
        AmbBiome biomeNow = ambBiome();
#if BIOME_DEBUG_MODE == 1
        if (uv.y > 0.92) debugOut = bar;
#elif BIOME_DEBUG_MODE == 2
        // Swatches of this frame's palette: zenith, mid, horizon = fog, cloud top, cloud
        // underside, Nether tint.
        if (uv.y > 0.80) {
            int slot = int(uv.x * 6.0);
            debugOut = slot == 0 ? vPalZenith : slot == 1 ? vPalMid : slot == 2 ? vPalHorizon :
                       slot == 3 ? vPalCloudTop : slot == 4 ? vPalCloudUnder : ambNetherFogTint();
        }
#elif BIOME_DEBUG_MODE == 3
        // Terrain in the last 15 % before the fog end minus the sky behind it, x8: black in
        // every biome (the fog colour is the sky function).
        debugOut = vec3(0.0);
        if (sceneDepth < 0.99999 && !cloudPixel && isEyeInWater == 0) {
            float edge = smoothstep(far * FOG_END * 0.85, far * FOG_END, length(playerPosition.xz));
            vec3 skyBehind = ambienceSky(worldViewRay(uv), vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
            debugOut = abs(colorAfterFog - skyBehind) * edge * 8.0;
        }
#elif BIOME_DEBUG_MODE == 4
        // Effective fog density multiplier as grey (0.5 = x1.0), the dust layer in red.
        float character = BIOME_DENSITY_MULTIPLIER_STRENGTH * biomeNow.strength;
        float densityNow = mix(1.0, clamp(biomeNow.density, 0.5, 1.6), character);
        debugOut = vec3(0.5 * densityNow);
#ifdef BIOME_DESERT_DUST
        debugOut.r += 0.5 * biomeNow.dust * character;
#endif
#elif BIOME_DEBUG_MODE == 5
        // Transition: grey = the largest family weight (1 = settled); it moves smoothly while
        // the camera crosses a border. The weight bar is on top.
        debugOut = vec3(maxWeight);
        if (uv.y > 0.92) debugOut = bar;
#elif BIOME_DEBUG_MODE == 6
        // Palette table: 17 columns (family 0-16), horizon colour above, zenith below, cloud
        // tint in the middle band; the current or forced family gets a white frame.
        int column = clamp(int(uv.x * 17.0), 0, 16);
        debugOut = uv.y > 0.55 ? AMB_BIOME_HORIZON[column] : (uv.y > 0.45 ? AMB_BIOME_CLOUD[column] : AMB_BIOME_ZENITH[column]);
        float cell = fract(uv.x * 17.0);
        if (w[column] >= maxWeight - 1.0e-4 && (cell < 0.04 || cell > 0.96)) debugOut = vec3(1.0);
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef LIGHT_DEBUG
    {
        // Update-1 diagnostics (sun rays, cloud occlusion, underwater caustics); the expected
        // look of each view is in the README. Views 7, 9, 10, 13, 15-17 are written by the
        // terrain program and returned at the top of main; view 8 is a split of the normal image.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        float debugCameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
#if LIGHT_DEBUG_MODE == 1
        // Sun visibility V (yellow) and the share of the sun behind clouds (blue), full screen:
        // both change smoothly while an edge crosses the sun.
        debugOut = color * 0.25 + vec3(1.0, 0.85, 0.3) * (vSunVisibility * vSunScreenFade * 0.75) +
                   vec3(0.2, 0.4, 1.0) * (vSunCloudCover * 0.75);
#elif LIGHT_DEBUG_MODE == 2
        // Open-sky mask of the shafts (quarter resolution, linear filtering): soft edges, no grain.
        debugOut = vec3(texture(colortex5, vTexCoord).a);
#elif LIGHT_DEBUG_MODE == 3
        // Rim alone: thin light only on silhouette edges turned to the sun, right around it.
        debugOut = vec3(gLightDebugRim);
#elif LIGHT_DEBUG_MODE == 4
        // Shafts alone (x4): faint streaks from gaps, fading with the angle to the sun.
        debugOut = vec3(gLightDebugShaft * 4.0);
#elif LIGHT_DEBUG_MODE == 5
        // Clouds: red = marker opacity (1 = hides the sun), green = linear depth / (4 x render
        // distance), black elsewhere.
        debugOut = vec3(0.0);
#ifdef AMB_CLOUD_MARKER
        if (cloudPixel) debugOut = vec3(ambienceInfo.g, clamp(raysLinearDepth(sceneDepth) / (4.0 * far), 0.0, 1.0), 0.0);
#endif
#elif LIGHT_DEBUG_MODE == 6
        // Hidden by clouds: cloud pixels in front of the sun square red, in front of the moon
        // blue, at night cyan (stars behind them hidden); other clouds grey; the sky dimmed.
        debugOut = color * 0.25;
        if (cloudPixel) {
            debugOut = vec3(0.30);
            vec4 sunBehind = ambSunDisc(debugDir, vSunWorld, finalPixelAngle());
            vec3 moonPlane = ambCelestialPlane(debugDir, -vSunWorld);
            bool moonBehind = moonPlane.z > 0.0 && max(abs(moonPlane.x), abs(moonPlane.y)) < AMB_MOON_HALF;
            if (vSunElevation < -0.10) debugOut = vec3(0.0, 0.55, 0.60);
            if (moonBehind) debugOut = vec3(0.15, 0.35, 1.0);
            if (sunBehind.a > 0.0) debugOut = vec3(1.0, 0.15, 0.10);
        }
#elif LIGHT_DEBUG_MODE == 11
        // Camera in water: blue full screen (black above water); the bar on top is the surface
        // fade (it ramps up over the first 0.4 blocks below the surface).
        debugOut = isEyeInWater == 1 ? vec3(0.0, 0.45, 0.85) : vec3(0.0);
#ifdef CAUSTICS_UNDERWATER_FLOOR
        if (vTexCoord.y > 0.95) debugOut = vec3(smoothstep(0.05, 0.40, vclWaterSurfaceY - debugCameraY) * float(isEyeInWater == 1));
#endif
#elif LIGHT_DEBUG_MODE == 12
        // Estimated camera depth below the surface: grey = depth / 16 blocks; red above water.
        debugOut = vec3(1.0, 0.0, 0.0);
#ifdef CAUSTICS_UNDERWATER_FLOOR
        if (isEyeInWater == 1) debugOut = vec3(clamp((vclWaterSurfaceY - debugCameraY) / 16.0, 0.0, 1.0));
#endif
#elif LIGHT_DEBUG_MODE == 14
        // Water surface in front of the pixel (seen from below with the camera underwater):
        // white = surface, where underwater caustics must never appear.
        debugOut = color * 0.2;
#ifdef AMB_FINAL_INFO
        if (waterPixel) debugOut = isEyeInWater == 1 ? vec3(1.0) : vec3(0.35, 0.35, 0.5);
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef MOON_DEBUG
    {
        // Update-2A diagnostics (moon light, sun/moon handover, sun identity); the expected look
        // of each view is in the README.
        vec3 debugOut = color;
        vec3 debugDir = worldViewRay(vTexCoord);
        AmbMoon dMoon = finalMoon();
        float dPixelAngle = finalPixelAngle();
        vec3 dPlane = ambCelestialPlane(debugDir, dMoon.dir);
        float dSquare = dPlane.z > 0.0 ? max(abs(dPlane.x), abs(dPlane.y)) : 10.0;
#if MOON_DEBUG_MODE == 1
        // Ray weights over a whole day: x = sun altitude from -90 (left) to +90 degrees (right),
        // y = weight 0 (10 % from the bottom) to 1 (10 % from the top); yellow = the sun's
        // (veil, rim, shafts), blue = the moon's (this phase and weather, moon opposite the sun),
        // white line = now. Both curves are smooth; they overlap only a little, near 0 degrees.
        float sunAltitude = (vTexCoord.x * 2.0 - 1.0) * 1.5707963;
        vec3 sunD = vec3(cos(sunAltitude), sin(sunAltitude), 0.0);
        float y = (vTexCoord.y - 0.1) / 0.8;
        float sunCurve = y - ambSunGlowVisibility(sunD);
        float moonCurve = y - clamp(ambMoonLight(-sunD, sunD, moonPhase), 0.0, 1.0);
        debugOut = color * 0.25;
        if (abs(y) * 0.8 * viewHeight < 1.0 || abs(y - 1.0) * 0.8 * viewHeight < 1.0) debugOut = vec3(0.35);
        if (abs(sunCurve) / max(length(vec2(dFdx(sunCurve), dFdy(sunCurve))), 1.0e-6) < 1.5) debugOut = vec3(1.0, 0.85, 0.2);
        if (abs(moonCurve) / max(length(vec2(dFdx(moonCurve), dFdy(moonCurve))), 1.0e-6) < 1.5) debugOut = vec3(0.35, 0.55, 1.0);
        float nowX = (asin(clamp(vSunElevation, -1.0, 1.0)) / 1.5707963 + 1.0) * 0.5;
        if (abs(vTexCoord.x - nowX) * viewWidth < 1.0) debugOut = vec3(1.0);
#elif MOON_DEBUG_MODE == 2
        // Moon position: its disc square (light blue) and sprite quad (dark blue) outlined on the
        // sky, crosshairs at the screen positions (blue moon, yellow sun; only when in front),
        // altitude bars at the left edge (moon, then sun; -90 at the bottom, +90 at the top).
        debugOut = color * 0.3;
        if (abs(dSquare - AMB_MOON_HALF) < dPixelAngle) debugOut = vec3(0.45, 0.65, 1.0);
        if (abs(dSquare - 4.0 * AMB_MOON_HALF) < dPixelAngle) debugOut = vec3(0.20, 0.30, 0.60);
        if (vMoonInFront > 0.5 && (abs(vTexCoord.x - vMoonUV.x) * viewWidth < 1.0 || abs(vTexCoord.y - vMoonUV.y) * viewHeight < 1.0)) debugOut = mix(debugOut, vec3(0.3, 0.5, 1.0), 0.6);
        if (vSunInFront > 0.5 && (abs(vTexCoord.x - vSunUV.x) * viewWidth < 1.0 || abs(vTexCoord.y - vSunUV.y) * viewHeight < 1.0)) debugOut = mix(debugOut, vec3(1.0, 0.85, 0.2), 0.6);
        if (vTexCoord.x < 0.015) debugOut = vTexCoord.y < 0.5 + 0.5 * dMoon.dir.y ? vec3(0.3, 0.5, 1.0) : vec3(0.0);
        else if (vTexCoord.x < 0.03) debugOut = vTexCoord.y < 0.5 + 0.5 * vSunElevation ? vec3(1.0, 0.85, 0.2) : vec3(0.0);
#elif MOON_DEBUG_MODE == 3 || MOON_DEBUG_MODE == 4 || MOON_DEBUG_MODE == 5
        // One glow term alone (x4, halo x2): smooth, round (or leaning to the lit side with
        // MOON_GLOW_QUALITY 2), black on the disc itself, no steps or rings.
        AmbMoonGlow dGlow = ambMoonGlowTerms(debugDir, dMoon, dPixelAngle);
#if MOON_DEBUG_MODE == 3
        debugOut = vec3(dGlow.bloom * 4.0);
#elif MOON_DEBUG_MODE == 4
        debugOut = vec3(dGlow.mid * 4.0);
#else
        debugOut = vec3(dGlow.halo * 2.0);
#endif
#elif MOON_DEBUG_MODE == 6
        // Moon visibility V (blue) and the share of the moon behind clouds (cyan), full screen:
        // both change smoothly while an edge or a cloud crosses the moon.
        debugOut = color * 0.25 + vec3(0.3, 0.5, 1.0) * (vMoonRays.x * vMoonRays.z * 0.75) + vec3(0.0, 0.8, 0.8) * (vMoonRays.y * 0.75);
#elif MOON_DEBUG_MODE == 7
        // Moon veil alone (x8): a faint smooth glow over terrain near the moon, none on the sky.
        debugOut = vec3(gMoonDebugVeil * 8.0);
#elif MOON_DEBUG_MODE == 8
        // Moon rim alone (x4): thin light only on silhouette edges turned to the moon.
        debugOut = vec3(gMoonDebugRim * 4.0);
#elif MOON_DEBUG_MODE == 9
        // Moon shafts alone (x32): faint streaks from gaps toward the moon, narrower than the sun's.
        debugOut = vec3(gMoonDebugShaft * 32.0);
#elif MOON_DEBUG_MODE == 10
        // Clouds over the moon: cloud pixels in front of the disc blue, other clouds grey, plus
        // the silver patch weight in green; the bar on top: moon V (blue), cloud cover (cyan).
        debugOut = color * 0.25;
        if (cloudPixel) {
            debugOut = dSquare < AMB_MOON_HALF ? vec3(0.15, 0.35, 1.0) : vec3(0.30);
            debugOut.g += 1.5 * clamp(CLOUD_MOON_GLOW_THROUGH * ambCloudMoonGlow(debugDir, dMoon), 0.0, 0.60);
        }
        if (vTexCoord.y > 0.97) {
            debugOut = vTexCoord.x < vMoonRays.x ? vec3(0.3, 0.5, 1.0) : (vTexCoord.x < vMoonRays.x + vMoonRays.y ? vec3(0.0, 0.8, 0.8) : vec3(0.0));
        }
#elif MOON_DEBUG_MODE == 11
        // Everything the moon adds (x4): on the sky its glow and halo, on terrain and clouds its
        // veil, rim and shafts. Clamped; dark everywhere except around the moon.
        if (skyPixel) {
            debugOut = abs(ambienceSkyFullMoon(debugDir, vSunWorld, finalPalette(), dMoon, dPixelAngle) -
                           ambienceSkyFull(debugDir, vSunWorld, finalPalette(), 0.0, dPixelAngle)) * 4.0;
        } else {
            debugOut = abs(gMoonDebugRaysAfter - gMoonDebugRaysBefore) * 4.0;
        }
        debugOut = clamp(debugOut, 0.0, 1.0);
#elif MOON_DEBUG_MODE == 12
        // Dark banding test: each 8-bit step of the output becomes a stripe (mod 4). Left half
        // without the dither: wide clean rings = banding; right half with the final dither (night
        // boost included): the stripes dissolve into a fine, static grain.
        float dDither = vTexCoord.x < 0.5 ? 0.0 : ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * (1.0 + finalNightDitherBoost(color));
        vec3 codes = floor(clamp(color + dDither, 0.0, 1.0) * 255.0 + 0.5);
        debugOut = mod(codes, 4.0) / 3.0;
        if (abs(vTexCoord.x - 0.5) * viewWidth < 0.75) debugOut = vec3(1.0, 0.0, 0.0);
#elif MOON_DEBUG_MODE == 13
        // Sun identity check: red = the sky's sun part now minus before (x4096), green = the
        // sun's veil, rim and shafts through the new CelestialLight path minus the previous code
        // (x4096). Expected: black everywhere, at any time (blue tint = the moon has light now).
        debugOut = vec3(0.0, 0.0, dMoon.light > 0.0 ? 0.15 : 0.0);
        if (skyPixel) {
            AmbMoon dark = dMoon;
            dark.light = 0.0;
            vec3 skyBefore = ambienceSkyFull(debugDir, vSunWorld, finalPalette(), 0.0, dPixelAngle);
            vec3 skyNowSun = ambienceSkyFullMoon(debugDir, vSunWorld, finalPalette(), dark, dPixelAngle);
            debugOut.r = clamp(4096.0 * length(skyNowSun - skyBefore), 0.0, 1.0);
        } else if (gMoonDebugTerrain > 0.5) {
            vec3 previous = finalSunRaysPrevious(gMoonDebugSunBefore, debugDir, playerPosition, sceneDepth, cloudPixel);
            debugOut.g = clamp(4096.0 * length(gMoonDebugSunAfter - previous), 0.0, 1.0);
        }
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef SKY_DEBUG
    {
        // Patch 2.1 sky diagnostics; the expected look of each view is in the README. Sky layers
        // are shown on sky pixels (x4 where faint), everything else is the dimmed image.
        vec3 debugOut = color * 0.25;
        vec3 debugDir = worldViewRay(vTexCoord);
        AmbPalette dPal = finalPalette();
        float dPixelAngle = finalPixelAngle();
        vec3 dSkyHaze = ambienceSky(debugDir, vSunWorld, vPalZenith, vPalMid, vPalHorizon, vPalGlow, vPalGolden);
#ifdef MOON_RAYS
        vec3 dSkyFull = ambienceSkyFullMoon(debugDir, vSunWorld, dPal, finalMoon(), dPixelAngle);
        AmbMoon dDark = finalMoon();
        dDark.light = 0.0;
        vec3 dSkyNoMoon = ambienceSkyFullMoon(debugDir, vSunWorld, dPal, dDark, dPixelAngle);
#else
        vec3 dSkyFull = ambienceSkyFull(debugDir, vSunWorld, dPal, moonBrightness, dPixelAngle);
        vec3 dSkyNoMoon = ambienceSkyFull(debugDir, vSunWorld, dPal, 0.0, dPixelAngle);
#endif
#if SKY_DEBUG_MODE == 1
        // The analytic sky alone (gradient, haze, glows, sun disc): smooth everywhere.
        if (skyPixel) debugOut = dSkyFull;
#elif SKY_DEBUG_MODE == 2
        // The palette gradient alone.
        if (skyPixel) debugOut = ambSkyGradient(debugDir, vPalZenith, vPalMid, vPalHorizon);
#elif SKY_DEBUG_MODE == 3
        // Golden tint, wide halo and haze scattering over the gradient (x4).
        if (skyPixel) debugOut = abs(dSkyHaze - ambSkyGradient(debugDir, vPalZenith, vPalMid, vPalHorizon)) * 4.0;
#elif SKY_DEBUG_MODE == 4
        // The sun's glow and disc (the difference they make).
        if (skyPixel) debugOut = abs(dSkyNoMoon - dSkyHaze);
#elif SKY_DEBUG_MODE == 5
        // The moon's glow and halo (x4).
        if (skyPixel) debugOut = abs(dSkyFull - dSkyNoMoon) * 4.0;
#elif SKY_DEBUG_MODE == 6
        // What vanilla draws on top of the sky (stars, the moon sprite), x4.
        if (skyPixel) debugOut = max(scene.rgb - dSkyFull - vec3(0.004), vec3(0.0)) * smoothstep(0.035, 0.07, debugDir.y) * 4.0;
#elif SKY_DEBUG_MODE == 7
        // Procedural stars alone (x8): night only, zero by day.
        debugOut = vec3(0.0);
#ifdef PROCEDURAL_STARS
        if (skyPixel) debugOut = vec3(evaluateProceduralStars(debugDir) * 0.22 * 8.0);
#endif
#elif SKY_DEBUG_MODE == 8
        // Red: the cells of the fake birds (GOLDEN_FAKE_BIRDS) at this moment, drawn or not (with
        // SKY_PIXEL_FIX they are removed; these were the stray dark pixels). Yellow: the
        // quarter-resolution layer added to the sky (bloom wash and pollen motes), x8.
        if (skyPixel) {
            debugOut = vec3(0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES)
            debugOut = vec3(1.0, 0.85, 0.2) * ambLuma(texture(colortex5, vTexCoord).rgb) * 8.0;
#endif
            if (skyDebugBirds(vTexCoord) > 0.0) debugOut = vec3(1.0, 0.1, 0.1);
        }
#elif SKY_DEBUG_MODE == 9
        // Invalid values (NaN, infinity, out of range): magenta = the final colour here, red = the
        // scene buffer colortex0, orange = the quarter-resolution buffer. Expected: none.
        if (!skyColorValid(texture(colortex0, vTexCoord).rgb)) debugOut = vec3(1.0, 0.0, 0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(RAYS_SHAFTS)
        if (!skyColorValid(texture(colortex5, vTexCoord).rgb)) debugOut = vec3(1.0, 0.5, 0.0);
#endif
        if (!skyColorValid(color)) debugOut = vec3(1.0, 0.0, 1.0);
#elif SKY_DEBUG_MODE == 10
        // Isolated pixels in the sky: the composed sky (as final builds it, before grading) at this
        // pixel against four neighbours 8 pixels away. Magenta = darker than all four by more than
        // 3/255 (never expected in an empty sky), cyan = brighter than all four (stars, the sun and
        // moon discs are expected here). Sky pixels are dimmed, the rest black.
        debugOut = vec3(0.0);
        bool dCentreSky;
        ivec2 dPx = ivec2(gl_FragCoord.xy);
        vec3 dCentre = skyDebugCompose(dPx, dCentreSky);
        if (dCentreSky) {
            debugOut = dCentre * 0.3;
            float lc = ambLuma(dCentre);
            float darker = 0.0;
            float brighter = 0.0;
            float usable = 0.0;
            ivec2 dOff[4] = ivec2[4](ivec2(8, 0), ivec2(-8, 0), ivec2(0, 8), ivec2(0, -8));
            for (int i = 0; i < 4; ++i) {
                bool nSky;
                vec3 n = skyDebugCompose(clamp(dPx + dOff[i], ivec2(0), ivec2(viewWidth, viewHeight) - 1), nSky);
                if (!nSky) continue;
                usable += 1.0;
                float ln = ambLuma(n);
                if (lc < ln - 3.0 / 255.0) darker += 1.0;
                if (lc > ln + 3.0 / 255.0) brighter += 1.0;
            }
            if (usable >= 3.0 && darker == usable) debugOut = vec3(1.0, 0.0, 1.0);
            if (usable >= 3.0 && brighter == usable) debugOut = vec3(0.0, 1.0, 1.0);
        }
#elif SKY_DEBUG_MODE == 11
        // Sky mask: grey = sky by both tests, black = not sky by both, white = the exact test
        // (depth >= 1.0) and the pack's epsilon test (depth > 0.99999) disagree.
        bool exactSky = sceneDepth >= 1.0;
        bool epsilonSky = sceneDepth > 0.99999;
        debugOut = exactSky != epsilonSky ? vec3(1.0) : (epsilonSky ? vec3(0.5) : vec3(0.0));
#elif SKY_DEBUG_MODE == 12
        // The quarter-resolution buffer colortex5: left half RGB x4 (bloom, shallow-water shafts,
        // pollen), right half alpha (the shaft mask or the shafts).
        debugOut = vec3(0.0);
#if defined(BLOOM) || defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(RAYS_SHAFTS)
        vec4 dQuarter = texture(colortex5, vTexCoord);
        debugOut = vTexCoord.x < 0.5 ? dQuarter.rgb * 4.0 : vec3(dQuarter.a);
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef ADAPT_DEBUG
    {
        // Patch 2.1 adaptive-eyes diagnostics; the expected look of each view is in the README.
        // Bars run left to right over the top of the screen on the dimmed image.
        vec3 debugOut = color * 0.35;
        float xCaveD = log2(max(float(ADAPT_MAX_BRIGHTEN), 1.0));
        float barScale = 1.0 / max(xCaveD + 0.5, 0.5);
        float lineW = 1.5 / viewHeight;
        float y = vTexCoord.y;
        vec4 dHistory = texelFetch(colortex6, ivec2(0, 0), 0);
#if ADAPT_DEBUG_MODE == 1
        // Exposure graph, the last 12.7 seconds (newest at the right, a tick every second):
        // white = the gain applied, blue = the gain the light asks for (tier 1), orange = tier 2's
        // change (around the middle line), yellow = over-brightness. Scale: the bottom is no gain,
        // the top 0.5 stop above ADAPT_MAX_BRIGHTEN.
        debugOut = color;
        if (y > 0.70) {
            float gy = (y - 0.70) / 0.30;
            debugOut = vec3(0.05);
            int current = 1 + int(mod(floor(frameTimeCounter * 10.0), 127.0));
            int age = int(floor((1.0 - vTexCoord.x) * 126.0));
            int slot = 1 + int(mod(float(current - 1 - age) + 254.0, 127.0));
            vec4 s = texelFetch(colortex6, ivec2(slot, 0), 0);
            float tick = abs(fract((1.0 - vTexCoord.x) * 12.6 + 0.5) - 0.5) * viewWidth / 12.6;
            if (tick < 0.75) debugOut = vec3(0.22);
            float h = lineW / 0.30;
            if (abs(gy - 0.5) < h * 0.5) debugOut = vec3(0.30);
            if (abs(gy - (0.5 + 0.5 * s.z / max(float(ADAPT_SCENE_REFINE_LIMIT), 0.1))) < h) debugOut = vec3(1.0, 0.55, 0.1);
            if (abs(gy - s.w * barScale) < h) debugOut = vec3(1.0, 0.9, 0.2);
            if (abs(gy - s.y * barScale) < h) debugOut = vec3(0.3, 0.55, 1.0);
            if (abs(gy - s.x * barScale) < h) debugOut = vec3(1.0);
        }
#elif ADAPT_DEBUG_MODE == 2
        // The gain now: the bar's length is the gain (linear light) from 1 (left) to
        // ADAPT_MAX_BRIGHTEN (right); the screen turns bluer as the gain rises.
        debugOut = mix(color * 0.5, vec3(0.2, 0.4, 1.0), 0.5 * clamp(vAdaptDebugGain / max(xCaveD, 0.01), 0.0, 1.0));
        if (y > 0.95) debugOut = vTexCoord.x < (exp2(vAdaptDebugGain) - 1.0) / max(float(ADAPT_MAX_BRIGHTEN) - 1.0, 0.01) ? vec3(1.0) : vec3(0.1);
#elif ADAPT_DEBUG_MODE == 3
        // Targets (each bar: no gain at the left, ADAPT_MAX_BRIGHTEN + 0.5 stop at the right):
        // green = the eyes (tier 1, smoothed), blue = what the light asks for, orange = tier 2's
        // change (centre = none, the grey ticks are its limit), white = the final gain.
        float limitD = ADAPT_SCENE_LUMA_WEIGHT * float(ADAPT_SCENE_REFINE_LIMIT) * barScale;
        if (y > 0.94) debugOut = vTexCoord.x < vAdaptDebug.x * barScale ? vec3(0.2, 0.9, 0.3) : vec3(0.08);
        else if (y > 0.88) debugOut = vTexCoord.x < vAdaptDebug.y * barScale ? vec3(0.3, 0.55, 1.0) : vec3(0.08);
        else if (y > 0.82) {
            float c = 0.5 + 0.5 * vAdaptDebug.w * barScale;
            debugOut = (vTexCoord.x - 0.5) * (c - 0.5) > 0.0 && abs(vTexCoord.x - 0.5) < abs(c - 0.5) ? vec3(1.0, 0.55, 0.1) : vec3(0.08);
            if (abs(abs(vTexCoord.x - 0.5) - 0.5 * limitD) * viewWidth < 1.0) debugOut = vec3(0.5);
        }
        else if (y > 0.76) debugOut = vTexCoord.x < vAdaptDebugGain * barScale ? vec3(1.0) : vec3(0.08);
#elif ADAPT_DEBUG_MODE == 4
        // Scene taps of tier 2: green = measured, red = left out (sky or cloud); the larger ones
        // are the centre group.
        debugOut = color * 0.5;
        for (int i = 0; i < ADAPT_TAP_COUNT; ++i) {
            vec3 tap = adaptTap(i);
            vec2 d = (vTexCoord - tap.xy) * vec2(viewWidth, viewHeight);
            float radius = tap.z > 0.5 ? mix(5.0, 12.0, ADAPT_CENTER_WEIGHT) : 5.0;
            if (dot(d, d) < radius * radius) {
                ivec2 texel = ivec2(tap.xy * vec2(viewWidth, viewHeight));
                bool excluded = texelFetch(depthtex0, texel, 0).r > 0.99999;
#ifdef AMB_CLOUD_MARKER
                vec4 tapInfo = texelFetch(colortex1, texel, 0);
                excluded = excluded || (tapInfo.a > 0.5 && tapInfo.r < 0.5);
#endif
                debugOut = excluded ? vec3(1.0, 0.15, 0.1) : vec3(0.2, 1.0, 0.3);
            }
        }
#elif ADAPT_DEBUG_MODE == 5
        // Scene luminance (tier 2): the screen shows the measured log-average as a grey; the bars:
        // white = measured, blue = what the light at the camera predicts (-10 stops at the left,
        // +2 at the right, the tick is the daylight reference).
        float measuredD = dHistory.w > 0.5 ? dHistory.z : 0.0;
        float expectedD = log2(exp2(-max(vclAdaptDark, 0.0)) + ADAPT_FLOOR);
        debugOut = vec3(pow(clamp(exp2(measuredD) * ADAPT_Y_REF, 0.0, 1.0), 1.0 / 2.2));
        if (y > 0.94) debugOut = vTexCoord.x < (measuredD + 10.0) / 12.0 ? vec3(1.0) : vec3(0.08);
        else if (y > 0.88) debugOut = vTexCoord.x < (expectedD + 10.0) / 12.0 ? vec3(0.3, 0.55, 1.0) : vec3(0.08);
        if (y > 0.88 && abs(vTexCoord.x - 10.0 / 12.0) * viewWidth < 1.0) debugOut = vec3(1.0, 0.2, 0.2);
#elif ADAPT_DEBUG_MODE == 6
        // Over-bright moment (yellow, 0 to 1 stop) and punch (magenta, 0 to 1).
        if (y > 0.94) debugOut = vTexCoord.x < vAdaptDebug.z ? vec3(1.0, 0.9, 0.2) : vec3(0.08);
        else if (y > 0.88) debugOut = vTexCoord.x < vAdaptA.w ? vec3(1.0, 0.3, 0.9) : vec3(0.08);
#elif ADAPT_DEBUG_MODE == 7
        // Split: left without the exposure stage, right with it (the normal image otherwise).
        debugOut = color;
        if (abs(vTexCoord.x - 0.5) * viewWidth < 0.75) debugOut = vec3(1.0, 0.0, 0.0);
#elif ADAPT_DEBUG_MODE == 8
        // Dark banding test: the 8-bit output (dither included) stretched 6 x, so codes 0-42
        // fill the range. Wide clean bands in the cave walls = banding; a fine static grain = OK.
        vec3 dithered = color + ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * (1.0 + finalNightDitherBoost(color)) +
                        ambDither(gl_FragCoord.xy) * (ADAPT_DITHER / 255.0) * vAdaptB.z;
        vec3 codes = floor(clamp(dithered, 0.0, 1.0) * 255.0 + 0.5);
        debugOut = clamp(codes * 6.0 / 255.0, 0.0, 1.0);
#elif ADAPT_DEBUG_MODE == 9
        // Local lift: grey = the extra factor of the toe (x2: mid grey = 1.25 x).
        float lumaD = adaptLuma(adaptBefore) * vAdaptA.x;
        debugOut = vec3(clamp(2.0 * vAdaptA.y * 0.0036 / ((lumaD + 0.06) * (lumaD + 0.06)), 0.0, 1.0));
#elif ADAPT_DEBUG_MODE == 10
        // Highlight roll-off: left = the gain without the roll-off (red where it clips), right =
        // the real stage (red where a channel passes 0.98). Expected: no red in a window on the right.
        vec3 raw = adaptBefore * vAdaptA.x;
        vec3 rolled = adaptApply(adaptBefore, auxiliary, vAdaptA, vAdaptB);
        bool left = vTexCoord.x < 0.5;
        vec3 shown = left ? raw : rolled;
        debugOut = clamp(shown, 0.0, 1.0);
        if (max(shown.r, max(shown.g, shown.b)) > (left ? 1.0 : 0.98)) debugOut = vec3(1.0, 0.0, 0.0);
        if (abs(vTexCoord.x - 0.5) * viewWidth < 0.75) debugOut = vec3(1.0);
#endif
#if ADAPT_DEBUG_MODE != 7
        gl_FragColor = vec4(debugOut, 1.0);
        return;
#else
        color = debugOut;
#endif
    }
#endif

#ifdef UNDERWATER_DEBUG
    {
        // Update 3 underwater diagnostics; the expected look of each view is in the README.
        vec3 debugOut = color * 0.3;
        vec3 debugDir = worldViewRay(vTexCoord);
        float debugDist = skyPixel ? 1.0e4 : length(playerPosition);
#if UNDERWATER_DEBUG_MODE == 1
        // Eye in water: blue full screen (black above water); the bar on top is the crossing fade.
        debugOut = isEyeInWater == 1 ? vec3(0.0, 0.40, 0.85) : vec3(0.0);
        if (vTexCoord.y > 0.95) debugOut = vTexCoord.x < vclUwFade ? vec3(1.0) : vec3(0.1);
#elif UNDERWATER_DEBUG_MODE == 2
        // Estimated camera depth below the surface: grey = depth / 40 blocks; the bar = depth / 64.
        debugOut = vec3(clamp(vclUwDepth / 40.0, 0.0, 1.0));
        if (vTexCoord.y > 0.95) debugOut = vTexCoord.x < vclUwDepth / 64.0 ? vec3(0.3, 0.6, 1.0) : vec3(0.1);
#elif UNDERWATER_DEBUG_MODE == 3
        // Transmittance per channel at each pixel's distance (the background: 0); red goes first.
        debugOut = isEyeInWater == 1 ? uwTransmittance(debugDist) : vec3(1.0);
#elif UNDERWATER_DEBUG_MODE == 4
        // Brightness by view direction: dark looking down or away from the light, white looking up at it.
        debugOut = vec3(uwViewTerm(debugDir));
#elif UNDERWATER_DEBUG_MODE == 5
        // Tier 1 shafts alone (x 2): soft broad beams around the refracted sun, darker bands between.
        float debugT1 = uwShaftTier1(debugDir, float(UW_SHAFT_LENGTH)) * (1.0 - exp(-3.0 * (skyPixel ? 1.0e4 : debugDist) / float(UW_SHAFT_LENGTH)));
        debugOut = vec3(debugT1 * uwShaftLobe(debugDir) * 2.0);
#elif UNDERWATER_DEBUG_MODE == 6
        // Tier 2 shafts alone (x 2): like tier 1, with dark gaps behind terrain and floating blocks.
        debugOut = vec3(0.0);
#ifdef UNDERWATER_SHAFTS_TIER2
        debugOut = vec3(raysShaftUpsample(vTexCoord, raysLinearDepth(sceneDepth), vec2(viewWidth, viewHeight)) * uwShaftLobe(debugDir) * 2.0);
#endif
#elif UNDERWATER_DEBUG_MODE == 7
        // The light pattern on the surface above each point 8 blocks along the view: large smooth cells.
        vec2 debugWrap = vec2((cameraPositionInt.xz + ivec2(AMB_WRAP_OFFSET)) % ivec2(AMB_WRAP)) + cameraPositionFract.xz;
        vec3 debugPoint = debugDir * 8.0;
        debugOut = vec3(uwShaftPattern(uwSurfacePoint(debugPoint, max(vclUwDepth - debugPoint.y, 0.0)) + debugWrap, frameTimeCounter));
#elif UNDERWATER_DEBUG_MODE == 8
        // Snell window on the surface seen from below: white inside 48.6 degrees of the vertical, dark
        // blue outside, a soft edge (SNELL_WINDOW_SOFTNESS); everything else dimmed.
        float debugSoft = radians(float(SNELL_WINDOW_SOFTNESS));
        float debugInside = smoothstep(cos(0.8483 + debugSoft), cos(max(0.8483 - debugSoft, 0.0)), debugDir.y);
        debugOut = color * 0.25;
#ifdef AMB_FINAL_INFO
        if (waterPixel && isEyeInWater == 1) debugOut = mix(vec3(0.05, 0.10, 0.30), vec3(1.0), debugInside);
#endif
#elif UNDERWATER_DEBUG_MODE == 9
        // Split: left half without the underwater ambience (the previous look), right half with it.
        debugOut = color;
        if (abs(vTexCoord.x - 0.5) * viewWidth < 0.75) debugOut = vec3(1.0, 0.0, 0.0);
#endif
#if UNDERWATER_DEBUG_MODE != 9
        gl_FragColor = vec4(debugOut, 1.0);
        return;
#else
        color = debugOut;
#endif
    }
#endif

#ifdef NETHER_DEBUG
    {
        // Update 3 Nether diagnostics (views 4 and 5 are written by the terrain program).
        vec3 debugOut = color * 0.3;
        vec3 debugDir = worldViewRay(vTexCoord);
        float debugMidY = float(cameraPositionInt.y) + cameraPositionFract.y + (skyPixel ? 48.0 * debugDir.y : 0.5 * playerPosition.y);
#if NETHER_DEBUG_MODE == 1
        // Fog amount: black near, white far; the empty background is 1.
        debugOut = vec3(skyPixel ? 1.0 : netherFogAmount(length(playerPosition)));
#elif NETHER_DEBUG_MODE == 2
        // The fog colour by direction (x 2): one smooth function, ceiling a little darker.
        debugOut = netherFogColor(debugDir, debugMidY) * 2.0;
#elif NETHER_DEBUG_MODE == 3
        // Biome weights (bar on top): wastes brown, crimson red, warped teal, soul cyan, basalt grey;
        // below it the blended fog colour (x 2).
        debugOut = netherFogBase() * 2.0;
        if (vTexCoord.y > 0.92) {
            float debugW[5] = float[5](vclNWastes, vclNCrimson, vclNWarped, vclNSoul, vclNBasalt);
            vec3 debugC[5] = vec3[5](vec3(0.55, 0.25, 0.12), vec3(0.85, 0.10, 0.15), vec3(0.10, 0.65, 0.60), vec3(0.30, 0.75, 0.95), vec3(0.55, 0.55, 0.60));
            float debugSum = max(debugW[0] + debugW[1] + debugW[2] + debugW[3] + debugW[4], 1.0e-3);
            float debugAcc = 0.0;
            debugOut = vec3(0.05);
            for (int i = 0; i < 5; ++i) {
                float w = debugW[i] / debugSum;
                if (vTexCoord.x >= debugAcc && vTexCoord.x < debugAcc + w) debugOut = debugC[i];
                debugAcc += w;
            }
        }
#elif NETHER_DEBUG_MODE == 6
        // Lava-sea haze factor: bright near Y = 31, fading upward.
        debugOut = vec3(0.0);
#ifdef LAVA_SEA_HAZE
        debugOut = vec3(netherLavaHaze(debugMidY));
#endif
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

#ifdef END_DEBUG
    {
        // Update 3 End diagnostics (views 6 and 7 are written by the terrain program).
        vec3 debugOut = color * 0.3;
        vec3 debugDir = worldViewRay(vTexCoord);
        float y = vTexCoord.y;
#ifdef END_FLASHES
#if END_DEBUG_MODE == 1
        // Scheduler bars over the image, top to bottom: white = the envelope (/ 1.5), purple = the
        // game's flash intensity (smoothed), yellow = the double pulse, cyan = position in the 30-second
        // window, then this flash's colour and its peak factor.
        debugOut = color;
        if (y > 0.95) debugOut = vTexCoord.x < vFlashA.w / 1.5 ? vec3(1.0) : vec3(0.08);
        else if (y > 0.90) debugOut = vTexCoord.x < vclFlash ? vec3(0.70, 0.40, 0.90) : vec3(0.08);
        else if (y > 0.85) debugOut = vTexCoord.x < vclFlashBump ? vec3(1.0, 0.85, 0.2) : vec3(0.08);
        else if (y > 0.80) debugOut = vTexCoord.x < float(worldTime - (worldTime / 600) * 600) / 600.0 ? vec3(0.2, 0.9, 0.9) : vec3(0.08);
        else if (y > 0.75) debugOut = vTexCoord.x < 0.2 ? endFlashColor() : (vTexCoord.x < 0.2 + 0.4 * (vclFlashPeak - 0.5) ? vec3(0.6) : vec3(0.08));
#elif END_DEBUG_MODE == 2
        // Flash direction: the screen tinted by it (rgb = direction x 0.5 + 0.5), a magenta cross at its
        // screen position and a yellow ring 5 degrees around it.
        debugOut = mix(color * 0.4, vFlashA.xyz * 0.5 + 0.5, 0.45);
        if (abs(ambAngle(debugDir, vFlashA.xyz) - 0.0873) < 1.5 * finalPixelAngle()) debugOut = vec3(1.0, 0.9, 0.2);
        if (vFlashB.z > 0.5 && (abs(vTexCoord.x - vFlashB.x) * viewWidth < 1.0 || abs(vTexCoord.y - vFlashB.y) * viewHeight < 1.0)) debugOut = vec3(1.0, 0.3, 1.0);
#elif END_DEBUG_MODE == 3
        // Flash intensity (the envelope) as a grey level over the whole screen.
        debugOut = vec3(vFlashA.w);
#elif END_DEBUG_MODE == 4
        // The flash glow alone (x 3), by direction, on every pixel.
        debugOut = endFlashGlow(ambAngle(debugDir, vFlashA.xyz), endFlashColor(), vFlashA.w) * (FLASH_SKY_GLOW_STRENGTH * 3.0);
#elif END_DEBUG_MODE == 5
        // Update 4.1, the volumetric flash fog (terrain only): red = the share of the sky's glow held by the air in
        // front of this surface, green = the lit share of the view ray (composite1's volumetric shadow: dark =
        // the air in front is in the shadow of something between you and the flash).
        debugOut = vec3(0.0);
        if (!skyPixel) {
            float debugD = length(playerPosition);
            float debugLit = endFlashFogVisibility(vTexCoord, sceneDepth);
            debugOut = vec3(endFlashFogShare(debugD, debugLit), debugLit, 0.0);
        }
#elif END_DEBUG_MODE == 9
        // Shadow light check: green = shadowLightPosition is the sun or the moon (always in the
        // Overworld and the Nether: the original shadows), blue = the End flash (FLASH_SHADOWS in the
        // End), red = neither.
        vec3 debugL = normalize(shadowLightPosition);
        bool debugSunMoon = length(debugL - normalize(sunPosition)) < 2.0e-3 || length(debugL - normalize(moonPosition)) < 2.0e-3;
        bool debugFlash = dot(endFlashPosition, endFlashPosition) > 1.0 && length(debugL - normalize(endFlashPosition)) < 2.0e-3;
        debugOut = debugSunMoon ? vec3(0.1, 0.8, 0.2) : (debugFlash ? vec3(0.2, 0.4, 1.0) : vec3(0.9, 0.1, 0.1));
#elif END_DEBUG_MODE == 11
        // The flash shafts alone (x 8); black while FLASH_FOG_SHADOWS is on (view 5 shows the fog's lit share).
        debugOut = vec3(0.0);
#ifdef END_FLASH_SHAFTS
        debugOut = vec3(shaftDebug * 8.0);
#endif
#elif END_DEBUG_MODE == 12
        // Dragon fight (heavyFog): the screen turns red while the boss fog is on.
        debugOut = mix(color * 0.4, vec3(1.0, 0.1, 0.1), 0.6 * vclDragon);
#endif
#endif
#if END_DEBUG_MODE == 8
        // The shadow map (shadowtex0) as grey: in the End during a flash it shows the scene from the
        // flash direction.
        debugOut = vec3(texture(shadowtex0, vTexCoord).r);
#elif END_DEBUG_MODE == 10
        // Sky check on sky pixels (x 4), the rest dimmed. Left half: what was drawn into colortex0 (the
        // game's End sky box and its flash sprite; a flat band up to about 5 degrees would be Iris's
        // horizon fan, which gbuffers_skybasic discards in the End; only the clear colour during the
        // dragon fight, when the game draws no sky). Right half: the sky final builds (Update 4: the
        // smooth Vibrant Visuals sky, END_SKY_GRAIN adds the vanilla texture's grain).
        debugOut = skyPixel ? (vTexCoord.x < 0.5 ? scene.rgb : endSkyFull(debugDir)) * 4.0 : color * 0.2;
#endif
        gl_FragColor = vec4(debugOut, 1.0);
        return;
    }
#endif

    // Static triangular dither (SKY_DITHER x 1/255) before the 8-bit output: no banding in
    // the smooth sky, glow and fog gradients, no visible grain, no crawl (no frame input). At
    // night the dark regions get a little more (finalNightDitherBoost, 0 by day).
    float nightDitherBoost = finalNightDitherBoost(color);
#if defined(UNDERWATER_AMBIENCE) || defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
    // Update 3: deep water, the Nether and the End (0 in the Overworld above water).
    float dimensionDitherBoost = finalDimensionDitherBoost(color);
#endif
    color += ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0);
    if (nightDitherBoost > 0.0) color += ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * nightDitherBoost;
#if defined(UNDERWATER_AMBIENCE) || defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
    if (dimensionDitherBoost > 0.0) color += ambDither(gl_FragCoord.xy) * (SKY_DITHER / 255.0) * dimensionDitherBoost;
#endif
#ifdef ADAPTIVE_EYES
    // While the view is brightened: a little more of the same static dither (ADAPT_DITHER x 1/255
    // at the largest gain; no frame input, so it never crawls). 0 on the reference image.
    if (vAdaptB.z > 0.0) color += ambDither(gl_FragCoord.xy) * (ADAPT_DITHER / 255.0) * vAdaptB.z;
#endif
    gl_FragColor = vec4(color, scene.a);
}
