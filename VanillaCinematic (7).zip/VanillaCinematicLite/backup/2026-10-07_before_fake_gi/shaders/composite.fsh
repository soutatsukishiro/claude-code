#version 330 compatibility

#include "/lib/settings.glsl"

// Quarter-resolution helper pass: bloom, shallow-water shafts and pollen motes in RGB, and the
// pre-filtered open-sky mask for the shafts in alpha (SUN_SHAFTS, MOON_SHAFTS; composite1
// marches it toward whichever light owns the shafts this frame: one source, one channel).
// The old screen-space sun rays (random jitter, hard depth steps, a shadow-map read per pixel)
// were removed; the sun's glow and veil are analytic, the rim and shafts deterministic
// (lib/ambience.glsl, lib/sun_rays.glsl). The sun system never reads the shadow map; only the
// sunlit/shadow debug views of ATMOS_DEBUG and VV_DEBUG and the shallow-water shafts do.
#if (defined(ATMOS_DEBUG) && ATMOS_DEBUG_MODE == 1) || (defined(VV_DEBUG) && (VV_DEBUG_MODE == 1 || VV_DEBUG_MODE == 5))
#define COMPOSITE_SUNLIT_DEBUG
#endif

#ifdef BLOOM
uniform sampler2D colortex0;
#endif
#ifdef EMISSIVE_GLOW
// Update 4: the glow buffer. gbuffers_terrain, gbuffers_textured_lit and gbuffers_spidereyes write what
// each emitter emits (lib/gbuffers_forward.fsh); it is cleared to black every frame and its mip chain is
// built for this pass, so the glow reads 4 x 4 and 8 x 8 averages: steady on 2-pixel eyes, no shimmer.
uniform sampler2D colortex3;
const bool colortex3MipmapEnabled = true;
#endif
/*
const int colortex3Format = R11F_G11F_B10F;
const bool colortex3Clear = true;
const vec4 colortex3ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/

#if defined(SHALLOW_WATER_LIGHTING) || defined(ATMOSPHERIC_PARTICLES) || defined(COMPOSITE_SUNLIT_DEBUG) || defined(RAYS_SHAFTS) || defined(UNDERWATER_SHAFTS)
uniform sampler2D depthtex0;
#endif

#ifdef SHALLOW_WATER_LIGHTING
uniform sampler2D colortex1;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex1;
uniform sampler2D noisetex;
#elif defined(RAYS_SHAFTS) && (defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS))
// Cloud marker for the shaft mask (clouds are occluders).
uniform sampler2D colortex1;
#endif
#if defined(UNDERWATER_SHAFTS_TIER2) && !defined(SHALLOW_WATER_LIGHTING)
// Update 3: the opaque-only shadow map for the shadow-aware underwater shafts (read only).
uniform sampler2D shadowtex1;
#endif

#ifdef COMPOSITE_SUNLIT_DEBUG
uniform sampler2D shadowtex0;
#endif

// Plain uniforms are declared unconditionally (unused ones cost nothing); lib/ambience.glsl
// needs several of them for the cloud shadows on the shallow-water shafts.
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float thunderStrength;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform float frameTimeCounter;
uniform float atmosOverworld;
uniform float aspectRatio;
uniform float viewWidth;
uniform float viewHeight;
uniform float temperature;
uniform float rainfall;
uniform float atmosHumidBiome;
uniform float atmosCoolBiome;
uniform float atmosWoodlandBiome;
uniform float atmosSavannaBiome;
uniform float atmosDesertBiome;
uniform float far;

#include "/lib/ambience.glsl"
#ifdef RAYS_SHAFTS
#include "/lib/sun_rays.glsl"
#endif
#ifdef UNDERWATER_SHAFTS
// Update 3: the underwater fog's absorption and the shaft pattern (lib/dimension_ambience.glsl), with the
// tier-1 shaft function.
#define UW_TIER1_FUNCTIONS
#include "/lib/dimension_ambience.glsl"
#endif

in vec2 vTexCoord;
in vec2 vSunUV;
in float vSunElevation;
in float vSunInFront;
in vec2 vMoonUV;
in float vMoonElevation;
in float vMoonInFront;
#ifdef MOON_SHAFTS
flat in float vMoonShaftOwner;
#endif
#ifdef END_FLASH_SHAFTS
// The End flash: screen position (xy) and whether it owns the shafts this frame (z).
flat in vec3 vFlashShaft;
#endif

/* RENDERTARGETS: 5 */
/*
const int colortex5Format = RGBA16F;
*/
layout(location = 0) out vec4 postEffects;

#if defined(SHALLOW_WATER_LIGHTING) || defined(COMPOSITE_SUNLIT_DEBUG) || defined(UNDERWATER_SHAFTS_TIER2)
#include "/lib/shadow_distortion.glsl"
#endif

#ifdef ATMOSPHERIC_PARTICLES
float cheapHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}
#endif

#ifdef EMISSIVE_GLOW
// Update 4: the Vibrant Visuals glow around light sources, eyes, crystals and light-emitting items,
// gathered at quarter resolution from the glow buffer's mips: the centre and two rings of six taps (6 and
// 13 px at 1080p, scaled with the screen height), weights 0.20 / 0.30 / 0.50 (sum 1). Fitted to your
// reference's enderman eyes: +17 / +7 / +4 levels 6 / 12 / 18 px from the eye (model: +16 / +7 / +4),
// gone by about 25 px. Final adds it with the bloom (colortex5 RGB), before the fog, so distant glows
// fade with their emitter.
vec3 emissiveGlow(vec2 uv) {
    float scale = max(viewHeight * (1.0 / 1080.0), 0.5);
    vec2 px = scale / vec2(textureSize(colortex3, 0));
    float lod = 2.0 + log2(scale);
    vec3 g = textureLod(colortex3, uv, lod).rgb * 0.20;
    for (int i = 0; i < 6; ++i) {
        float a = float(i) * 1.0471976;
        vec2 d1 = vec2(cos(a), sin(a));
        vec2 d2 = vec2(cos(a + 0.5235988), sin(a + 0.5235988));
        g += textureLod(colortex3, uv + d1 * (6.0 * px), lod).rgb * 0.05;
        g += textureLod(colortex3, uv + d2 * (13.0 * px), lod + 1.0).rgb * 0.0833;
    }
    // Update 4.2: the wide halo of big bright emitters (your Vibrant Visuals image 7: the End crystal's glow
    // reaches about 60 px, +15 / +8 / +3 levels at 32 / 48 / 64 px from its centre; ours stopped near 25 px):
    // two rings of 8 taps at 36 and 60 px on the 16 x 16 and 32 x 32 px averages. A small source such as an
    // eye hardly reaches them (+1 level at 30 px), so the eyes' fitted glow stays as it was.
    for (int i = 0; i < 8; ++i) {
        float a = float(i) * 0.7853982 + 0.3;
        vec2 d3 = vec2(cos(a), sin(a));
        g += textureLod(colortex3, uv + d3 * (36.0 * px), lod + 2.0).rgb * 0.05;
        g += textureLod(colortex3, uv + d3 * (60.0 * px), lod + 3.0).rgb * 0.03;
    }
    return g * EMISSIVE_GLOW_STRENGTH;
}
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(COMPOSITE_SUNLIT_DEBUG)
vec4 reconstructView(vec2 uv, float depth) {
    return gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
}

float linearDepth(float depth) {
    vec4 viewH = reconstructView(vec2(0.0), depth);
    return -viewH.z / max(viewH.w, 0.0001);
}

vec3 reconstructWorldPosition(vec2 uv, float depth, out vec3 playerPosition) {
    vec4 viewH = reconstructView(uv, depth);
    vec3 viewPosition = viewH.xyz / max(viewH.w, 0.0001);
    playerPosition = (gbufferModelViewInverse * vec4(viewPosition, 1.0)).xyz;
    return cameraPosition + playerPosition;
}
#endif

#ifdef COMPOSITE_SUNLIT_DEBUG
float shadowVisibility(vec3 playerPosition) {
    vec4 shadowClip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    if (shadowClip.w <= 0.0001) return 0.0;
    vec3 shadowCoord = shadowClip.xyz / shadowClip.w * 0.5 + 0.5;
    if (shadowCoord.x < 0.0 || shadowCoord.x > 1.0 ||
        shadowCoord.y < 0.0 || shadowCoord.y > 1.0 ||
        shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
        return 0.0;
    }
    return step(shadowCoord.z - 0.00075, texture(shadowtex0, shadowCoord.xy).r);
}
#endif

#if defined(SHALLOW_WATER_LIGHTING) || defined(UNDERWATER_SHAFTS_TIER2)
float opaqueWaterShadowVisibility(vec3 playerPosition) {
    if (dot(playerPosition, playerPosition) > shadowDistance * shadowDistance) return 1.0;
    vec4 shadowClip = shadowProjection * shadowModelView * vec4(playerPosition, 1.0);
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    if (shadowClip.w <= 0.0001) return 1.0;
    vec3 shadowCoord = shadowClip.xyz / shadowClip.w * 0.5 + 0.5;
    if (shadowCoord.x < 0.0 || shadowCoord.x > 1.0 ||
        shadowCoord.y < 0.0 || shadowCoord.y > 1.0 ||
        shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
        return 1.0;
    }
    // This pass shades water receivers, so translucent water must not occlude its own light.
    return step(shadowCoord.z - 0.00075, texture(shadowtex1, shadowCoord.xy).r);
}
#endif

#ifdef UNDERWATER_SHAFTS_TIER2
// Update 3, tier 2 underwater shafts (quarter resolution, camera in water): UW_SHAFT_STEPS fixed
// steps from the camera along the view ray, up to the scene or UW_SHAFT_LENGTH blocks; at each step
// one opaque-only shadow-map read (is the point in sunlight? terrain and floating blocks cut dark
// gaps; the water never shadows itself), the surface light pattern above the point (the same as
// tier 1) and the absorption on the light's way down and back to the eye. Deterministic: the steps
// sit at the centres of equal segments, no jitter; composite1 blurs it by depth, final upsamples it
// by depth. The shadow map stays read only and untouched.
float uwShaftMarch(vec2 uv) {
    if (vclUwShaft <= 0.0005) return 0.0;
    float depth = texture(depthtex0, uv).r;
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec3 player = (gbufferModelViewInverse * vec4(viewH.xyz / max(viewH.w, 1.0e-4), 1.0)).xyz;
    float playerLength = length(player);
    vec3 dir = player / max(playerLength, 1.0e-4);
    float rayLength = depth > 0.99999 ? float(UW_SHAFT_LENGTH) : min(playerLength, float(UW_SHAFT_LENGTH));
    vec2 wrap = vec2((cameraPositionInt.xz + ivec2(AMB_WRAP_OFFSET)) % ivec2(AMB_WRAP)) + cameraPositionFract.xz;
    float sigma = dot(uwAbsorption(), vec3(0.0, 0.5, 0.5));
    float sum = 0.0;
    for (int i = 0; i < UW_SHAFT_STEPS; ++i) {
        float t = (float(i) + 0.5) / float(UW_SHAFT_STEPS) * rayLength;
        vec3 p = dir * t;
        float depthBelow = vclUwDepth - p.y;
        if (depthBelow > 0.0) {
            float lightPath = depthBelow / max(vclUwLy, 0.2) + t;
            float sunlit = opaqueWaterShadowVisibility(p);
            sum += sunlit * smoothstep(0.0, 0.6, depthBelow) * exp(-sigma * lightPath) *
                   uwShaftPattern(uwSurfacePoint(p, depthBelow) + wrap, frameTimeCounter);
        }
    }
    return sum / float(UW_SHAFT_STEPS);
}
#endif

#if defined(UNDERWATER_SHAFTS) && !defined(UNDERWATER_SHAFTS_TIER2)
// Update 3, tier 1 underwater shafts at quarter resolution (camera in water): the analytic surface
// pattern at three fixed points along the view ray over UW_SHAFT_LENGTH blocks (lib/dimension_ambience.glsl),
// independent of the scene, so it is a smooth function of the view direction only and final can
// upsample it with one bilinear fetch without any halo at silhouettes (final scales it by the water in
// front of each pixel).
float uwShaftTier1Quarter(vec2 uv) {
    if (vclUwShaft <= 0.0005) return 0.0;
    vec4 viewH = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    vec3 dir = mat3(gbufferModelViewInverse) * (viewH.xyz / max(viewH.w, 1.0e-6));
    return uwShaftTier1(dir * inversesqrt(max(dot(dir, dir), 1.0e-12)), float(UW_SHAFT_LENGTH));
}
#endif

void main() {
    vec2 uv = vTexCoord;
    vec3 postAdd = vec3(0.0);
#if defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
    float debugSunLitMask = 0.0;
    float debugShadowMask = 0.0;
    vec3 debugBloomBuffer = vec3(0.0);
#endif

#ifdef COMPOSITE_SUNLIT_DEBUG
    if (hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        float debugDepth = texture(depthtex0, uv).r;
        float debugDay = smoothstep(0.025, 0.24, vSunElevation) * vSunInFront;
        float debugCameraSky = smoothstep(24.0, 96.0, float(eyeBrightnessSmooth.y));
        if (debugDepth > 0.99999) {
            debugSunLitMask = debugDay * debugCameraSky;
            debugShadowMask = debugSunLitMask;
        } else if (debugDay > 0.001 && debugCameraSky > 0.001) {
            vec3 debugPlayer;
            reconstructWorldPosition(uv, debugDepth, debugPlayer);
            float debugVisibility = shadowVisibility(debugPlayer);
            debugSunLitMask = debugDay * debugCameraSky * debugVisibility;
            debugShadowMask = debugVisibility;
        }
    }
#endif

#ifdef BLOOM
    vec2 sourceTexel = 1.0 / vec2(textureSize(colortex0, 0));
    vec2 bloomUV = uv;
#ifdef GOLDEN_BLOCKY_BLOOM
    vec2 bloomResolution = vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
    float bloomCell = float(GOLDEN_BLOOM_PIXEL_SIZE);
    vec2 snappedBloomUV = (floor(uv * bloomResolution / bloomCell) + 0.5) * bloomCell / bloomResolution;
    bloomUV = mix(uv, snappedBloomUV, GOLDEN_BLOOM_BLOCKINESS * float(MATCH_STRENGTH) * 0.01);
#endif
    vec3 bright = max(texture(colortex0, bloomUV).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(-2.0, 0.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2( 2.0, 0.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(0.0, -2.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    bright += max(texture(colortex0, bloomUV + sourceTexel * vec2(0.0,  2.0)).rgb - vec3(BLOOM_THRESHOLD), vec3(0.0));
    // Existing five-tap thresholded quarter-resolution glow, bilinearly upsampled in final.
    vec3 bloomContribution = bright * 0.11 * BLOOM_STRENGTH;
    postAdd += bloomContribution;
#if defined(ATMOS_DEBUG) || defined(VV_DEBUG) || defined(TARGET_DEBUG)
    debugBloomBuffer = bloomContribution;
#endif
#endif

#ifdef SHALLOW_WATER_LIGHTING
    vec4 waterInfo = texture(colortex1, uv);
    bool shallowShaftsHere = true;
#ifdef UNDERWATER_AMBIENCE
    // Update 3: these shafts are for water seen from above; with the camera underwater they would add
    // unfogged light to the surface seen from below (the underwater shafts take over there).
    shallowShaftsHere = isEyeInWater == 0;
#endif
    if (shallowShaftsHere && waterInfo.r > 0.50 && vSunInFront > 0.5 && hasSkylight && !hasCeiling && atmosOverworld > 0.5) {
        float waterDepth = texture(depthtex0, uv).r;
        float floorDepth = texture(depthtex1, uv).r;
        if (floorDepth < 0.99999 && waterDepth < 0.99999 && waterDepth + 0.00001 < floorDepth) {
            float waterDistance = linearDepth(waterDepth);
            vec3 waterPlayer;
            vec3 waterWorld = reconstructWorldPosition(uv, waterDepth, waterPlayer);
            vec3 floorPlayer;
            vec3 floorWorld = reconstructWorldPosition(uv, floorDepth, floorPlayer);
            float waterColumn = max(waterWorld.y - floorWorld.y, 0.0);
            // Shares the caustic depth range (the old SHALLOW_DEPTH_RANGE slider was removed).
            float depthMask = 1.0 - smoothstep(CAUSTIC_FULL_DEPTH, CAUSTIC_FADE_DEPTH, waterColumn);
            float distanceFade = 1.0 - smoothstep(40.0, 48.0, waterDistance);
            float sunFade = smoothstep(0.025, 0.24, vSunElevation);
            float rainFade = 1.0 - clamp(rainStrength, 0.0, 1.0);
            float skyLight = smoothstep(0.22, 0.92, waterInfo.g);
            float shallowMask = depthMask * distanceFade;

            if (shallowMask > 0.002 && skyLight > 0.01 && sunFade > 0.01) {
            // The fluid mask is registered at full resolution; this is the existing quarter-res approximation.
            float directWaterLight = shallowMask * skyLight * sunFade * rainFade * opaqueWaterShadowVisibility(floorPlayer);
#ifdef CLOUD_SHADOW_ENABLE
            // Same cloud cells as the gbuffers: the shallow-water shafts dim under cloud shadows.
            directWaterLight *= ambienceCloudShadow(floorPlayer, ambSunDirection());
#endif
            vec2 scroll = vec2(frameTimeCounter * 0.0031, -frameTimeCounter * 0.0023);
            vec2 waterUV = fract(floorWorld.xz * 0.035 + scroll);
            vec2 rayStretch = (vSunUV - uv) * RAY_LENGTH * 0.24;
            float waterRaySum = 0.0;
            float waterRayWeight = 0.0;
            for (int i = 0; i < 6; ++i) {
                float t = float(i + 1) / 6.0;
                float weight = 1.0 - t * 0.35;
                waterRaySum += texture(noisetex, fract(waterUV + rayStretch * t + scroll * t)).r * weight;
                waterRayWeight += weight;
            }
            float waterRays = smoothstep(0.48, 0.70, waterRaySum / max(waterRayWeight, 0.001));
            postAdd += vec3(0.42, 0.72, 0.92) * waterRays * RAY_INTENSITY * 0.30 * directWaterLight;

            float waterDepthBlend = clamp(waterColumn / CAUSTIC_FADE_DEPTH, 0.0, 1.0);
            vec3 depthTint = mix(vec3(0.18, 0.72, 0.82), vec3(0.035, 0.17, 0.42), waterDepthBlend);
            postAdd += depthTint * directWaterLight * 0.06;
            }
        }
    }
#endif

#ifdef ATMOSPHERIC_PARTICLES
    if (hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        float cameraSkyFade = smoothstep(24.0, 96.0, float(eyeBrightnessSmooth.y));
        float particleSun = smoothstep(0.025, 0.24, vSunElevation) * vSunInFront;
        particleSun *= cameraSkyFade * clamp(1.0 - rainStrength * 0.82 - thunderStrength * 0.18, 0.0, 1.0);
        float openSky = step(0.99995, texture(depthtex0, uv).r);
        float humidWeight = clamp(max(atmosHumidBiome, smoothstep(0.72, 1.0, rainfall) * 0.25), 0.0, 1.0);
        float woodlandWeight = clamp(max(atmosWoodlandBiome, atmosSavannaBiome), 0.0, 1.0);
        float forestFactor = max(woodlandWeight, humidWeight);
        vec2 screenCell = floor(uv * vec2(viewWidth, viewHeight) / 32.0);
        float particleTick = floor(frameTimeCounter * 1.5);
        float moteHash = cheapHash(screenCell + vec2(particleTick, particleTick * 0.37));
        float mote = step(0.987, moteHash) * openSky * particleSun * forestFactor * PARTICLE_AMOUNT;
        postAdd += vec3(1.0, 0.84, 0.62) * mote;
    }
#endif

#ifdef EMISSIVE_GLOW
    postAdd += emissiveGlow(uv);
#endif

#ifdef VV_DEBUG
#if VV_DEBUG_MODE == 1
    postEffects = vec4(vec3(debugSunLitMask), 0.0);
#elif VV_DEBUG_MODE == 5
    postEffects = vec4(vec3(debugShadowMask), 0.0);
#elif VV_DEBUG_MODE == 9
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    // Mode 2 showed the removed sun rays; it is black now.
    postEffects = vec4(0.0);
#endif
#elif defined(TARGET_DEBUG)
#if TARGET_DEBUG_MODE == 7
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    postEffects = vec4(0.0);
#endif
#elif defined(ATMOS_DEBUG)
#if ATMOS_DEBUG_MODE == 1
    postEffects = vec4(vec3(debugSunLitMask), 0.0);
#elif ATMOS_DEBUG_MODE == 6
    postEffects = vec4(debugBloomBuffer, 0.0);
#else
    postEffects = vec4(vec3(0.0), 0.0);
#endif
#else
    // Alpha: the open-sky mask for the shafts (0 when they are off or cannot show). The mask is
    // the same for either light; only whether it is needed depends on the source.
    float shaftMask = 0.0;
#ifdef RAYS_SHAFTS
    bool shaftSource = false;
#ifdef SUN_SHAFTS
    shaftSource = vSunInFront > 0.5 && vSunElevation > -0.08;
#endif
#ifdef MOON_SHAFTS
    shaftSource = shaftSource || vMoonShaftOwner > 0.0;
#endif
    if (shaftSource && hasSkylight && !hasCeiling && atmosOverworld > 0.5 && isEyeInWater == 0) {
        shaftMask = raysQuarterMask(uv, vec2(viewWidth, viewHeight));
    }
#ifdef END_FLASH_SHAFTS
    // Update 3: in the End the flash owns the shafts while it is on (the same open-sky mask).
    if (vFlashShaft.z > 0.5 && isEyeInWater == 0) shaftMask = raysQuarterMask(uv, vec2(viewWidth, viewHeight));
#endif
#ifdef UNDERWATER_SHAFTS_TIER2
    // Update 3: with the camera underwater the alpha carries the tier-2 shafts (the sun and moon
    // shafts are off underwater).
    if (isEyeInWater == 1) shaftMask = uwShaftMarch(uv);
#endif
#endif
#if defined(UNDERWATER_SHAFTS) && !defined(UNDERWATER_SHAFTS_TIER2)
    // Update 3: with the camera underwater the alpha carries the tier-1 shafts.
    if (isEyeInWater == 1) shaftMask = uwShaftTier1Quarter(uv);
#endif
    postEffects = vec4(postAdd, shaftMask);
#endif
}
