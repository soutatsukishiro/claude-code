#version 330 compatibility

// Shafts (SUN_SHAFTS, MOON_SHAFTS), quarter resolution, after composite: a deterministic radial
// march toward the screen position of the light that owns the shafts this frame (the sun, or
// the moon at night; never both: one buffer, one channel) over the pre-filtered open-sky mask
// composite left in colortex5.a (read with linear filtering, so neighbouring samples overlap):
// fixed offsets, Gaussian-like weights, no jitter, no noise, never the shadow map. RGB (bloom,
// shallow-water shafts, pollen) passes through untouched; the shaft amount replaces the mask
// in alpha and final applies it with a depth-aware upsample. Iris ping-pongs colortex5 (read
// and written here), so the read sees composite's output.
// Update 4.1: in the End, while a flash is on, this pass instead marches the flash fog's
// screen-space volumetric shadow over the depth buffer (FLASH_FOG_SHADOWS) and writes its lit share
// into the alpha for final's volumetric flash fog.

#include "/lib/settings.glsl"

uniform sampler2D colortex5;
uniform float aspectRatio;
// Declared for lib/sun_rays.glsl (its mask and rim functions); this pass only marches.
uniform sampler2D depthtex0;
uniform float far;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
uniform sampler2D colortex1;
#endif

#include "/lib/sun_rays.glsl"

in vec2 vTexCoord;
in vec2 vSunUV;
in float vSunInFront;
#ifdef MOON_SHAFTS
in vec2 vMoonUV;
flat in float vMoonShaftOwner;
#endif
#if defined(END_FLASH_SHAFTS) || defined(FLASH_FOG_SHADOWS)
// Update 3: the End flash (composite1.vsh): screen position, owner of the shafts this frame.
flat in vec3 vFlashShaft;
#endif
#ifdef FLASH_FOG_SHADOWS
// Update 4.1: the edge fade of the flash fog's shadow (composite1.vsh): 1 well inside, 0 where the flash's
// screen point leaves -0.6..1.6, so the stored lit share reaches 1 before final stops reading it (no pop).
flat in float vFlashFogFade;

// Update 4.1: the lit share of this quarter-resolution pixel's view ray in the flash fog (1 = fully lit), for
// final's volumetric flash fog. Screen-space volumetric shadow: the flash is a directional light, so its screen
// point is the vanishing point of its rays. The light line through a point at view depth zq on this pixel's ray
// crosses the screen point a fraction u of the way to the flash at depth zq / (1 - u); what is drawn there, at
// depth z, blocks it when zq / (1 - u) lies inside the occluder, between z and z + T (T: its thickness). So
// each tap shadows the part [z (1 - u), (z + T)(1 - u)] of the view ray. T = max(3, 0.2 z) blocks (checked
// against a 3D ray march of pillars and mob-sized boxes: lit-share error rms 0.04, 0.06 with 0.3 z): a pillar's
// own body shadows the air in front of its far side, as in your references (image 4: a pillar right in front
// of the flash stays dark; image 2: one beside it is lit on its flash side and dark on its far side), while
// the terrain far behind a pillar or a mob keeps light in the air in front of it (an infinitely thick
// occluder would cast a long dark wedge there, which Vibrant Visuals does not show). Taps on one continuous
// surface shadow everything between them, and if that surface reaches the flash point the air right in front
// of the camera too (the limit u -> 1); when the march leaves the screen on such a surface (a pillar hiding a
// flash just above the screen's edge), it is taken to go on up to the flash, so nothing changes when the
// flash's screen point crosses the edge. One tap every 2 quarter-resolution texels (8 px at 1080p) toward the
// flash, at least 8, at most FLASH_FOG_TAPS (beyond that the spacing grows: the finite thickness keeps a skipped
// thin occluder's error under 1/255, checked on 4 to 16 px occluders). The union is kept in a 24-bin mask over
// [0, zp]. Off-screen taps, the sky and anything nearer than 2 blocks (the hand) never shadow. Deterministic,
// no noise, no shadow map (every tier).
const int FLASH_FOG_BINS = 24;

float endFlashOccluderThickness(float z) {
    return max(3.0, 0.2 * z);
}

// Marks [a, b] (blocks) of the view ray [0, zp] as shadowed: the bins whose centre lies inside (scale = bins / zp).
uint endFlashMarkShadow(uint mask, float a, float b, float scale) {
    int b0 = max(int(ceil(a * scale - 0.5)), 0);
    int b1 = min(int(floor(b * scale - 0.5)), FLASH_FOG_BINS - 1);
    if (b1 < b0) return mask;
    uint upTo = (2u << uint(b1)) - 1u;
    uint below = (1u << uint(b0)) - 1u;
    return mask | (upTo & ~below);
}

float endFlashLitShare(vec2 uv, vec2 flashUV) {
    ivec2 sizeI = textureSize(depthtex0, 0);
    vec2 size = vec2(sizeI);
    ivec2 maxTexel = sizeI - 1;
    float depthHere = texelFetch(depthtex0, clamp(ivec2(uv * size), ivec2(0), maxTexel), 0).r;
    if (depthHere >= 1.0) return 1.0;
    float zp = raysLinearDepth(depthHere);
    if (zp < 2.0) return 1.0;
    float scale = float(FLASH_FOG_BINS) / zp;
    float segment = length((flashUV - uv) * vec2(textureSize(colortex5, 0)));
    int n = clamp(int(ceil(segment * 0.5)), 8, FLASH_FOG_TAPS);
    float du = 1.0 / float(n + 1);
    uint mask = 0u;
    float zPrev = -1.0;   // the previous tap's depth (negative: no occluder there)
    float uPrev = 0.0;
    bool reached = true;  // every tap was on screen
    for (int i = 1; i <= FLASH_FOG_TAPS; ++i) {
        if (i > n) break;
        float u = float(i) * du;
        vec2 p = mix(uv, flashUV, u);
        if (any(lessThan(p, vec2(0.0))) || any(greaterThanEqual(p, vec2(1.0)))) {
            // Off screen: a surface the march was on when it left the screen, if it shadows this ray at all (not
            // ground lying below the light lines), is taken to go on to the flash.
            if (zPrev > 0.0 && zPrev * (1.0 - uPrev) < zp) mask = endFlashMarkShadow(mask, 0.0, (zPrev + endFlashOccluderThickness(zPrev)) * (1.0 - uPrev), scale);
            reached = false;
            break;
        }
        float dS = texelFetch(depthtex0, clamp(ivec2(p * size), ivec2(0), maxTexel), 0).r;
        float z = dS < 1.0 ? raysLinearDepth(dS) : -1.0;
        if (z > 2.0) {
            float b = (z + endFlashOccluderThickness(z)) * (1.0 - u);
            if (zPrev > 0.0 && abs(z - zPrev) < 0.2 * max(z, zPrev)) {
                b = max(b, (zPrev + endFlashOccluderThickness(zPrev)) * (1.0 - uPrev));
            }
            mask = endFlashMarkShadow(mask, z * (1.0 - u), b, scale);
            zPrev = z;
            uPrev = u;
        } else {
            zPrev = -1.0;
        }
    }
    if (reached && zPrev > 0.0 && zPrev * (1.0 - uPrev) < zp && all(greaterThanEqual(flashUV, vec2(0.0))) && all(lessThan(flashUV, vec2(1.0)))) {
        float dF = texelFetch(depthtex0, clamp(ivec2(flashUV * size), ivec2(0), maxTexel), 0).r;
        float zF = dF < 1.0 ? raysLinearDepth(dF) : -1.0;
        if (zF > 2.0 && abs(zF - zPrev) < 0.2 * max(zF, zPrev)) {
            mask = endFlashMarkShadow(mask, 0.0, (zPrev + endFlashOccluderThickness(zPrev)) * (1.0 - uPrev), scale);
        }
    }
    int shadowed = 0;
    for (int k = 0; k < FLASH_FOG_BINS; ++k) shadowed += int((mask >> uint(k)) & 1u);
    return 1.0 - float(shadowed) / float(FLASH_FOG_BINS);
}
#endif
#if defined(UNDERWATER_SHAFTS) || defined(FLASH_FOG_SHADOWS)
uniform int isEyeInWater;
#endif
#ifdef UNDERWATER_SHAFTS_TIER2

// Update 3: depth-aware pre-blur of the tier-2 underwater shafts (composite's march, quarter
// resolution): the centre and four neighbours UW_SHAFT_SOFTNESS apart, each weighted by how close its
// depth is to the centre's, so shafts never bleed across a silhouette (no halos around objects).
float uwShaftBlur() {
    ivec2 q = ivec2(gl_FragCoord.xy);
    vec2 quarterSize = vec2(textureSize(colortex5, 0));
    ivec2 qMax = ivec2(quarterSize) - 1;
    vec2 scale = vec2(textureSize(depthtex0, 0)) / quarterSize;
    ivec2 fullMax = textureSize(depthtex0, 0) - 1;
    float centreDistance = raysLinearDepth(texelFetch(depthtex0, clamp(ivec2((vec2(q) + 0.5) * scale), ivec2(0), fullMax), 0).r);
    int r = 1 + int(UW_SHAFT_SOFTNESS * 2.0 + 0.01);
    ivec2 offsets[4] = ivec2[4](ivec2(r, 0), ivec2(-r, 0), ivec2(0, r), ivec2(0, -r));
    float sum = 2.0 * texelFetch(colortex5, q, 0).a;
    float weightSum = 2.0;
    for (int k = 0; k < 4; ++k) {
        ivec2 t = clamp(q + offsets[k], ivec2(0), qMax);
        float d = raysLinearDepth(texelFetch(depthtex0, clamp(ivec2((vec2(t) + 0.5) * scale), ivec2(0), fullMax), 0).r);
        float w = exp(-10.0 * abs(d - centreDistance) / max(centreDistance, 0.5));
        sum += w * texelFetch(colortex5, t, 0).a;
        weightSum += w;
    }
    return sum / weightSum;
}
#endif

/* RENDERTARGETS: 5 */
layout(location = 0) out vec4 postEffects;

void main() {
    vec4 current = texelFetch(colortex5, ivec2(gl_FragCoord.xy), 0);
    float shafts = 0.0;
#ifdef RAYS_SHAFTS
    bool moonOwns = false;
#ifdef MOON_SHAFTS
    moonOwns = vMoonShaftOwner > 0.0;
#endif
#ifdef SUN_SHAFTS
    // Nothing to march when the sun is behind the camera or far off screen, or far from this
    // pixel (final's cone fades shafts out about 45 degrees from the sun anyway).
    vec2 toSun = (vSunUV - vTexCoord) * vec2(aspectRatio, 1.0);
    bool sunNear = vSunInFront > 0.5 && all(greaterThan(vSunUV, vec2(-0.6))) && all(lessThan(vSunUV, vec2(1.6))) &&
                   dot(toSun, toSun) < 1.44;
    if (sunNear && !moonOwns) shafts = raysShaftMarch(colortex5, vTexCoord, vSunUV, aspectRatio, SHAFT_LENGTH);
#endif
#ifdef MOON_SHAFTS
    // The moon's march is shorter (0.75 x SHAFT_LENGTH); its cone in final is narrower.
    vec2 toMoon = (vMoonUV - vTexCoord) * vec2(aspectRatio, 1.0);
    bool moonNear = moonOwns && all(greaterThan(vMoonUV, vec2(-0.6))) && all(lessThan(vMoonUV, vec2(1.6))) &&
                    dot(toMoon, toMoon) < 1.44;
    if (moonNear) shafts = raysShaftMarch(colortex5, vTexCoord, vMoonUV, aspectRatio, 0.75 * SHAFT_LENGTH);
#endif
#ifdef END_FLASH_SHAFTS
    // Update 3: the End flash's march (the sun's function, a slightly longer reach); the sun and the
    // moon have no mask in the End, so this never mixes with them.
    vec2 toFlash = (vFlashShaft.xy - vTexCoord) * vec2(aspectRatio, 1.0);
    if (vFlashShaft.z > 0.5 && dot(toFlash, toFlash) < 1.44) shafts = raysShaftMarch(colortex5, vTexCoord, vFlashShaft.xy, aspectRatio, 0.35);
#endif
#ifdef FLASH_FOG_SHADOWS
    // Update 4.1: in the End, while a flash owns the channel, the alpha carries the flash fog's lit share, faded
    // to 1.0 (never 0) toward 1.2 screen heights from the flash and as the flash leaves -0.6..1.6, so final,
    // which reads it under the same test, never sees a seam or a pop.
    if (vFlashShaft.z > 0.5 && isEyeInWater == 0) {
        vec2 toFlashFog = (vFlashShaft.xy - vTexCoord) * vec2(aspectRatio, 1.0);
        float fogFade = vFlashFogFade * (1.0 - smoothstep(0.9, 1.2, length(toFlashFog)));
        shafts = fogFade > 0.0 ? mix(1.0, endFlashLitShare(vTexCoord, vFlashShaft.xy), fogFade) : 1.0;
    }
#endif
#ifdef UNDERWATER_SHAFTS_TIER2
    // Update 3: with the camera underwater the alpha holds the tier-2 shafts: blur them instead.
    if (isEyeInWater == 1) shafts = uwShaftBlur();
#endif
#endif
#if defined(UNDERWATER_SHAFTS) && !defined(UNDERWATER_SHAFTS_TIER2)
    // Update 3: with the camera underwater the alpha holds the tier-1 shafts (composite): keep them.
    if (isEyeInWater == 1) shafts = current.a;
#endif
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 2
    // The sky-mask view shows composite's mask itself.
    shafts = current.a;
#endif
    postEffects = vec4(current.rgb, shafts);
}
