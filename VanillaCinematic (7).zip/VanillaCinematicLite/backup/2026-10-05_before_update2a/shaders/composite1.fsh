#version 330 compatibility

// Sun shafts (SUN_SHAFTS), quarter resolution, after composite: a deterministic radial march
// toward the sun's screen position over the pre-filtered open-sky mask composite left in
// colortex5.a (read with linear filtering, so neighbouring samples overlap): fixed offsets,
// Gaussian-like weights, no jitter, no noise, never the shadow map. RGB (bloom, shallow-water
// shafts, pollen) passes through untouched; the shaft amount replaces the mask in alpha and
// final applies it with a depth-aware upsample. Iris ping-pongs colortex5 (read and written
// here), so the read sees composite's output.

#include "/lib/settings.glsl"

uniform sampler2D colortex5;
uniform float aspectRatio;
// Declared for lib/sun_rays.glsl (its mask and rim functions); this pass only marches.
uniform sampler2D depthtex0;
uniform float far;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
uniform sampler2D colortex1;
#endif

#include "/lib/sun_rays.glsl"

in vec2 vTexCoord;
in vec2 vSunUV;
in float vSunInFront;

/* RENDERTARGETS: 5 */
layout(location = 0) out vec4 postEffects;

void main() {
    vec4 current = texelFetch(colortex5, ivec2(gl_FragCoord.xy), 0);
    float shafts = 0.0;
#ifdef SUN_SHAFTS
    // Nothing to march when the sun is behind the camera or far off screen, or far from this
    // pixel (final's cone fades shafts out about 45 degrees from the sun anyway).
    vec2 toSun = (vSunUV - vTexCoord) * vec2(aspectRatio, 1.0);
    bool sunNear = vSunInFront > 0.5 && all(greaterThan(vSunUV, vec2(-0.6))) && all(lessThan(vSunUV, vec2(1.6))) &&
                   dot(toSun, toSun) < 1.44;
    if (sunNear) shafts = raysShaftMarch(colortex5, vTexCoord, vSunUV, aspectRatio);
#endif
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 2
    // The sky-mask view shows composite's mask itself.
    shafts = current.a;
#endif
    postEffects = vec4(current.rgb, shafts);
}
