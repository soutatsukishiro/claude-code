// Sun rays: the edge rim (with its soft bleed) and the faint shafts through gaps. Everything here
// is deterministic and noise-free: fixed tap offsets, smooth weights, no jitter, no frame input,
// and never the shadow map (only the camera depth buffer and the cloud marker).
// Used by composite (the quarter-resolution open-sky mask), composite1 (the shaft march) and
// final (the rim, the depth-derived normal and the shaft upsample).
// The includer declares: depthtex0, far, gbufferProjectionInverse, gbufferModelViewInverse, and
// colortex1 when the cloud marker exists (AMBIENCE_COLORS or AMBIENCE_CLOUDS); final also
// colortex5 for the shaft upsample.

#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// gbuffers_clouds writes the cloud marker into colortex1: A = 1, R = 0, G = the face's opacity.
#define RAYS_CLOUD_MARKER
#endif

// View-space distance (blocks) of a depth-buffer value.
float raysLinearDepth(float depth) {
    vec4 v = gbufferProjectionInverse * vec4(0.0, 0.0, depth * 2.0 - 1.0, 1.0);
    return -v.z / max(v.w, 1.0e-6);
}

// Camera-relative position of a screen point.
vec3 raysPlayerPosition(vec2 uv, float depth) {
    vec4 v = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(v.xyz / max(v.w, 1.0e-6), 1.0)).xyz;
}

// Open sky at one full-resolution texel: sky = 1, a cloud = its transparency (an opaque cloud is
// an occluder), terrain = 0, softened toward 1 near the render distance where the fog turns
// terrain into the sky colour (a wide smoothstep on the linear depth, never a hard step).
float raysOpenSkyTexel(ivec2 texel) {
#ifdef RAYS_CLOUD_MARKER
    vec4 info = texelFetch(colortex1, texel, 0);
    if (info.a > 0.5 && info.r < 0.5) return 1.0 - info.g;
#endif
    float depth = texelFetch(depthtex0, texel, 0).r;
    if (depth > 0.99999) return 1.0;
    return smoothstep(0.75 * far, 1.05 * far, raysLinearDepth(depth));
}

#ifdef SUN_EDGE_RIM
// Edge gather for the rim and its soft bleed: taps from this pixel straight toward the sun's
// screen position at fixed offsets (pixels at 1080p, scaled with the resolution and RIM_REACH),
// with smooth decreasing weights. 1 right at an edge with open sky toward the sun, a soft ramp
// inside the silhouette, 0 deeper in (a tap past the sun's centre only finds more disc). Inside the sun's own
// screen square (sunRadius = its half size in pixels) an edge can have its open side away from
// the centre (the centre just sank behind it while the rest of the disc still shows, or the
// lower edge of a bar across the disc): the same taps away from the centre take over there,
// fading out between 0.9 and 1.4 half sizes, so the rim never switches off at once.
float raysRimGather(vec2 uv, vec2 sunUV, vec2 screen, float sunRadius) {
    vec2 toSun = (sunUV - uv) * screen;
    float distanceToSun = length(toSun);
    // Right at the sun's centre the direction is undefined: look up and down instead.
    vec2 direction = distanceToSun > 0.5 ? toSun / distanceToSun : vec2(0.0, 1.0);
    float scale = (screen.y / 1080.0) * RIM_REACH;
    float inside = 1.0 - smoothstep(0.9 * sunRadius, 1.4 * sunRadius, distanceToSun);
    // Weights fitted to the reference: a bright edge over the first taps, then a soft bleed.
#if RIM_TAPS == 3
    const int TAPS = 3;
    const float OFFSET[3] = float[3](2.0, 5.0, 10.0);
    const float WEIGHT[3] = float[3](0.50, 0.30, 0.20);
#elif RIM_TAPS == 6
    const int TAPS = 6;
    const float OFFSET[6] = float[6](1.5, 3.0, 5.0, 8.0, 11.0, 14.0);
    const float WEIGHT[6] = float[6](0.26, 0.20, 0.17, 0.14, 0.12, 0.11);
#else
    const int TAPS = 4;
    const float OFFSET[4] = float[4](2.0, 4.0, 8.0, 14.0);
    const float WEIGHT[4] = float[4](0.40, 0.27, 0.19, 0.14);
#endif
    ivec2 maxTexel = ivec2(screen) - 1;
    float gather = 0.0;
    float away = 0.0;
    for (int i = 0; i < TAPS; ++i) {
        float reach = OFFSET[i] * scale;
        vec2 position = uv * screen + direction * reach;
        gather += WEIGHT[i] * raysOpenSkyTexel(clamp(ivec2(position), ivec2(0), maxTexel));
        if (inside > 0.0) {
            vec2 opposite = uv * screen - direction * reach;
            away += WEIGHT[i] * raysOpenSkyTexel(clamp(ivec2(opposite), ivec2(0), maxTexel));
        }
    }
    return max(gather, away * inside);
}

// Surface normal from the depth buffer: per screen axis the neighbour closer in depth (it stays
// on the same face at block edges and silhouettes), a cross product, turned toward the camera.
// Exact on the flat faces of blocks.
vec3 raysNormal(ivec2 texel, float depth, vec3 position, vec2 screen) {
    ivec2 maxTexel = ivec2(screen) - 1;
    ivec2 left = clamp(texel - ivec2(1, 0), ivec2(0), maxTexel);
    ivec2 right = clamp(texel + ivec2(1, 0), ivec2(0), maxTexel);
    ivec2 down = clamp(texel - ivec2(0, 1), ivec2(0), maxTexel);
    ivec2 up = clamp(texel + ivec2(0, 1), ivec2(0), maxTexel);
    float depthLeft = texelFetch(depthtex0, left, 0).r;
    float depthRight = texelFetch(depthtex0, right, 0).r;
    float depthDown = texelFetch(depthtex0, down, 0).r;
    float depthUp = texelFetch(depthtex0, up, 0).r;
    bool useLeft = abs(depthLeft - depth) < abs(depthRight - depth);
    bool useDown = abs(depthDown - depth) < abs(depthUp - depth);
    ivec2 horizontal = useLeft ? left : right;
    ivec2 vertical = useDown ? down : up;
    vec3 a = raysPlayerPosition((vec2(horizontal) + 0.5) / screen, useLeft ? depthLeft : depthRight) - position;
    vec3 b = raysPlayerPosition((vec2(vertical) + 0.5) / screen, useDown ? depthDown : depthUp) - position;
    vec3 n = cross(a, b);
    float n2 = dot(n, n);
    if (n2 < 1.0e-14) return -position * inversesqrt(max(dot(position, position), 1.0e-6));
    n *= inversesqrt(n2);
    return dot(n, position) > 0.0 ? -n : n;
}
#endif

#ifdef SUN_SHAFTS
// Pre-filtered open-sky mask of one quarter-resolution pixel: four full-resolution taps spread
// over its 4 x 4 block (a box filter), so the march reads a soft mask whose samples overlap.
float raysQuarterMask(vec2 uv, vec2 fullSize) {
    vec2 centre = uv * fullSize;
    ivec2 maxTexel = ivec2(fullSize) - 1;
    float mask = raysOpenSkyTexel(clamp(ivec2(centre + vec2(-1.0, -1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(1.0, -1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(-1.0, 1.0)), ivec2(0), maxTexel));
    mask += raysOpenSkyTexel(clamp(ivec2(centre + vec2(1.0, 1.0)), ivec2(0), maxTexel));
    return 0.25 * mask;
}

// Deterministic radial march from this quarter-resolution pixel toward the sun over the mask
// (bilinear, alpha of maskTex): SHAFT_SAMPLES fixed offsets along a short ray (SHAFT_LENGTH of
// the distance to the sun, capped at half of SHAFT_LENGTH in screen heights, so the samples
// stay close enough to overlap), Gaussian-like weights. Result: the share of open sky seen
// toward the sun, 0 deep inside occluders, partial next to gaps.
float raysShaftMarch(sampler2D maskTex, vec2 uv, vec2 sunUV, float aspect) {
    vec2 delta = (sunUV - uv) * vec2(aspect, 1.0);
    float distanceToSun = length(delta);
    if (distanceToSun < 1.0e-4) return texture(maskTex, uv).a;
    float span = min(distanceToSun * SHAFT_LENGTH, 0.5 * SHAFT_LENGTH);
    vec2 march = delta / distanceToSun * span / vec2(aspect, 1.0);
    float sum = 0.0;
    float weightSum = 0.0;
    for (int i = 0; i < SHAFT_SAMPLES; ++i) {
        float t = (float(i) + 0.5) / float(SHAFT_SAMPLES);
        float weight = exp(-0.5 * t * t / (SHAFT_SOFTNESS * SHAFT_SOFTNESS));
        sum += weight * texture(maskTex, uv + march * t).a;
        weightSum += weight;
    }
    return sum / weightSum;
}

// Where shafts show: strongest near the sun, gone about 45 degrees away (smooth cone).
float raysShaftFalloff(float theta) {
    return exp(-max(theta - 0.075, 0.0) / 0.22) * (1.0 - smoothstep(0.45, 0.80, theta));
}
#endif

#if defined(SUN_SHAFTS) && defined(RAYS_SHAFT_UPSAMPLE)
// Depth-aware upsample of the quarter-resolution shafts (colortex5.a): the four nearest
// quarter-resolution texels with their bilinear weights, each weighted by how close its depth
// (the full-resolution depth at its centre) is to this pixel's, so shafts on a distant hill
// never bleed onto a fence post in front of it.
float raysShaftUpsample(vec2 uv, float pixelDistance, vec2 fullSize) {
    vec2 quarterSize = vec2(textureSize(colortex5, 0));
    vec2 position = uv * quarterSize - 0.5;
    ivec2 base = ivec2(floor(position));
    vec2 f = position - floor(position);
    ivec2 maxQuarter = ivec2(quarterSize) - 1;
    ivec2 maxTexel = ivec2(fullSize) - 1;
    float sum = 0.0;
    float weightSum = 0.0;
    for (int j = 0; j < 2; ++j) {
        for (int i = 0; i < 2; ++i) {
            ivec2 q = clamp(base + ivec2(i, j), ivec2(0), maxQuarter);
            float bilinear = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
            ivec2 centre = clamp(ivec2((vec2(q) + 0.5) * fullSize / quarterSize), ivec2(0), maxTexel);
            float texelDistance = raysLinearDepth(texelFetch(depthtex0, centre, 0).r);
            float relative = abs(texelDistance - pixelDistance) / max(pixelDistance, 0.5);
            float weight = bilinear * (exp(-12.0 * relative) + 1.0e-4);
            sum += weight * texelFetch(colortex5, q, 0).a;
            weightSum += weight;
        }
    }
    return sum / max(weightSum, 1.0e-6);
}
#endif
