#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
// Needed by lib/ambience.glsl (palettes are evaluated here, once per vertex).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#include "/lib/ambience.glsl"

#if defined(WATER_GBUFFER) || defined(TERRAIN_GBUFFER)
in vec2 mc_Entity;
#endif

#if defined(WATER_GBUFFER) && defined(WAVE_LIGHTING)
// Iris attribute: centre of this quad's atlas sprite. With the vertex UV it gives the
// sprite half-extent, which keeps the wave pseudo-normal taps inside the sprite.
in vec4 mc_midTexCoord;
out vec2 vMidTexCoord;
out vec2 vSpriteHalf;
#endif

#ifdef AMBIENCE_COLORS
// Palette sunlight and sky light for the terrain light response (same for every vertex).
flat out vec3 vAmbSunLight;
flat out vec3 vAmbSkyLight;
#endif
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS)
// Ambient light for the shadow colours (terrain only): the palette sky light with the biome
// haze tint, or the vanilla sky colour without the Ambience colours.
flat out vec3 vAmbShadowLight;
#ifndef AMBIENCE_COLORS
uniform vec3 skyColor;
#endif
#endif
#if defined(WATER_GBUFFER) && defined(WATER_REFLECTION_IMPROVEMENT)
// Palette sky for the improved Tier-1 water reflection.
flat out vec3 vAmbZenith;
flat out vec3 vAmbMid;
flat out vec3 vAmbHorizon;
flat out vec3 vAmbGlow;
flat out vec3 vAmbCloudTop;
flat out vec3 vAmbCloudUnder;
flat out float vAmbGolden;
#endif

#include "/lib/shadow_distortion.glsl"

out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vNormalView;
out vec3 vWorldPosition;
out vec3 vPlayerPosition;
out vec4 vShadowClip;
out vec3 vViewPosition;
out vec3 vWorldNormal;
out float vIsFluid;
out float vSunElevation;
out float vViewDistance;
out float vIsFoliage;
out float vIsThin;
out float vMaterialGroup;

void main() {
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPosition = gbufferModelViewInverse * viewPosition;

    gl_Position = gl_ProjectionMatrix * viewPosition;
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;
    vec3 transformedNormal = gl_NormalMatrix * gl_Normal;
    vNormalView = transformedNormal * inversesqrt(max(dot(transformedNormal, transformedNormal), 0.000001));
    vWorldNormal = mat3(gbufferModelViewInverse) * vNormalView;
    vViewPosition = viewPosition.xyz;
    vViewDistance = length(viewPosition.xyz);
    vec3 worldSun = mat3(gbufferModelViewInverse) * sunPosition;
    vSunElevation = worldSun.y * inversesqrt(max(dot(worldSun, worldSun), 0.000001));
    vWorldPosition = cameraPosition + playerPosition.xyz;
    vPlayerPosition = playerPosition.xyz;
    vec4 shadowClip = shadowProjection * shadowModelView * playerPosition;
    shadowClip.xyz = distortShadowClip(shadowClip.xyz);
    vShadowClip = shadowClip;
    vIsFluid = 0.0;
    vIsFoliage = 0.0;
    vIsThin = 0.0;
    vMaterialGroup = 0.0;
#ifdef WATER_GBUFFER
    // Iris sets mc_Entity.y = 1 on fluid-renderer geometry (-1 on blocks). Lava renders in
    // the solid layer, so in this translucent program any fluid quad is water: source,
    // flowing, waterlogged blocks and every visible face. block.1 (ID 1) is a fallback.
    vIsFluid = (mc_Entity.y > 0.5 || abs(mc_Entity.x - 1.0) < 0.5) ? 1.0 : 0.0;
    vMaterialGroup = mc_Entity.x;
    vIsThin = mc_Entity.x == 8.0 ? 1.0 : 0.0;
#ifdef WAVE_LIGHTING
    vMidTexCoord = (gl_TextureMatrix[0] * vec4(mc_midTexCoord.xy, 0.0, 1.0)).xy;
    vSpriteHalf = abs(vTexCoord - vMidTexCoord);
#endif
#endif
#ifdef TERRAIN_GBUFFER
    vMaterialGroup = mc_Entity.x;
    vIsFoliage = mc_Entity.x == 2.0 ? 1.0 : 0.0;
    vIsThin = (mc_Entity.x == 3.0 || mc_Entity.x == 8.0) ? 1.0 : 0.0;
#endif

#if defined(WATER_GBUFFER) && defined(WATER_REFLECTION_IMPROVEMENT)
    // Biome ambience follows into the water reflection only with BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION.
    AmbPalette ambPal = ambiencePaletteBiome(ambSunDirection(), AMB_WATER_BIOME);
    vAmbZenith = ambPal.zenith;
    vAmbMid = ambPal.mid;
    vAmbHorizon = ambPal.horizon;
    vAmbGlow = ambPal.glow;
    vAmbCloudTop = ambPal.cloudTop;
    vAmbCloudUnder = ambPal.cloudUnder;
    vAmbGolden = ambPal.golden;
#ifdef AMBIENCE_COLORS
    vAmbSunLight = ambPal.sunLight;
    vAmbSkyLight = ambPal.skyLight;
#endif
#elif defined(AMBIENCE_COLORS)
    AmbTime ambT = ambTime(ambSunDirection());
    vAmbSunLight = ambColor(ambT, AMB_SUN_LIGHT);
    vAmbSkyLight = ambSkyLightColor(ambT);
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS)
    vAmbShadowLight = ambShadowAmbient(ambT);
#endif
#endif
#if defined(TERRAIN_GBUFFER) && defined(SHADOW_COLORS) && !defined(AMBIENCE_COLORS)
    vAmbShadowLight = max(skyColor, vec3(0.02));
#endif
}
