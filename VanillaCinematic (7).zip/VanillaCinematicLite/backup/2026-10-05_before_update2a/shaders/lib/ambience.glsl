// Ambience: time-of-day and biome palettes, the ONE sky colour function (the fog, the clouds,
// the water's Tier-1 reflection and the sky itself all use it), the analytic sun and its glow,
// the closed-form layered height fog with smooth banks, vanilla-aligned cloud shadows and the
// terrain light response. Palettes are evaluated in vertex shaders and handed on as flat
// varyings; the per-pixel parts are ALU plus at most four texel fetches of the small cloud
// texture. Nothing here uses noise per pixel, random jitter or the shadow map.
// The includer declares: gbufferModelViewInverse, sunPosition, rainStrength,
// thunderStrength, cameraPositionInt, cameraPositionFract, frameTimeCounter.
// No function here reads gl_FragCoord, so vertex shaders can include this file too.

// Iris uniforms that reproduce the vanilla cloud layer (checked in the 26.3 client and
// Iris 1.11 jars): cloudTime = ((game time mod width x 400) + partial tick) x 0.03, the
// cloud scroll in blocks; cloudHeight = the cloud-height environment attribute (base of the
// layer, fallback 192).
uniform float cloudTime;
uniform float cloudHeight;

#ifdef BIOME_AMBIENCE
// Biome ambience, blended ONCE per frame on the CPU (custom uniforms in shaders.properties):
// family weights of the CAMERA biome (Iris has no per-pixel biome), smoothed over
// BIOME_TRANSITION_TIME, and the finished midday target colours and fog character.
uniform float bfOcean;
uniform float bfWarmOcean;
uniform float bfSnowy;
uniform float bfPlains;
uniform float bfForest;
uniform float bfDarkForest;
uniform float bfTaiga;
uniform float bfJungle;
uniform float bfSwamp;
uniform float bfDesert;
uniform float bfSavanna;
uniform float bfBadlands;
uniform float bfWindswept;
uniform float bfPeaks;
uniform float bfCherry;
uniform float bfMushroom;
uniform float bfScale;
uniform float bfBase;
uniform float bZenithR;
uniform float bZenithG;
uniform float bZenithB;
uniform float bMidR;
uniform float bMidG;
uniform float bMidB;
uniform float bHorR;
uniform float bHorG;
uniform float bHorB;
uniform float bCloudR;
uniform float bCloudG;
uniform float bCloudB;
uniform float bDensity;
uniform float bFalloff;
uniform float bScatter;
uniform float bSaturation;
uniform float bDust;
uniform float bgWarm;
uniform float bgCold;
uniform float bgHumid;
uniform float bgOcean;
uniform float bRainVisible;
uniform float bSnowfall;
uniform float bNetherR;
uniform float bNetherG;
uniform float bNetherB;
#endif

#ifdef AMB_CLOUD_TEXTURE
// customTexture.vclClouds = textures/clouds.png (a copy of the vanilla clouds.png inside the
// pack): the image the vanilla CloudRenderer turns into cells (one texel = one 12 x 12 block
// cell, alpha < 10 = empty).
uniform sampler2D vclClouds;
#endif

const float AMB_CLOUD_CELL = 12.0;       // vanilla cell size in blocks
const float AMB_CLOUD_Z_OFFSET = 3.96;   // vanilla: cloud z = camera z + 3.96
const float AMB_CLOUD_THICKNESS = 4.0;   // vanilla fancy cloud height in blocks
// World x/z are wrapped by this many blocks using the camera's integer position, so there is
// no float precision loss far from spawn. 24576 is a multiple of 12 x 256 (the cloud texture
// period), of every fog bank period and of every shadow grid step. The offset (24576 x 1221)
// lies beyond the world border, so % only ever sees non-negative values.
const int AMB_WRAP = 24576;
const int AMB_WRAP_OFFSET = 30007296;

// Celestial quads of the 26.3 SkyRenderer: the sun quad is 30 units across half its width at
// a distance of 100, and the bright 8 x 8-texel square fills the middle quarter of the
// 32 x 32 sun.png, so the visible sun square has a half size of 0.075 on the quad plane
// (about 4.3 degrees). The moon quad is 20/100 with the same layout: 0.05.
const float AMB_SUN_HALF = 0.075;
const float AMB_MOON_HALF = 0.05;

float ambLuma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float ambHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

// 4x4 ordered dither in (0, 1); fragment shaders pass gl_FragCoord.xy. Only the optional
// banded fog look uses it.
float ambBayer4(vec2 fragCoord) {
    const float B[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    ivec2 p = ivec2(fragCoord) & 3;
    return (B[p.x + p.y * 4] + 0.5) / 16.0;
}

// Interleaved gradient noise (Jimenez 2014): a fixed per-pixel value, no frame dependence.
float ambIGN(vec2 fragCoord) {
    return fract(52.9829189 * fract(dot(fragCoord, vec2(0.06711056, 0.00583715))));
}

// Static triangular-distribution dither in (-1, 1) from two decorrelated IGN samples. At an
// amplitude of one 8-bit step it removes banding without any visible grain or crawl.
float ambDither(vec2 fragCoord) {
    return ambIGN(fragCoord) + ambIGN(fragCoord + vec2(83.0, 47.0)) - 1.0;
}

vec3 ambSunDirection() {
    vec3 s = mat3(gbufferModelViewInverse) * sunPosition;
    return s * inversesqrt(max(dot(s, s), 1.0e-6));
}

// World position of a camera-relative point: x/z wrapped by AMB_WRAP, y exact.
vec3 ambWrappedWorld(vec3 playerPos) {
    ivec3 wrapped = (cameraPositionInt + ivec3(AMB_WRAP_OFFSET)) % ivec3(AMB_WRAP);
    return vec3(float(wrapped.x), float(cameraPositionInt.y), float(wrapped.z)) + cameraPositionFract + playerPos;
}

// Exact angle between two unit vectors (no acos precision loss near the sun).
float ambAngle(vec3 a, vec3 b) {
    return 2.0 * asin(clamp(0.5 * length(a - b), 0.0, 1.0));
}

// Moon brightness from the Iris moonPhase uniform (0 = full moon, 4 = new moon).
float ambMoonBrightness(int phase) {
    return abs(4.0 - float(phase)) * 0.25;
}

// ---------------------------------------------------------------------------------------
// Biome ambience. The base family is the look before biome ambience; every other family is
// described by its clear-midday colours, and its tint is target / base, applied on top of the
// time-of-day, golden-hour and weather palettes below (a delta, so those keep working).
const vec3 AMB_BIOME_BASE_ZENITH = vec3(0.3961, 0.5765, 0.9333);  // #6593EE
const vec3 AMB_BIOME_BASE_MID = vec3(0.5216, 0.6588, 0.9333);     // #85A8EE
const vec3 AMB_BIOME_BASE_HORIZON = vec3(0.6471, 0.7216, 0.9333); // #A5B8EE
const vec3 AMB_BIOME_BASE_CLOUD = vec3(0.6627, 0.7020, 0.9333);   // #A9B3EE
const vec3 AMB_NETHER_FOG_DEFAULT = vec3(0.48, 0.24, 0.19);       // the previous fixed Nether tint
const vec3 AMB_END_FOG_DEFAULT = vec3(0.38, 0.29, 0.58);          // the previous fixed End tint
const vec3 AMB_END_FOG = vec3(0.1020, 0.0627, 0.1882);            // #1A1030

#if defined(BIOME_AMBIENCE) && (FORCE_BIOME_PREVIEW > 0 || defined(BIOME_DEBUG))
// Family table (generated with the properties uniforms; index = family number in the README).
// Only the forced preview and the debug views use it; the normal path reads the CPU blend.
const vec3 AMB_BIOME_ZENITH[17] = vec3[17](vec3(0.3961, 0.5765, 0.9333), vec3(0.3686, 0.6039, 0.9176), vec3(0.3333, 0.6588, 0.9333), vec3(0.4784, 0.6196, 0.9020), vec3(0.4157, 0.6078, 0.9412), vec3(0.3961, 0.5765, 0.8941), vec3(0.3529, 0.4980, 0.7843), vec3(0.3725, 0.5412, 0.8471), vec3(0.3059, 0.6039, 0.8627), vec3(0.4353, 0.5608, 0.7216), vec3(0.3608, 0.5922, 0.9098), vec3(0.3608, 0.5961, 0.9020), vec3(0.4157, 0.5961, 0.8941), vec3(0.4157, 0.5608, 0.8471), vec3(0.4235, 0.6039, 0.9255), vec3(0.4941, 0.6275, 0.9176), vec3(0.5412, 0.5490, 0.9098));
const vec3 AMB_BIOME_MID[17] = vec3[17](vec3(0.5216, 0.6588, 0.9333), vec3(0.5176, 0.6980, 0.9255), vec3(0.5020, 0.7529, 0.9255), vec3(0.6431, 0.7373, 0.9255), vec3(0.5608, 0.6902, 0.9333), vec3(0.5255, 0.6588, 0.8627), vec3(0.4824, 0.5961, 0.7529), vec3(0.5098, 0.6275, 0.8235), vec3(0.4706, 0.7137, 0.8392), vec3(0.5529, 0.6510, 0.6980), vec3(0.6157, 0.6980, 0.8706), vec3(0.6431, 0.7137, 0.8471), vec3(0.6627, 0.7059, 0.8471), vec3(0.5569, 0.6510, 0.8235), vec3(0.6118, 0.7294, 0.9333), vec3(0.6902, 0.7059, 0.9098), vec3(0.6902, 0.6431, 0.9098));
const vec3 AMB_BIOME_HORIZON[17] = vec3[17](vec3(0.6471, 0.7216, 0.9333), vec3(0.6627, 0.7765, 0.9255), vec3(0.6588, 0.8392, 0.9176), vec3(0.8039, 0.8549, 0.9412), vec3(0.6902, 0.7686, 0.9255), vec3(0.6588, 0.7608, 0.8471), vec3(0.5647, 0.6431, 0.7373), vec3(0.6588, 0.7373, 0.8392), vec3(0.6118, 0.8118, 0.7961), vec3(0.6392, 0.7020, 0.6039), vec3(0.9020, 0.8235, 0.6902), vec3(0.9294, 0.8118, 0.6118), vec3(0.8941, 0.7451, 0.6431), vec3(0.7059, 0.7529, 0.8392), vec3(0.8314, 0.8863, 0.9647), vec3(0.9098, 0.8000, 0.9020), vec3(0.8314, 0.7373, 0.9098));
const vec3 AMB_BIOME_CLOUD[17] = vec3[17](vec3(0.6627, 0.7020, 0.9333), vec3(0.7059, 0.7608, 0.9333), vec3(0.7373, 0.7922, 0.9333), vec3(0.8627, 0.8863, 0.9569), vec3(0.7059, 0.7451, 0.9333), vec3(0.6824, 0.7373, 0.8784), vec3(0.6118, 0.6667, 0.8157), vec3(0.6902, 0.7373, 0.8784), vec3(0.6902, 0.8157, 0.8784), vec3(0.6902, 0.7216, 0.7843), vec3(0.8941, 0.8471, 0.9176), vec3(0.9216, 0.8667, 0.8784), vec3(0.9020, 0.8235, 0.8627), vec3(0.7216, 0.7529, 0.8784), vec3(0.8784, 0.9020, 0.9647), vec3(0.9412, 0.8471, 0.9255), vec3(0.8784, 0.8000, 0.9412));
const vec4 AMB_BIOME_CHAR[17] = vec4[17](vec4(1.0000, 1.0000, 1.0000, 1.0000), vec4(1.0000, 1.0000, 1.0000, 1.0000), vec4(0.9000, 1.0000, 1.0500, 1.0500), vec4(1.1500, 0.9000, 0.9000, 0.9500), vec4(0.9000, 1.0000, 1.0000, 1.0000), vec4(1.0500, 1.0000, 1.0000, 1.0000), vec4(1.3500, 0.8000, 0.8500, 0.9000), vec4(1.1000, 1.0000, 0.9500, 0.9500), vec4(1.2500, 1.0000, 1.2000, 1.1000), vec4(1.4000, 0.7500, 0.9000, 0.9000), vec4(0.7000, 1.0000, 1.3000, 1.0000), vec4(0.8000, 1.0000, 1.3000, 1.0000), vec4(0.7500, 1.0000, 1.2500, 1.0000), vec4(0.8500, 1.0000, 1.0000, 0.9500), vec4(1.0000, 1.1000, 0.9500, 0.9500), vec4(0.9500, 1.0000, 1.0500, 1.0000), vec4(1.0000, 1.0000, 1.0000, 1.0000)); // density, falloff, scatter, saturation
const float AMB_BIOME_DUST[17] = float[17](0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 1.0000, 0.5000, 0.8000, 0.0000, 0.0000, 0.0000, 0.0000);
const int AMB_BIOME_GROUP[17] = int[17](0, 4, 4, 2, 0, 0, 0, 2, 3, 3, 1, 1, 1, 0, 2, 0, 0); // 0 other, 1 warm, 2 cold, 3 humid, 4 ocean
#endif

struct AmbBiome {
    vec3 zenith;        // clear-midday targets of the current family mix
    vec3 mid;
    vec3 horizon;       // = the fog colour at midday
    vec3 cloud;
    float density;      // fog character multipliers
    float falloff;
    float scatter;
    float saturation;
    float dust;         // optional desert/badlands ground dust (BIOME_DESERT_DUST)
    float strength;     // how much of the biome look applies (group sliders; 0 = off)
    float rainVisible;  // 0 in biomes without precipitation (desert, savanna, badlands)
    float snowfall;     // 1 where it snows instead of raining
    float goldenWarm;   // warm-biome weight for the golden-hour sky tint
};

float ambBiomeGroupStrength(int group) {
#ifdef BIOME_AMBIENCE
    if (group == 1) return BIOME_WARM_STRENGTH;
    if (group == 2) return BIOME_COLD_STRENGTH;
    if (group == 3) return BIOME_HUMID_STRENGTH;
    if (group == 4) return BIOME_OCEAN_STRENGTH;
#endif
    return 1.0;
}

// The current biome look: the CPU blend (or a forced family for testing). With the feature
// off, or if the custom uniforms did not load, this is the base look (strength 0).
AmbBiome ambBiome() {
    AmbBiome b;
    b.zenith = AMB_BIOME_BASE_ZENITH;
    b.mid = AMB_BIOME_BASE_MID;
    b.horizon = AMB_BIOME_BASE_HORIZON;
    b.cloud = AMB_BIOME_BASE_CLOUD;
    b.density = 1.0;
    b.falloff = 1.0;
    b.scatter = 1.0;
    b.saturation = 1.0;
    b.dust = 0.0;
    b.strength = 0.0;
    b.rainVisible = 1.0;
    b.snowfall = 0.0;
    b.goldenWarm = 0.0;
#ifdef BIOME_AMBIENCE
#if FORCE_BIOME_PREVIEW > 0
    b.zenith = AMB_BIOME_ZENITH[FORCE_BIOME_PREVIEW];
    b.mid = AMB_BIOME_MID[FORCE_BIOME_PREVIEW];
    b.horizon = AMB_BIOME_HORIZON[FORCE_BIOME_PREVIEW];
    b.cloud = AMB_BIOME_CLOUD[FORCE_BIOME_PREVIEW];
    vec4 character = AMB_BIOME_CHAR[FORCE_BIOME_PREVIEW];
    b.density = character.x;
    b.falloff = character.y;
    b.scatter = character.z;
    b.saturation = character.w;
    b.dust = AMB_BIOME_DUST[FORCE_BIOME_PREVIEW];
    b.strength = ambBiomeGroupStrength(AMB_BIOME_GROUP[FORCE_BIOME_PREVIEW]);
#ifdef BIOME_PRECIPITATION
    b.rainVisible = AMB_BIOME_GROUP[FORCE_BIOME_PREVIEW] == 1 ? 0.0 : 1.0;
    b.snowfall = (FORCE_BIOME_PREVIEW == 3 || FORCE_BIOME_PREVIEW == 14) ? 1.0 : 0.0;
#endif
    b.goldenWarm = FORCE_BIOME_PREVIEW == 11 ? 0.55 : ((FORCE_BIOME_PREVIEW == 4 || FORCE_BIOME_PREVIEW == 5) ? 0.24 : 0.0);
#else
    vec3 horizon = vec3(bHorR, bHorG, bHorB);
    if (horizon.r + horizon.g + horizon.b > 0.05) {
        b.zenith = vec3(bZenithR, bZenithG, bZenithB);
        b.mid = vec3(bMidR, bMidG, bMidB);
        b.horizon = horizon;
        b.cloud = vec3(bCloudR, bCloudG, bCloudB);
        b.density = bDensity;
        b.falloff = bFalloff;
        b.scatter = bScatter;
        b.saturation = bSaturation;
        b.dust = bDust;
        b.strength = 1.0 + bgWarm * (BIOME_WARM_STRENGTH - 1.0) + bgCold * (BIOME_COLD_STRENGTH - 1.0) +
                     bgHumid * (BIOME_HUMID_STRENGTH - 1.0) + bgOcean * (BIOME_OCEAN_STRENGTH - 1.0);
#ifdef BIOME_PRECIPITATION
        b.rainVisible = bRainVisible;
        b.snowfall = bSnowfall;
#endif
        b.goldenWarm = max(bfSavanna * bfScale * 0.55, (bfForest + bfPlains) * bfScale * 0.24);
    }
#endif
#endif
    return b;
}

// Rain as the sky and fog see it: biomes without precipitation (desert, savanna, badlands)
// stay clear while it rains elsewhere (BIOME_PRECIPITATION). Thunder is left as it was.
float ambRain() {
    return clamp(rainStrength, 0.0, 1.0) * ambBiome().rainVisible;
}

// How much of the midday biome tint shows now: all of it by day, about a third at sunrise
// and sunset (the golden palettes dominate, slightly tinted: desert sunsets a little redder,
// jungle sunsets a little greener), 15 % at night (calm and blue).
float ambBiomeTimeWeight(float sunElevation) {
    float day = mix(0.30, 1.0, smoothstep(0.08, 0.35, sunElevation));
    float night = mix(0.15, 0.30, smoothstep(-0.25, 0.0, sunElevation));
    return sunElevation > 0.0 ? day : night;
}

// Biome tint: target / base raised to k (0 = no change, 1 = the full midday shift), turned
// toward grey in rain. Clamped, so no palette can push a channel to zero or past twice.
vec3 ambBiomeTint(vec3 target, vec3 base, float k, float rain) {
    vec3 ratio = clamp(target / base, vec3(0.5), vec3(1.8));
    ratio = mix(ratio, vec3(dot(ratio, vec3(0.2126, 0.7152, 0.0722))), 0.5 * rain);
    return pow(ratio, vec3(max(k, 0.0)));
}

// Nether fog tint of the current Nether biome (the previous fixed tint without the feature).
vec3 ambNetherFogTint() {
#ifdef BIOME_AMBIENCE
    vec3 c = vec3(bNetherR, bNetherG, bNetherB);
    if (c.r + c.g + c.b > 0.01) return c;
#endif
    return AMB_NETHER_FOG_DEFAULT;
}

vec3 ambEndFogTint() {
#ifdef BIOME_AMBIENCE
    return AMB_END_FOG;
#else
    return AMB_END_FOG_DEFAULT;
#endif
}

// ---------------------------------------------------------------------------------------
// Palettes. Rows: 0 night, 1 dusk, 2 sunset, 3 golden hour (pm), 4 afternoon, 5 midday,
// 6 dawn, 7 sunrise, 8 golden hour (am), 9 morning, 10 rain (day), 11 thunder (day).
// Columns: zenith, mid sky, horizon (= the fog colour at the horizon), 3-6 retired (the near
// fog and the cloud colours are now derived from the sky, see ambiencePalette), sunlight,
// sky light. Midday, afternoon and morning sky columns are sampled from the cornflower sky
// reference (README v5).
const vec3 AMB_PAL[108] = vec3[108](
    vec3(0.027, 0.047, 0.118), vec3(0.055, 0.086, 0.188), vec3(0.102, 0.141, 0.251), vec3(0.094, 0.133, 0.235), vec3(0.133, 0.165, 0.267), vec3(0.173, 0.212, 0.329), vec3(0.078, 0.102, 0.180), vec3(0.353, 0.416, 0.604), vec3(0.157, 0.196, 0.306),
    vec3(0.118, 0.157, 0.314), vec3(0.235, 0.267, 0.455), vec3(0.424, 0.392, 0.533), vec3(0.353, 0.353, 0.502), vec3(0.361, 0.361, 0.502), vec3(0.541, 0.439, 0.565), vec3(0.204, 0.220, 0.353), vec3(0.376, 0.439, 0.627), vec3(0.290, 0.329, 0.502),
    vec3(0.290, 0.369, 0.612), vec3(0.604, 0.518, 0.690), vec3(0.957, 0.604, 0.424), vec3(0.847, 0.604, 0.549), vec3(0.941, 0.659, 0.565), vec3(1.000, 0.690, 0.439), vec3(0.431, 0.408, 0.565), vec3(1.000, 0.604, 0.361), vec3(0.549, 0.565, 0.753),
    vec3(0.416, 0.518, 0.769), vec3(0.690, 0.643, 0.800), vec3(0.973, 0.769, 0.612), vec3(0.941, 0.737, 0.612), vec3(0.973, 0.824, 0.722), vec3(1.000, 0.816, 0.549), vec3(0.643, 0.596, 0.722), vec3(1.000, 0.784, 0.533), vec3(0.706, 0.722, 0.863),
    vec3(0.416, 0.604, 0.941), vec3(0.431, 0.612, 0.933), vec3(0.659, 0.729, 0.925), vec3(0.800, 0.769, 0.878), vec3(0.902, 0.871, 0.925), vec3(1.000, 0.949, 0.902), vec3(0.776, 0.769, 0.863), vec3(1.000, 0.902, 0.769), vec3(0.776, 0.800, 0.918),
    vec3(0.396, 0.588, 0.933), vec3(0.388, 0.573, 0.929), vec3(0.643, 0.722, 0.925), vec3(0.784, 0.769, 0.902), vec3(0.894, 0.886, 0.957), vec3(0.965, 0.961, 0.988), vec3(0.816, 0.824, 0.925), vec3(1.000, 0.945, 0.863), vec3(0.784, 0.831, 0.941),
    vec3(0.125, 0.173, 0.345), vec3(0.251, 0.290, 0.486), vec3(0.439, 0.408, 0.557), vec3(0.369, 0.369, 0.525), vec3(0.376, 0.376, 0.494), vec3(0.565, 0.471, 0.596), vec3(0.212, 0.235, 0.376), vec3(0.408, 0.471, 0.659), vec3(0.306, 0.345, 0.533),
    vec3(0.306, 0.392, 0.643), vec3(0.627, 0.549, 0.722), vec3(0.957, 0.659, 0.549), vec3(0.863, 0.643, 0.627), vec3(0.949, 0.706, 0.643), vec3(1.000, 0.753, 0.627), vec3(0.447, 0.439, 0.596), vec3(1.000, 0.659, 0.471), vec3(0.565, 0.596, 0.784),
    vec3(0.431, 0.533, 0.784), vec3(0.659, 0.659, 0.831), vec3(0.941, 0.784, 0.722), vec3(0.910, 0.753, 0.722), vec3(0.957, 0.839, 0.800), vec3(1.000, 0.878, 0.722), vec3(0.643, 0.627, 0.769), vec3(1.000, 0.824, 0.627), vec3(0.722, 0.753, 0.894),
    vec3(0.416, 0.604, 0.941), vec3(0.431, 0.612, 0.933), vec3(0.659, 0.729, 0.925), vec3(0.792, 0.761, 0.886), vec3(0.894, 0.863, 0.941), vec3(1.000, 0.949, 0.949), vec3(0.769, 0.776, 0.878), vec3(1.000, 0.918, 0.816), vec3(0.769, 0.808, 0.933),
    vec3(0.541, 0.573, 0.620), vec3(0.604, 0.635, 0.675), vec3(0.659, 0.682, 0.714), vec3(0.643, 0.667, 0.698), vec3(0.651, 0.671, 0.706), vec3(0.706, 0.722, 0.753), vec3(0.494, 0.518, 0.557), vec3(0.784, 0.800, 0.816), vec3(0.643, 0.675, 0.722),
    vec3(0.290, 0.314, 0.361), vec3(0.337, 0.361, 0.408), vec3(0.392, 0.416, 0.455), vec3(0.369, 0.392, 0.431), vec3(0.361, 0.384, 0.424), vec3(0.416, 0.439, 0.478), vec3(0.235, 0.259, 0.298), vec3(0.541, 0.565, 0.596), vec3(0.361, 0.392, 0.439)
);
// Sun elevation (sin of the altitude) of rows 0-5; rows 1-4 have morning twins (rows 6-9).
const float AMB_KEY_E[6] = float[6](-0.30, -0.10, 0.00, 0.12, 0.35, 0.70);

const int AMB_ZENITH = 0;
const int AMB_MID = 1;
const int AMB_HORIZON = 2;
const int AMB_SUN_LIGHT = 7;
const int AMB_SKY_LIGHT = 8;

struct AmbTime {
    int key;            // lower palette row
    float blend;        // smoothstep weight toward key + 1 (no pops)
    float morning;      // 1 = the sun is in the east (rising), 0 = west (setting)
    float rain;
    float thunder;
    float weatherLight; // overcast palettes darken with the time of day
    float snow;         // 1 where it snows: the overcast palette is brighter and whiter
    AmbBiome biome;     // the current biome look (CPU blend)
    float biomeK;       // how much of the midday biome tint applies now (time, rain, groups)
};

vec3 ambKey(int key, int column, float morning) {
    int morningKey = (key >= 1 && key <= 4) ? key + 5 : key;
    return mix(AMB_PAL[key * 9 + column], AMB_PAL[morningKey * 9 + column], morning);
}

AmbTime ambTime(vec3 sunDir) {
    AmbTime t;
    float e = sunDir.y;
    t.key = e < AMB_KEY_E[1] ? 0 : (e < AMB_KEY_E[2] ? 1 : (e < AMB_KEY_E[3] ? 2 : (e < AMB_KEY_E[4] ? 3 : 4)));
    t.blend = smoothstep(AMB_KEY_E[t.key], AMB_KEY_E[t.key + 1], e);
    t.morning = smoothstep(-0.25, 0.25, sunDir.x);
    t.biome = ambBiome();
    t.rain = clamp(rainStrength, 0.0, 1.0) * t.biome.rainVisible;
    t.thunder = clamp(thunderStrength, 0.0, 1.0);
    t.weatherLight = mix(0.14, 1.0, smoothstep(-0.25, 0.10, e));
    t.snow = t.biome.snowfall;
    t.biomeK = ambBiomeTimeWeight(e) * (1.0 - 0.6 * t.rain) * t.biome.strength;
    return t;
}

// One palette column at the current time and weather (biome not applied).
vec3 ambColor(AmbTime t, int column) {
    vec3 clear = mix(ambKey(t.key, column, t.morning), ambKey(t.key + 1, column, t.morning), t.blend);
    vec3 wet = AMB_PAL[90 + column] * t.weatherLight;
    // Snowfall is brighter and whiter than rain grey.
    wet = mix(wet, min(wet * 1.22 + vec3(0.04, 0.05, 0.07), vec3(1.0)), t.snow);
    clear = mix(clear, wet, t.rain * 0.85);
    return mix(clear, AMB_PAL[99 + column] * t.weatherLight, t.thunder * 0.90);
}

// Lavender control: 0 = neutral blue haze, 1 = palette, 1.5 = more lavender.
vec3 ambLavender() {
    return mix(vec3(1.0), vec3(1.05, 0.96, 1.03), ENV_LAVENDER - 1.0);
}

// Sky light for the terrain light response: a faint touch of the biome haze (about the
// strength the previous biome ratio had on it).
vec3 ambSkyLightColor(AmbTime t) {
    return ambColor(t, AMB_SKY_LIGHT) *
           ambBiomeTint(t.biome.horizon, AMB_BIOME_BASE_HORIZON, 0.12 * t.biomeK * BIOME_FOG_STRENGTH, t.rain);
}

// Warmth of a low sun (1 at the horizon, 0 from about 17 degrees up).
float ambSunTwilight(vec3 sunDir) {
    return 1.0 - smoothstep(0.03, 0.30, sunDir.y);
}

// Visibility of the sun's glow: below the horizon, rain and thunder take it away smoothly.
float ambSunGlowVisibility(vec3 sunDir) {
    return smoothstep(-0.06, 0.04, sunDir.y) * (1.0 - 0.85 * ambRain()) *
           (1.0 - 0.90 * clamp(thunderStrength, 0.0, 1.0));
}

// Glow colour: warm white at midday (fitted to the sun reference: #FFF7F0), golden when low.
vec3 ambSunGlowColor(vec3 sunDir) {
    return mix(vec3(1.00, 0.97, 0.94), vec3(1.00, 0.78, 0.52), ambSunTwilight(sunDir));
}

struct AmbPalette {
    vec3 zenith;
    vec3 mid;
    vec3 horizon;      // the sky (and so the fog) at the horizon
    vec3 fogNear;      // = horizon (kept for the fog-aware water reflection)
    vec3 cloudTop;     // derived from the sky, see below
    vec3 cloudEdge;
    vec3 cloudUnder;
    vec3 sunLight;
    vec3 skyLight;
    vec3 glow;         // sun scattering colour, already scaled by sun visibility and weather
    float golden;      // weight of the golden-hour sky tint (GOLDEN_TARGET_SKY)
};

// The palette for this frame: time of day and weather (the rows above), then the biome look
// as a tint on top. biomeAmount = 0 gives the palette without the biome (the water's own
// reflection when BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off).
AmbPalette ambiencePaletteBiome(vec3 sunDir, float biomeAmount) {
    AmbTime t = ambTime(sunDir);
    AmbBiome b = t.biome;
    vec3 lavender = ambLavender();
    AmbPalette p;
    vec3 horizon = ambColor(t, AMB_HORIZON);
    // Biome tint. The horizon colour IS the fog colour (one function), so the horizon tint
    // uses BIOME_FOG_STRENGTH; the mid sky BIOME_SKY_STRENGTH; the zenith only a little.
    float k = t.biomeK * biomeAmount;
    p.zenith = ambColor(t, AMB_ZENITH) * ambBiomeTint(b.zenith, AMB_BIOME_BASE_ZENITH, k * BIOME_SKY_STRENGTH * BIOME_ZENITH_SHIFT, t.rain);
    p.mid = ambColor(t, AMB_MID) * ambBiomeTint(b.mid, AMB_BIOME_BASE_MID, k * BIOME_SKY_STRENGTH, t.rain) * mix(vec3(1.0), lavender, 0.5);
    p.horizon = horizon * ambBiomeTint(b.horizon, AMB_BIOME_BASE_HORIZON, k * BIOME_FOG_STRENGTH, t.rain) * lavender;
    // Haze saturation of the biome (jungle a little richer, swamp and dark forest duller).
    float saturation = 1.0 + (clamp(b.saturation, 0.7, 1.3) - 1.0) * k * BIOME_FOG_STRENGTH;
    p.horizon = max(mix(vec3(ambLuma(p.horizon)), p.horizon, saturation), vec3(0.0));
    p.mid = max(mix(vec3(ambLuma(p.mid)), p.mid, saturation), vec3(0.0));
    p.fogNear = p.horizon;
    p.sunLight = ambColor(t, AMB_SUN_LIGHT);
    p.skyLight = ambSkyLightColor(t);
    float sunVisible = smoothstep(-0.06, 0.06, sunDir.y) * (1.0 - 0.85 * t.rain) * (1.0 - 0.9 * t.thunder);
    // The haze sun scattering colour, scaled by the biome's sun-scatter multiplier (clamped).
    float scatterBiome = mix(1.0, clamp(b.scatter, 0.5, 1.5), BIOME_DENSITY_MULTIPLIER_STRENGTH * b.strength * biomeAmount);
    p.glow = p.sunLight * (0.35 * sunVisible * scatterBiome);

    // Cloud colours from the same sky (no separate palette that could clash): lit faces mix
    // the horizon colour toward a lavender white lit by the sun (golden when the sun is low,
    // grey in rain, dim blue at night); undersides are a cooler, deeper horizon colour. The
    // biome's cloud tint replaces the horizon tint here (BIOME_CLOUD_TINT_STRENGTH).
    // Translucent fit (CLOUD_OPACITY 0.65): over the midday sky (side faces 0.75) the result is
    // the v5 reference: side faces #AAB4F2, upper body #A1B0ED, side base #8DA1E6, underside #829BE5.
    vec3 cloudBase = horizon * ambBiomeTint(b.cloud, AMB_BIOME_BASE_CLOUD, k * BIOME_CLOUD_TINT_STRENGTH, t.rain) * lavender;
    float sunLuma = ambLuma(p.sunLight);
    float lowSunLight = 0.8 * ambSunTwilight(sunDir) * smoothstep(-0.10, 0.02, sunDir.y);
    vec3 lavenderWhite = vec3(1.00, 0.86, 1.00) * sunLuma;
    vec3 cloudLight = mix(lavenderWhite, p.sunLight, lowSunLight);
    p.cloudTop = mix(cloudBase, cloudLight, clamp(0.36 * CLOUD_BRIGHTNESS, 0.0, 1.0));
    p.cloudEdge = mix(cloudBase, cloudLight, clamp((0.36 + 0.10 * CLOUD_EDGE_HIGHLIGHT) * CLOUD_BRIGHTNESS, 0.0, 1.0));
    p.cloudUnder = cloudBase * mix(vec3(1.0), vec3(0.80, 0.74, 0.90), CLOUD_UNDERSIDE_DARKNESS);
#ifdef CLOUDS_BLOCK_SUN
    // Opaque fit (CLOUD_OPACITY 1.0), measured on the update-1 reference at midday, clouds seen
    // from below: undersides #DACEE0 (pale lavender-pink), side faces edge-on #DCDCFF (thin,
    // lighter, bluish white); the top faces (not visible there) a little lighter and pinker.
    // Same inputs (horizon, biome cloud tint, sunlight), so sunsets turn golden, rain grey,
    // nights dim blue. Between 0.65 and 1.0 the two fits blend, so lowering CLOUD_OPACITY brings
    // the previous translucent look back.
    float opaqueFit = clamp((CLOUD_OPACITY - 0.65) / 0.35, 0.0, 1.0);
    vec3 pinkWhite = mix(vec3(1.05, 0.925, 0.88) * sunLuma, p.sunLight, lowSunLight);
    vec3 skyWhite = mix(vec3(1.00, 1.00, 1.056) * sunLuma, p.sunLight, lowSunLight);
    vec3 opaqueTop = mix(cloudBase, pinkWhite, clamp(0.70 * CLOUD_BRIGHTNESS, 0.0, 1.0));
    vec3 opaqueEdge = mix(cloudBase, skyWhite, clamp((0.55 + 0.20 * CLOUD_EDGE_HIGHLIGHT) * CLOUD_BRIGHTNESS, 0.0, 1.0));
    vec3 opaqueUnder = mix(cloudBase, pinkWhite, clamp((1.0 - 0.82 * CLOUD_UNDERSIDE_DARKNESS) * CLOUD_BRIGHTNESS, 0.0, 1.0));
    p.cloudTop = mix(p.cloudTop, opaqueTop, opaqueFit);
    p.cloudEdge = mix(p.cloudEdge, opaqueEdge, opaqueFit);
    p.cloudUnder = mix(p.cloudUnder, opaqueUnder, opaqueFit);
#endif

    p.golden = 0.0;
#ifdef GOLDEN_TARGET_SKY
    // Same weights as the golden-hour sky tint in final, so sky, fog and reflections agree.
    float twilightSky = 1.0 - smoothstep(0.035, 0.34, abs(sunDir.y));
    float daySide = smoothstep(-0.16, -0.005, sunDir.y);
    float weather = clamp(1.0 - t.rain * 0.58 - t.thunder * 0.32, 0.0, 1.0);
    // Warm biomes (savanna, and a little plains/forest) keep a golden tint a bit longer.
    float warmBiome = clamp(b.goldenWarm * biomeAmount, 0.0, 1.0) * (1.0 - smoothstep(-0.10, 0.18, sunDir.y));
    p.golden = max(twilightSky * daySide, warmBiome) * weather * float(MATCH_STRENGTH) * 0.01 * GOLDEN_SKY_TINT_STRENGTH;
#endif
    return p;
}

AmbPalette ambiencePalette(vec3 sunDir) {
    return ambiencePaletteBiome(sunDir, 1.0);
}

// ---------------------------------------------------------------------------------------
// The sky. ONE colour function: the sky pixels, the fog (at every distance), the clouds'
// haze, the sky behind translucent clouds and the water's Tier-1 reflection all evaluate
// ambienceSky with the real view direction, so terrain that dissolves into the haze lands
// exactly on the sky colour behind it and there is no line at the horizon.

// Vertical gradient (display colours), fitted to the cornflower reference: the horizon colour
// holds near the horizon and gives way to the mid sky by about 33 degrees, then the zenith.
// Below the horizon the sky is the horizon colour (no darker band).
vec3 ambSkyGradient(vec3 dir, vec3 zenith, vec3 mid, vec3 horizon) {
    float e = max(dir.y, 0.0);
    vec3 sky = mix(horizon, mid, smoothstep(0.0, 0.55, e));
    return mix(sky, zenith, smoothstep(0.45, 1.0, e));
}

// Wide halo and haze sun scattering on top of a sky colour, with ONE falloff
// (SUN_HALO_SIZE): the halo is just a lighter version of the local sky colour; the
// scattering happens in the low haze (horizonWeight = 1 at and below the horizon, fading
// upward), warmer and lighter toward the sun and slightly cooler away from it.
vec3 ambHaze(vec3 sky, vec3 dir, vec3 sunDir, vec3 glow, float horizonWeight, out float halo, out float scatter) {
    float theta = ambAngle(dir, sunDir);
    halo = 0.0;
    scatter = 0.0;
#ifdef SUN_GLOW
    halo = SUN_HALO_STRENGTH * exp(-theta / SUN_HALO_SIZE) * ambSunGlowVisibility(sunDir);
    sky = mix(sky, min(sky * 1.30 + vec3(0.04), vec3(1.0)), halo);
#endif
#ifdef FOG_SCATTERING
    float forward = 0.5 + 0.5 * dot(dir, sunDir);
    scatter = FOG_SUN_SCATTER * horizonWeight *
              (0.65 * exp(-theta / (1.5 * SUN_HALO_SIZE)) + 0.35 * forward * forward);
    sky += glow * scatter;
    sky *= mix(vec3(1.0), vec3(0.95, 0.96, 1.04), (1.0 - forward) * horizonWeight * 0.5 * min(FOG_SUN_SCATTER, 1.0));
#endif
    return sky;
}

// The sky along dir without the sun's own glow and disc: gradient, golden-hour tint, wide
// halo and haze scattering. This is also the fog colour for a surface seen along dir.
vec3 ambienceSkyTerms(vec3 dir, vec3 sunDir, vec3 zenith, vec3 mid, vec3 horizon, vec3 glow, float golden,
                      out float halo, out float scatter) {
    vec3 sky = ambSkyGradient(dir, zenith, mid, horizon);
#ifdef GOLDEN_TARGET_SKY
    vec3 goldenSky = mix(vec3(0.46, 0.37, 0.27), vec3(1.00, 0.72, 0.39), 1.0 - smoothstep(0.015, 0.90, max(dir.y, 0.0)));
    sky = mix(sky, goldenSky, golden);
#endif
    sky = ambHaze(sky, dir, sunDir, glow, 1.0 - smoothstep(0.0, 0.45, dir.y), halo, scatter);
    return max(sky, vec3(0.0));
}

vec3 ambienceSky(vec3 dir, vec3 sunDir, vec3 zenith, vec3 mid, vec3 horizon, vec3 glow, float golden) {
    float halo;
    float scatter;
    return ambienceSkyTerms(dir, sunDir, zenith, mid, horizon, glow, golden, halo, scatter);
}

// Haze colour from a horizon colour alone (the fog-aware water reflection's segment colour):
// the halo and scattering of ambienceSky at the horizon.
vec3 ambienceFogNear(vec3 dir, vec3 sunDir, vec3 fogNear, vec3 glow) {
    float halo;
    float scatter;
    return ambHaze(fogNear, dir, sunDir, glow, 1.0, halo, scatter);
}

// Gnomonic coordinates of dir on the plane of a celestial quad that faces c: x along the
// sun path, y along the path axis (world Z when sunPathRotation = 0, which is how the
// vanilla quad is oriented), z = cos(angle to c).
vec3 ambCelestialPlane(vec3 dir, vec3 c) {
    vec3 axis = vec3(0.0, 0.0, 1.0) - c * c.z;
    axis *= inversesqrt(max(dot(axis, axis), 1.0e-6));
    vec3 along = cross(axis, c);
    float cosA = dot(dir, c);
    float inv = 1.0 / max(cosA, 1.0e-3);
    return vec3(dot(dir, along) * inv, dot(dir, axis) * inv, cosA);
}

struct AmbGlow {
    float core;   // thin bloom hugging the sun square (mix weight)
    float mid;    // mid glow, ray lobes included (mix weight)
    float rays;   // the ray modulation alone (1 = none)
    float moon;   // the moon's smaller, cooler glow (mix weight)
};

// Sun and moon glow, analytic and never stepped. Fitted to the sun reference (pixel profile
// above the sun square): mix weight 0.47 exp(-d / 0.125 h) + 0.37 exp(-d / 0.65 h), with d
// the angular distance from the square's edge and h its half size. The thin bloom follows
// the square (Chebyshev distance), the mid glow is round. The soft rays modulate the mid
// glow with 7 + 11 smooth lobes that turn very slowly (integer lobe counts, so there is no
// seam; the rates repeat exactly when frameTimeCounter wraps at 3600 s); they fade out near
// the disc, where the lobes would get thin.
AmbGlow ambCelestialGlow(vec3 dir, vec3 sunDir, float moonBrightness) {
    AmbGlow g;
    g.core = 0.0;
    g.mid = 0.0;
    g.rays = 1.0;
    g.moon = 0.0;
#ifdef SUN_GLOW
    float strength = SUN_GLOW_STRENGTH * ambSunGlowVisibility(sunDir) * mix(0.85, 1.30, ambSunTwilight(sunDir));
    vec3 p = ambCelestialPlane(dir, sunDir);
    float theta = ambAngle(dir, sunDir);
    float q = p.z > 0.0 ? max(abs(p.x), abs(p.y)) : 10.0;
    float dSquare = max(q - AMB_SUN_HALF, 0.0);
    float dRound = max(theta - AMB_SUN_HALF * 1.06, 0.0);
    g.core = 0.47 * exp(-dSquare / (0.125 * AMB_SUN_HALF)) * strength;
#ifdef SUN_RAYS
    float phi = atan(p.y, p.x + 1.0e-6);
    float lobes = 0.62 * cos(7.0 * phi + 0.0523599 * frameTimeCounter) +
                  0.38 * cos(11.0 * phi - 0.0314159 * frameTimeCounter + 1.3);
    g.rays = 1.0 + RAY_VARIATION * lobes * smoothstep(AMB_SUN_HALF * 0.8, AMB_SUN_HALF * 2.0, theta);
#endif
    g.mid = 0.37 * exp(-dRound / (0.65 * AMB_SUN_HALF)) * g.rays * strength;

    float moonVisible = smoothstep(-0.04, 0.06, -sunDir.y) * moonBrightness *
                        (1.0 - 0.85 * ambRain()) * (1.0 - 0.90 * clamp(thunderStrength, 0.0, 1.0));
    if (moonVisible > 0.0) {
        vec3 m = ambCelestialPlane(dir, -sunDir);
        float qm = m.z > 0.0 ? max(abs(m.x), abs(m.y)) : 10.0;
        float dm = max(qm - AMB_MOON_HALF, 0.0);
        g.moon = (0.22 * exp(-dm / (0.15 * AMB_MOON_HALF)) + 0.12 * exp(-dm / (0.90 * AMB_MOON_HALF))) *
                 moonVisible * SUN_GLOW_STRENGTH;
    }
#endif
    return g;
}

// The sun itself. shaders.properties sets sun=false, so the vanilla quad is not drawn and
// this is the only sun: style 0 is the vanilla 8 x 8-texel square at its exact size and
// orientation with its three pixel rings (vanilla #FFD54A / #FFFFAA / #FFFFD9, lifted toward
// the bright white-yellow target: #FFF2C2 / #FFFADB / #FFFBE6); style 1 is a soft round disc
// of the same area. The edges are
// anti-aliased over one pixel (pixelAngle = angular size of a pixel). Premultiplied rgb, a =
// coverage.
vec4 ambSunDisc(vec3 dir, vec3 sunDir, float pixelAngle) {
    vec3 p = ambCelestialPlane(dir, sunDir);
    if (p.z <= 0.0) return vec4(0.0);
    float aa = max(pixelAngle, 1.0e-5);
#if SUN_STYLE == 0
    float q = max(abs(p.x), abs(p.y));
    float inside = AMB_SUN_HALF - q;
    float texel = AMB_SUN_HALF * 0.25;
    float cover = clamp(inside / aa + 0.5, 0.0, 1.0);
    float inner = clamp((inside - texel) / aa + 0.5, 0.0, 1.0);
    float core = clamp((inside - 2.0 * texel) / aa + 0.5, 0.0, 1.0);
    vec3 c = mix(vec3(1.00, 0.95, 0.76), vec3(1.00, 0.98, 0.86), inner);
    c = mix(c, vec3(1.00, 0.984, 0.902), core);
#else
    const float radius = AMB_SUN_HALF * 1.128;
    float cover = 1.0 - smoothstep(radius - max(aa, radius * 0.12), radius + 0.5 * aa, length(p.xy));
    vec3 c = vec3(1.00, 0.984, 0.902);
#endif
    c *= mix(vec3(1.0), vec3(1.00, 0.84, 0.62), ambSunTwilight(sunDir));
    // Rain hides the sun like vanilla; it sinks smoothly into the horizon haze.
    cover *= (1.0 - ambRain()) * smoothstep(-0.02, 0.04, dir.y);
    return vec4(c * cover, cover);
}

// The sky with the glow of the sun and moon (no disc): the clouds' haze target.
vec3 ambienceSkyGlow(vec3 dir, vec3 sunDir, AmbPalette pal, float moonBrightness) {
    vec3 sky = ambienceSky(dir, sunDir, pal.zenith, pal.mid, pal.horizon, pal.glow, pal.golden);
#ifdef SUN_GLOW
    AmbGlow g = ambCelestialGlow(dir, sunDir, moonBrightness);
    sky = mix(sky, ambSunGlowColor(sunDir), clamp(g.core + g.mid, 0.0, 0.92));
    sky = mix(sky, vec3(0.78, 0.86, 1.00), clamp(g.moon, 0.0, 0.60));
#endif
    return sky;
}

// The full sky: glow plus the sun disc on top (the centre is never overwritten by the glow).
// gbuffers_skybasic writes exactly this into colortex0, so translucent clouds show it;
// final rebuilds the same value on sky pixels.
vec3 ambienceSkyFull(vec3 dir, vec3 sunDir, AmbPalette pal, float moonBrightness, float pixelAngle) {
    vec3 sky = ambienceSkyGlow(dir, sunDir, pal, moonBrightness);
    vec4 disc = ambSunDisc(dir, sunDir, pixelAngle);
    return sky * (1.0 - disc.a) + disc.rgb;
}

// Veil around the sun over terrain and clouds (from the angle, so it stays correct off
// screen): strong within about two sun sizes, plus a gentle wide part with the halo falloff.
float ambVeilFalloff(float theta) {
    return 0.65 * exp(-max(theta - AMB_SUN_HALF, 0.0) / (1.2 * AMB_SUN_HALF)) + 0.35 * exp(-theta / SUN_HALO_SIZE);
}

// The edge rim only exists right around the sun.
float ambRimFalloff(float theta) {
    return exp(-max(theta - AMB_SUN_HALF, 0.0) / (0.6 * AMB_SUN_HALF));
}

// Rim light colour, fitted to the reference: the stone edge under the sun reads #D4B585, i.e.
// this golden light mixed in at about 0.55 (more orange with a low sun).
vec3 ambRimColor(vec3 sunDir) {
    return mix(vec3(1.00, 0.82, 0.50), vec3(1.00, 0.68, 0.36), ambSunTwilight(sunDir));
}

// A cloud in front of (or near) the sun glows softly, as if lit from behind: a smooth patch
// around the sun's position plus a broad forward-scattering lobe. Analytic in the angle, so a
// cloud edge drifting across the sun never flickers. Mix weight toward the sun's glow colour.
float ambCloudSunGlow(vec3 dir, vec3 sunDir) {
    float theta = ambAngle(dir, sunDir);
    float sunPatch = exp(-max(theta - AMB_SUN_HALF, 0.0) / (1.6 * AMB_SUN_HALF));
    float lobe = exp(-theta / (1.5 * SUN_HALO_SIZE));
    return (0.70 * sunPatch + 0.30 * lobe) * ambSunGlowVisibility(sunDir);
}

// Ambient light for the shadow colours: the palette sky light (blue at midday, violet-blue at
// dusk, grey in rain, deep blue at night) with the biome tint of the ZENITH, because shade is lit
// by the sky dome, not by the horizon haze: teal in jungles, still slightly cool in deserts (the
// sky above a desert is blue even though its haze is warm). Snowy biomes keep the clear blue
// sky light (their pale palette sky would grey the shadows, but snow shadows read icy blue).
// Per vertex, no texture fetch.
vec3 ambShadowAmbient(AmbTime t) {
    return ambColor(t, AMB_SKY_LIGHT) *
           ambBiomeTint(t.biome.zenith, AMB_BIOME_BASE_ZENITH, 0.60 * t.biomeK * BIOME_SKY_STRENGTH * (1.0 - 0.75 * t.snow), t.rain);
}

// ---------------------------------------------------------------------------------------
// Fog.

// Optical depth per unit density of rho(h) = exp(-k h) along a straight path between two
// heights (h relative to FOG_BASE_HEIGHT), in closed form. Heights below -8 are clamped, so
// deep valleys and caves do not blow up; both exponentials stay bounded by exp(8 k).
float ambFogOpticalDepth(float pathLength, float hStart, float hEnd, float k) {
    float a = max(hStart, -8.0);
    float b = max(hEnd, -8.0);
    float ea = exp(-k * a);
    float dh = b - a;
    return pathLength * (abs(k * dh) > 1.0e-3 ? (ea - exp(-k * b)) / (k * dh) : ea);
}

#if FOG_BANK_QUALITY > 0
// Smooth value noise (bilinear with a smoothstep fade) on large cells, periodic in the
// world wrap: no visible cells, no grain.
float ambValueNoise(vec2 p, float period) {
    vec2 cell = floor(p);
    vec2 f = p - cell;
    f = f * f * (3.0 - 2.0 * f);
    float a = ambHash(mod(cell, period));
    float b = ambHash(mod(cell + vec2(1.0, 0.0), period));
    float c = ambHash(mod(cell + vec2(0.0, 1.0), period));
    float d = ambHash(mod(cell + vec2(1.0, 1.0), period));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Fog bank thickness (0..1). The drift goes round a very large circle that closes exactly
// when frameTimeCounter wraps (3600 s), so the banks never jump; its speed is
// FOG_DRIFT_SPEED blocks per second.
float ambFogBank(vec2 worldXZ) {
    const float period = float(AMB_WRAP / FOG_BANK_SCALE);
    float angle = frameTimeCounter * (6.2831853 / 3600.0);
    vec2 drift = vec2(cos(angle), sin(angle)) * (FOG_DRIFT_SPEED * 3600.0 / 6.2831853);
    vec2 p = (worldXZ + drift) / float(FOG_BANK_SCALE);
#if FOG_BANK_QUALITY == 1
    return ambValueNoise(p, period);
#else
    return 0.65 * ambValueNoise(p, period) + 0.35 * ambValueNoise(p * 2.0 + vec2(17.0, 31.0), period * 2.0);
#endif
}
#endif

struct AmbFog {
    vec3 color;
    float amount;
    float desaturation;
    float bank;      // bank density multiplier (debug)
    float scatter;   // sun scattering term (debug)
};

// Layered height fog from the camera to a surface: closed-form optical depth (no ray march),
// a clear zone around the camera, smooth bank noise sampled inside the fogged segment, and a
// ramp to full opacity at the render distance. Its colour is ambienceSky along the same
// direction, i.e. the sky behind the surface: at the far end terrain dissolves exactly into
// the sky, with no line at the horizon.
AmbFog ambienceFog(vec3 playerPos, vec3 sunDir, AmbPalette pal, float renderDistance,
                   float cloudShadow, float caveLight) {
    AmbFog fog;
    float pathLength = length(playerPos);
    vec3 dir = playerPos / max(pathLength, 1.0e-4);
    float horizontalDistance = length(playerPos.xz);
    float rain = ambRain();
    float thunder = clamp(thunderStrength, 0.0, 1.0);
    float night = 1.0 - smoothstep(-0.30, -0.05, sunDir.y);

    float t0 = min(float(FOG_START), pathLength);
    float segment = pathLength - t0;
    float cameraY = float(cameraPositionInt.y) + cameraPositionFract.y;
    float hStart = cameraY + dir.y * t0 - float(FOG_BASE_HEIGHT);
    float hEnd = cameraY + playerPos.y - float(FOG_BASE_HEIGHT);
    // Biome character: density and height-falloff multipliers, clamped so no biome can take the
    // fog away or make it opaque (BIOME_DENSITY_MULTIPLIER_STRENGTH, group sliders).
    AmbBiome biome = ambBiome();
    float biomeCharacter = BIOME_DENSITY_MULTIPLIER_STRENGTH * biome.strength;
    float biomeDensity = mix(1.0, clamp(biome.density, 0.5, 1.6), biomeCharacter);
    float biomeFalloff = mix(1.0, clamp(biome.falloff, 0.6, 1.4), biomeCharacter);
    // Rain: denser, grayer (palette) and lower (faster falloff). Night: a calmer haze. Caves:
    // thinner (the camera sees little sky), never darker, so a cave mouth still matches the sky.
    float k = FOG_HEIGHT_FALLOFF * (1.0 + 0.6 * rain) * biomeFalloff;
    float density = FOG_DENSITY * (1.0 + 1.5 * rain + 1.0 * thunder) * mix(1.0, 0.85, night) *
                    biomeDensity * mix(0.30, 1.0, caveLight);

    fog.bank = 1.0;
#if FOG_BANK_QUALITY > 0
    if (horizontalDistance < renderDistance) {
        vec2 cameraXZ = ambWrappedWorld(vec3(0.0)).xz;
        float noise = ambFogBank(cameraXZ + dir.xz * (t0 + segment * 0.5));
        fog.bank = 1.0 + FOG_BANK_STRENGTH * (2.0 * noise - 1.0);
    }
#endif
    float tau = density * fog.bank * ambFogOpticalDepth(segment, hStart, hEnd, k);
#ifdef BIOME_DESERT_DUST
    // Optional dust in deserts, badlands and (less) savanna: a second, shallow layer (8-block
    // scale height) that only thickens the air near the ground. Gone in rain and in caves.
    float dust = biome.dust * biomeCharacter * (1.0 - rain) * caveLight;
    tau += FOG_DENSITY * 0.9 * dust * ambFogOpticalDepth(segment, hStart, hEnd, 0.12);
#endif

    float farRamp = smoothstep(renderDistance * FOG_END * 0.65, renderDistance * FOG_END, horizontalDistance);
    fog.amount = 1.0 - exp(-tau) * (1.0 - farRamp);
    fog.desaturation = ENV_DISTANCE_DESATURATION * max(1.0 - exp(-1.6 * tau), farRamp);

    float halo;
    fog.color = ambienceSkyTerms(dir, sunDir, pal.zenith, pal.mid, pal.horizon, pal.glow, pal.golden, halo, fog.scatter);
    // Under cloud shadows the near haze is a little darker and cooler; the effect is gone by
    // the far end, where the fog must equal the sky.
    float farWeight = max(smoothstep(renderDistance * 0.20, renderDistance * 0.90, horizontalDistance), farRamp);
    fog.color *= mix(vec3(1.0), vec3(0.84, 0.87, 0.95), (1.0 - cloudShadow) * (1.0 - farWeight));
    return fog;
}

// Atmospheric perspective and fog: far surfaces lose saturation toward the fog hue, get
// lighter and blend into the fog colour, keeping their silhouettes.
vec3 ambienceApplyFog(vec3 color, AmbFog fog) {
    float luma = ambLuma(color);
    vec3 fogHue = fog.color / max(ambLuma(fog.color), 1.0e-3);
    color = mix(color, vec3(luma) * mix(vec3(1.0), fogHue, 0.25), fog.desaturation * 0.6);
    return mix(color, fog.color, fog.amount);
}

// Transmittance of the height fog along a segment between two world heights (reflected light,
// read by the fog-aware water reflection). The biome fog character applies here only when
// BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is on.
float ambienceSegmentTransmittance(float pathLength, float worldYStart, float worldYEnd) {
    float rain = ambRain();
    float k = FOG_HEIGHT_FALLOFF * (1.0 + 0.6 * rain);
    float density = FOG_DENSITY * (1.0 + 1.5 * rain + 1.0 * clamp(thunderStrength, 0.0, 1.0));
#ifdef BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION
    AmbBiome biome = ambBiome();
    float biomeCharacter = BIOME_DENSITY_MULTIPLIER_STRENGTH * biome.strength;
    k *= mix(1.0, clamp(biome.falloff, 0.6, 1.4), biomeCharacter);
    density *= mix(1.0, clamp(biome.density, 0.5, 1.6), biomeCharacter);
#endif
    return exp(-density * ambFogOpticalDepth(pathLength, worldYStart - float(FOG_BASE_HEIGHT),
                                             worldYEnd - float(FOG_BASE_HEIGHT), k));
}

// ---------------------------------------------------------------------------------------
// Vanilla cloud cells (shadows and the improved cloud reflection).
#if defined(CLOUD_SHADOW_ENABLE) || defined(WATER_REFLECTION_IMPROVEMENT)
float ambCloudPeriod() {
#ifdef AMB_CLOUD_TEXTURE
    return AMB_CLOUD_CELL * float(textureSize(vclClouds, 0).x);
#else
    return AMB_CLOUD_CELL * 256.0;
#endif
}

// Occupancy of one cloud cell: 1 = cloud, 0 = clear. cell = floor(cloud-space position / 12).
float ambCloudCell(vec2 cell) {
#ifdef AMB_CLOUD_TEXTURE
    vec2 size = vec2(textureSize(vclClouds, 0));
    return step(0.04, texelFetch(vclClouds, ivec2(mod(cell, size)), 0).a);
#else
    // Procedural cells (VANILLA_CLOUD_CELLS off): clusters plus single cells; not the vanilla shapes.
    vec2 c = mod(cell, 256.0);
    return step(0.58, ambHash(floor(c * 0.25)) * 0.65 + ambHash(c) * 0.35);
#endif
}

// Cloud-space position where the ray from a (wrapped) world point along dir meets the middle
// of the cloud layer: x carries the vanilla scroll, z the vanilla 3.96 offset. dir.y > 0.
vec2 ambCloudSpace(vec3 world, vec3 dir, out float t) {
    t = (cloudHeight + 0.5 * AMB_CLOUD_THICKNESS - world.y) / dir.y;
    vec2 q = world.xz + dir.xz * t;
    return vec2(q.x + mod(cloudTime, ambCloudPeriod()), q.y + AMB_CLOUD_Z_OFFSET);
}
#endif

#ifdef CLOUD_SHADOW_ENABLE
// Strongest at midday, weaker with a low sun, gone at night, in rain and in thunder.
float ambCloudShadowFade(vec3 sunDir) {
    return smoothstep(0.04, 0.50, sunDir.y) * (1.0 - clamp(rainStrength, 0.0, 1.0)) *
           (1.0 - clamp(thunderStrength, 0.0, 1.0));
}

// Soft blocky cloud shadow for a camera-relative receiver: 1 = lit, 1 - CLOUD_SHADOW_STRENGTH
// = under a cloud. The receiver is moved along the sun direction to the cloud layer and the
// vanilla cell there is read: one fetch (quality 1) or four (quality 2).
float ambienceCloudShadow(vec3 playerPos, vec3 sunDir, out float rawMask, out vec2 cellUV) {
    rawMask = 0.0;
    cellUV = vec2(0.0);
    vec3 world = ambWrappedWorld(playerPos);
    // Only below the layer: receivers inside or above the clouds get no cloud shadow.
    float fade = ambCloudShadowFade(sunDir) * (1.0 - smoothstep(cloudHeight - 6.0, cloudHeight + 1.0, world.y));
    if (fade <= 0.0) return 1.0;
#if CLOUD_SHADOW_GRID > 0
    // The receiver steps on a coarse world block grid, so the shadow edges come out blocky.
    world.xz = (floor(world.xz / float(CLOUD_SHADOW_GRID)) + 0.5) * float(CLOUD_SHADOW_GRID);
#endif
    float t;
    vec2 cells = ambCloudSpace(world, vec3(sunDir.x, max(sunDir.y, 0.05), sunDir.z), t) / AMB_CLOUD_CELL;
#if CLOUD_SHADOW_QUALITY == 1
    float mask = ambCloudCell(floor(cells));
#else
    // Bilinear coverage of the four nearest cell centres, then a soft threshold: the penumbra
    // is CLOUD_SHADOW_SOFTNESS x 12 blocks wide, wider with a low sun.
    vec2 lattice = cells - 0.5;
    vec2 base = floor(lattice);
    vec2 f = lattice - base;
    float coverage = mix(mix(ambCloudCell(base), ambCloudCell(base + vec2(1.0, 0.0)), f.x),
                         mix(ambCloudCell(base + vec2(0.0, 1.0)), ambCloudCell(base + vec2(1.0, 1.0)), f.x), f.y);
    float halfWidth = clamp(0.5 * CLOUD_SHADOW_SOFTNESS * mix(1.6, 1.0, smoothstep(0.15, 0.70, sunDir.y)), 0.02, 0.5);
    float mask = smoothstep(0.5 - halfWidth, 0.5 + halfWidth, coverage);
#endif
    rawMask = mask;
    cellUV = fract(cells * (AMB_CLOUD_CELL / ambCloudPeriod()));
    return 1.0 - CLOUD_SHADOW_STRENGTH * mask * fade;
}

float ambienceCloudShadow(vec3 playerPos, vec3 sunDir) {
    float rawMask;
    vec2 cellUV;
    return ambienceCloudShadow(playerPos, sunDir, rawMask, cellUV);
}
#endif

// ---------------------------------------------------------------------------------------
// Terrain light response (opaque surfaces and glass; never water).
#ifdef AMBIENCE_COLORS
// Warm sunlit faces, cool soft shade (warm albedos such as sand and rock resist it), gentle
// vibrance on dull colours with a neon clamp, and a slight blue on snow and ice with a
// highlight shoulder so they never burn out to flat white.
vec3 ambienceTerrainResponse(vec3 lit, vec3 albedo, float sunMask, float shadeMask, vec3 sunLight, vec3 skyLight) {
    vec3 sunTint = sunLight / max(ambLuma(sunLight), 1.0e-3);
    vec3 skyTint = skyLight / max(ambLuma(skyLight), 1.0e-3);
    float warmAlbedo = smoothstep(0.03, 0.22, albedo.r - albedo.b);
    lit *= mix(vec3(1.0), sunTint, clamp(sunMask * ENV_WARMTH, 0.0, 1.0));
    lit *= mix(vec3(1.0), skyTint, clamp(shadeMask * ENV_SHADOW_COOLNESS, 0.0, 1.0) * (1.0 - 0.5 * warmAlbedo));

    float luma = ambLuma(lit);
    float maxC = max(lit.r, max(lit.g, lit.b));
    float sat = (maxC - min(lit.r, min(lit.g, lit.b))) / max(maxC, 1.0e-3);
    vec3 vivid = mix(vec3(luma), lit, 1.0 + ENV_VIBRANCE * (1.0 - sat));
    float vividMax = max(vivid.r, max(vivid.g, vivid.b));
    float vividSat = (vividMax - min(vivid.r, min(vivid.g, vivid.b))) / max(vividMax, 1.0e-3);
    // Neon clamp: the boost never pushes a colour past 80 % saturation.
    lit = max(mix(lit, vivid, clamp((0.80 - sat) / max(vividSat - sat, 1.0e-3), 0.0, 1.0)), vec3(0.0));

    float albedoMax = max(albedo.r, max(albedo.g, albedo.b));
    float albedoSat = (albedoMax - min(albedo.r, min(albedo.g, albedo.b))) / max(albedoMax, 1.0e-3);
    float snow = smoothstep(0.70, 0.86, ambLuma(albedo)) * (1.0 - smoothstep(0.06, 0.18, albedoSat)) * ENV_SNOW_TINT;
    lit *= mix(vec3(1.0), vec3(0.93, 0.97, 1.05), snow);
    lit -= max(lit - vec3(0.80), vec3(0.0)) * (0.45 * snow);
    return lit;
}
#endif
