#version 330 compatibility

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
// Needed by lib/ambience.glsl (the palette is evaluated here, once per frame in practice).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#ifdef AMB_SUN_VISIBILITY
uniform sampler2D depthtex0;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// Cloud marker written by gbuffers_clouds: A = 1, R = 0, G = the face's opacity.
#define FINAL_VSH_CLOUD_MARKER
uniform sampler2D colortex1;
#endif
#endif

#include "/lib/ambience.glsl"

out vec2 vTexCoord;
out float vSunElevation;
out float vMoonElevation;
out vec2 vSunUV;
out float vSunInFront;
out vec2 vMoonUV;
out float vMoonInFront;

// Ambience palette for this frame (sky, fog, clouds, light) and the world sun direction.
flat out vec3 vSunWorld;
flat out vec3 vPalZenith;
flat out vec3 vPalMid;
flat out vec3 vPalHorizon;
flat out vec3 vPalFogNear;
flat out vec3 vPalCloudTop;
flat out vec3 vPalCloudUnder;
flat out vec3 vPalSkyLight;
flat out vec3 vPalGlow;
flat out float vPalGolden;
// Sun visibility V (0..1), the share of the sun hidden by clouds, and the on-screen fade of the
// veil, rim and shafts, identical for every vertex.
flat out float vSunVisibility;
flat out float vSunCloudCover;
flat out float vSunScreenFade;
#ifdef AMB_WATER_OWN_PALETTE
// The palette without the biome look, for the screen-space water reflection (it must match
// the water's own Tier-1 reflection when BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off).
flat out vec3 vWaterZenith;
flat out vec3 vWaterMid;
flat out vec3 vWaterHorizon;
flat out vec3 vWaterCloudTop;
flat out vec3 vWaterCloudUnder;
flat out vec3 vWaterGlow;
flat out float vWaterGolden;
#endif

#ifdef AMB_SUN_VISIBILITY
// One texel: open sky = 1, a cloud = its transparency (opaque clouds hide the sun), anything
// else = 0; cloud = how much of it is cloud.
void sunTexel(ivec2 texel, out float open, out float cloud) {
    open = texelFetch(depthtex0, texel, 0).r > 0.99999 ? 1.0 : 0.0;
    cloud = 0.0;
#ifdef FINAL_VSH_CLOUD_MARKER
    vec4 info = texelFetch(colortex1, texel, 0);
    if (info.a > 0.5 && info.r < 0.5) {
        open = 1.0 - info.g;
        cloud = info.g;
    }
#endif
}

// One visibility tap, bilinear between the four nearest texels: as the sun (and so the tap)
// moves across a block or cloud edge, its value changes continuously instead of jumping, so
// the veil, rim and shafts never pop. Taps outside the screen count as open (the effects fade
// out off screen anyway).
void sunTap(vec2 uv, inout float open, inout float cloud) {
    if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) {
        open += 1.0;
        return;
    }
    vec2 size = vec2(textureSize(depthtex0, 0));
    vec2 position = uv * size - 0.5;
    ivec2 base = ivec2(floor(position));
    vec2 f = position - floor(position);
    ivec2 maxTexel = ivec2(size) - 1;
    float o00, o10, o01, o11, c00, c10, c01, c11;
    sunTexel(clamp(base, ivec2(0), maxTexel), o00, c00);
    sunTexel(clamp(base + ivec2(1, 0), ivec2(0), maxTexel), o10, c10);
    sunTexel(clamp(base + ivec2(0, 1), ivec2(0), maxTexel), o01, c01);
    sunTexel(clamp(base + ivec2(1, 1), ivec2(0), maxTexel), o11, c11);
    open += mix(mix(o00, o10, f.x), mix(o01, o11, f.x), f.y);
    cloud += mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
}

// A tap covering a small area: four bilinear samples at +-0.12 sun half-sizes, so an edge
// sweeping over the sun changes V in many small continuous ramps instead of a few steps.
void sunAreaTap(vec2 uv, vec2 halfSize, inout float open, inout float cloud) {
    vec2 o = halfSize * 0.12;
    float o4 = 0.0;
    float c4 = 0.0;
    sunTap(uv + vec2(-o.x, -o.y), o4, c4);
    sunTap(uv + vec2(o.x, -o.y), o4, c4);
    sunTap(uv + vec2(-o.x, o.y), o4, c4);
    sunTap(uv + vec2(o.x, o.y), o4, c4);
    open += 0.25 * o4;
    cloud += 0.25 * c4;
}

// A ring of taps at a fixed radius (in sun half-sizes) and angular phase: a deterministic
// pattern, no random offsets, so V is the same every frame for the same view.
void sunRing(vec2 centre, vec2 halfSize, int count, float radius, float phase, inout float open, inout float cloud, inout float weight) {
    for (int i = 0; i < count; ++i) {
        float a = phase + 6.2831853 * float(i) / float(count);
        sunAreaTap(centre + vec2(cos(a), sin(a)) * halfSize * radius, halfSize, open, cloud);
        weight += 1.0;
    }
}
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec3 sunWorld = mat3(gbufferModelViewInverse) * sunPosition;
    float sunLength2 = dot(sunWorld, sunWorld);
    sunWorld = sunLength2 > 0.000001 ? sunWorld * inversesqrt(sunLength2) : vec3(0.0, 1.0, 0.0);
    vSunElevation = sunWorld.y;

    vec3 moonWorld = mat3(gbufferModelViewInverse) * moonPosition;
    float moonLength2 = dot(moonWorld, moonWorld);
    moonWorld = moonLength2 > 0.000001 ? moonWorld * inversesqrt(moonLength2) : vec3(0.0, -1.0, 0.0);
    vMoonElevation = moonWorld.y;

    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    vMoonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = vMoonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);

    vSunWorld = sunWorld;
    AmbPalette pal = ambiencePalette(sunWorld);
    vPalZenith = pal.zenith;
    vPalMid = pal.mid;
    vPalHorizon = pal.horizon;
    vPalFogNear = pal.fogNear;
    vPalCloudTop = pal.cloudTop;
    vPalCloudUnder = pal.cloudUnder;
    vPalSkyLight = pal.skyLight;
    vPalGlow = pal.glow;
    vPalGolden = pal.golden;
#ifdef AMB_WATER_OWN_PALETTE
    AmbPalette waterPal = ambiencePaletteBiome(sunWorld, 0.0);
    vWaterZenith = waterPal.zenith;
    vWaterMid = waterPal.mid;
    vWaterHorizon = waterPal.horizon;
    vWaterCloudTop = waterPal.cloudTop;
    vWaterCloudUnder = waterPal.cloudUnder;
    vWaterGlow = waterPal.glow;
    vWaterGolden = waterPal.golden;
#endif

    // Sun visibility: fixed taps inside the sun square, read once per vertex (a few hundred
    // fetches per frame in total). The fade takes the veil, rim and shafts away smoothly once
    // the sun is outside the screen (NDC 1.0 to 1.35) or behind the camera.
    vSunVisibility = 1.0;
    vSunCloudCover = 0.0;
    vSunScreenFade = 0.0;
    if (vSunInFront > 0.5) {
        vec2 ndc = sunClip.xy / sunClip.w;
        vSunScreenFade = 1.0 - smoothstep(1.0, 1.35, max(abs(ndc.x), abs(ndc.y)));
    }
#ifdef AMB_SUN_VISIBILITY
    if (vSunInFront > 0.5) {
        vec2 halfSize = vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * (0.5 * AMB_SUN_HALF);
        float open = 0.0;
        float cloud = 0.0;
        sunAreaTap(vSunUV, halfSize, open, cloud);
        float weight = 1.0;
#if SUN_VISIBILITY_TAPS == 9
        sunRing(vSunUV, halfSize, 8, 0.70, 0.0, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 13
        sunRing(vSunUV, halfSize, 6, 0.50, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 6, 1.00, 0.5236, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 21
        sunRing(vSunUV, halfSize, 8, 0.45, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 12, 0.95, 0.2618, open, cloud, weight);
#else
        sunRing(vSunUV, halfSize, 8, 0.35, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 8, 0.70, 0.3927, open, cloud, weight);
        sunRing(vSunUV, halfSize, 12, 1.00, 0.2618, open, cloud, weight);
#endif
        vSunVisibility = open / weight;
        vSunCloudCover = cloud / weight;
    }
#endif
}
