#version 330 compatibility

// Full-screen quad of the quarter-resolution shaft pass, with the sun's screen position.

uniform mat4 gbufferProjection;
uniform vec3 sunPosition;

out vec2 vTexCoord;
out vec2 vSunUV;
out float vSunInFront;

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
}
