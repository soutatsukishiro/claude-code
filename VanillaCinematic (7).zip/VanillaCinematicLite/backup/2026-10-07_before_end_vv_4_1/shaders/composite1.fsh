#version 330 compatibility

// Shafts (SUN_SHAFTS, MOON_SHAFTS), quarter resolution, after composite: a deterministic radial
// march toward the screen position of the light that owns the shafts this frame (the sun, or
// the moon at night; never both: one buffer, one channel) over the pre-filtered open-sky mask
// composite left in colortex5.a (read with linear filtering, so neighbouring samples overlap):
// fixed offsets, Gaussian-like weights, no jitter, no noise, never the shadow map. RGB (bloom,
// shallow-water shafts, pollen) passes through untouched; the shaft amount replaces the mask
// in alpha and final applies it with a depth-aware upsample. Iris ping-pongs colortex5 (read
// and written here), so the read sees composite's output.

#include "/lib/settings.glsl"

uniform sampler2D colortex5;
uniform float aspectRatio;
// Declared for lib/sun_rays.glsl (its mask and rim functions); this pass only marches.
uniform sampler2D depthtex0;
uniform float far;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
uniform sampler2D colortex1;
#endif

#include "/lib/sun_rays.glsl"

in vec2 vTexCoord;
in vec2 vSunUV;
in float vSunInFront;
#ifdef MOON_SHAFTS
in vec2 vMoonUV;
flat in float vMoonShaftOwner;
#endif
#ifdef END_FLASH_SHAFTS
// Update 3: the End flash (composite1.vsh): screen position, owner of the shafts this frame.
flat in vec3 vFlashShaft;
#endif
#ifdef UNDERWATER_SHAFTS
uniform int isEyeInWater;
#endif
#ifdef UNDERWATER_SHAFTS_TIER2

// Update 3: depth-aware pre-blur of the tier-2 underwater shafts (composite's march, quarter
// resolution): the centre and four neighbours UW_SHAFT_SOFTNESS apart, each weighted by how close its
// depth is to the centre's, so shafts never bleed across a silhouette (no halos around objects).
float uwShaftBlur() {
    ivec2 q = ivec2(gl_FragCoord.xy);
    vec2 quarterSize = vec2(textureSize(colortex5, 0));
    ivec2 qMax = ivec2(quarterSize) - 1;
    vec2 scale = vec2(textureSize(depthtex0, 0)) / quarterSize;
    ivec2 fullMax = textureSize(depthtex0, 0) - 1;
    float centreDistance = raysLinearDepth(texelFetch(depthtex0, clamp(ivec2((vec2(q) + 0.5) * scale), ivec2(0), fullMax), 0).r);
    int r = 1 + int(UW_SHAFT_SOFTNESS * 2.0 + 0.01);
    ivec2 offsets[4] = ivec2[4](ivec2(r, 0), ivec2(-r, 0), ivec2(0, r), ivec2(0, -r));
    float sum = 2.0 * texelFetch(colortex5, q, 0).a;
    float weightSum = 2.0;
    for (int k = 0; k < 4; ++k) {
        ivec2 t = clamp(q + offsets[k], ivec2(0), qMax);
        float d = raysLinearDepth(texelFetch(depthtex0, clamp(ivec2((vec2(t) + 0.5) * scale), ivec2(0), fullMax), 0).r);
        float w = exp(-10.0 * abs(d - centreDistance) / max(centreDistance, 0.5));
        sum += w * texelFetch(colortex5, t, 0).a;
        weightSum += w;
    }
    return sum / weightSum;
}
#endif

/* RENDERTARGETS: 5 */
layout(location = 0) out vec4 postEffects;

void main() {
    vec4 current = texelFetch(colortex5, ivec2(gl_FragCoord.xy), 0);
    float shafts = 0.0;
#ifdef RAYS_SHAFTS
    bool moonOwns = false;
#ifdef MOON_SHAFTS
    moonOwns = vMoonShaftOwner > 0.0;
#endif
#ifdef SUN_SHAFTS
    // Nothing to march when the sun is behind the camera or far off screen, or far from this
    // pixel (final's cone fades shafts out about 45 degrees from the sun anyway).
    vec2 toSun = (vSunUV - vTexCoord) * vec2(aspectRatio, 1.0);
    bool sunNear = vSunInFront > 0.5 && all(greaterThan(vSunUV, vec2(-0.6))) && all(lessThan(vSunUV, vec2(1.6))) &&
                   dot(toSun, toSun) < 1.44;
    if (sunNear && !moonOwns) shafts = raysShaftMarch(colortex5, vTexCoord, vSunUV, aspectRatio, SHAFT_LENGTH);
#endif
#ifdef MOON_SHAFTS
    // The moon's march is shorter (0.75 x SHAFT_LENGTH); its cone in final is narrower.
    vec2 toMoon = (vMoonUV - vTexCoord) * vec2(aspectRatio, 1.0);
    bool moonNear = moonOwns && all(greaterThan(vMoonUV, vec2(-0.6))) && all(lessThan(vMoonUV, vec2(1.6))) &&
                    dot(toMoon, toMoon) < 1.44;
    if (moonNear) shafts = raysShaftMarch(colortex5, vTexCoord, vMoonUV, aspectRatio, 0.75 * SHAFT_LENGTH);
#endif
#ifdef END_FLASH_SHAFTS
    // Update 3: the End flash's march (the sun's function, a slightly longer reach); the sun and the
    // moon have no mask in the End, so this never mixes with them.
    vec2 toFlash = (vFlashShaft.xy - vTexCoord) * vec2(aspectRatio, 1.0);
    if (vFlashShaft.z > 0.5 && dot(toFlash, toFlash) < 1.44) shafts = raysShaftMarch(colortex5, vTexCoord, vFlashShaft.xy, aspectRatio, 0.35);
#endif
#ifdef UNDERWATER_SHAFTS_TIER2
    // Update 3: with the camera underwater the alpha holds the tier-2 shafts: blur them instead.
    if (isEyeInWater == 1) shafts = uwShaftBlur();
#endif
#endif
#if defined(UNDERWATER_SHAFTS) && !defined(UNDERWATER_SHAFTS_TIER2)
    // Update 3: with the camera underwater the alpha holds the tier-1 shafts (composite): keep them.
    if (isEyeInWater == 1) shafts = current.a;
#endif
#if defined(LIGHT_DEBUG) && LIGHT_DEBUG_MODE == 2
    // The sky-mask view shows composite's mask itself.
    shafts = current.a;
#endif
    postEffects = vec4(current.rgb, shafts);
}
