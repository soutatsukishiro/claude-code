// Update 3: the ambience of the three special environments, shared by lib/gbuffers_forward.fsh
// (terrain, water, entities, the hand, particles), composite, composite1, final.vsh and final.fsh.
//
//   UNDERWATER (the camera in water, isEyeInWater == 1): per-channel absorption fog, darker water
//     with depth, the biome water colour, brighter water toward the surface and the light, the
//     surface seen from below and the light-shaft pattern (tier 1 analytic in final, tier 2 a
//     shadow-aware march in composite).
//   THE NETHER: the biome fog palette (one function for the fog, the far distance and the empty
//     background), warm block light with a gentle flicker, the emissive boost, the lava-sea haze.
//   THE END: the Vibrant Visuals atmospherics (a dark smooth sky, a thin fog of the same colour, a dim
//     warm-neutral light; Update 4) and the vanilla End flash of Minecraft 26.3 (EndFlashState: one
//     flash in every 30-second window, a smooth half-sine pulse of 5 to 19 s, a random direction;
//     Iris 1.11.7 exposes it as endFlashIntensity and endFlashPosition and orients the shadow map
//     along it with endFlashShadows = true), shown the way Vibrant Visuals shows it: a purple
//     directional light (#E45DFF) with shadows, a dense purple fog that glows toward the flash (in
//     the sky and over distant terrain; no flash sprite), and shafts. Because the pack follows the
//     vanilla flash, its timing, its direction and the vanilla flash sound always agree. The End sky
//     itself is the smooth Vibrant Visuals sky built from the view direction (final.fsh; Update 4).
//
// Everything that is the same for every pixel comes from custom uniforms (shaders.properties,
// evaluated once per frame on the CPU) or from flat values of a vertex stage; the sliders are
// compile-time constants (a linear slider costs at most one multiply-add per pixel). Deterministic:
// no noise, no jitter, no random numbers; the only time input is the slow drift of the shaft pattern.
// The includer declares the Iris uniforms it passes in (atmosNether, atmosEnd, isEyeInWater, ...);
// this file declares only the custom uniforms and endFlashPosition.

#if defined(UNDERWATER_AMBIENCE) || defined(NETHER_AMBIENCE) || defined(END_AMBIENCE)
float dimLuma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}
#endif

// ---------------------------------------------------------------------------------------------
// UNDERWATER
#ifdef UNDERWATER_AMBIENCE
// Per-frame values (shaders.properties). Colours are display values like everything in the pack.
uniform float vclUwFade;        // 0 -> 1 in about 0.3 s after the eye goes under, 0 at once above water
uniform float vclUwDepth;       // camera depth below the surface in blocks (smoothed, about 1.5 s)
uniform float vclUwLight;       // brightness of the light in the water: day, moon, weather, Night Vision
uniform float vclUwShallowR;    // biome water colour near the surface, times vclUwLight
uniform float vclUwShallowG;
uniform float vclUwShallowB;
uniform float vclUwDarkR;       // biome water colour at the camera depth, times vclUwLight
uniform float vclUwDarkG;
uniform float vclUwDarkB;
uniform float vclUwOceanShallowR; // the same two for the standard ocean (UNDERWATER_BIOME_TINT_STRENGTH)
uniform float vclUwOceanShallowG;
uniform float vclUwOceanShallowB;
uniform float vclUwOceanDarkR;
uniform float vclUwOceanDarkG;
uniform float vclUwOceanDarkB;
uniform float vclUwVis;         // visibility factor: biome (open ocean 1, swamp 0.42) and Night Vision
uniform float vclUwLx;          // the sun (the moon at night) refracted into the water: world
uniform float vclUwLy;          // direction toward the light, unit length (Snell, n = 1.333)
uniform float vclUwLz;
uniform float vclUwShaft;       // shaft light: light elevation x weather x camera sky light (0..1)

// Red is absorbed fastest, then green; blue sets the visibility (5 % of blue left after
// UNDERWATER_VISIBILITY blocks). Fitted to the reference: red is gone within a few blocks, the
// near floor keeps a little of its own colour.
const vec3 UW_ABSORPTION_RATIO = vec3(4.0, 1.8, 1.0);
// Brightness of the in-scattered light by view direction: down / away from the light (min) to up
// and toward the refracted light (max), around the colours of the palette.
const float UW_VIEW_MIN = 1.0 - 0.55 * UNDERWATER_VIEW_BRIGHTNESS;
const float UW_VIEW_MAX = 1.0 + 0.45 * UNDERWATER_VIEW_BRIGHTNESS;

vec3 uwLightDir() {
    return vec3(vclUwLx, vclUwLy, vclUwLz);
}

vec3 uwAbsorption() {
    float blue = (3.0 / float(UNDERWATER_VISIBILITY)) * UNDERWATER_FOG_DENSITY / max(vclUwVis, 0.2);
    return clamp(blue, 3.0 / 160.0, 0.6) * UW_ABSORPTION_RATIO;
}

// The near-surface colour and the colour at the camera depth (biome tint strength applied).
vec3 uwShallowColor() {
    return mix(vec3(vclUwOceanShallowR, vclUwOceanShallowG, vclUwOceanShallowB),
               vec3(vclUwShallowR, vclUwShallowG, vclUwShallowB), UNDERWATER_BIOME_TINT_STRENGTH);
}

// The water colour at the camera depth: UNDERWATER_DEPTH_DARKENING 0 = the surface colour at any
// depth, 1 = the designed curve (royal blue near the surface, navy at about 15 blocks, almost black
// blue beyond 40), higher = darker sooner.
vec3 uwBaseColor() {
    vec3 shallowC = uwShallowColor();
    vec3 darkC = mix(vec3(vclUwOceanDarkR, vclUwOceanDarkG, vclUwOceanDarkB),
                     vec3(vclUwDarkR, vclUwDarkG, vclUwDarkB), UNDERWATER_BIOME_TINT_STRENGTH);
    return max(mix(shallowC, darkC, UNDERWATER_DEPTH_DARKENING), shallowC * 0.03);
}

// 0 looking straight down or away from the light, 1 looking up toward it (smooth, pow-free).
float uwViewTerm(vec3 viewDir) {
    float up = smoothstep(-0.65, 0.95, viewDir.y);
    float g = max(dot(viewDir, uwLightDir()), 0.0);
    float g2 = g * g;
    return clamp(0.58 * up + 0.42 * g2 * g2, 0.0, 1.0);
}

// In-scattered light along viewDir (the fog colour at full fog).
vec3 uwFogColor(vec3 viewDir) {
    return uwBaseColor() * mix(UW_VIEW_MIN, UW_VIEW_MAX, uwViewTerm(viewDir));
}

// Per-channel transmittance over dist blocks of water.
vec3 uwTransmittance(float dist) {
    return exp(-max(dist, 0.0) * uwAbsorption());
}

// The absorption fog: what is seen at dist blocks keeps T of its light per channel, the rest is
// replaced by the in-scattered light. vclUwFade ramps it in as the eye goes under.
vec3 uwApplyFog(vec3 color, float dist, vec3 viewDir) {
    vec3 T = uwTransmittance(dist);
    vec3 fogged = color * T + uwFogColor(viewDir) * (1.0 - T);
    return mix(color, fogged, clamp(vclUwFade, 0.0, 1.0));
}

#ifdef SURFACE_FROM_BELOW
// The water surface seen from below: a luminous ceiling lit by the sky (sky light at the surface,
// day and night and weather through the colours), the vanilla wave texture as fine streaks, never a
// clear window and never a full mirror. With SNELL_WINDOW: inside about 48.6 degrees of the vertical
// the sky shows through (lower opacity, brighter); outside, total internal reflection gives a
// darker mirror of the water below (a subtle approximation, no reflection rendering).
// waveLuma: luminance of the vanilla water texel (0.65 to 0.83); surfaceSky: its sky light (0..1).
// Returns the surface colour and opacity.
vec4 uwSurfaceFromBelow(vec3 viewDir, float waveLuma, float surfaceSky) {
    vec3 shallowC = uwShallowColor();
    float lit = mix(0.22, 1.0, smoothstep(0.30, 0.95, surfaceSky));
    // Ocean, day: about #3366C7 before the fog (your screenshot's surface: #3062BE), a pale water blue.
    vec3 ceiling = (shallowC * 0.85 + vec3(0.17, 0.10, 0.06) * vclUwLight) * (SURFACE_FROM_BELOW_BRIGHTNESS * lit);
    float streak = clamp(1.0 + 1.7 * (waveLuma - 0.70), 0.75, 1.30);
    ceiling *= streak;
    float alpha = 0.88;
#ifdef SNELL_WINDOW
    const float EDGE = 0.8483;  // 48.6 degrees, the critical angle of water (n = 1.333)
    const float SOFT = radians(float(SNELL_WINDOW_SOFTNESS));
    float inside = smoothstep(cos(EDGE + SOFT), cos(max(EDGE - SOFT, 0.0)), viewDir.y);
    vec3 mirror = mix(ceiling * 0.58, uwFogColor(vec3(viewDir.x, -viewDir.y, viewDir.z)) * streak, 0.35);
    ceiling = mix(mirror, ceiling * 1.12, inside);
    alpha = mix(0.93, 0.50, inside);
#endif
    return vec4(ceiling, alpha);
}
#endif

#if defined(UNDERWATER_SHAFTS) || defined(UNDERWATER_DEBUG)
// Light pattern on the water surface plane (wrapped world x/z, blocks): three sine waves along
// integer directions, so the pattern tiles exactly with the 24576-block world wrap of
// lib/ambience.glsl; soft cells about UW_SHAFT_PATTERN_SCALE blocks across. Each wave drifts by a
// whole number of periods per 3600 s, so the wrap of frameTimeCounter never shows.
const float UW_K = 6.2831853 / (2.0 * float(UW_SHAFT_PATTERN_SCALE));
const float UW_TWO_PI_HOUR = 6.2831853 / 3600.0;
const float UW_W1 = UW_TWO_PI_HOUR * floor(UW_SHAFT_DRIFT_SPEED * UW_K * 1.4142 * 3600.0 / 6.2831853 + 0.5);
const float UW_W2 = UW_TWO_PI_HOUR * floor(UW_SHAFT_DRIFT_SPEED * UW_K * 2.2361 * 3600.0 / 6.2831853 + 0.5);
const float UW_W3 = UW_TWO_PI_HOUR * floor(UW_SHAFT_DRIFT_SPEED * UW_K * 2.2361 * 3600.0 / 6.2831853 + 0.5);

float uwShaftPattern(vec2 p, float time) {
    float s = sin(UW_K * (p.x + p.y) - UW_W1 * time) +
              sin(UW_K * (2.0 * p.x - p.y) - UW_W2 * time + 1.7) +
              sin(UW_K * (2.0 * p.y - p.x) + UW_W3 * time + 4.1);
    // About 3 to 4 soft lit cells across the view; UW_SHAFT_CONTRAST widens the dark gaps.
    float edge0 = -0.35 - 0.25 * (1.0 - UW_SHAFT_CONTRAST);
    return smoothstep(edge0, 1.2, s);
}

// Where along the light the point p (camera-relative) gets its light from: the surface point above
// it along the refracted light. depthBelow: the point's depth below the surface (blocks).
vec2 uwSurfacePoint(vec3 p, float depthBelow) {
    vec3 L = uwLightDir();
    return p.xz + L.xz * (depthBelow / max(L.y, 0.2));
}

// The soft lobe around the refracted light (the same smooth wide falloff style as the sun glow).
float uwShaftLobe(vec3 viewDir) {
    float c = dot(viewDir, uwLightDir());
    float wide = smoothstep(-0.35, 1.0, c);
    float g2 = max(c, 0.0) * max(c, 0.0);
    return 0.45 * wide + 0.55 * g2 * g2;
}

// The shaft colour: a lighter, slightly cyan-white version of the water colour (never white or grey).
vec3 uwShaftColor() {
    vec3 c = uwShallowColor();
    vec3 hue = c / max(max(c.r, max(c.g, c.b)), 1.0e-3);
    return mix(hue * 0.95, vec3(0.62, 0.86, 0.96), 0.55);
}

#ifdef UW_TIER1_FUNCTIONS
// Tier 1 underwater shafts (composite, at quarter resolution; final's debug view): the surface light
// pattern gathered at three fixed points along the view ray (deterministic, no jitter), each lit
// through the surface point above it along the refracted light and attenuated on its way down and back
// to the eye (blue-green absorption). Broad soft beams with darker bands between them; zero above the
// surface. The includer declares cameraPositionInt, cameraPositionFract and frameTimeCounter and
// includes lib/ambience.glsl (the world wrap) first.
float uwShaftTier1(vec3 viewDir, float rayLength) {
    vec2 wrap = vec2((cameraPositionInt.xz + ivec2(AMB_WRAP_OFFSET)) % ivec2(AMB_WRAP)) + cameraPositionFract.xz;
    float sigma = dot(uwAbsorption(), vec3(0.0, 0.5, 0.5));
    float sum = 0.0;
    for (int i = 0; i < 3; ++i) {
        float t = (float(i) + 0.5) * (1.0 / 3.0) * rayLength;
        vec3 p = viewDir * t;
        float depthBelow = vclUwDepth - p.y;
        float inWater = smoothstep(0.0, 0.6, depthBelow);
        vec2 q = uwSurfacePoint(p, max(depthBelow, 0.0)) + wrap;
        float lightPath = max(depthBelow, 0.0) / max(vclUwLy, 0.2) + t;
        sum += inWater * exp(-sigma * lightPath) * uwShaftPattern(q, frameTimeCounter);
    }
    return sum * (1.0 / 3.0);
}
#endif
#endif
#endif

// ---------------------------------------------------------------------------------------------
// THE NETHER
#ifdef NETHER_AMBIENCE
uniform float vclNFogR;         // full-fog colour of the camera's Nether biome (blended, display values)
uniform float vclNFogG;
uniform float vclNFogB;
uniform float vclNFogDensity;   // biome density factor (crimson forest 1)
uniform float vclNLowR;         // warm block light palette: low light (deep red; teal in soul sand valleys)
uniform float vclNLowG;
uniform float vclNLowB;
uniform float vclNHighR;        // and near sources (orange-yellow; cyan-white in soul sand valleys)
uniform float vclNHighG;
uniform float vclNHighB;
uniform float vclNFlicker;      // -1..1, smooth (two sines, 6.3 and 7.7 Hz), the same for every pixel
#ifdef NETHER_DEBUG
uniform float vclNWastes;       // the smoothed Nether biome weights (debug view 3)
uniform float vclNCrimson;
uniform float vclNWarped;
uniform float vclNSoul;
uniform float vclNBasalt;
#endif

// Nether wastes: the palette everywhere at NETHER_FOG_BIOME_TINT 0 (the same colour as the wastes
// entry of vclNFog in shaders.properties).
const vec3 NETHER_WASTES_FOG = vec3(0.198, 0.062, 0.035);
// The lava sea glow near Y = 31.
const vec3 NETHER_LAVA_GLOW = vec3(0.62, 0.20, 0.05);

vec3 netherFogBase() {
    return mix(NETHER_WASTES_FOG, vec3(vclNFogR, vclNFogG, vclNFogB), NETHER_FOG_BIOME_TINT);
}

#if defined(LAVA_SEA_HAZE) || defined(NETHER_DEBUG)
// The lava-sea haze factor at world height midY: one exp, strongest at the lava level (Y = 31).
float netherLavaHaze(float midY) {
    return min(NETHER_LAVA_HAZE * 0.55 * exp(-max(midY - 31.0, 0.0) / 14.0), 0.85);
}
#endif

// The fog colour along dir: the biome colour, the ceiling a little darker, the low haze a little
// lighter (no band: it depends on the direction only), and the lava-sea glow from the height of
// the middle of the view ray (midY, world Y). The same function colours the empty background.
vec3 netherFogColor(vec3 dir, float midY) {
    vec3 c = netherFogBase() * mix(1.06, 0.80, smoothstep(-0.10, 0.85, dir.y));
#ifdef LAVA_SEA_HAZE
    c += NETHER_LAVA_GLOW * (0.32 * netherLavaHaze(midY));
#endif
    return c;
}

// Fog amount over dist blocks: a few blocks clear, about 93 % at 70 blocks in the crimson forest.
float netherFogAmount(float dist) {
    float density = (2.65 / 70.0) * NETHER_FOG_DENSITY * vclNFogDensity;
    return 1.0 - exp(-max(dist - 4.0, 0.0) * density);
}

#ifdef NETHER_WARM_LIGHT
// Hue of the block light (luminance 1, so the vanilla lightmap keeps the brightness): deep red at low
// light, orange-yellow near a source; blockLight = lightmap block coordinate (0..1).
vec3 netherBlockLightHue(float blockLight) {
    vec3 c = mix(vec3(vclNLowR, vclNLowG, vclNLowB), vec3(vclNHighR, vclNHighG, vclNHighB),
                 smoothstep(0.25, 0.95, blockLight));
    return c / max(dimLuma(c), 1.0e-3);
}
#endif
#endif

// ---------------------------------------------------------------------------------------------
// THE END
#ifdef END_AMBIENCE
// Update 4 (End VV): the End of Vibrant Visuals, measured on your three references (decoded pixels,
// display values, 5 x 5 to 20 x 10 px averages; END_VV_REPORT.md):
//   sky between flashes  #0E0916 high up (still at about 60 degrees), #0C0813 at about 10 degrees,
//                        #0A060E at the horizon; smooth (luma deviation 0.8 to 1.6 in 200 x 200 px,
//                        compression noise only: no texture grain). The wiki's VV zenith (RGB 22 17 36)
//                        is brighter than any sky pixel of the references, so the zenith is #100A19;
//   end stone ground     #4D492F (the texture under a dim warm-neutral light, not violet);
//   flash glow           centre #683A70 over #100B18, half brightness at about 15 degrees, gone near
//                        45 degrees, colour (1.00, 0.53, 0.98) above the background (bluer than before);
//                        fitted over about 3 500 sky cells of image 2 (20 px grid; rms error 2.2 to 2.8 of 255 in luma).
// The sky and the fog are one function, so the far terrain dissolves into exactly the sky behind it and
// the horizon has no edge, no band and no colour step.
const vec3 END_SKY_ZENITH = vec3(0.063, 0.039, 0.098);    // #100A19
const vec3 END_SKY_HIGH = vec3(0.055, 0.035, 0.086);      // #0E0916, about 30 degrees and above
const vec3 END_SKY_LOW = vec3(0.047, 0.031, 0.075);       // #0C0813, about 10 degrees
const vec3 END_SKY_HORIZON = vec3(0.039, 0.024, 0.055);   // #0A060E
const vec3 END_SKY_VOID = vec3(0.027, 0.016, 0.039);      // #07040A, the void 30 degrees below
// Average colour of the vanilla End sky (end_sky.png x the vertex colour 40/255, measured from the 26.3
// texture): END_SKY_GRAIN adds the texture's grain around this average (0 = the smooth VV sky).
const vec3 END_VANILLA_SKY = vec3(0.071, 0.054, 0.096);
// The brightest the vanilla End sky gets (texel 219/255 x 40/255): anything in colortex0 above it on a
// sky pixel was drawn on top of the sky (fireworks, beams, the dragon's death rays).
const float END_SKY_OVERLAY_FLOOR = 0.14;
// The End light on blocks and entities (the sky-lit part of the lightmap; torch light keeps its own
// colour): the vanilla End ambient (#3F473F, grey-green) times this gives the reference's end stone
// (#4D492F from the texture's #DCDF9E: about 0.35 / 0.33 / 0.30) at END_AMBIENT_TINT 1 and
// END_AMBIENT_BRIGHTNESS 0.67. Luminance 1: the brightness is the slider.
const vec3 END_AMBIENT_HUE = vec3(1.151, 0.957, 0.978);

// The End sky along dir (display values): smooth, darkest at the horizon, the void below a little darker.
vec3 endSkyColor(vec3 dir) {
    float up = dir.y;
    vec3 c = mix(END_SKY_HORIZON, END_SKY_LOW, smoothstep(0.0, 0.17, up));
    c = mix(c, END_SKY_HIGH, smoothstep(0.10, 0.50, up));
    c = mix(c, END_SKY_ZENITH, smoothstep(0.45, 1.0, up));
    c = mix(c, END_SKY_VOID, smoothstep(0.0, 0.50, -up));
    return c * END_SKY_BRIGHTNESS;
}

// The fog colour along dir: the sky of that direction (one function with the sky, no tone break).
vec3 endFogColor(vec3 dir) {
    return endSkyColor(dir);
}

// Fog amount over dist blocks (thin between flashes: about 17 % at 100 blocks, as on the reference's
// ground, which keeps its colour up to the island's edge); a flash thickens it by densityBoost.
float endFogAmount(float dist, float densityBoost) {
    return 1.0 - exp(-max(dist - 8.0, 0.0) * (END_FOG_DENSITY * 0.0020) * densityBoost);
}

#ifdef END_SKY_TEXTURE
// The vanilla End sky rebuilt from the view direction (final.fsh), so the sky never depends on what was
// drawn into colortex0: Minecraft 26.3's SkyRenderer.buildEndSky draws six faces 100 blocks away with
// end_sky.png repeated 16 times per face (UV 0..16), nearest filtering, colour 40/255; the faces are the
// bottom face turned by rotationX(+-90), rotationX(180), rotationZ(+-90) (checked in the 26.3 jar). This
// reproduces that mapping texel for texel (the same 128 x 128 texture, shipped as textures/end_sky.png).
// Read only for END_SKY_GRAIN above 0 (percent) and for END_DEBUG view 10.
uniform sampler2D vclEndSky;

vec3 endVanillaSky(vec3 dir) {
    vec3 a = abs(dir);
    vec2 p;   // the point on the face, in blocks (-100..100), in the face's own u/v axes
    if (a.y >= a.x && a.y >= a.z) {
        p = dir.xz * (100.0 / a.y);
        if (dir.y > 0.0) p.y = -p.y;           // top face: v runs north
    } else if (a.z >= a.x) {
        p = dir.xy * (100.0 / a.z);
        if (dir.z < 0.0) p.y = -p.y;           // north face: v runs down
    } else {
        p = dir.yz * (100.0 / a.x);
        if (dir.x < 0.0) p.x = -p.x;           // west face: u runs down
    }
    ivec2 size = textureSize(vclEndSky, 0);
    vec2 uv = (p + 100.0) * (16.0 / 200.0);
    ivec2 texel = min(ivec2(fract(uv) * vec2(size)), size - 1);
    return texelFetch(vclEndSky, texel, 0).rgb * (40.0 / 255.0);
}
#endif

// The End sky of final.fsh: the smooth VV sky, plus the vanilla texture's grain at END_SKY_GRAIN.
vec3 endSkyFull(vec3 dir) {
    vec3 c = endSkyColor(dir);
#if defined(END_SKY_TEXTURE) && END_SKY_GRAIN > 0
    c = max(c + (endVanillaSky(dir) - END_VANILLA_SKY) * (float(END_SKY_GRAIN) * 0.01 * END_SKY_BRIGHTNESS), vec3(0.0));
#endif
    return c;
}

#ifdef END_FLASHES
// Iris 1.11.7: the flash direction in view space x 100 (zero outside the End).
uniform vec3 endFlashPosition;
uniform float vclFlash;         // vanilla flash intensity (0..1), smoothed over the 20 Hz tick steps
uniform float vclFlashBump;     // the double pulse on the rising half of the flash (0..1.1)
uniform float vclFlashHue;      // per flash (30-second window), 0..1
uniform float vclFlashPeak;     // per flash peak variation (0.85..1.15)
uniform float vclDragon;        // 1 during the Ender Dragon fight (heavyFog), smoothed

// The Ender Dragon fight (the boss bar's world fog). Your references are all taken with the dragon
// alive (crystals on the pillars, the dragon in view) and show the flash and the same calm sky, so by
// default the fight changes nothing (Update 3 hid the flash glow and thickened the fog then, which is
// why no flash showed in the sky before the dragon was killed). END_DRAGON_FOG brings the old look back.
float endDragonFight() {
#ifdef END_DRAGON_FOG
    return clamp(vclDragon, 0.0, 1.0);
#else
    return 0.0;
#endif
}

// The flash light on a surface turned straight to it, at the flash peak (x the albedo and colour). It
// replaces the game's own flash light (about +0.6 to +0.9 on the lightmap at sky light 15), so the
// ground under the open sky brightens by about a third at the peak and the pillars get a violet rim.
const float FLASH_LIGHT_GAIN = 0.5;
// The flash glow at its centre at the flash peak (above the sky): your reference's #683A70 over #100B18.
const float FLASH_GLOW_PEAK = 0.40;

#ifdef FLASH_PHOTOSENSITIVITY_LIMIT
// At most a gentle second bump (no strobing: the bumps are about 0.5 to 3 s apart).
const float FLASH_PULSE_EFF = min(FLASH_PULSE, 0.20);
#else
const float FLASH_PULSE_EFF = FLASH_PULSE;
#endif

// The flash envelope used by every effect: the vanilla half-sine (Vibrant Visuals fades its flash light in
// and out the same way), the optional double pulse on its rising half (FLASH_PULSE, 0 = none, as in Vibrant
// Visuals), the optional per-flash strength (FLASH_COLOR_VARIATION, 0 = always the same), a third during
// the dragon fight only with END_DRAGON_FOG, the intensity slider. 0 between flashes.
float endFlashEnvelope() {
    float e = clamp(vclFlash, 0.0, 1.0) * (1.0 + FLASH_PULSE_EFF * vclFlashBump);
    e *= mix(1.0, vclFlashPeak, FLASH_COLOR_VARIATION) * mix(1.0, 1.0 / 3.0, endDragonFight());
    return e < 0.001 ? 0.0 : e * FLASH_INTENSITY;
}

// Flash colour: the Vibrant Visuals End flash light, RGB 228 93 255 (#E45DFF); with FLASH_COLOR_VARIATION
// it varies per flash between #CC66FF and #FC54FF (the middle is #E45DFF).
vec3 endFlashColor() {
    float t = clamp(0.5 + (vclFlashHue - 0.5) * FLASH_COLOR_VARIATION, 0.0, 1.0);
    return mix(vec3(0.800, 0.400, 1.000), vec3(0.988, 0.330, 1.000), t);
}

// The colour of the glowing fog: the flash light scattered by the fog, paler than the light. With #E45DFF
// it is (0.94, 0.53, 0.98): your references' glow above the background, (1.00, 0.53, 0.98).
vec3 endFlashGlowColor(vec3 flashColor) {
    return mix(flashColor, vec3(1.00, 0.78, 0.95), 0.40);
}

// The flash glow in the fog toward the flash. Vibrant Visuals does not draw the classic flash sprite: the
// flash shows as the bright tinting of the purple fog. The same function colours the sky pixels and the
// fog over terrain, so distant islands dissolve into exactly the glow behind them. Shape fitted to your
// reference with the glow centre in view (image 2; image 4, with the centre behind the pillar, agrees): a
// soft Gaussian (FLASH_HALO_SIZE 0.34 = 19.5 degrees; half brightness at about 15 degrees) with a faint
// exponential tail; almost nothing past 45 degrees, nothing added to the rest of the sky. No disc: the flash
// has no visible source. theta: angle to the flash (radians); e: the envelope.
vec3 endFlashGlow(float theta, vec3 flashColor, float e) {
    float t = theta * (1.0 / FLASH_HALO_SIZE);
    float shape = 0.85 * exp(-t * t) + 0.15 * exp(-theta * (1.0 / (1.2 * FLASH_HALO_SIZE)));
    return endFlashGlowColor(flashColor) * (FLASH_GLOW_PEAK * e * shape);
}
#endif
#endif
