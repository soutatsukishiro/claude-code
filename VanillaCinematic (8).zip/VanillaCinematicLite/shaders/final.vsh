#version 330 compatibility

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
// Needed by lib/ambience.glsl (the palette is evaluated here, once per frame in practice).
uniform float rainStrength;
uniform float thunderStrength;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float frameTimeCounter;

#ifdef MOON_RAYS
uniform int moonPhase;
#endif

#if defined(AMB_SUN_VISIBILITY) || defined(AMB_MOON_VISIBILITY)
uniform sampler2D depthtex0;
#if defined(AMBIENCE_COLORS) || defined(AMBIENCE_CLOUDS)
// Cloud marker written by gbuffers_clouds: A = 1, R = 0, G = the face's opacity.
#define FINAL_VSH_CLOUD_MARKER
uniform sampler2D colortex1;
#endif
#endif

#include "/lib/ambience.glsl"

// Dimension weights (custom uniforms): the adaptive eyes and the End flash read them.
uniform float atmosNether;
uniform float atmosEnd;
uniform float atmosOverworld;
uniform int isEyeInWater;

#ifdef END_FLASHES
// Update 3: the End flash for final.fsh, once per frame (identical for every vertex): its world
// direction and envelope, its screen position for the shafts (the same values composite and
// composite1 compute for the shaft mask and march).
#include "/lib/dimension_ambience.glsl"
// xyz = world direction toward the flash, w = envelope (0 between flashes and outside the End).
flat out vec4 vFlashA;
// xy = screen position, z = 1 in front of the camera, w = on-screen fade (as the sun's).
flat out vec4 vFlashB;
#endif

#ifdef ADAPTIVE_EYES
// Patch 2.1: the adaptive eyes' numbers for this frame (identical for every vertex), handed to
// final.fsh as flat values, so the per-pixel stage only multiplies and shapes.
uniform float blindness;
uniform float darknessFactor;
uniform float nightVision;
#ifdef ADAPT_SCENE_LUMA
// Tier 2's smoothed scene refinement (composite2, one texel).
uniform sampler2D colortex6;
#endif
#include "/lib/adaptive_eyes.glsl"
// A: x = display gain, y = local lift amount, z = dark amount, w = punch.
// B: x = bloom boost, y = highlight protection weight, z = dither scale, w = 0.
flat out vec4 vAdaptA;
flat out vec4 vAdaptB;
#ifdef ADAPT_DEBUG
// The state for the debug views: eye, goal, over-bright and tier-2 stops; final gain stops.
flat out vec4 vAdaptDebug;
flat out float vAdaptDebugGain;
#endif
#endif

out vec2 vTexCoord;
out float vSunElevation;
out float vMoonElevation;
out vec2 vSunUV;
out float vSunInFront;
out vec2 vMoonUV;
out float vMoonInFront;

// Ambience palette for this frame (sky, fog, clouds, light) and the world sun direction.
flat out vec3 vSunWorld;
flat out vec3 vPalZenith;
flat out vec3 vPalMid;
flat out vec3 vPalHorizon;
flat out vec3 vPalFogNear;
flat out vec3 vPalCloudTop;
flat out vec3 vPalCloudUnder;
flat out vec3 vPalSkyLight;
flat out vec3 vPalGlow;
flat out float vPalGolden;
// Sun visibility V (0..1), the share of the sun hidden by clouds, and the on-screen fade of the
// veil, rim and shafts, identical for every vertex.
flat out float vSunVisibility;
flat out float vSunCloudCover;
flat out float vSunScreenFade;
#ifdef MOON_RAYS
// The moon for this frame (lib/ambience.glsl, AmbMoon): direction (xyz) and light (w); colour
// tint (rgb) and night weight (a, 0 by day); lit side; and its rays: visibility V, share behind
// clouds, on-screen fade, shaft gate (> 0 = the moon owns the shaft buffer).
flat out vec4 vMoonWorldLight;
flat out vec4 vMoonTintNight;
flat out vec2 vMoonSide;
flat out vec4 vMoonRays;
#ifdef MOON_SHAFTS
// 0 while the moon owns the shaft buffer, else 1 (the sun's shafts).
flat out float vSunShaftGate;
#endif
#endif
#ifdef AMB_WATER_OWN_PALETTE
// The palette without the biome look, for the screen-space water reflection (it must match
// the water's own Tier-1 reflection when BIOME_AMBIENCE_AFFECTS_WATER_REFLECTION is off).
flat out vec3 vWaterZenith;
flat out vec3 vWaterMid;
flat out vec3 vWaterHorizon;
flat out vec3 vWaterCloudTop;
flat out vec3 vWaterCloudUnder;
flat out vec3 vWaterGlow;
flat out float vWaterGolden;
#endif

#if defined(AMB_SUN_VISIBILITY) || defined(AMB_MOON_VISIBILITY)
// Visibility taps, shared by the sun and the moon (the moon passes its own centre and size).
// One texel: open sky = 1, a cloud = its transparency (opaque clouds hide the sun), anything
// else = 0; cloud = how much of it is cloud.
void sunTexel(ivec2 texel, out float open, out float cloud) {
    open = texelFetch(depthtex0, texel, 0).r > 0.99999 ? 1.0 : 0.0;
    cloud = 0.0;
#ifdef FINAL_VSH_CLOUD_MARKER
    vec4 info = texelFetch(colortex1, texel, 0);
    if (info.a > 0.5 && info.r < 0.5) {
        open = 1.0 - info.g;
        cloud = info.g;
    }
#endif
}

// One visibility tap, bilinear between the four nearest texels: as the sun (and so the tap)
// moves across a block or cloud edge, its value changes continuously instead of jumping, so
// the veil, rim and shafts never pop. Taps outside the screen count as open (the effects fade
// out off screen anyway).
void sunTap(vec2 uv, inout float open, inout float cloud) {
    if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) {
        open += 1.0;
        return;
    }
    vec2 size = vec2(textureSize(depthtex0, 0));
    vec2 position = uv * size - 0.5;
    ivec2 base = ivec2(floor(position));
    vec2 f = position - floor(position);
    ivec2 maxTexel = ivec2(size) - 1;
    float o00, o10, o01, o11, c00, c10, c01, c11;
    sunTexel(clamp(base, ivec2(0), maxTexel), o00, c00);
    sunTexel(clamp(base + ivec2(1, 0), ivec2(0), maxTexel), o10, c10);
    sunTexel(clamp(base + ivec2(0, 1), ivec2(0), maxTexel), o01, c01);
    sunTexel(clamp(base + ivec2(1, 1), ivec2(0), maxTexel), o11, c11);
    open += mix(mix(o00, o10, f.x), mix(o01, o11, f.x), f.y);
    cloud += mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
}

// A tap covering a small area: four bilinear samples at +-0.12 sun half-sizes, so an edge
// sweeping over the sun changes V in many small continuous ramps instead of a few steps.
void sunAreaTap(vec2 uv, vec2 halfSize, inout float open, inout float cloud) {
    vec2 o = halfSize * 0.12;
    float o4 = 0.0;
    float c4 = 0.0;
    sunTap(uv + vec2(-o.x, -o.y), o4, c4);
    sunTap(uv + vec2(o.x, -o.y), o4, c4);
    sunTap(uv + vec2(-o.x, o.y), o4, c4);
    sunTap(uv + vec2(o.x, o.y), o4, c4);
    open += 0.25 * o4;
    cloud += 0.25 * c4;
}

// A ring of taps at a fixed radius (in sun half-sizes) and angular phase: a deterministic
// pattern, no random offsets, so V is the same every frame for the same view.
void sunRing(vec2 centre, vec2 halfSize, int count, float radius, float phase, inout float open, inout float cloud, inout float weight) {
    for (int i = 0; i < count; ++i) {
        float a = phase + 6.2831853 * float(i) / float(count);
        sunAreaTap(centre + vec2(cos(a), sin(a)) * halfSize * radius, halfSize, open, cloud);
        weight += 1.0;
    }
}
#endif

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec3 sunWorld = mat3(gbufferModelViewInverse) * sunPosition;
    float sunLength2 = dot(sunWorld, sunWorld);
    sunWorld = sunLength2 > 0.000001 ? sunWorld * inversesqrt(sunLength2) : vec3(0.0, 1.0, 0.0);
    vSunElevation = sunWorld.y;

    vec3 moonWorld = mat3(gbufferModelViewInverse) * moonPosition;
    float moonLength2 = dot(moonWorld, moonWorld);
    moonWorld = moonLength2 > 0.000001 ? moonWorld * inversesqrt(moonLength2) : vec3(0.0, -1.0, 0.0);
    vMoonElevation = moonWorld.y;

    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vSunInFront = sunClip.w > 0.001 ? 1.0 : 0.0;
    vSunUV = vSunInFront > 0.5 ? sunClip.xy / sunClip.w * 0.5 + 0.5 : vec2(-2.0);
    vec4 moonClip = gbufferProjection * vec4(moonPosition, 1.0);
    vMoonInFront = moonClip.w > 0.001 ? 1.0 : 0.0;
    vMoonUV = vMoonInFront > 0.5 ? moonClip.xy / moonClip.w * 0.5 + 0.5 : vec2(-2.0);

    vSunWorld = sunWorld;
    AmbPalette pal = ambiencePalette(sunWorld);
    vPalZenith = pal.zenith;
    vPalMid = pal.mid;
    vPalHorizon = pal.horizon;
    vPalFogNear = pal.fogNear;
    vPalCloudTop = pal.cloudTop;
    vPalCloudUnder = pal.cloudUnder;
    vPalSkyLight = pal.skyLight;
    vPalGlow = pal.glow;
    vPalGolden = pal.golden;
#ifdef AMB_WATER_OWN_PALETTE
    AmbPalette waterPal = ambiencePaletteBiome(sunWorld, 0.0);
    vWaterZenith = waterPal.zenith;
    vWaterMid = waterPal.mid;
    vWaterHorizon = waterPal.horizon;
    vWaterCloudTop = waterPal.cloudTop;
    vWaterCloudUnder = waterPal.cloudUnder;
    vWaterGlow = waterPal.glow;
    vWaterGolden = waterPal.golden;
#endif

    // Sun visibility: fixed taps inside the sun square, read once per vertex (a few hundred
    // fetches per frame in total). The fade takes the veil, rim and shafts away smoothly once
    // the sun is outside the screen (NDC 1.0 to 1.35) or behind the camera.
    vSunVisibility = 1.0;
    vSunCloudCover = 0.0;
    vSunScreenFade = 0.0;
    if (vSunInFront > 0.5) {
        vec2 ndc = sunClip.xy / sunClip.w;
        vSunScreenFade = 1.0 - smoothstep(1.0, 1.35, max(abs(ndc.x), abs(ndc.y)));
    }
#ifdef AMB_SUN_VISIBILITY
    if (vSunInFront > 0.5) {
        vec2 halfSize = vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * (0.5 * AMB_SUN_HALF);
        float open = 0.0;
        float cloud = 0.0;
        sunAreaTap(vSunUV, halfSize, open, cloud);
        float weight = 1.0;
#if SUN_VISIBILITY_TAPS == 9
        sunRing(vSunUV, halfSize, 8, 0.70, 0.0, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 13
        sunRing(vSunUV, halfSize, 6, 0.50, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 6, 1.00, 0.5236, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 21
        sunRing(vSunUV, halfSize, 8, 0.45, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 12, 0.95, 0.2618, open, cloud, weight);
#else
        sunRing(vSunUV, halfSize, 8, 0.35, 0.0, open, cloud, weight);
        sunRing(vSunUV, halfSize, 8, 0.70, 0.3927, open, cloud, weight);
        sunRing(vSunUV, halfSize, 12, 1.00, 0.2618, open, cloud, weight);
#endif
        vSunVisibility = open / weight;
        vSunCloudCover = cloud / weight;
    }
#endif

#ifdef MOON_RAYS
    // The moon: the same per-frame terms with its own direction (moonPosition), size, phase and
    // colours. Its visibility uses the sun's tap pattern at the moon's size; in vanilla the
    // moon and the sun are opposite, so at most one of them is in front of the camera and only
    // one tap set runs per frame.
    vec3 moonDir = ambCelestialDirection(moonPosition);
    vec3 sunDir = ambCelestialDirection(sunPosition);
    AmbMoon moon = ambMoon(moonDir, sunDir, moonPhase);
    vMoonWorldLight = vec4(moon.dir, moon.light);
    vMoonTintNight = vec4(moon.tint, ambMoonUp(moonDir, sunDir));
    vMoonSide = moon.side;
    float moonScreenFade = 0.0;
    if (vMoonInFront > 0.5) {
        vec2 ndc = moonClip.xy / moonClip.w;
        moonScreenFade = 1.0 - smoothstep(1.0, 1.35, max(abs(ndc.x), abs(ndc.y)));
    }
    float moonVisibility = 1.0;
    float moonCloudCover = 0.0;
#ifdef AMB_MOON_VISIBILITY
    if (vMoonInFront > 0.5 && moon.light > 0.0) {
        vec2 halfSize = vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * (0.5 * AMB_MOON_HALF);
        float open = 0.0;
        float cloud = 0.0;
        sunAreaTap(vMoonUV, halfSize, open, cloud);
        float weight = 1.0;
#if SUN_VISIBILITY_TAPS == 9
        sunRing(vMoonUV, halfSize, 8, 0.70, 0.0, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 13
        sunRing(vMoonUV, halfSize, 6, 0.50, 0.0, open, cloud, weight);
        sunRing(vMoonUV, halfSize, 6, 1.00, 0.5236, open, cloud, weight);
#elif SUN_VISIBILITY_TAPS == 21
        sunRing(vMoonUV, halfSize, 8, 0.45, 0.0, open, cloud, weight);
        sunRing(vMoonUV, halfSize, 12, 0.95, 0.2618, open, cloud, weight);
#else
        sunRing(vMoonUV, halfSize, 8, 0.35, 0.0, open, cloud, weight);
        sunRing(vMoonUV, halfSize, 8, 0.70, 0.3927, open, cloud, weight);
        sunRing(vMoonUV, halfSize, 12, 1.00, 0.2618, open, cloud, weight);
#endif
        moonVisibility = open / weight;
        moonCloudCover = cloud / weight;
    }
#endif
    float moonShaftGate = 0.0;
#ifdef MOON_SHAFTS
    moonShaftGate = ambMoonShaftOwner(vMoonInFront, moon.light, moonDir, vSunInFront, sunDir.y);
    vSunShaftGate = moonShaftGate > 0.0 ? 0.0 : 1.0;
#endif
    vMoonRays = vec4(moonVisibility, moonCloudCover, moonScreenFade, moonShaftGate);
#endif

#ifdef ADAPTIVE_EYES
    vec4 adaptHistory = vec4(0.0);
#ifdef ADAPT_SCENE_LUMA
    adaptHistory = texelFetch(colortex6, ivec2(0), 0);
#endif
    AdaptState adapt = adaptState(adaptHistory, atmosOverworld, atmosNether, atmosEnd, blindness, darknessFactor, nightVision,
                                  isEyeInWater == 1 ? 1.0 : 0.0);
    // Linear-light stops to a factor on the pack's display values (exactly 1.0 at 0 stops).
    float adaptGain = exp2(adapt.gainStops / 2.2);
#ifdef LM_TONE
    // Update 6 (Lighting Match): the bright-scene punch (an S-curve that darkens the darks and adds contrast in snowy and
    // sunny views) works against the soft game curve, so it is halved in the Overworld above water.
    float lmPunch = adapt.punch * (atmosOverworld > 0.5 && isEyeInWater == 0 ? 0.5 : 1.0);
    vAdaptA = vec4(adaptGain, ADAPT_LOCAL_LIFT_STRENGTH * 0.8 * adapt.darkAmount, adapt.darkAmount, lmPunch);
#else
    vAdaptA = vec4(adaptGain, ADAPT_LOCAL_LIFT_STRENGTH * 0.8 * adapt.darkAmount, adapt.darkAmount, adapt.punch);
#endif
    // The highlight roll-off is fully on from +6 % screen gain; the extra dither scales up to the
    // largest gain (1.43 x screen at ADAPT_MAX_BRIGHTEN 2.2).
    vAdaptB = vec4(1.0 + ADAPT_FLASH_BLOOM * adapt.flashStops, clamp((adaptGain - 1.0) / 0.06, 0.0, 1.0),
                   clamp((adaptGain - 1.0) / 0.43, 0.0, 1.0), 0.0);
#ifdef ADAPT_DEBUG
    vAdaptDebug = vec4(adapt.eyeStops, adapt.goalStops, adapt.flashStops, adapt.sceneStops);
    vAdaptDebugGain = adapt.gainStops;
#endif
#endif

#ifdef END_FLASHES
    // The End flash (Iris: endFlashPosition, view space x 100, zero outside the End). Its direction
    // is constant during a flash; it changes between windows, while the envelope is 0.
    vec3 flashWorld = mat3(gbufferModelViewInverse) * endFlashPosition;
    float flashLength2 = dot(flashWorld, flashWorld);
    bool flashValid = flashLength2 > 1.0e-6 && atmosEnd > 0.5;
    flashWorld = flashValid ? flashWorld * inversesqrt(flashLength2) : vec3(0.0, 1.0, 0.0);
    vFlashA = vec4(flashWorld, flashValid ? endFlashEnvelope() : 0.0);
    vec4 flashClip = gbufferProjection * vec4(endFlashPosition, 1.0);
    float flashInFront = (flashValid && flashClip.w > 0.001) ? 1.0 : 0.0;
    vec2 flashUV = flashInFront > 0.5 ? flashClip.xy / flashClip.w * 0.5 + 0.5 : vec2(-2.0);
    float flashFade = flashInFront > 0.5 ? 1.0 - smoothstep(1.0, 1.35, max(abs(flashUV.x * 2.0 - 1.0), abs(flashUV.y * 2.0 - 1.0))) : 0.0;
    vFlashB = vec4(flashUV, flashInFront, flashFade);
#endif
}
