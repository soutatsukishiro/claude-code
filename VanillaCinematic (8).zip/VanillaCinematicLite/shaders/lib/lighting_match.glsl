// Update 6: Lighting Match (Vibrant Visuals: soft, cold, game-like light). Shared helpers.
//
// The pack works in display values (no linear-light stage), so every amount below is on display values, like the
// rest of the pack. Included after lib/ambience.glsl (the biome weights) by lib/gbuffers_forward.fsh and final.fsh,
// only with LIGHTING_MATCH on. Nothing here runs in the Nether, the End or under water (the callers pass the
// Overworld weight).
#ifndef LIGHTING_MATCH_GLSL
#define LIGHTING_MATCH_GLSL

const vec3 LM_LUMA = vec3(0.2126, 0.7152, 0.0722);

// How cold the environment light is here (ENV_COOLNESS x the biome group: full in the snowy family, a share in the
// neutral biomes, none in deserts, badlands, savannas, jungles and swamps). The camera's biome blend, as the sky
// palette uses it.
float lmBiomeCoolShare() {
    float cold = 0.0;
    float warm = 0.0;
#ifdef BIOME_AMBIENCE
#if FORCE_BIOME_PREVIEW > 0
    int group = AMB_BIOME_GROUP[FORCE_BIOME_PREVIEW];
    cold = group == 2 ? 1.0 : 0.0;
    warm = (group == 1 || group == 3) ? 1.0 : 0.0;
#else
    cold = clamp(bgCold, 0.0, 1.0);
    warm = clamp(bgWarm + bgHumid, 0.0, 1.0);
#endif
#endif
    float neutral = clamp(1.0 - cold - warm, 0.0, 1.0);
    return cold * float(ENV_COOL_COLD) + neutral * float(ENV_COOL_NEUTRAL);
}

float lmCoolWeight() {
    return float(ENV_COOLNESS) * lmBiomeCoolShare();
}

// A light colour made colder: its own hue pushed further the way it already leans (the sky light leans blue), at
// the same luminance. cool = 0 keeps it.
vec3 lmCoolHue(vec3 lightColor, float cool) {
    vec3 hue = lightColor / max(dot(lightColor, LM_LUMA), 1.0e-4);
    // Only a light that already leans blue is pushed (a warm sunset sky light is left as it is, never made warmer).
    cool *= smoothstep(0.0, 0.08, hue.b - hue.r);
    vec3 pushed = pow(max(hue, vec3(1.0e-3)), vec3(1.0 + 1.6 * cool));
    return pushed / max(dot(pushed, LM_LUMA), 1.0e-4);
}

#ifdef LM_TONE
// The soft game curve (TONE_CURVE 2), on luminance with the hue kept: identity up to the knee (0.60 x HIGHLIGHTS),
// then a tanh shoulder toward WHITES (slope 1 at the knee, never past WHITES), blended by TONE_SHOULDER_STRENGTH;
// then the black lift (TONE_BLACK_LIFT, in the cool ambient's hue, gone by mid grey). No toe that crushes.
vec3 lmToneCurve(vec3 color, vec3 liftHue) {
    vec3 c = max(color, vec3(0.0));
    float L = dot(c, LM_LUMA);
    float knee = 0.60 * float(HIGHLIGHTS);
    float W = float(WHITES);
    float s = L;
    if (L > knee) {
        float x = (L - knee) / (W - knee);
        // tanh(x) = 1 - 2 / (exp(2x) + 1), safe for large x.
        s = knee + (W - knee) * (1.0 - 2.0 / (exp(2.0 * min(x, 20.0)) + 1.0));
    }
    s = mix(L, s, float(TONE_SHOULDER_STRENGTH));
    vec3 outColor = L > 1.0e-5 ? c * (s / L) : c;
    float lift = float(TONE_BLACK_LIFT) * (1.0 - smoothstep(0.0, 0.5, s));
    return outColor + liftHue * lift;
}
#endif

#ifdef LM_COLOR
// Midtone saturation and vibrance: GLOBAL_SATURATION everywhere it is safe, VIBRANCE more on the weakly coloured
// pixels; full on greens, blues and cyans, 60 % on warm hues; nothing near black, on near-white (snow, highlights)
// or where weight is 0 (the sky, the far fog). Never brighter than the brightest channel was, never negative.
vec3 lmSaturation(vec3 color, float weight) {
    vec3 c = max(color, vec3(0.0));
    float L = dot(c, LM_LUMA);
    float hi = max(c.r, max(c.g, c.b));
    float lo = min(c.r, min(c.g, c.b));
    float chroma = (hi - lo) / max(hi, 1.0e-4);
    float mid = smoothstep(0.02, 0.14, L) * (1.0 - smoothstep(0.62, 0.92, L));
    float coolHue = mix(0.60, 1.0, smoothstep(-0.02, 0.06, max(c.g, c.b) - c.r));
    float amount = (float(GLOBAL_SATURATION) - 1.0 + float(VIBRANCE) * (1.0 - chroma)) * mid * coolHue * weight;
    amount = clamp(amount, -0.5, 0.35);
    vec3 outColor = vec3(L) + (c - vec3(L)) * (1.0 + amount);
    return clamp(outColor, vec3(0.0), vec3(max(hi, 1.0)));
}
#endif

#endif
