# Update 6: Lighting Match (Vibrant Visuals) + texture-pattern reflection

Your spec calls this "UPDATE 5". The pack already has an Update 5 (the fake GI, and its 5.1 fix), so this one is
**Update 6** in the files, the menus and the changelog. Nothing else was renamed.

This update has two parts:
- **Part A, the texture-pattern reflection (`TEXTURE_REFLECT`):** your earlier Portuguese request, the mask per block.
- **Part B, Lighting Match (`LIGHTING_MATCH`):** the English spec.

Both have their own switch.

- **Backup** of every file as it was before this update: `backup/2026-10-08_before_lighting_match/` (the whole
  `shaders/` folder and `README.md` of Update 5.1). Copy it back to undo.
- **Off = Update 5.1.** With `LIGHTING_MATCH` and `TEXTURE_REFLECT` both off, every program in all five presets
  preprocesses to the 5.1 code (checked program by program). The one textual exception is the literal `1.0` →
  `1.00` of `GI_FALLOFF_DIST` (fix 11 in section 2), which is numerically identical. With only `LIGHTING_MATCH` off,
  the difference is Part A alone.

---

## 0. Capability check, consent, what I could not do

- **I have no screen capture and no computer-use tools in this session.** This is a cloud container with no game
  and no GPU. I never ran Minecraft.
- **Where the numbers come from:**
  - **Measured:** the two attached screenshots, pixel by pixel.
  - **Verified:** the shader code, compiled by three independent checkers.
  - **Estimated:** a numerical region model of the pipeline (section 3). Model numbers are predictions, not captures.
- **Consent:** I ask your permission before any capture. If you agree, you take the screenshots yourself, only the
  Minecraft window, nothing else kept. The list is in section 9.
- **Performance numbers are estimates** from operation counts (section 8).

## 1. The screenshots

The two images are the same snowy taiga with a frozen lake, at noon, but **not the same framing**:
- IMAGE 1 (Vibrant Visuals) is 1794 × 1009.
- IMAGE 2 (yours) is 1920 × 1080 and slightly rotated.

So regions were measured separately in each image (boxes in section 3).

**IMAGE 1, Vibrant Visuals: the whole frame sits inside a narrow band.**
- Luma (display) runs from 0.12 (1st percentile) to 0.68 (99th). Nothing is crushed (0.00 % below 0.03) and nothing
  clips (0.00 % above 0.97).
- **Almost everything is blue or teal:**
  - 93 % of the pixels have a blue hue; under 1 % are green.
  - The spruce leaves read teal (hue 196-204°).
  - Even the darkest trunk texels are a blue-violet grey, `#1C1B20`.
- **Snow:** a saturated lavender-blue. The top is `#8B9CD8` (luma 0.61), shaded snow `#5973B8`.
- **Sky:** a rich blue, `#6084D5` at the top and `#7492DE` near the horizon, darker than the snow.
- **Lake:** a saturated `#4C70DE`.
- **Distant trees:** `#485876`, still readable through the haze.

**IMAGE 2, your shader: a wider range with crushed darks.**
- Luma runs from 0.048 (1st percentile) to 0.83 (99th); 0.20 % of the pixels are crushed.
- **Leaves:** green (hue 120-160°), with near-black gaps: the darkest texels are `#020C04`, luma 0.036.
- **Trunks:** warm brown `#1F150B`.
- **Snow:** a pale lavender-white, `#B8C3E7` (0.77), with clipped white glint dots.
- **Sky and haze:** pale `#B4C4F6`, as bright as the snow.
- **Lake:** pale `#9FB7EE`.
- **Distant trees:** washed to `#97A2B0`.

**Your reading, corrected by measurement:**

| Item | Your estimate | Measured |
|---|---|---|
| VV sky top / horizon | `#4F7FE0` / `#8FA8EC` | `#6084D5` / `#7492DE` (the horizon is darker than you thought) |
| VV leaf base / lit / darkest | `#2A6458` / `#3E8A78` / `#1A3A38` | `#2A434C` / `#3A6064` / `#182B36`: bluer and darker; teal, not green |
| VV snow top / sides | `#C8D2F2` / `#9AA8DC` | `#8B9CD8` / `#5973B8` (shaded): much darker and more saturated |
| VV ground in tree shadow | `#4A8A8C` | `#2B5268` |
| VV trunk | `#3A2418` | `#242024`: a neutral violet grey, not brown |
| VV lake / haze | `#3D6FE0` / `#9CB0EC` | `#4C70DE` / `#485876` (distant trees) |
| Ours: sky | `#A8B8F0`-`#C8D4F6` | `#B4C4F6` / `#BCCBF2`: right |
| Ours: leaves / gaps | `#1E4A2E` / `#0A1A10` | `#192D20` / `#020C04`: darker than you thought |
| Ours: snow tops | `#E6EAF8` | `#B8C3E7` (0.77), with white dots: less bright than you thought, but the dots clip |
| Ours: trunk | `#4A2814` | `#1F150B` |

**What else I see:**
- **VV's shadow contrast on snow is the same as ours.** Lit to shaded snow is 1.37 in both. The VV shade is only far
  bluer (saturation 40 % against 20 %).
- **The big differences are the dark end and the bright end:**
  - VV's darkest leaf texels are 4× brighter in display (0.157 against 0.036).
  - VV's snow and sky are 20-33 % darker.

  In short, VV compresses the whole range (blacks up, whites down) and pushes everything toward blue.
- **The leaf teal.** In Java, spruce leaves are not biome-tinted: their colour is the constant `0x619961`, a green. So
  none of IMAGE 1's teal is expected from the pack's biome tint. It can only come from the cool light, and a hue of
  196° is far from green. The cool tint gets the leaves part of the way. Matching it fully would need a strong blue
  cast, which you ruled out ("no blue filter").

## 2. Diagnosis (spec section 4)

### 2.1 Where the light is combined: order and formula

The order below is verified in the code.

**`lib/gbuffers_forward.fsh`, `shadeFragment` (terrain, ice and glass):**
1. **Albedo:** `texel = texture × vColor`. `vColor` is the biome tint × the **vanilla corner AO** (unless `separateAo`).
2. **Light:** `base = texel × lightmap`. The lightmap holds block light and sky light; with `CHROMATIC_LIGHT` the
   block light is ramped.
3. **Face model** (Update 2B): `base *= mix(1, max(shade × hemi + direct × visibility × wrap, SHADE_FLOOR), skyWeight)`.
   - `shade = 1 − 0.34 × FACE_CONTRAST` (0.66);
   - `direct = 0.08 + 0.34 × FACE_CONTRAST` (0.42);
   - `hemi` is 0.70 for faces turned down, 0.85 for sides, 1.0 for tops.
   - This is the only "ambient fill". It is a scalar with no colour, and it multiplies the lightmap.
4. **Micro-detail sheen:** `base *= 1 + sheen`.
5. **Colour responses** (luminance-preserving hue shifts):
   - `ATMOSPHERIC_GRADE` warm/cool (0.10);
   - `ambienceTerrainResponse` (the sun warmth; the shade cool tint `ENV_SHADOW_COOLNESS` 0.60; vibrance; the snow
     shoulder);
   - `shadowColorResponse` (dynamic shadow colours).
6. **Highlights:** leaf back-light, glints (capped at 1.15), the light code for the GI (alpha).

**`final.fsh`:**
1. Fake GI: `colour × (1 + M)`, where M includes the screen-space AO.
2. `+ bloom`.
3. **Tone map:** `finalToneMap`, a 42 % identity / 58 % Reinhard shoulder that clips at 1.07, on display values.
   The sky is not tone-mapped.
4. Sky rebuild.
5. Fog (`ambienceApplyFog`).
6. Veil, rim and shafts.
7. **Adaptive eyes** (a gain that is never below ×1; the bright-scene "punch" S-curve).
8. Golden grade.
9. Green vibrance.
10. Vignette.
11. Dither.

**General:** the pack has no linear-light stage and **no exposure control that can darken**.

### 2.2 Table

| # | Finding (file, function) | Severity | Evidence | Fix in Update 6 |
|---|---|---|---|---|
| 1 | **Black leaf gaps: the vanilla corner AO in `vColor`**, applied to all the light (`shadeFragment`, `texel = rawTexel × vColor`) | High | Inner leaf faces have vertex AO ≈ 0.2 (vanilla: full blocks contribute 0.2 per corner), times the face factor 0.46-0.56, times the lightmap under the canopy: 0.02-0.05 luma. The fake GI's screen-space AO adds only about 3 % on leaves (full block faces count a fifth). Measured: our darkest leaf texels 0.036, VV 0.157. | `LM_VERTEX_AO`: `separateAo`, a softened AO (strength 0.60, curve 0.85; foliage 75 %) applied fully to the ambient light and a third to the direct sun. Model: 0.036 → 0.153. |
| 2 | **No additive or coloured sky fill.** The face model is a colourless scalar on the lightmap; `SHADE_FLOOR` 0.45 never acts at noon (the lowest face is 0.462). | Medium | Faces turned down: 0.462 of the lit top; sides 0.561. | `LM_FILL`: a hemispherical fill in the sky light's colour (ground bounce from below), and `SKY_FILL` (down faces +26 %, sides +11 %). `LM_SHADOWS`: `SHADOW_FLOOR` 0.52 now acts. |
| 3 | **Shadows not cool enough.** The cool terms are luminance-preserving hue shifts of +8-17 % blue; `ATMOSPHERIC_GRADE` cool acts on cast shadows only. | Medium | Ours: shaded snow 227° at 20 % saturation; VV: 224° at 40 %. | `LM_COLOR`: `ENV_COOLNESS` pushes the existing shade and shadow tints further (by biome); the fill carries the same cool hue. |
| 4 | **Hard shadow edges.** `SHADOW_QUALITY` 1 (LOW, MEDIUM) is one binary tap; Q2's taps sit exactly on texel borders with a screen-anchored jitter; Q3 has no centre tap (1-texel shadows vanish). | Medium | `getShadow` | `LM_SOFT_SHADOWS`: bilinear PCF per tap on the cell-snapped receiver (pixel grid kept), 1 or 4 taps on a fixed rotated grid, plus `SHADOW_HARDNESS`. The old kernels are untouched (they are used when the part is off). |
| 5 | **Snow blows out, and the white dots.** Lit snow ≈ 0.99 × 1.08; the snow shoulder takes only 45 % above 0.80; the tone map clips at 1.07. The dots are kind-3 glitter: the detail mask covers every snow texel (thresholds −9σ/−8σ), 9.6 % of the texels are chosen by hash, and each dot adds +0.38, capped at 1.15, so it clips. | High (for snow) | `blkMicroDetail` glints; measured snow 0.77 plus clipped dots | `LM_TONE`: a soft shoulder (never past `WHITES` 0.90) and an exposure baseline. `LM_SNOW`: glints capped at 0.08 and cool. With `TEXTURE_REFLECT` snow has no hash dots at all. |
| 6 | **Pale sky and white haze: the snowy-taiga biome palette.** The snowy horizon target `#CDDAF0` (and taiga `#A8BCD6`) halves the horizon saturation (0.31 → 0.16) and lifts it 12 %. The horizon is the fog colour, and the lower ~15° of the sky is the horizon colour. | High (for the look) | Computed from `AMB_PAL` row 5 and the `bHor*` uniforms. Measured: our sky top `#B4C4F6` against VV `#6084D5`. | **Not changed: it is the sky gradient's biome palette (frozen). Question 1.** Done inside the scope: thinner, cooler haze (`LM_FOG`) and the exposure baseline (it also lowers the sky's brightness). |
| 7 | **The fog greys distant colour.** The distance desaturation goes to near-neutral grey; snowy taiga density is ×1.13. | Medium | `ambienceApplyFog` | `LM_FOG`: desaturation toward the sky's blue, a cooler partial haze, `FOG_DENSITY_MATCH` 0.80. The full fog is still exactly the sky colour (no seam). |
| 8 | **The bright-scene punch** (adaptive eyes) darkens darks by 9-11 % and adds contrast exactly in snowy views. | Low | `adaptApply` punch curve | Halved in the Overworld while `LM_TONE` is on (`final.vsh`). |
| 9 | Low saturation | Low | Final has only a green-only vibrance (+8 % on green-dominant pixels). | `LM_COLOR`: midtone saturation and vibrance, greens and blues first, sky and full fog untouched. |
| 10 | Vignette darkens the snow at the edges by 7 % (MEDIUM) | Info | | Not changed (not in scope). |
| 11 | `GI_FALLOFF_DIST` default `1.0` not in its own list (`1.00`) | Low (my Update 5 bug) | `settings.glsl` | Fixed: default and presets `1.00`. |
| 12 | Bloom: about 2/255 on snow already | Info | `composite.fsh` | **No change needed:** "very subtle" is already true. `BLOOM_STRENGTH` and `BLOOM_THRESHOLD` are unchanged. |

**Generic checks (spec 4.5):**
- Every preset and 41 Lighting Match option combinations compile with glslang, Iris's own parser (glsl-transformer
  2.0.2 + JCPP) and the Mesa driver (compile and link).
- No NaN paths: every `pow` base is clamped positive and every division guarded.
- Inherited settings I noticed (not rewritten):
  - `END_FLASH_SHAFTS` and `FLASH_SHAFT_STRENGTH` do nothing while `FLASH_FOG_SHADOWS` is on.
  - `GOLDEN_FAKE_BIRDS` does nothing while `SKY_PIXEL_FIX` is on.
  - `HAZE_DENSITY`, `HORIZON_BLEND` and the `GOLDEN_TARGET_HAZE` options do nothing while `AMBIENCE_FOG` is on (all
    presets).
  - `PREVIOUS_SUN_LIFT` touches blocks only with `DIRECTIONAL_LIGHTING` off.
  - The comment above `SHADOW_QUALITY` says "MEDIUM: 4 reads", but MEDIUM uses 1.

## 3. Measurements (spec section 10)

### 3.1 Whole frame (display luma, measured)

| | 1 % | 5 % | 25 % | 50 % | 75 % | 95 % | 99 % | crushed < 0.03 | clipped > 0.97 | mean saturation |
|---|---|---|---|---|---|---|---|---|---|---|
| IMAGE 1, VV | 0.124 | 0.190 | 0.284 | 0.497 | 0.566 | 0.653 | 0.681 | 0.00 % | 0.00 % | 44 % |
| IMAGE 2, ours | 0.048 | 0.080 | 0.185 | 0.599 | 0.750 | 0.813 | 0.832 | 0.20 % | 0.06 % | 32 % |

**Hue groups** (HSV saturation):

| | Green pixels | Their saturation | Blue pixels | Their saturation |
|---|---|---|---|---|
| VV | 0.9 % | 0.41 | 93 % | 0.45 |
| Ours | 34 % | 0.43 | 57 % | 0.24 |

### 3.2 Regions

- **Measured:** the VV and "ours now" columns.
- **Model:** the Update 6 column, at the shipped defaults.
- Boxes in the scratch scripts; leaf texels are the 0-5 / 25-75 / 95-100 % percentiles of the leaf pixels, sky and
  snow seen through holes excluded.

| Region | Ours now | **Model, Update 6** | VV | Luma now / new / VV | Tolerance | Met? |
|---|---|---|---|---|---|---|
| Snow top, lit | `#B8C3E7` 226° 49 % | `#A8B6E3` 226° 51 % | `#8B9CD8` 227° 50 % | 0.766 / 0.715 / 0.615 | ±0.05 | no (exposure, see below) |
| Snow in shadow | `#858EAD` 227° 20 % | `#8F9DCB` 227° 37 % | `#5973B8` 224° 40 % | 0.558 / 0.617 / 0.449 | hue ±10°, sat ±10 pts | hue and saturation yes; luma no |
| Leaf base (canopy side) | `#192D20` 141° | `#295038` 143° | `#2A434C` 196° | 0.156 / 0.273 / 0.244 | ±0.04 | yes (0.029) |
| Leaf darkest texels | `#020C04` | `#0C3115` | `#182B36` | 0.036 / 0.153 / 0.156 | ±0.03 | **yes** |
| Leaf lit texels (top) | `#446544` | `#4A784C` | `#3A6064` | 0.359 / 0.420 / 0.346 | ±0.05 | no (+0.07) |
| Trunk (side faces) | `#1F150B` | `#322417` | `#242024` | 0.088 / 0.149 / 0.130 | ±0.03 | yes |
| Ground in tree shadow | `#2D4647` 182° | `#335659` 185° | `#2B5268` 202° | 0.254 / 0.309 / 0.295 | ±0.03 | yes |

**Other measured values:**
- **Sky top / horizon:** VV `#6084D5` / `#7492DE`; ours `#B4C4F6` / `#BCCBF2`.
- **Lake:** VV `#4C70DE`; ours `#9FB7EE`.
- **Distant trees:** VV `#485876` (0.34); ours `#97A2B0` (0.63).
- **Lit / shaded ratios:**

  | | VV | Ours |
  |---|---|---|
  | Snow | 1.37 | 1.37 |
  | Leaves (lit / base) | 1.41 | 2.29 (model: 1.54) |
  | Trunks (both side faces) | about 0.9 | about 0.9 |

**The model and the rounds.**
- **How it works:** it inverts our previous tone map on each region, applies the new light factor and the new curve,
  exposure and saturation, and compares the result with VV.
- **Its assumptions (estimates):** each region's face direction, sun and vanilla AO (dark leaf texels: inner faces
  with AO 0.25; leaf base 0.6; trunk 0.8).
- **Rounds** (luma rms against VV over the 7 regions):

  | Round | Values | rms |
  |---|---|---|
  | 0 | Your starting ranges, mid-point | 0.139 |
  | 1 | Free fit | 0.027 |
  | 2 | Shipped: fit inside your ranges | 0.080 |
  | – | Before the update | 0.098 |

  The free fit needed:
  - exposure −0.50 EV;
  - no additive fill;
  - full shadow strength;
  - `WHITES` 0.88, black lift 0.06.

**What the rounds say:**
- The dark end (leaves, trunks, ground) now matches within tolerance.
- The remaining error is the bright end. Snow and sky need about −0.5 EV, twice your "−0.10 to −0.25" range. I kept
  −0.25 and put −0.35 and −0.50 in the list (question 2).
- Your starting "shadow strength −15 to −30 %" would make snow shadows brighter than VV's, which are as deep as ours
  (only bluer). So I used −8 % (`SHADOW_STRENGTH` 0.92) and put the difference into the cool tint.

### 3.3 The tone curve (display in → out, at the shipped values)

| In | 0.02 | 0.05 | 0.10 | 0.20 | 0.35 | 0.50 | 0.65 | 0.80 | 0.95 | 1.10 | 1.30 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Previous | 0.020 | 0.050 | 0.099 | 0.197 | 0.341 | 0.483 | 0.623 | 0.760 | 0.895 | 1.027 (clips) | 1.199 (clips) |
| New curve | 0.065 | 0.094 | 0.140 | 0.229 | 0.360 | 0.500 | 0.641 | 0.750 | 0.819 | 0.858 | 0.883 |
| New + exposure −0.25 EV | 0.060 | 0.087 | 0.130 | 0.212 | 0.332 | 0.462 | 0.593 | 0.693 | 0.757 | 0.793 | 0.816 |

## 4. Part B, the changes in your priority order

Each part has a switch (compiled out when off) and its sliders. "Replaces" means the earlier parameter is used with the
new value while the part is on (no second term).

### 4.1 Ambient and sky fill (`LM_FILL`)
- **What:**
  - `AMBIENT_FILL` (0.05) adds a hemispherical fill: the sky light's colour from above, a ground bounce (sky and sun
    hue mixed, ×0.75) from below.
  - It follows the lightmap's sky row, so caves, interiors and covered areas stay dark; the night gets a third of it.
  - The softened AO multiplies it.
  - `SKY_FILL` (0.20) raises the face model's sky dome for faces turned down and sideways: ground factor
    0.70 → 0.88.
- **Matched or approximated:** the hemisphere is an approximation of VV's ambient and sky light; the colour comes from
  your sky palette (`vAmbSkyLight`), no new hard-coded colour.
- **Cost:** 1 lightmap read and about 15 operations per block fragment (~0.02 ms on a 1050 Ti).
- **Cannot do:** it is not real sky visibility; a face under a roof that still has sky light 15 gets it.

### 4.2 Shadow intensity (`LM_SHADOWS`)
- **What:**
  - `SHADOW_STRENGTH` 0.92: a cast shadow keeps 8 % of the sun.
  - `SHADOW_CONTRAST` 0.90: multiplies `FACE_CONTRAST` (shade 0.66 → 0.69, lit tops unchanged).
  - `SHADOW_FLOOR` 0.52: replaces `SHADE_FLOOR` and now acts on faces turned down.
  - Mobs, items and the hand take the same cast-shadow strength.
- **Why these values:** see 3.2 (VV's snow shadows are as deep as ours).
- **Cost:** constants, about 0.

### 4.3 Tone mapping and dynamic range (`LM_TONE`, `TONE_CURVE` 2)
- **What:** a curve on luminance, with the hue kept:
  - identity up to the knee (0.60 × `HIGHLIGHTS` 0.80 = 0.48);
  - then a tanh shoulder to `WHITES` 0.90 (slope 1 at the knee, never clipping);
  - blended by `TONE_SHOULDER_STRENGTH` (reused, 1.00);
  - plus `TONE_BLACK_LIFT` 0.045 in the cool ambient's hue, gone by mid grey. No crushing toe.
- **Where:** the Overworld above water only. The Nether, the End and underwater keep the previous curve; the sky
  stays display-referred as before. `TONE_CURVE` 1 = the previous curve for comparison.
- **Cost:** about 20 operations per pixel (~0.01 ms).

### 4.4 AO (`LM_VERTEX_AO`)
- **What:**
  - With Iris's `separateAo` the vertex alpha is the vanilla AO.
  - It is softened (`VERTEX_AO_STRENGTH` 0.60, `AO_POWER` 0.85; foliage 75 % of the strength).
  - It is applied in full to the ambient, sky and block light, and a third of it to the direct sun.
  - The fake GI's AO (`AO_STRENGTH`, `AO_RADIUS`) is reused unchanged: it is already small on blocks.
- **Water stays identical:** the AO is multiplied back into its colour.
- **The shadow map stays identical:** `shadow.vsh` drops the alpha (section 6).
- **Cost:** about 10 operations (~0.01 ms).
- **Unverified:** that Iris 1.11.7 with Sodium (and Vitrail) honour `separateAo` for terrain (question 4).
  - If one does not, the vertex alpha stays 1, the AO stays in the colour as before, and nothing breaks: only the
    softening is lost.

### 4.5 Shadow softness (`LM_SOFT_SHADOWS`)
- **What:**
  - Each tap is a bilinear PCF: 4 `texelFetch` compares of the nearest-filtered map, weighted by the receiver's
    position between texel centres.
  - The receiver is still snapped to its 1/16 world cell (`PIXEL_SHADOWS`), so the result is one value per cell: the
    pixel-grid look stays, and edges step through grey levels.
  - `SHADOW_SOFTNESS` 1 = one tap (4 reads); 2 and 3 = 4 taps on a fixed rotated grid at 0.75 and 1.25 texels
    (16 reads).
  - `SHADOW_HARDNESS` 0.35 sharpens the result back toward the hard edge (0 = softest, 1 = hard).
  - No noise, no frame input: stable when the sun or the camera moves.
- **Not touched:** the shadow map, its resolution, distance, distortion, bias and the old `SHADOW_QUALITY` kernels.
- **Cost:** about +3 reads per sun-facing fragment at 1, +15 at 2 and 3 (section 8).
- **Cannot do:** contact-hardening penumbrae.

### 4.6 Exposure (`EXPOSURE_BASE_EV` −0.25)
- **What:** applied in the adaptive eyes' stage, just before their gain, as a display factor `2^(EV / 2.2)` (the eyes'
  own convention).
  - On everything the eye sees, the sky included, in the Overworld above water.
  - At normal daylight the eyes' gain stays 1, so this is the new reference. Their behaviour elsewhere is unchanged.
- **Also:** the bright-scene punch is halved in the Overworld (its S-curve crushed the darks in snowy views).

### 4.7 Atmospheric and fog tint (`LM_FOG`)
- **What:**
  - `FOG_DENSITY_MATCH` 0.80 × `FOG_DENSITY` (reused).
  - `FOG_COOL_TINT` 0.50 × the biome share:
    - the distance desaturation leans to the sky's blue instead of grey;
    - the partial haze is a little cooler.
  - The full fog is still exactly the sky colour (no seam at the horizon).
- **Changed:** only fog tint and density (`lib/ambience.glsl`, `ambienceFog` and `ambienceApplyFog`). The sky gradient
  code is untouched.

### 4.8 Saturation and vibrance (`LM_COLOR`)
- **What:**
  - `GLOBAL_SATURATION` 1.06 and `VIBRANCE` 0.15, midtone-weighted:
    - nothing near black, on near-white (snow, highlights), on the sky or in the full fog;
    - greens, blues and cyans in full, warm hues 60 %;
    - never past the brightest channel (no neon).
  - They replace the green vibrance while on.
- **Cool environment (`ENV_COOLNESS` 0.70):**
  - It pushes the sky-light hue further the way it already leans, for the fill, the shade tint
    (`ENV_SHADOW_COOLNESS`'s colour) and the shadow colours.
  - By biome: full in snowy, taiga and peaks (`ENV_COOL_COLD` 1.00); 35 % in the other biomes (`ENV_COOL_NEUTRAL`);
    none in deserts, badlands, savannas, jungles and swamps; none in the Nether and the End.

### 4.9 Highlights and snow (`LM_SNOW`)
- **What:**
  - Snow and powder snow glints are capped at `SNOW_GLINT_CAP` 0.08 and cooled (0.90, 0.95, 1.00); the other
    glitter blocks keep theirs.
  - With `TEXTURE_REFLECT` on, snow has no hash dots at all (part A).

### 4.10 Bloom
- **No change.** Already about 2/255 on full-white snow; `BLOOM_STRENGTH` and `BLOOM_THRESHOLD` are reused as they are.

### 4.11 Light falloff
- Covered by the fill, the floor and the softer edges. No separate term.

## 5. Part A: texture-pattern reflection (`TEXTURE_REFLECT`)

**Your request:**
- The mask per block.
- Ice: the transparent part without it, the lighter part lit in its own colour with a maximum brightness.
- Leaves as in your night screenshot: the lighter texels lit, also by the fake GI, the darker ones without reflection.
- The same for obsidian, sand and other blocks.
- Grass, stone and cobblestone almost imperceptible.
- Ores unchanged.

**What changed:**
- **The random glint dots are gone on every kind except the metals and ores.** Before, the detail mask of ice and
  snow covered every texel (−9σ/−8σ), and 7-10 % of the texels were picked by a hash, hence isolated dots.
- **Instead, the lighter part of each sprite catches the light:**
  - Texels above the texture's own mean, with per-kind thresholds (`BLK_PATTERN` in `lib/block_lighting.glsl`), get
    a sheen that multiplies their lit colour, so it is in their own colour and the light's.
  - The light: the sun (or the moon at night, or the End flash), with the face's direction, its shadow and the sky
    light; plus the block light (`TEXTURE_REFLECT_BLOCKLIGHT` 0.60).
  - The fake GI multiplies the whole lit colour afterwards, so lit texels scale with it too.
- **Peak (`TEXTURE_REFLECT_MAX` 0.80):**
  - A reflecting texel never goes past it, and one cap covers this and the Update 5 near-light detail together.
  - Sunlit snow is already above it, so it gets none.
- **Ice and glass:**
  - The clearer texels (more transparent than the sprite's mean alpha, read from its smallest mip) are left out of
    the reflection and of the faint sky reflection.
  - With fewer than 4 mip levels nothing is left out, and only the lighter-texel rule applies.
- **Strength per block (`TEXTURE_REFLECT_STRENGTH` 0.50):**

  | Share | Blocks |
  |---|---|
  | Full | sand, red sand, snow, ice (all three), obsidian (and crying obsidian), amethyst, glass, leaves |
  | Half | the other mapped blocks: gravel, calcite, deepslate, soul sand, farmland, clay and mud, moss, dirt and podzol, logs, planks, mushroom blocks, blackstone, basalt, quartz, prismarine, vines, carpets |
  | `TEXTURE_REFLECT_SOFT` 0.05 (almost imperceptible) | grass block, grass plants (short and tall grass, ferns), stone, cobblestone, mossy cobblestone, andesite |
  | Unchanged (previous glints and sheen) | copper, gold, iron, gem and netherite blocks, and the ores |

- **Snow:** its texture has almost no lighter texels (σ 0.02), so snow gets no reflection and no dots. VV's snow shows
  no glints either.
- **Cost:** cheaper than the glints (no hash and no micro-normal); one extra texture read on ice and glass only.

## 6. Files

All files in the zip are complete (no diffs).

- **New:**
  - `shaders/lib/lighting_match.glsl`
  - this report
- **Changed:**
  - `lib/settings.glsl` (options, cleanup rules)
  - `lib/block_lighting.glsl` (part A table and sheen; the face constants and floor; snow glint cap)
  - `lib/gbuffers_forward.fsh` (AO split, fill, shadow strength, cool tint, soft filter, debug)
  - `final.fsh` (curve, exposure, saturation, fog hooks, debug)
  - `final.vsh` (punch)
  - `lib/ambience.glsl` (fog density and tint)
  - `shadow.vsh`
  - `shaders.properties` (`separateAo`, screens, sliders, presets)
  - `lang/en_us.lang`
  - `README.md`
- **Frozen-system files I touched, and why:**
  - **`shadow.vsh` (shadow pass)**, 5 lines.
    - Why: with `separateAo` the vertex alpha becomes the AO, which the shadow alpha test would read. Dropping it
      keeps the shadow map exactly as before.
    - Unavoidable once `separateAo` is used; compiled only with `LM_VERTEX_AO`.
  - **`final.vsh`, adaptive eyes**, 1 value: the punch halved under `LM_TONE` in the Overworld. Your scope lists the
    eyes' exposure; the punch is part of that stage.
  - **`lib/ambience.glsl`, the fog functions:** density and tint only (in scope). The sky gradient, palettes and
    clouds are untouched.
- **Unchanged:** every other file, including water, sky, clouds, stars, sun and moon, the End and Nether systems,
  entities' plastic gloss and the GI passes.

## 7. Settings and presets

**New screen "Lighting Match"** (first in the menu), in two columns:
- `LIGHTING_MATCH`, `LM_DEBUG`, `LM_DEBUG_MODE`
- `LM_FILL`: `AMBIENT_FILL`, `SKY_FILL`
- `LM_SHADOWS`: `SHADOW_STRENGTH`, `SHADOW_CONTRAST`, `SHADOW_FLOOR`
- `LM_SOFT_SHADOWS`: `SHADOW_SOFTNESS`, `SHADOW_HARDNESS`
- `LM_VERTEX_AO`: `VERTEX_AO_STRENGTH`, `AO_POWER`
- `LM_TONE`: `TONE_CURVE`, `EXPOSURE_BASE_EV`, `HIGHLIGHTS`, `WHITES`, `TONE_BLACK_LIFT`
- `LM_COLOR`: `ENV_COOLNESS`, `ENV_COOL_COLD`, `ENV_COOL_NEUTRAL`, `GLOBAL_SATURATION`, `VIBRANCE`
- `LM_FOG`: `FOG_COOL_TINT`, `FOG_DENSITY_MATCH`
- `LM_SNOW`: `SNOW_GLINT_CAP`

The part A options are in the Block detail screen.

**Reused (unchanged defaults, still in their own screens):**
- `AO_STRENGTH` and `AO_RADIUS` (Fake GI screen)
- `TONE_SHOULDER_STRENGTH` (Colour screen; also blends the new curve)
- `FOG_DENSITY` (Fog screen; `FOG_DENSITY_MATCH` scales it)
- `BLOOM_STRENGTH` and `BLOOM_THRESHOLD` (Glow screen)

I did not list them twice: an option in two screens risks Iris ignoring one.

**Not reused:**
- **`AO_STRENGTH` / `AO_RADIUS` for the vanilla AO:** they already mean the fake GI's AO, so the vanilla AO got its
  own `VERTEX_AO_STRENGTH` and `AO_POWER`.
- **Fog density:** `FOG_DENSITY_MATCH` is a share rather than a new `FOG_DENSITY` value, so `LIGHTING_MATCH` off
  gives back exactly your old fog.

**Renamed or removed:** none.

**Presets** (every option of this update is defined in all five; `!` = off):

| | ULTRA_LOW | LOW | MEDIUM | HIGH | CINEMATIC |
|---|---|---|---|---|---|
| `LIGHTING_MATCH` | on | on | on | on | on |
| Fill, shadows, tone and exposure | on | on | on | on | on |
| Soft shadows (`SHADOW_SOFTNESS`) | off (the cheap 1-tap filter) | on (1) | on (1) | on (2) | on (3) |
| Vertex AO, colour, fog, snow | off | on | on | on | on |
| `TEXTURE_REFLECT` | defined (no effect: no micro-detail on ULTRA_LOW) | on | on | on | on |

All sliders are at the defaults above in every preset.

**Debug views** (`LM_DEBUG` + `LM_DEBUG_MODE`):

| Mode | View | What a correct look is |
|---|---|---|
| 1 | Albedo only | Identical with the update on and off. With `LM_VERTEX_AO` off the vanilla AO is part of the vertex colour, so it shows there. |
| 2 | Direct light | |
| 3 | Fill alone (×4) | |
| 4 | Shadow factor | |
| 5 | Final shadow term | |
| 6 | AO | Left: vertex AO; right: screen-space AO |
| 7 | Cool shade tint | |
| 8 | Tone curve | Left: old; right: new |
| 9 | Luminance false colour | |
| 10 | Clipping | Red > 0.97, blue < 0.03 |
| 11 | Saturation | |
| 12 | Fog contribution | |
| 13 | Split | Left: without the Lighting Match parts that can switch per pixel (fill, AO change, cool tint, curve, exposure, colour, fog); the face constants and the shadow strength are compile-time and stay on both halves |

## 8. CHANGELOG and performance

### CHANGELOG (Update 6)
- **Added: texture-pattern reflection.** Each block's lighter texels catch the light in their own colour; darker
  texels none; no random dots except on ores and metals.
  - Ice and glass: the clearer texels are left out.
  - Grass, stone and cobblestone: almost nothing.
  - One peak cap over the reflection and the near-light detail.
- **Added: Lighting Match.**
  - Coloured hemispherical sky fill and a stronger sky dome on sides and undersides.
  - A real shadow floor; cast shadows keep 8 % of the sun; slightly lower face contrast.
  - Softer vanilla AO: no black leaf gaps.
  - Soft shadow edges on the pixel grid.
  - The soft game tone curve (no clipping, lifted blacks) and an exposure baseline of −0.25 EV.
  - The bright-scene punch halved.
  - A cool environment by biome; midtone saturation and vibrance (replacing the green vibrance).
  - A cooler, thinner haze.
  - Snow glints capped.
- **Fixed:** `GI_FALLOFF_DIST`'s default was not in its own value list.
- **Visible differences, with everything on:**
  - Darker, non-clipping snow and highlights.
  - Readable leaf interiors and trunks.
  - Bluer shade.
  - Less white distant haze.
  - Slightly richer midtones.
  - Softer shadow edges.
  - A slightly darker sky (exposure only).
- **Unchanged with both switches off:** everything, checked program by program.

### Performance (estimated, 1080p, not measured)

| Item | GTX 1050 Ti | RTX 3050 |
|---|---|---|
| Fill + AO split + floors | ~0.03 ms | ~0.01 ms |
| Soft shadows, softness 1 (+3 reads per sun-facing fragment) | ~0.08-0.12 ms | ~0.03-0.05 ms |
| Soft shadows, softness 2 or 3 (+15 reads) | ~0.35-0.5 ms | ~0.12-0.2 ms |
| Tone, exposure, saturation, fog tint | ~0.02 ms | ~0.01 ms |
| Texture-pattern reflection | about 0 (cheaper than the glints it replaces) | – |
| **MEDIUM total** | **~0.13-0.17 ms** | **~0.05-0.07 ms** |

- MEDIUM on the 1050 Ti is a little above your +0.10 ms. The soft filter is most of it.
- Nothing in the AO could be made cheaper: the vanilla AO is free and the GI's AO is part of its gather.
- If your measurement shows it, LOW and MEDIUM can drop `LM_SOFT_SHADOWS` (−0.08-0.12 ms).
- ULTRA_LOW adds about 0.03 ms.

## 9. Test plan

**Independent review.** Three reviewers (gbuffers; final and fog; configuration) read the whole diff, and each
finding was checked against the code. Fixed:
- **A compile error with `MOON_RAYS` off.** The biome cold weight came from a function that only exists with the moon
  rays. Every preset turns them on, but switching them off in the menu would have disabled the pack. It has its own
  function now.
- **The soft shadow filter acted on the End flash shadows, on the water surface and under water.** It is now the
  Overworld sun on non-fluid surfaces only, camera above water. The End flash and the water keep the 5.1 filter.
- **The softened AO now acts only in the Overworld above water, never on water.** Elsewhere the AO goes back into the
  colour exactly as before, so the End flash light, the Nether and underwater are unchanged.
- **The fake GI's light code includes the corner AO again,** so the GI's bounce and emitter light stay AO-shaded as
  before.
- **Water tints taken from the vertex colour (`SHALLOW_TINT` or `NEAR_WATER_TINT` 0) keep the AO.**
- **Saturation and vibrance no longer touch water pixels.**
- **With `ATMOS_TONE_MAP` off (ULTRA_LOW), the places Lighting Match does not act** (underwater, other dimensions)
  keep no tone curve, as before. The sky and clouds always keep their previous treatment.
- **The cool push never warms a sunset light or haze:** only light that already leans blue is cooled.
- **Labels** that over-promised were corrected (master switch, ambient fill, AO strength).
- **`atmosEnd` guard.** The soft filter also compiles with every dimension ambience off.

Known and left as is (documented):
- **Exposure scales the whole frame, sky included,** like the adaptive eyes do (question 1).
- **The texture-pattern reflection also applies in the End and the Nether**, because you asked for it per block. On
  End obsidian the flash now lights the speckles as a pattern instead of random dots; tell me if the End should keep
  the old glints.
- **Under clouds or rain, a mob's soft shadow edge** can be a little darker than its inside: the entity flag reads the
  centre texel only.
- **`SHADOW_QUALITY` does nothing while `LM_SOFT_SHADOWS` is on** (the menu says so).
- **The fill and the face sliders act on blocks only, and need Directional lighting.**

**What I ran:**
- **Compile:** all 5 presets, plus 41 Lighting Match combinations (every debug view, each part off, both curves,
  softness 2 and 3 with `PIXEL_SHADOWS` off, without directional lighting, micro-detail, ambience colours, the tone
  map, biomes, fog, eyes, GI, moon rays, every dimension ambience; water tints 0; a forced biome): glslang, Iris's
  glsl-transformer parser and Mesa compile and link. **0 failures.**
- **Every boolean option of the pack toggled one at a time** on top of MEDIUM (120 builds, glslang): **0 failures.**
- **Identity:** `LIGHTING_MATCH` and `TEXTURE_REFLECT` off give the 5.1 code in all presets.
- **Region model:** section 3.

**What you should run, and what to expect:**
1. **The IMAGE 1 scene** (same place, F1).
   - Expected:
     - no black leaf gaps;
     - trunks a readable dark brown;
     - bluer shaded snow;
     - snow tops below white, without dots;
     - softer shadow edges with visible grey steps;
     - distant trees bluer and less washed.
   - The sky stays paler than VV's (question 1 in section 10).
2. **Biomes at noon:** plains, forest, birch, dark forest, taiga, jungle, swamp, desert, badlands, savanna,
   mountains, ocean.
   - The cool bias is strongest in snowy biomes, mild in the others, absent in desert, badlands, savanna, jungle and
     swamp.
3. **Times of day:** sunrise, golden hour, sunset, dusk, night.
   - The fill follows the lightmap (a third at night); the golden-hour grade is unchanged.
4. **Rain and thunder; caves, interiors, under a canopy; a village; water edges.**
   - Caves and interiors stay dark (the fill scales with sky light).
   - Water looks exactly as before.
   - The Nether, the End and underwater are unchanged (the gates are Overworld-only).
5. **Artefacts:**
   - Banding in lifted shadows (debug 9 and 10; the existing triangular dither runs after everything).
   - Shadow shimmer while moving: there should be none, since the filter is fixed per world cell.
   - Leaf gaps (debug 6).
   - Clipped snow (debug 10: no red on snow).
6. **Regression:** `LIGHTING_MATCH` off = 5.1 (with `TEXTURE_REFLECT` off too).
7. **Performance:** F3 frame time, standing still, with `LM_SOFT_SHADOWS` on and off and with `LIGHTING_MATCH` on and
   off, in a dense forest and on a snow field.

**Screenshots I would like** (only with your permission; only the Minecraft window):
- The IMAGE 1 scene, same coordinates, camera, time and settings:
  - with `LIGHTING_MATCH` off and on;
  - with `LM_DEBUG_MODE` 6, 9 and 10.
- The same with `EXPOSURE_BASE_EV` −0.35 and −0.50.
- A desert and a jungle at noon.
- A cave entrance.
- The frame times.

## 10. Questions

1. **The pale snowy sky and haze come from the biome palette.**
   - The snowy target `#CDDAF0` and the taiga target `#A8BCD6` are near-white and halve the horizon's saturation.
   - Changing them means touching the sky gradient's biome palette, which you froze.
   - May I make the snowy and taiga horizon and mid targets bluer? About VV's `#7492DE`; it would change the sky and
     the fog colour in those biomes only.
2. **Exposure beyond your range.** The model fits VV best at −0.50 EV; you said −0.10 to −0.25. Keep −0.25, or go to
   −0.35 or −0.50?
3. **Shadow strength.** Your starting range was −15 to −30 %, but VV's snow shadows are as deep as ours (only bluer).
   I used −8 %. Keep it?
4. **The Iris log** after loading, and a check that the corner AO softens (debug 6). This confirms Iris and Sodium
   honour `separateAo` (if not, nothing breaks; only that part does nothing).
5. **Ores and metal blocks.** You said ores will get a different reflection later. I also left the metal and gem
   blocks (copper, gold, iron, diamond, emerald, netherite) unchanged, assuming they are part of that. Correct?
