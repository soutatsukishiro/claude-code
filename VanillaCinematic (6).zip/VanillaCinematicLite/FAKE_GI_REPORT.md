# Update 5: Fake Global Illumination + Chromatic Light Falloff

Your spec calls it "UPDATE 4". The pack already has an Update 4 (the End and Vibrant Visuals work, including 4.1 and
4.2), so this one is called **Update 5** in the files, menus and changelog. Nothing else was renamed.

- **Backup** of every file I modified: `backup/2026-10-07_before_fake_gi/` (the Update 4.2 versions; copy them back
  to undo).
- **Off = Update 4.2.** With `FAKE_GI` and `CHROMATIC_LIGHT` off, every program preprocesses to exactly the Update 4.2
  code. Checked program by program in all five presets.

---

## 0. Capability check, consent, and what I could not do

- **I have no screen capture and no computer-use tools in this session.** This is a cloud container with no game,
  no GPU and no display. I never ran Minecraft, so every in-game claim below is reasoned from the code, measured
  on your two screenshots, or measured on a numerical model.
- That model is a voxel ray caster plus a line-by-line NumPy port of the new shader code. I wrote it for this update.
- **Consent:** I ask your permission before any capture. If you give it, you would take the screenshots yourself:
  only the Minecraft window, nothing else kept. The list is in section 9.
- **Performance numbers are estimates, not measurements.** They come from a cost model (operation counts from the
  shader code, throughput from public GPU specs, pessimistic efficiency). Please measure (section 7).

## 1. The FPS budget, stated back

| Baseline | Frame time | 2 FPS lost | 3 FPS lost |
|---|---|---|---|
| 120 FPS | 8.33 ms | +0.14 ms | +0.21 ms |
| 90 FPS | 11.11 ms | +0.25 ms | +0.38 ms |
| 60 FPS | 16.67 ms | +0.57 ms | +0.88 ms |

Your budgets at 1080p:

| Preset | Budget | Reference GPU |
|---|---|---|
| LOW | ≤ 0.18 ms | GTX 1050 Ti |
| MEDIUM | ≤ 0.30 ms | RTX 3050 |
| HIGH | ≤ 0.45 ms | – |
| ULTRA LOW | off, or ≤ 0.05 ms | – |
| CINEMATIC | no limit (cost reported) | – |

## 2. The two screenshots and your current state

All values are measured on the PNGs: 8-bit display values, HSL as hue°, saturation %, lightness %.

### Image 1 (`9.png`, Vibrant Visuals)

- **Sky:** almost black violet, `#080710`, luma 7.9, hue 247°. Your `#0A0818` was close.
- **Cage bars:** warm grey-beige, not gold.
  - Brightest 1 %: `#999081` (39°, 10 %, 55 %).
  - Brightest 10 %: `#7E7666`.
  - Your `#C0AE80` is brighter and more saturated than the image.
  - Correction: the lower half of the cage is brighter than the upper half (luma 127 against 113). That is light
    from below, the fire under the crystal, not "brighter upper edges".
- **Orange spark at the cage's base:** `#C94015` (14°, 81 %). It is the fire; the crystal itself is not visible
  from this angle.
- **Obsidian front face:** a hue that changes downward. Full table in section 3.
- **Correction on the left faces:** the leftmost face is not darker. It is a uniform, neutral grey `#0D0D0D`
  (luma 13), lighter than both the front face's dark texels and the sky, with no speckles. Between it and the front
  face is a dark strip (luma 7) and a thin lighter edge strip (luma 10 to 12). So Vibrant Visuals lights that face
  with a flat, neutral, directional ambient. Your obsidian faces get no such thing (section 4, question 1).
- **Frame coverage:** only about 10.8 blocks of pillar below the cage are in frame. From the texture's own period
  (one block = one 16-texel repeat, 33 px under the cage and 64 px at the bottom), the bottom of the image is about
  10.8 blocks down. Your 16- and 24-block rows cannot be measured on this image.

### Image 2 (`10.png`, your shader)

- **A different pillar:** no cage, a wider rounded top, the fire and crystal out of view on top.
- **Sky:** `#0F0A17`, luma 11.7 (1.5 × Vibrant Visuals' here).
- **Speckles:**
  - just under the top, `#27242A` (273°, 8 %, 15 %): the same brightness as Vibrant Visuals by the cage;
  - 6 blocks down, `#19171C`;
  - 10 to 13 blocks down, `#131015`.
- **Dark texels:** `#040207`, near black (Vibrant Visuals' are `#0D080D`).
- **One hue (270°) all the way down.** It is obsidian's own violet under nearly neutral light: no warm tint, no hue
  change, and the texture stays contrasted to the bottom.
- **Build:** no ambient haze, so it was taken before Update 4.2.

### What in the code explains image 2

| # | Cause | Where |
|---|---|---|
| 1 | No indirect or bounce light existed: the light was the vanilla lightmap, the face light and the End flash. | `lib/gbuffers_forward.fsh`, `shadeFragment` |
| 2 | The End crystal is an entity; Java entities emit no block light. `EMISSIVE_GLOW` only draws a screen halo around it. | game rule; `composite.fsh`, `emissiveGlow` |
| 3 | The only real light is the fire on top (level 15), falling one level per block step. On a wide pillar's sides that is about 9 levels minus the depth, and vanilla's curve makes it weak. | vanilla lightmap |
| 4 | `END_AMBIENT_TINT` fades out where block light is high, so the End ambient gets brighter and untinted next to a light. The fire's warm light is diluted into violet-grey: one hue, slow fall. | `lib/gbuffers_forward.fsh`, the `END_AMBIENCE` line |
| 5 | Obsidian's micro-detail (Update 2B, material 65) reacts to the sun, to the flash (0 between flashes) and to torches only through `TORCH_GLINT` 0.05. Its speckles never answer the fire. | `lib/block_lighting.glsl`, `blkMicroDetail` |
| 6 | Without 4.2's ambient haze, the far part keeps its texture contrast; Vibrant Visuals' far field is flat. | `final.fsh` (fixed in 4.2) |
| – | Exposure (adaptive eyes) is not the cause: the sky is dark too, and the eyes only adapt to the light at the camera. | – |

## 3. Addendum A and B: the measured table, and your three-layer reading

### Measurement method

- Pixels: the front face, 90 columns, ±0.3 block bands at each depth below the cage. Depth comes from the texture
  period.
- Colours: the brightest 5 % of each band (the speckles), and the linear-light excess of those speckles over the far
  field (the emitter's light alone).

| Depth below the cage | Speckles (top 5 %) | Hue / sat / light | Excess light colour (linear, R = 1) | Excess brightness |
|---|---|---|---|---|
| 0.5 | `#282228` | 304° / 8 % / 14.5 % | 1 : 0.67 : 0.94 | 1.00 |
| 1 | `#282127` | 308° / 10 % / 14.2 % | 1 : 0.60 : 0.91 | 0.93 |
| 3 | `#1D181C` | 308° / 9 % / 10.5 % | 1 : 0.61 : 0.86 | 0.50 |
| 6 | `#110E10` | 324° / 9 % / 6.2 % | 1 : 0.55 : 0.55 | 0.09 |
| 10 | `#09090B` | 239° / 10 % / 3.9 % | (none) | 0.00 |
| 16, 24 | out of frame | – | – | – |

Intermediate depths:

| Depth | Speckles | Hue / sat / light | Excess brightness |
|---|---|---|---|
| 2 | `#211C21` | 302° / 9 % / 11.9 % | 0.61 |
| 4 | `#1D171B` | 316° / 11 % / 10.1 % | 0.40 |
| 5 | `#141115` | 298° / 9 % / 7.4 % | 0.19 |
| 7 | `#0B0A0B` | 313° / 4 % / 4.1 % | 0.01 |
| 8 | `#09090B` | 238° / 10 % / 3.9 % | 0.00 |

### Your estimates against the measurement

| Zone | Your estimate | Measured |
|---|---|---|
| Near | `#7A3AA8` | `#282228`, 304° |
| Middle | `#5A2A3A` | `#1D171B`, 316–324° |
| Far | `#1C1A3A` | `#09090B`, 239° |

- The **hue path is right**: magenta-purple near the cage, redder in the middle (up to 324° at 6 blocks), blue-violet
  in the far field.
- Everything is about **3 to 4 × darker and 5 × less saturated** than your estimates (saturation 8 to 12 %, never
  50 %). Use the measured colours.

### What the excess light shows

- **Its colour shifts with distance.** Pink-white near the cage (B/R 0.94) turns orange-red toward its end (B/R 0.55,
  G/R 0.55). The obsidian's speckles are lavender, so a pink light makes them magenta and an orange-red light makes
  them red-magenta.
- **It has a hard reach.** Its brightness follows ((level − 4) / 7.5)^1.5, where level ≈ 11.5 − depth is Minecraft's
  block light from the fire. It is gone at about 7.5 blocks (level 4), where vanilla's own light curve still gives a
  sixth of it.
- **It is not specular.** Every texel's excess has the same hue, and the face that does not see the cage (the grey
  left face) has none.

### Verdict on your three-layer interpretation

- **Confirmed in shape:** a near light, a warmer light that lasts longer, then a static blue-violet field.
- **What the screenshot cannot tell apart:** whether the red middle is a second light with a larger radius (the fire,
  your reading) or one light whose colour drifts as it fades (per-channel falloff). Both fit the table within the
  8-bit noise at these levels (values 5 to 30 out of 255), so I implemented both, as you asked.
- **Could not be verified:**
  - how much of the near pink is the crystal's own light;
  - whether Vibrant Visuals' tone curve adds a hue shift in the dark end;
  - absolute brightness: your Vibrant Visuals screenshots have different exposures (image 7's sky is 2.3 × image 9's).

## 4. Code review and diagnosis (before this update)

| File / function | Severity | Finding | Fix in Update 5 |
|---|---|---|---|
| Whole pipeline | High (for GI) | Forward renderer: no normal buffer and no albedo buffer. `colortex0` holds the lit colour only. | Terrain writes a 16-bit "light code" into `colortex0`'s alpha (unused until now). Normals come from depth plus an exact block-face test. |
| `lib/gbuffers_forward.fsh`, End ambient line | Medium | `END_AMBIENT_TINT` fades out where block light is high, so the End ambient brightens near light sources and lights look violet-grey (image 2). | With `CHROMATIC_LIGHT`, the End ambient on blocks is a static layer (the same everywhere) and the block light is the ramp's alone. Off = as before. |
| `final.fsh`, order | Info | The tone map runs before the fog (`finalToneMap`, then sky, fog, shafts, exposure, grade). | The GI combine sits before both, and before the bloom add. |
| `final.fsh`, output | Low | The screen's alpha was `scene.a`. | With `FAKE_GI`, terrain gets 1.0 back (the code never reaches the screen). |
| `block.properties` class 9 | Low | Missing light sources: copper torches, lanterns and bulbs; lit redstone torches, furnaces, smokers and blast furnaces; candles and candle cakes; crying obsidian; amethyst clusters; glow berries on the hanging vine. | Added under `#ifdef FAKE_GI` (see section 6). |
| Lava / `EMISSIVE_THRESHOLD` 0.58 | Low | Much of the lava texture is under the threshold, so only its bright texels glow and emit. | Not changed (glow design). Lava still bounces through its lit colour. Tip in the README. |
| AO | Info | Vanilla vertex AO is in `vColor` (`texel = rawTexel * vColor`); there was no SSAO. | The new AO counts full block faces at 20 %, so block-to-block corners are not darkened twice. |
| `lib/gbuffers.vsh` (terrain) | Medium (future) | The terrain vertex shader now writes 64 components, the OpenGL and Vulkan minimum every driver must support (desktop GPUs allow 128). | Any future per-vertex output for terrain must replace one. |
| `final.fsh`, water SSR | Low, not fixed | The screen-space water reflection reads `colortex0` before the GI, so reflections of GI-lit walls lack the GI. | Water is frozen; noted only. |
| `shaders.properties`, inherited options | Info, not rewritten | (1) `END_FLASH_SHAFTS` and `FLASH_SHAFT_STRENGTH` do nothing while `FLASH_FOG_SHADOWS` is on (LOW and up). (2) `GOLDEN_FAKE_BIRDS` does nothing while `SKY_PIXEL_FIX` is on. (3) `PREVIOUS_SUN_LIFT` touches blocks only with `DIRECTIONAL_LIGHTING` off. | – |

### Uniforms and buffers used, all verified in your code or the Iris and Vitrail documentation

- **Uniforms:** `gbufferProjection(Inverse)`, `gbufferModelView(Inverse)`, `cameraPositionFract`, `isEyeInWater`,
  `viewWidth`, `viewHeight`, and the pack's own `atmosOverworld`, `atmosNether`, `atmosEnd`.
- **Depth:** `depthtex1` is the depth before translucents. The hand's depth is squeezed to an eighth
  (`MC_HAND_DEPTH`, the classic "depth < 0.56" test).

### Not verifiable without the game

- **Blending on terrain:** that Iris and Vitrail draw solid and cutout terrain without blending, so the alpha code
  survives. Iris's default and Vitrail's documentation say so.
- **Lightmap layout:** the 26.3 lightmap gives the light without block light in its row 0 (u = 1/32) at the same sky
  level.
- **Hex options:** that Iris accepts hex values (`0xFFC0C4`) in option lists. Vitrail's documentation does; Iris
  treats unknown tokens as string options.
- **The real frame time.**

## 5. Design note

### Pipeline and where each term lives

1. **gbuffers (terrain):** direct light and shadows as before, plus:
   - the chromatic ramp (per vertex) and the static ambient;
   - the near detail;
   - the light code in the alpha.
2. **composite (quarter resolution), second output `colortex4`: the gather.**
   - Per low-resolution pixel: 5 depth reads for the normal, then `GI_SAMPLES` taps.
   - Each tap reads depth, lit colour and code, depth-before-translucents, and the glow mip.
   - It produces the indirect light, colour bleeding, AO, emitter light (near and mid layers, per-channel falloff)
     and light wrap.
   - It writes a multiplier for the lit colour, plus the depth it was computed at.
3. **composite1 (quarter resolution), second output `colortex4`: a 4 × 4 depth-plane blur.** It resolves the
   gather's 4 × 4 tile of rotated patterns.
4. **composite2:** the adaptive eyes, unchanged. They measure the scene without the GI, so the GI cannot pump the
   exposure.
5. **final:** plane-aware upsample, then `colour *= 1 + M`. This happens before the bloom add, the fog, the tone map,
   the exposure and the grade, so distant GI fades with the fog and the bloom never sees it.
6. **Half resolution (CINEMATIC):** the gather is `composite3` and the blur `composite4`, both at 0.5 scale, between
   `composite2` and `final`.

### Each requested effect

1. **Indirect light (first bounce only).**
   - Each tap stands for its share of the disc's area on the surface it lands on, in blocks², divided by the cosine
     between that face and the view. A floor seen at a grazing angle covers more ground per pixel.
   - Its lit colour lights the receiver with the form factor
     `cos(receiver) × cos(sender) × area / (π (d² + GI_FALLOFF_DIST²))`. That is your 1 / (1 + (d/R)²) falloff with
     the area made explicit.
   - A smooth hard cap at `GI_RADIUS`.
   - The sender's face is exact on full blocks (the coordinate along it is an integer); elsewhere it counts as
     half-facing.
   - Consequences: two floors at one height exchange nothing, and a wall facing away sends nothing.
   - Sunlit receivers get a third (no washed-out sunny side, no second sun).
   - Sample radiance is soft-clamped (knee 1.2), so a white sunlit block never acts as a lamp.
   - The add is divided by the light the receiver already had. Final multiplies the lit colour, so the bounce
     multiplies the receiver's albedo: dark obsidian stays dark, and only light texels pick up colour.
2. **Colour bleeding.** The bounce keeps `COLOR_BLEEDING_STRENGTH` of its sender's colour, and `BOUNCE_SATURATION`
   caps all added light. Model result: a shaded white wall at the base of sunlit grass gets +6 % with a faint green
   (added RGB 5 : 7 : 6), fading to +1 % at 3 blocks.
3. **AO combined with the indirect light.**
   - Built from the same taps: occluders above the tangent plane within `AO_RADIUS`, with a gentle curve.
   - It halves the indirect light in corners. `AO_STRENGTH` takes it off the receiver's ambient share only (a
     quarter of it on sunlit pixels), never the direct sun.
   - Full block faces count 20 %: vanilla's corner AO already darkens block-meets-block, which would otherwise be
     darkened twice (measured −4.9 % before, −0.7 % after).
   - Mobs, plants, fences, slabs and stairs count fully (contact shadows vanilla doesn't make).
4. **Light wrapping.** `LIGHT_WRAP` widens the receiver's cosine for the indirect light, so it fades softly as a face
   turns away. The direct and ambient wrap already exists as `DIRECTIONAL_WRAP` (Update 2B) and was not duplicated.
5. **Emissive bounce and off-screen fallback.**
   - Visible emitters come from the glow buffer `colortex3` (the existing emissive mask: class-9 blocks, glowing
     mobs, the End crystal). Each tap reads the glow buffer's mip covering its share of the disc, so a torch is
     caught whatever the tap positions are: an area average, no hit-or-miss flicker.
   - No light through walls: Minecraft's own block light at the receiver must agree with a straight path from the
     emitter, otherwise the light is not added.
   - **Fallback when off-screen:** the block-light colour ramp (layer 4). It is per-vertex, recolours the light
     Minecraft already brings (so it adds no energy and nothing doubles), and always works. When an emitter leaves
     the frame only its extra bounce fades, over the last 3 % of the screen. Cost: a multiply-add per pixel.
6. **Micro-detail response (`GI_MICRODETAIL_RESPONSE`).**
   - Near a light (block level 9 to 13 and up), texels lighter than their texture's mean (the Update 2B detail mask:
     obsidian speckles, grains) catch up to `NEAR_DETAIL_RESPONSE` more light, in its colour.
   - The torch glints take the ramp's colour.
   - Because the GI multiplies the lit colour, the screen-space light also lands on the speckles.

### Addendum layers

| Layer | What | Cost | Cannot do |
|---|---|---|---|
| 1 Per-channel falloff | Near layer: 1 / (1 + (d/R)^(2k)) per channel, with k = 2 × `CHROMATIC_FALLOFF_R/G/B` (0.8 / 1.0 / 1.3, red lasts longest). Half strength in the Overworld. Manhattan distance by default (`FALLOFF_METRIC`). | 3 pow per emitter tap | True spectral light |
| 2 Two radii | Near: the light's own colour, `EMITTER_NEAR_RADIUS` 2.5. Mid: a warmer secondary light with a 1/d² tail, gone past 2 × `EMITTER_MID_RADIUS` 5 (0 = one layer). The class colour comes from the light's hue (crystal, fire, lava, lamps, soul, end rod, redstone), blended smoothly. | 2 extra accumulators; class mix once per pixel | Reach beyond the tap disc (about `GI_RADIUS` + footprint); the ramp carries farther |
| 3 Static ambient | Overworld caves cool blue-grey, Nether red-brown. In the End it is your `END_AMBIENT_BRIGHTNESS` light made static on blocks (not doubled). | A few multiply-adds | Directional ambient (see question 1) |
| 4 Light-level ramp | Near, mid and far colour by block level, per vertex. The End ramp also follows Vibrant Visuals' shorter reach (fitted on your table). The Nether keeps `NETHER_WARM_LIGHT` (already a ramp; not doubled). Overworld: 40 % (warm to slightly cool). | Per vertex, plus 1 lightmap read and ~10 operations per pixel | Telling which emitter class a level comes from (one ramp per dimension) |
| 5 Near detail | See point 6 above. | ~12 operations on mapped blocks | – |
| 6 Fog tint near lights | Off by default. Tints the fog's in-scatter by the hue of the GI light under it. | ~8 operations | Real volumetric light around emitters (`EMISSIVE_GLOW`'s halo stays that) |

### What this cannot do (honestly)

- **One bounce only.** No light around corners the camera cannot see, and no indirect shadows.
- **Screen space.** Light from emitters or lit surfaces off-screen, behind the camera or hidden behind objects does
  not bounce. The ramp is the only off-screen part.
- **Limited reach.** Near the camera the disc shrinks in blocks: it is capped at a quarter of the screen height.
- **Entities.** Mobs, items, particles and the hand receive `GI_ON_ENTITIES` of it. The hand receives none, because
  its depth is not in world units.
- **Translucents.** Water, glass and ice receive none. Their colour is a blend of two surfaces, and water is frozen.
- **Underwater:** `GI_UNDERWATER` 0.3, applied before the absorption fog.

### Your End pillar (test case 1), in the model

The pillar is seen from below. The crystal and fire are hidden behind its top edge, and the cage is coplanar with
the face, so the screen-space part adds nothing there. The colour ramp carries it.

| Depth | Vibrant Visuals | Update 4.2 (model) | Update 5, MEDIUM (model) |
|---|---|---|---|
| 0.5 | 304° | 321° | 327° |
| 2 | 302° | 311° | 318° |
| 3 | 308° | 305° | 307° |
| 4 | 316° | 298° | 290° |
| 6 | 324° | 291° | 281° |
| 8 | 238° | 288° | 282° |

- Update 5 is more saturated near the light (22 % against 12 %) and redder 1 to 3 blocks down.
- Mean hue error against Vibrant Visuals: about 20°, down from about 24°.
- The near light now ends at about 7.5 blocks.
- **What is still different:** the far field is about 2 × too bright relative to the near light, and violet, not
  blue. Your End ambient lights vertical faces as much as the ground; Vibrant Visuals' does not (the grey left face).
  That is question 1.

## 6. Files

All files in the zip are complete; there are no diffs.

- **New:**
  - `shaders/lib/fake_gi.glsl`
  - `shaders/composite3.vsh`, `shaders/composite3.fsh` (half-res gather)
  - `shaders/composite4.vsh`, `shaders/composite4.fsh` (half-res blur)
  - this report
- **Changed:** `block.properties`, `composite.fsh`, `composite1.fsh`, `final.fsh`, `gbuffers_terrain.fsh`,
  `lang/en_us.lang`, `lib/block_lighting.glsl` (one macro for the torch-glint colour), `lib/gbuffers.vsh`,
  `lib/gbuffers_forward.fsh`, `lib/settings.glsl`, `shaders.properties`, `README.md`.
- **Unchanged:** all other files.
- **Why each "other" file was unavoidable:**
  - `composite1`: the blur, to avoid a new quarter-resolution pass. It already runs on LOW and up.
  - `gbuffers.vsh`: the per-vertex ramp, which makes it nearly free.
  - `block_lighting.glsl`: the glint colour.
  - `lang`: labels.

### `block.properties`, under `#ifdef FAKE_GI` (so off = exactly as before)

- **Joined class 9:** copper torches and lanterns (with their oxidised and waxed forms), copper bulbs (`lit=true`),
  lit redstone torches, furnaces, smokers and blast furnaces, candles and candle cakes (`lit=true`), and
  `cave_vines_plant:berries=true`.
- **Moved to class 9, keeping their micro-detail material:** crying obsidian (`1660` → `1669`), and amethyst clusters
  and large buds (`1680` → `1689`).
- **Side effect while `FAKE_GI` is on:** these blocks also get class 9's glow and emissive lift, and no sun face
  shading, like every other light source.

### Settings

- **New screen:** Fake GI, with the sub-screens Chromatic Light and Emitter Colors.
- **All your names are kept:**
  - `FAKE_GI`, `FAKE_GI_STRENGTH`, `BOUNCE_LIGHT_STRENGTH`, `COLOR_BLEEDING_STRENGTH`, `EMISSIVE_BOUNCE_STRENGTH`
  - `GI_RADIUS`, `GI_SAMPLES`, `GI_RESOLUTION`, `GI_FALLOFF_DIST`, `GI_MAX_DISTANCE`, `EMISSIVE_RADIUS`
  - `BOUNCE_SATURATION`, `LIGHT_WRAP`, `AO_STRENGTH`, `AO_RADIUS`, `AO_BIAS`
  - `GI_ON_ENTITIES`, `GI_UNDERWATER`, `GI_MICRODETAIL_RESPONSE`
  - `CHROMATIC_LIGHT`, `CHROMATIC_FALLOFF_STRENGTH`, `CHROMATIC_FALLOFF_R/G/B`, `FALLOFF_METRIC`
  - `EMITTER_NEAR_RADIUS`, `EMITTER_MID_RADIUS`, `EMITTER_NEAR_COLOR_*` and `EMITTER_MID_COLOR_*` (per class)
  - `STATIC_AMBIENT_STRENGTH`, `AMBIENT_TINT`, `LIGHT_RAMP_STRENGTH`, `RAMP_NEAR_COLOR`, `RAMP_MID_COLOR`,
    `RAMP_FAR_COLOR`, `RAMP_SMOOTHNESS`, `NEAR_DETAIL_RESPONSE`, `FOG_TINT_NEAR_EMITTER`
- **Added:** `RAMP_OVERWORLD_AMOUNT`, `RAMP_END_AMOUNT`, `END_RAMP_NEAR/MID/FAR_COLOR` (the per-dimension ramp),
  `GI_DEBUG`, `GI_DEBUG_MODE`.
- Colours are choices written as `0xRRGGBB`, with names in the menu.
- **Removed or renamed options:** none.

### Presets

Every preset defines every option; disabled ones are written with `!`.

| | ULTRA_LOW | LOW | MEDIUM (default) | HIGH | CINEMATIC |
|---|---|---|---|---|---|
| `FAKE_GI` | off | off | on | on | on |
| `CHROMATIC_LIGHT` | off | on (ramp + static ambient) | on | on | on |
| `GI_RESOLUTION` / `GI_SAMPLES` | – | – | quarter / 8 | quarter / 12 | half / 16 |
| Emitter layers / micro-detail | – | – / off | 2 / on | 2 / on | 2 (mid 6) / on |
| Other | – | – | – | – | `GI_RADIUS` 4, `EMISSIVE_RADIUS` 5, distance 64 |

**Where this departs from your preset list, and why.** Your rule says to reduce and tell you when a budget cannot be
met.

- **ULTRA_LOW is fully off.** Even the ramp alone (~40 operations per terrain pixel) is estimated at 0.1 to 0.3 ms
  on integrated graphics, above your 0.05 ms.
- **LOW is ramp-only.** The gather's fixed costs (light code, blur, upsample) plus 4 to 6 taps are estimated at
  0.4 to 0.5 ms on a 1050 Ti, more than twice your 0.18 ms.
- **HIGH uses quarter resolution.** Half resolution at 12 taps is estimated at about 0.95 ms on an RTX 3050, against
  0.45 ms.
- **Changing them back:** if your measurement shows headroom, set `FAKE_GI` on in LOW (quarter, 4 to 6 taps) or
  `GI_RESOLUTION` 2 in HIGH from the menu.

## 7. CHANGELOG and performance

### CHANGELOG (Update 5)

- **Added:** fake GI.
  - Bounce light from lit surfaces, with colour bleeding.
  - AO on the ambient and indirect light only.
  - Light wrap.
  - Light from visible emitters, with no light through walls.
  - A 4 × 4 rotated tap pattern, resolved by a low-resolution depth-plane blur.
  - A plane-aware upsample in final, before the bloom, fog, tone map and exposure.
- **Added:** chromatic light.
  - Per-channel falloff and two emitter layers with per-class colours.
  - A per-vertex block-light colour ramp per dimension; the End's is fitted to your Vibrant Visuals pillar.
  - A static ambient where the sky does not reach.
  - The micro-detail response near lights.
  - An optional fog tint near lights.
- **Changed, only with `CHROMATIC_LIGHT` on:**
  - The End's ambient on blocks is static: no longer brightened next to light sources.
  - The End's block light is pink-warm near a source, red farther out, and gone about 7.5 blocks out.
  - Overworld block light: slightly warmer near a source, slightly cooler at the tail (40 %).
  - Torch glints take the block light's colour.
- **Changed, only with `FAKE_GI` on:** more blocks are light sources (section 6).
- **Unchanged with both off:** everything; checked program by program in all five presets.

### Performance (estimated at 1080p, not measured)

| Configuration | GTX 1050 Ti | RTX 3050 6 GB |
|---|---|---|
| Ramp only (LOW) | ~0.05–0.08 ms | ~0.02–0.03 ms |
| Quarter res, 4 taps | ~0.30–0.45 ms | ~0.13–0.19 ms |
| Quarter res, 6 taps | ~0.35–0.50 ms | ~0.15–0.22 ms |
| **Quarter res, 8 taps (MEDIUM)** | ~0.40–0.55 ms | **~0.18–0.25 ms** |
| **Quarter res, 12 taps (HIGH)** | ~0.50–0.70 ms | **~0.22–0.29 ms** |
| Quarter res, 16 taps | ~0.60–0.85 ms | ~0.27–0.35 ms |
| Half res, 8 taps | ~1.2–1.7 ms | ~0.55–0.75 ms |
| Half res, 12 taps | ~1.6–2.2 ms | ~0.7–0.95 ms |
| **Half res, 16 taps (CINEMATIC)** | ~2.0–2.8 ms | **~0.8–1.2 ms** |

**Where the time goes**, for MEDIUM on an RTX 3050:

| Part | Cost |
|---|---|
| Gather, 8 taps | ~0.12 ms |
| Blur | ~0.02 ms |
| Upsample + combine in final | ~0.03 ms |
| gbuffers (light code + ramp + near detail) | ~0.06 ms |

`GI_RADIUS` changes the cost little (the taps are the same), only the cache behaviour.

**How to measure:** stand still in the same spot and toggle `FAKE_GI` from the menu (or switch presets). Compare the
frame time in the F3 graph, or in a GPU profiler (Nsight Graphics / RenderDoc timing).

## 8. Pass order and buffer allocation

- **Order:** shadow → gbuffers → composite (+ the GI gather) → composite1 (+ the GI blur) → composite2 → [composite3
  and composite4 at half resolution] → final (+ the combine).
- **`colortex4` (new, the only new buffer):**
  - Format: `RGBA16F`. RGB = the multiplier (it can be negative: the AO); A = linear depth, −1 = none. 16-bit float
    keeps the dark end smooth; `RGBA8` would band.
  - Size: quarter resolution, 480 × 270 = 1.0 MB at 1080p. Half resolution, 960 × 540 = 4.1 MB.
  - Never cleared: every texel is written each frame.
  - Written by composite, read and written by composite1 (Iris ping-pongs it), read by final. At half resolution:
    composite3, then composite4, then final.
  - Nothing else touches it. Iris allocates it only while a program uses it (`FAKE_GI` on).
- **`colortex5` is shared by bloom, shallow-water shafts and particles. There is no conflict:**
  - **Channels:** composite's and composite1's `colortex5` outputs are computed exactly as before. The GI is a second,
    separate output, written after them, so the output order equals the locations (Vitrail).
  - **Clear flags:** none of them changed.
  - **Reads before writes:** none. composite1 reads `colortex4` after composite wrote it in the same frame. The
    programs that write it run whenever `FAKE_GI` is on at that resolution.
- **`colortex0` alpha:** terrain's light code.
  - Before this update, only final read that alpha, to pass it to the screen; it now writes 1.0 there.
  - Bloom, the adaptive eyes and the water SSR read RGB only.
  - Translucents blended over terrain spoil the code; the gather rejects those pixels by depth.
- **`colortex3` (the glow):** read only.
  - Quarter resolution uses composite's existing mip chain at no cost.
  - Half resolution asks for its own chain in composite3 (~0.03–0.06 ms), because Vitrail gives a chain only to the
    program that asks.

## 9. Test plan

### What I ran

| Test | Result |
|---|---|
| Compile | All 5 presets, plus 40 option combinations: all 20 debug views (also with `FAKE_GI` off), each switch off, half resolution, one emitter layer, Euclidean metric, without the glow, the micro-detail or the dimension ambiences, 4 and 16 taps, other debug systems. Every program compiles (glslang, GLSL 330). |
| Identity | `FAKE_GI` and `CHROMATIC_LIGHT` off: every program in all 5 presets preprocesses to Update 4.2's code. |
| Light code | All 30,720 values survive half precision exactly. No denormals, no infinities. Light quantisation error ≤ 1.8 % (rms 1 %). |
| Shaded white wall next to sunlit grass | +6 % at the base with a faint green, fading smoothly to +1 % at 3 blocks. No bands: the height profile is monotonic; side-to-side spread ±1.5–2 %, against ±4–5 % with a fixed pattern. |
| Lava pool in a cave | Back wall +8.9 % orange at the base. |
| Leak (lava behind a 1-block wall, seen from above) | The far side gets no lava light (removing the emitter light changes nothing); its +5 % is bounce off the wall's own lit face. |
| Upsample | 0.00–0.01 % of terrain pixels fall back (no texel on their plane). |
| Stability (strafe 0.05 block per frame) | Frame-to-frame change of the GI'd pixels: mean 0.39 %, 95th percentile 1.1 % (16 taps: 0.28 / 0.78 %). A fixed pattern would give 0.78 / 2.5 %. |
| Pop test (turning until a lava pool fills the frame) | The wall's GI stays between 7.3 and 10.3 %: no pop. |
| AO | At block corners it now costs −0.7 % (was −4.9 % before the block-face rule). |

### What you should run, and what to expect

1. **End pillar with cage and crystal** (your images). Set `GI_DEBUG` on with view 19 (hue): pink-purple near the
   cage, red 2 to 4 blocks down, gone by about 7. View 17 (colour ramp) shows the light colour itself.
2. **Cave with one torch:** a slight warm-to-cool tail.
3. **Cave with a lava pool:** a clear orange on walls 1 to 3 blocks away; no bloom-like halo (the halo is
   `EMISSIVE_GLOW`'s).
4. **Glowstone, and soul fire:** soul fire is cyan near, blue farther.
5. **White wall next to red wool and a green block:** faint red and green near the blocks.
6. **Sand next to a dark stone wall:** faint yellow at the wall's base.
7. **Forest floor:** green bounce under trees; soft contact AO around plants.
8. **Room with a window:** a soft sunlit patch, with a little light on the walls near it.
9. **Nether lava lake shore:** orange bounce; block light stays `NETHER_WARM_LIGHT`.
10. **Leak tests:** a thin wall with lava on one side, a fence, glass, leaves, trunks, screen borders.
    - View 13 (leak test): red pixels should be rare and only on silhouettes.
    - View 6: no light on the hidden side.
11. **Stability:** turn slowly and fast, strafe, change FOV, resize the window, and try 720p, 1080p, 1440p and 4K.
    - At most a very faint movement of the GI'd regions while moving; nothing while still.
    - The disc is in blocks, so it looks the same at every resolution.
12. **Off-screen pop:** turn toward a torch or lava. The warm tint (ramp) is there before it enters; the bounce
    fades in over the last 3 % of the screen.
13. **Rain, night, underwater (`GI_UNDERWATER` 0.3), high altitude, far from spawn.** The block-face test uses
    `cameraPositionFract`, so it stays exact far from the origin.
14. **Regression:** `FAKE_GI` and `CHROMATIC_LIGHT` off must give exactly 4.2 (ULTRA_LOW is that already). With them
    on, the sky, clouds, water, shadows, flash, glow and eyes must look as before, except for the light on blocks.

### Screenshots I would like (only with your permission; only the Minecraft window)

- **Conditions:** the same world, coordinates and camera, F1, the same FOV, render distance, GUI scale and
  resolution, each with `FAKE_GI` off and on.
- **List:**
  - the End pillar from image 9's viewpoint, with the cage;
  - a cave with a torch;
  - the lava cave;
  - the white wall next to red wool and a green block;
  - the Nether lava shore;
  - a forest at noon and at sunset;
  - `GI_DEBUG` views 6, 13 and 19 at the pillar.
- **Frame time at each spot.** Then I can replace the estimates with numbers and iterate (up to 5 rounds).

## 10. Questions

1. **Directional End ambient?** Your Vibrant Visuals pillar shows the End's ambient lighting faces unevenly: the left
   face is flat grey, the front is dark. Ours lights every face the same, so our pillars keep visible texture in the
   far field and the warm band ends early. Should I make the End's ambient on blocks directional (vertical faces
   dimmer, the ground unchanged)? It would change every vertical End face, and your Update 4 end stone match is on
   the ground only.
2. **LOW:** keep it ramp-only (inside your 0.18 ms), or turn the GI on there at 4 taps if your measurement allows?
3. **Screenshots and frame times** from the list above, if you agree to capture them.
4. **The Iris log** after loading the pack: to confirm the hex colour options and the program switches parse
   (`composite3` and `composite4` should not appear as active at quarter resolution).
